import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { OverviewDashboard } from './modules/dashboard/OverviewDashboard';
import { EmployeeList } from './modules/employees/EmployeeList';
import { PersonalFileManager } from './modules/personal-files/PersonalFileManager';
import { ContractManager } from './modules/contracts/ContractManager';
import { ContractExpiryAlertModal } from './modules/contracts/ContractExpiryAlertModal';
import { LeaveManager } from './modules/leave/LeaveManager';
import { TrainingManager } from './modules/training/TrainingManager';
import { AdminManager } from './modules/admin/AdminManager';
import { LeaveReviewDashboard } from './modules/leave/LeaveReviewDashboard';
import { GoogleAppsScriptHub } from './modules/gas-scripts/GoogleAppsScriptHub';
import { LoginPage } from './components/auth/LoginPage';

function MainApp() {
  const { isAuthenticated, currentUser } = useApp();
  const [activeModule, setActiveModule] = useState<string>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  const handleNavigate = (module: string) => {
    setActiveModule(module);
  };

  // If not authenticated, require login first before accessing files & dashboard
  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return (
    <div className="flex h-screen bg-slate-100 font-sans text-slate-900 antialiased overflow-hidden print:h-auto print:overflow-visible print:bg-white">
      {/* Sidebar Navigation (Desktop & Mobile Drawer) */}
      <Sidebar
        activeModule={activeModule}
        onSelectModule={setActiveModule}
        isOpenMobile={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative print:overflow-visible print:static print:w-full">
        <Header
          onToggleMobile={() => setMobileMenuOpen(!mobileMenuOpen)}
          onNavigate={handleNavigate}
        />

        <main className="flex-1 overflow-y-auto p-3.5 sm:p-6 lg:p-8 pb-24 lg:pb-8 print:p-0 print:overflow-visible print:static print:w-full print:m-0">
          <div className="max-w-7xl mx-auto print:max-w-none print:w-full print:m-0">
            {activeModule === 'dashboard' && (
              <OverviewDashboard onNavigate={handleNavigate} />
            )}
            {activeModule === 'employees' && (
              <EmployeeList onNavigateToDrive={() => handleNavigate('personal-files')} />
            )}
            {activeModule === 'personal-files' && (
              <PersonalFileManager />
            )}
            {activeModule === 'contracts' && (
              <ContractManager />
            )}
            {activeModule === 'leave' && (
              <LeaveManager onNavigateToReview={() => handleNavigate('leave-review')} />
            )}
            {activeModule === 'leave-review' && (
              <LeaveReviewDashboard />
            )}

            {activeModule === 'training' && (
              <TrainingManager />
            )}
            {activeModule === 'gas-scripts' && (
              (currentUser.role === 'ADMIN' || currentUser.role === 'GM') ? (
                <GoogleAppsScriptHub />
              ) : (
                <OverviewDashboard onNavigate={handleNavigate} />
              )
            )}
            {activeModule === 'admin' && (
              (currentUser.role === 'ADMIN' || currentUser.role === 'GM') ? (
                <AdminManager />
              ) : (
                <OverviewDashboard onNavigate={handleNavigate} />
              )
            )}
          </div>
        </main>

        {/* Mobile Bottom Navigation Bar */}
        <div className="print:hidden">
          <MobileBottomNav
            activeModule={activeModule}
            onSelectModule={handleNavigate}
          />
        </div>

        {/* Automated Pop-up Expiry Alert (1 Month & 2 Months for Dept Head, HC, and GM) */}
        <div className="print:hidden">
          <ContractExpiryAlertModal
            onNavigateToContracts={() => handleNavigate('contracts')}
          />
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
