import { 
  Employee, 
  EmployeeDocument, 
  EmploymentContract, 
  LeaveApplication, 
  LeaveLedgerEntry, 
  PublicHoliday, 
  TrainingPlan, 
  TrainingSession,
  TrainingParticipantRecord,
  AuditLog, 
  NotificationItem,
  UserAccount,
  TrainingAttendance,
  AnnualTrainingKpiTarget
} from '../types';

/**
 * GMCC Human Capital Management System - Production Zero-Data Base
 * Seluruh nama dummy dihapus. Sistem dimulai murni dari nol data.
 */

export const INITIAL_EMPLOYEES: Employee[] = [];

export const INITIAL_DOCUMENTS: EmployeeDocument[] = [];

export const INITIAL_CONTRACTS: EmploymentContract[] = [];

export const INITIAL_LEAVE_APPLICATIONS: LeaveApplication[] = [];

export const INITIAL_LEAVE_LEDGER: LeaveLedgerEntry[] = [];

export const INITIAL_HOLIDAYS: PublicHoliday[] = [
  { id: 'HOL-01', date: '2026-01-01', name: 'New Year Day 2026', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-02', date: '2026-01-16', name: "Isra Mi'raj", type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-03', date: '2026-02-17', name: 'Chinese New Year 2577', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-04', date: '2026-03-20', name: 'Nyepi Saka 1948', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-05', date: '2026-03-21', name: 'Eid al-Fitr 1447 H (Day 1)', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-06', date: '2026-03-22', name: 'Eid al-Fitr 1447 H (Day 2)', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-07', date: '2026-04-03', name: 'Good Friday', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-08', date: '2026-05-01', name: 'Labor Day', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-09', date: '2026-05-14', name: 'Ascension Day of Jesus Christ', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-10', date: '2026-05-31', name: 'Waisak 2570', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-11', date: '2026-06-01', name: 'Pancasila Day', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-12', date: '2026-06-17', name: 'Eid al-Adha 1447 H', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-13', date: '2026-07-07', name: 'Islamic New Year 1448 H', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-14', date: '2026-08-17', name: 'Independence Day of Republic of Indonesia', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-15', date: '2026-09-15', name: 'Maulid Nabi Muhammad SAW', type: 'NATIONAL', isOfficial: true },
  { id: 'HOL-16', date: '2026-12-25', name: 'Christmas Day', type: 'NATIONAL', isOfficial: true }
];

export const INITIAL_TRAINING_PLANS: TrainingPlan[] = [];

export const INITIAL_TRAINING_SESSIONS: TrainingSession[] = [];

export const INITIAL_TRAINING_ATTENDANCE: TrainingAttendance[] = [];

export const INITIAL_TRAINING_PARTICIPANTS: TrainingParticipantRecord[] = [];

export const INITIAL_GM_KPI_TARGET: AnnualTrainingKpiTarget = {
  id: 'KPI-GM-2026',
  year: 2026,
  annualTargetHoursPerStaff: 20,
  gmEmployeeId: '',
  gmName: 'General Manager GMCC',
  sanctionDate: '2026-01-05T09:00:00Z',
  status: 'ACTIVE',
  strategicObjectives: 'Target pelatihan tahunan seluruh karyawan GMCC minimal 20 jam pelatihan per staf per tahun.',
  notes: 'Disahkan secara resmi oleh General Manager GMCC sebagai indikator kinerja utama (KPI) tahunan.',
  departmentTargets: [
    { departmentId: 'DEP-FBS', departmentName: 'Food & Beverage Service', targetHoursPerStaff: 20 },
    { departmentId: 'DEP-FBP', departmentName: 'Food & Beverage Product', targetHoursPerStaff: 20 },
    { departmentId: 'DEP-HK', departmentName: 'Housekeeping', targetHoursPerStaff: 20 },
    { departmentId: 'DEP-ENG', departmentName: 'Engineering & Facilities', targetHoursPerStaff: 20 },
    { departmentId: 'DEP-SEC', departmentName: 'Security & Safety', targetHoursPerStaff: 20 },
    { departmentId: 'DEP-SALES', departmentName: 'Sales & Marketing', targetHoursPerStaff: 20 },
    { departmentId: 'DEP-FIN', departmentName: 'Finance & Accounting', targetHoursPerStaff: 20 },
    { departmentId: 'DEP-HC', departmentName: 'Human Capital', targetHoursPerStaff: 20 }
  ],
  updatedAt: '2026-01-05T09:00:00Z'
};

export const INITIAL_AUDIT_LOGS: AuditLog[] = [];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [];

export const INITIAL_USER_ACCOUNTS: UserAccount[] = [
  {
    id: 'USR-ADMIN',
    userId: 'admin',
    username: 'admin',
    password: 'GolomoriCC26',
    name: 'System Administrator',
    email: 'admin@golomoricc.com',
    role: 'ADMIN',
    status: 'ACTIVE',
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z'
  }
];

export const CURRENT_SYSTEM_DATE = '2026-10-18';

