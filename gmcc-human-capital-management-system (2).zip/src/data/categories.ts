import { PersonalFileCategory, PersonalFileCategoryMeta } from '../types';

export const PERSONAL_FILE_CATEGORIES: PersonalFileCategoryMeta[] = [
  {
    code: '01_IDENTITY',
    folderNumber: '01',
    name: '01 Identity & Personal',
    description: 'KTP, Passport, Family Card (KK), NPWP, emergency contacts, identity records',
    isRestricted: false,
    allowedRoles: ['STAFF', 'DEPT_HEAD', 'HC', 'GM', 'ADMIN', 'AUDITOR']
  },
  {
    code: '02_RECRUITMENT',
    folderNumber: '02',
    name: '02 Recruitment & Onboarding',
    description: 'CV/Resume, application forms, interview records, assessment results, reference checks, offer letter',
    isRestricted: false,
    allowedRoles: ['HC', 'GM', 'ADMIN', 'AUDITOR']
  },
  {
    code: '03_EMPLOYMENT',
    folderNumber: '03',
    name: '03 Employment & Contracts',
    description: 'PKWT employment agreements, SPK Daily Worker, appointment letters, promotion, position changes, amendments',
    isRestricted: false,
    allowedRoles: ['STAFF', 'DEPT_HEAD', 'HC', 'GM', 'ADMIN', 'AUDITOR']
  },
  {
    code: '04_TRAINING',
    folderNumber: '04',
    name: '04 Training & Development',
    description: 'Attendance sheets, training certificates, pre/post evaluation records, qualifications, IDP',
    isRestricted: false,
    allowedRoles: ['STAFF', 'DEPT_HEAD', 'HC', 'GM', 'ADMIN', 'AUDITOR']
  },
  {
    code: '05_PERFORMANCE',
    folderNumber: '05',
    name: '05 Performance Appraisals',
    description: 'Annual appraisals, KPI review sheets, Performance Improvement Plans (PIP), commendations',
    isRestricted: false,
    allowedRoles: ['STAFF', 'DEPT_HEAD', 'HC', 'GM', 'ADMIN', 'AUDITOR']
  },
  {
    code: '06_ATTENDANCE_LEAVE',
    folderNumber: '06',
    name: '06 Attendance & Leave',
    description: 'Approved leave records, GM signed leave slips, authorized medical notes, compensatory authorizations',
    isRestricted: false,
    allowedRoles: ['STAFF', 'DEPT_HEAD', 'HC', 'GM', 'ADMIN', 'AUDITOR']
  },
  {
    code: '07_DISCIPLINE',
    folderNumber: '07',
    name: '07 Discipline & Relations',
    description: 'Warning letters (SP1, SP2, SP3), formal investigation files, grievance notes, counseling memos',
    isRestricted: true,
    allowedRoles: ['HC', 'GM', 'ADMIN', 'DEPT_HEAD'] // GM & Admin (Full Access), Dept Head (Lihat Saja / View Only - Tidak dapat edit & tambah)
  },
  {
    code: '08_COMPENSATION_BENEFITS',
    folderNumber: '08',
    name: '08 Compensation & Benefits',
    description: 'Salary review letters, allowance agreements, BPJS Ketenagakerjaan & Kesehatan, private insurance',
    isRestricted: true,
    allowedRoles: ['HC', 'GM', 'ADMIN', 'DEPT_HEAD'] // GM & Admin (Full Access), Dept Head (Lihat Saja / View Only - Tidak dapat edit & tambah)
  },
  {
    code: '09_HEALTH_WORK_REQUIREMENTS',
    folderNumber: '09',
    name: '09 Health & Work Safety',
    description: 'Occupational fitness certificates, medical fitness checks, food handler hygiene clearances',
    isRestricted: true,
    allowedRoles: ['HC', 'GM', 'ADMIN', 'DEPT_HEAD'] // GM & Admin (Full Access), Dept Head (Lihat Saja / View Only - Tidak dapat edit & tambah)
  },
  {
    code: '10_EXIT',
    folderNumber: '10',
    name: '10 Exit & Termination',
    description: 'Resignation letters, exit clearance checklists, handover acknowledgements, termination docs',
    isRestricted: false,
    allowedRoles: ['HC', 'GM', 'ADMIN', 'AUDITOR']
  }
];

export const GMCC_DEPARTMENTS = [
  { id: 'DEP-FBS', name: 'Food & Beverage Service', code: 'FBS', headEmployeeId: '', headName: '-', totalStaff: 0 },
  { id: 'DEP-FBP', name: 'Food & Beverage Product', code: 'FBP', headEmployeeId: '', headName: '-', totalStaff: 0 },
  { id: 'DEP-HK', name: 'Housekeeping', code: 'HK', headEmployeeId: '', headName: '-', totalStaff: 0 },
  { id: 'DEP-ENG', name: 'Engineering & Facilities', code: 'ENG', headEmployeeId: '', headName: '-', totalStaff: 0 },
  { id: 'DEP-SALES', name: 'Sales & Marketing', code: 'SALES', headEmployeeId: '', headName: '-', totalStaff: 0 },
  { id: 'DEP-FIN', name: 'Finance & Accounting', code: 'FIN', headEmployeeId: '', headName: '-', totalStaff: 0 },
  { id: 'DEP-HC', name: 'Human Capital', code: 'HC', headEmployeeId: '', headName: '-', totalStaff: 0 },
  { id: 'DEP-SEC', name: 'Security & Safety', code: 'SEC', headEmployeeId: '', headName: '-', totalStaff: 0 },
  { id: 'DEP-EXEC', name: 'Executive Office', code: 'EXEC', headEmployeeId: '', headName: '-', totalStaff: 0 }
];
