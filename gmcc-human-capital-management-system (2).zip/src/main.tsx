import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register service worker with instant skipWaiting & auto-update
const updateSW = registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log('Versi baru terdeteksi, memuat versi terbaru...');
    updateSW(true);
  },
  onOfflineReady() {
    console.log('App ready to work offline.');
  },
});

// Helper for users to force-clear stale caches on mobile
(window as any).forceClearCacheAndReload = async () => {
  try {
    if ('serviceWorker' in navigator) {
      const registrations = await navigator.serviceWorker.getRegistrations();
      for (const reg of registrations) {
        await reg.unregister();
      }
    }
    if ('caches' in window) {
      const keys = await caches.keys();
      for (const key of keys) {
        await caches.delete(key);
      }
    }
  } catch (e) {}
  window.location.reload();
};

createRoot(document.getElementById('root')!).render(<App />);

