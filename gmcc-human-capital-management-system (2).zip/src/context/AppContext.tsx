import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Employee, 
  EmployeeDocument, 
  EmploymentContract, 
  LeaveApplication, 
  LeaveLedgerEntry, 
  LeaveBalanceSummary,
  LeaveType,
  LeaveStatus,
  PublicHoliday, 
  TrainingPlan, 
  TrainingSession,
  TrainingParticipantRecord,
  AuditLog, 
  NotificationItem,
  UserRole,
  PersonalFileCategory,
  Department,
  EmployeeLeaveReviewReport,
  UserAccount,
  ContractTerminationDetails,
  TerminationReason,
  TrainingAttendance,
  AnnualTrainingKpiTarget,
  TrainingScope
} from '../types';
import { 
  INITIAL_EMPLOYEES, 
  INITIAL_DOCUMENTS, 
  INITIAL_CONTRACTS, 
  INITIAL_LEAVE_APPLICATIONS, 
  INITIAL_LEAVE_LEDGER, 
  INITIAL_HOLIDAYS, 
  INITIAL_TRAINING_PLANS, 
  INITIAL_TRAINING_SESSIONS,
  INITIAL_TRAINING_PARTICIPANTS,
  INITIAL_TRAINING_ATTENDANCE,
  INITIAL_GM_KPI_TARGET,
  INITIAL_AUDIT_LOGS, 
  INITIAL_NOTIFICATIONS,
  INITIAL_USER_ACCOUNTS,
  CURRENT_SYSTEM_DATE 
} from '../data/seedData';
import { PERSONAL_FILE_CATEGORIES, GMCC_DEPARTMENTS } from '../data/categories';
import { db, collection, onSnapshot, getDocs, getDocsFromServer, handleFirestoreError, OperationType } from '../lib/firebase';
import { saveToFirestore, deleteFromFirestore } from '../lib/firestoreSync';
import firebaseConfig from '../../firebase-applet-config.json';

export interface CurrentUser {
  id: string;
  name: string;
  role: UserRole;
  employeeId?: string;
  departmentId?: string;
  email: string;
}

export const DEMO_USERS: CurrentUser[] = [
  {
    id: 'USR-ADMIN',
    name: 'System Administrator',
    role: 'ADMIN',
    email: 'admin@golomoricc.com'
  }
];

interface AppContextType {
  currentUser: CurrentUser;
  setCurrentUser: (user: CurrentUser) => void;
  systemDate: string;
  employees: Employee[];
  documents: EmployeeDocument[];
  contracts: EmploymentContract[];
  leaveApplications: LeaveApplication[];
  leaveLedger: LeaveLedgerEntry[];
  holidays: PublicHoliday[];
  trainingPlans: TrainingPlan[];
  trainingSessions: TrainingSession[];
  trainingParticipants: TrainingParticipantRecord[];
  trainingAttendance: TrainingAttendance[];
  annualKpiTarget: AnnualTrainingKpiTarget;
  auditLogs: AuditLog[];
  notifications: NotificationItem[];
  
  // Balance calculation
  getLeaveBalanceSummary: (employeeId: string, leaveType: LeaveType) => LeaveBalanceSummary;
  
  // Actions
  addEmployee: (emp: Omit<Employee, 'id' | 'driveFolderId' | 'createdAt' | 'updatedAt'>) => Employee;
  updateEmployee: (emp: Employee) => void;
  deleteEmployee: (employeeId: string) => void;
  
  // Personal Files & Drive
  uploadDocument: (doc: Omit<EmployeeDocument, 'id' | 'uploadedAt' | 'driveFileId' | 'drivePath'>) => EmployeeDocument;
  deleteDocument: (documentId: string) => void;
  canAccessCategory: (category: PersonalFileCategory, targetEmployeeId: string) => boolean;
  canModifyCategory: (category: PersonalFileCategory, targetEmployeeId?: string) => boolean;
  
  // Contracts
  addContract: (contract: Omit<EmploymentContract, 'id' | 'version' | 'createdAt' | 'updatedAt'> & { version?: number }) => EmploymentContract;
  updateContract: (contract: EmploymentContract) => void;
  deleteContract: (contractId: string) => void;
  renewContract: (
    oldContractId: string, 
    newStartDate: string, 
    newEndDate: string, 
    notes: string, 
    newContractNumber?: string, 
    newTermNumber?: number,
    compensationData?: {
      compensationStatus?: 'DITERIMA' | 'BELUM';
      compensationAmount?: number;
      compensationPaidDate?: string;
      compensationNotes?: string;
    }
  ) => EmploymentContract | undefined;
  terminateContract: (contractId: string, details: ContractTerminationDetails) => void;
  attachSignedContract: (contractId: string, fileData: { fileName: string; fileUrl?: string; notes?: string }) => void;
  getDaysUntilExpiry: (endDate: string) => number | null;

  // User Accounts & Login Credentials
  userAccounts: UserAccount[];
  addUserAccount: (user: Omit<UserAccount, 'id' | 'createdAt' | 'updatedAt'>) => UserAccount;
  updateUserAccount: (user: UserAccount) => void;
  deleteUserAccount: (userId: string) => void;
  resetUserPassword: (userId: string, newPass: string) => void;
  changeAdminPassword: (newPass: string) => { success: boolean; message: string };
  getUserAccountByEmployeeId: (empId: string) => UserAccount | undefined;
  loginWithCredentials: (userIdOrEmail: string, password: string) => { success: boolean; message?: string };
  logout: (reason?: string) => void;
  logoutReason: string | null;
  clearLogoutReason: () => void;
  
  // Leave Ledger & Entitlements Management
  addLedgerEntry: (entry: Omit<LeaveLedgerEntry, 'id' | 'createdAt'>) => LeaveLedgerEntry;
  updateLedgerEntry: (entry: LeaveLedgerEntry) => void;
  deleteLedgerEntry: (entryId: string) => void;
  getAnnualLeaveReviewData: (year: number, deptId?: string) => EmployeeLeaveReviewReport[];

  // Holidays
  addHoliday: (holiday: Omit<PublicHoliday, 'id'>) => PublicHoliday;
  updateHoliday: (holiday: PublicHoliday) => void;
  deleteHoliday: (holidayId: string) => void;

  // Departments
  departments: Department[];
  updateDepartment: (dept: Department) => void;

  // Leave Workflow
  submitLeaveApplication: (app: {
    employeeId: string;
    leaveType: LeaveType;
    startDate: string;
    endDate: string;
    totalDays: number;
    reason: string;
    contactDuringLeave?: string;
    handoverToEmployeeId?: string;
  }) => { success: boolean; message: string };
  
  processLeaveApproval: (applicationId: string, action: 'APPROVE' | 'REJECT' | 'RETURN', comment: string) => { success: boolean; message: string };
  cancelLeaveApplication: (applicationId: string, reason: string) => { success: boolean; message: string };
  
  // Training
  submitTrainingPlan: (plan: Omit<TrainingPlan, 'id' | 'status' | 'submittedBy' | 'submittedByName' | 'submittedAt' | 'createdAt' | 'updatedAt'>) => void;
  updateTrainingPlanStatus: (planId: string, status: TrainingPlan['status'], notes?: string) => void;
  addTrainingSession: (session: Omit<TrainingSession, 'id'>) => TrainingSession;
  recordTrainingAttendance: (data: {
    sessionId: string;
    sessionTitle: string;
    trainingScope: TrainingScope;
    photoProofUrl: string;
    notes?: string;
    location?: string;
    trainingHours?: number;
    employeeId?: string;
  }) => { success: boolean; message: string; attendance?: TrainingAttendance };
  verifyTrainingAttendance: (attendanceId: string, status: 'VERIFIED' | 'REJECTED', notes?: string) => void;
  updateAnnualKpiTarget: (target: Partial<AnnualTrainingKpiTarget>) => { success: boolean; message: string };
  
  // Auth state & session
  isAuthenticated: boolean;

  // Google Apps Script Cloud Sync
  gasWebAppUrl: string;
  setGasWebAppUrl: (url: string) => void;
  isSyncing: boolean;
  lastSyncTime: string | null;
  syncStatus: { success: boolean; message: string; details?: string } | null;
  syncToGoogleAppsScript: (urlOverride?: string) => Promise<{ success: boolean; message: string; details?: string }>;

  // Online Realtime Database (Firebase Firestore)
  firebaseSyncStatus: {
    connected: boolean;
    isSyncing: boolean;
    lastSyncedAt: string | null;
    projectId: string;
    databaseId: string;
    mode: 'CLOUD_FIRESTORE' | 'LOCAL_OFFLINE';
  };
  syncAllToFirebase: () => Promise<void>;
  forceServerSync: () => Promise<{ success: boolean; message: string }>;

  // Notifications & Audit
  markNotificationAsRead: (id: string) => void;
  resetDemoData: () => void;
  exportBackupData: () => void;
  importBackupData: (jsonData: string) => { success: boolean; message: string };
}

// Tombstone tracking: Records that were explicitly deleted by GM or Admin
// This ensures that user-created staff permanently persist across refreshes,
// and are never wiped or lost due to empty initial snapshots or network delays.
export const getDeletedIds = (key: string): Set<string> => {
  if (typeof window === 'undefined') return new Set();
  try {
    const raw = localStorage.getItem(key);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
};

export const recordDeletedId = (key: string, id: string) => {
  if (typeof window === 'undefined') return;
  try {
    const current = getDeletedIds(key);
    current.add(id);
    localStorage.setItem(key, JSON.stringify(Array.from(current)));
  } catch {}
};

export const removeDeletedId = (key: string, id: string) => {
  if (typeof window === 'undefined') return;
  try {
    const current = getDeletedIds(key);
    current.delete(id);
    localStorage.setItem(key, JSON.stringify(Array.from(current)));
  } catch {}
};

if (typeof window !== 'undefined') {
  try {
    // Purge legacy persistent logins so browser close always requires re-login
    localStorage.removeItem('gmcc_authenticated');
    localStorage.removeItem('gmcc_current_user');
  } catch (e) {}
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Session is strictly bound to sessionStorage: closing the browser/tab clears the session
  const [currentUser, setCurrentUser] = useState<CurrentUser>(() => {
    const saved = sessionStorage.getItem('gmcc_current_user');
    return saved ? JSON.parse(saved) : DEMO_USERS[0];
  });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('gmcc_authenticated') === 'true';
  });
  const [logoutReason, setLogoutReason] = useState<string | null>(() => {
    return sessionStorage.getItem('gmcc_logout_reason');
  });
  const systemDate = CURRENT_SYSTEM_DATE;

  const [gasWebAppUrl, setGasWebAppUrlState] = useState<string>(() => {
    return localStorage.getItem('gmcc_gas_web_app_url') || '';
  });
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() => {
    return localStorage.getItem('gmcc_last_sync_time') || null;
  });
  const [syncStatus, setSyncStatus] = useState<{ success: boolean; message: string; details?: string } | null>(null);

  const setGasWebAppUrl = (url: string) => {
    setGasWebAppUrlState(url);
    localStorage.setItem('gmcc_gas_web_app_url', url);
  };

  const [firebaseSyncStatus, setFirebaseSyncStatus] = useState<{
    connected: boolean;
    isSyncing: boolean;
    lastSyncedAt: string | null;
    projectId: string;
    databaseId: string;
    mode: 'CLOUD_FIRESTORE' | 'LOCAL_OFFLINE';
  }>({
    connected: true,
    isSyncing: false,
    lastSyncedAt: null,
    projectId: firebaseConfig.projectId,
    databaseId: firebaseConfig.firestoreDatabaseId,
    mode: 'CLOUD_FIRESTORE'
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem('gmcc_employees');
    return saved ? JSON.parse(saved) : [];
  });

  const [documents, setDocuments] = useState<EmployeeDocument[]>(() => {
    const saved = localStorage.getItem('gmcc_documents');
    return saved ? JSON.parse(saved) : [];
  });

  const [contracts, setContracts] = useState<EmploymentContract[]>(() => {
    const saved = localStorage.getItem('gmcc_contracts');
    return saved ? JSON.parse(saved) : [];
  });

  const [leaveApplications, setLeaveApplications] = useState<LeaveApplication[]>(() => {
    const saved = localStorage.getItem('gmcc_leave_applications');
    return saved ? JSON.parse(saved) : [];
  });

  const [leaveLedger, setLeaveLedger] = useState<LeaveLedgerEntry[]>(() => {
    const saved = localStorage.getItem('gmcc_leave_ledger');
    return saved ? JSON.parse(saved) : [];
  });

  const [holidays, setHolidays] = useState<PublicHoliday[]>(() => {
    const saved = localStorage.getItem('gmcc_holidays');
    return saved ? JSON.parse(saved) : INITIAL_HOLIDAYS;
  });

  const [trainingPlans, setTrainingPlans] = useState<TrainingPlan[]>(() => {
    const saved = localStorage.getItem('gmcc_training_plans');
    return saved ? JSON.parse(saved) : INITIAL_TRAINING_PLANS;
  });

  const [trainingSessions, setTrainingSessions] = useState<TrainingSession[]>(() => {
    const saved = localStorage.getItem('gmcc_training_sessions');
    return saved ? JSON.parse(saved) : INITIAL_TRAINING_SESSIONS;
  });

  const [trainingParticipants, setTrainingParticipants] = useState<TrainingParticipantRecord[]>(() => {
    const saved = localStorage.getItem('gmcc_training_participants');
    return saved ? JSON.parse(saved) : INITIAL_TRAINING_PARTICIPANTS;
  });

  const [trainingAttendance, setTrainingAttendance] = useState<TrainingAttendance[]>(() => {
    const saved = localStorage.getItem('gmcc_training_attendance');
    return saved ? JSON.parse(saved) : INITIAL_TRAINING_ATTENDANCE;
  });

  const [annualKpiTarget, setAnnualKpiTarget] = useState<AnnualTrainingKpiTarget>(() => {
    const saved = localStorage.getItem('gmcc_annual_kpi_target');
    return saved ? JSON.parse(saved) : INITIAL_GM_KPI_TARGET;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem('gmcc_audit_logs');
    const logs: AuditLog[] = saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
    const seen = new Set<string>();
    return logs.map((log, idx) => {
      let uniqueId = log.id;
      if (!uniqueId || seen.has(uniqueId)) {
        uniqueId = `AUD-${Date.now().toString(36)}-${idx}-${Math.random().toString(36).substring(2, 6)}`;
      }
      seen.add(uniqueId);
      return { ...log, id: uniqueId };
    });
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('gmcc_notifications');
    return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
  });

  const [departments, setDepartments] = useState<Department[]>(() => {
    const saved = localStorage.getItem('gmcc_departments');
    if (saved) {
      try {
        const parsed: Department[] = JSON.parse(saved);
        const hasFBS = parsed.some(d => d.id === 'DEP-FBS');
        const hasFBP = parsed.some(d => d.id === 'DEP-FBP');
        const hasHK = parsed.some(d => d.id === 'DEP-HK');
        if (hasFBS && hasFBP && hasHK) return parsed;
      } catch (e) {}
    }
    return GMCC_DEPARTMENTS;
  });

  const [userAccounts, setUserAccounts] = useState<UserAccount[]>(() => {
    const saved = localStorage.getItem('gmcc_user_accounts');
    let list: UserAccount[] = saved ? JSON.parse(saved) : INITIAL_USER_ACCOUNTS;
    list = list.map(u => (u.userId === 'admin' || u.id === 'USR-ADMIN') ? { ...u, password: u.password || 'GolomoriCC26' } : u);
    return list;
  });

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('gmcc_user_accounts', JSON.stringify(userAccounts));
  }, [userAccounts]);
  useEffect(() => {
    localStorage.setItem('gmcc_employees', JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem('gmcc_departments', JSON.stringify(departments));
  }, [departments]);


  useEffect(() => {
    localStorage.setItem('gmcc_documents', JSON.stringify(documents));
  }, [documents]);

  useEffect(() => {
    localStorage.setItem('gmcc_contracts', JSON.stringify(contracts));
  }, [contracts]);

  useEffect(() => {
    localStorage.setItem('gmcc_leave_applications', JSON.stringify(leaveApplications));
  }, [leaveApplications]);

  useEffect(() => {
    localStorage.setItem('gmcc_leave_ledger', JSON.stringify(leaveLedger));
  }, [leaveLedger]);

  useEffect(() => {
    localStorage.setItem('gmcc_training_plans', JSON.stringify(trainingPlans));
  }, [trainingPlans]);

  useEffect(() => {
    localStorage.setItem('gmcc_training_sessions', JSON.stringify(trainingSessions));
  }, [trainingSessions]);

  useEffect(() => {
    localStorage.setItem('gmcc_training_attendance', JSON.stringify(trainingAttendance));
  }, [trainingAttendance]);

  useEffect(() => {
    localStorage.setItem('gmcc_annual_kpi_target', JSON.stringify(annualKpiTarget));
  }, [annualKpiTarget]);

  useEffect(() => {
    localStorage.setItem('gmcc_audit_logs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  useEffect(() => {
    localStorage.setItem('gmcc_notifications', JSON.stringify(notifications));
  }, [notifications]);

  // Automated Inactivity Logout (30 Menit / 1,800,000 ms)
  // When user is idle for 30 minutes, or closes the tab/browser, session is cleared
  useEffect(() => {
    if (!isAuthenticated) return;

    const INACTIVITY_TIMEOUT_MS = 30 * 60 * 1000; // 30 minutes in milliseconds

    if (!sessionStorage.getItem('gmcc_last_active_time')) {
      sessionStorage.setItem('gmcc_last_active_time', String(Date.now()));
    }

    let throttleTimer: any = null;
    const recordUserActivity = () => {
      if (!throttleTimer) {
        throttleTimer = setTimeout(() => {
          sessionStorage.setItem('gmcc_last_active_time', String(Date.now()));
          throttleTimer = null;
        }, 3000);
      }
    };

    const checkInactivity = () => {
      const stored = sessionStorage.getItem('gmcc_last_active_time');
      const lastActive = stored ? Number(stored) : Date.now();
      if (Date.now() - lastActive > INACTIVITY_TIMEOUT_MS) {
        logout('INACTIVITY_30MIN');
      }
    };

    const activityEvents = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart', 'click'];
    activityEvents.forEach(evt => window.addEventListener(evt, recordUserActivity, { passive: true }));

    // Check periodically every 10 seconds
    const intervalTimer = setInterval(checkInactivity, 10000);

    // Instant check when switching back to this tab
    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        checkInactivity();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);
    window.addEventListener('focus', handleVisibilityOrFocus);

    return () => {
      if (throttleTimer) clearTimeout(throttleTimer);
      activityEvents.forEach(evt => window.removeEventListener(evt, recordUserActivity));
      clearInterval(intervalTimer);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
      window.removeEventListener('focus', handleVisibilityOrFocus);
    };
  }, [isAuthenticated]);

  // Realtime Cloud Firestore Synchronization across Devices
  useEffect(() => {
    if (!db) return;

    setFirebaseSyncStatus(prev => ({ ...prev, isSyncing: true }));

    // Auto-seed initial datasets to Firestore if empty so all browsers get standard system accounts/settings
    // NOTE: Employees, contracts, and leave transactions are NEVER seeded to guarantee a pure 0-employee production state.
    const seedIfEmpty = async () => {
      try {
        const userSnap = await getDocs(collection(db, 'userAccounts'));
        if (userSnap.empty) {
          for (const u of INITIAL_USER_ACCOUNTS) await saveToFirestore('userAccounts', u);
        }
        const holSnap = await getDocs(collection(db, 'holidays'));
        if (holSnap.empty) {
          for (const h of INITIAL_HOLIDAYS) await saveToFirestore('holidays', h);
        }
        const deptSnap = await getDocs(collection(db, 'departments'));
        if (deptSnap.empty) {
          for (const d of GMCC_DEPARTMENTS) await saveToFirestore('departments', d);
        }
      } catch (e) {
        console.warn('Initial cloud seed notice:', e);
      }
    };
    seedIfEmpty().catch(() => {});

    const unsubEmployees = onSnapshot(collection(db, 'employees'), (snap) => {
      const remoteList: Employee[] = snap.docs.map(d => d.data() as Employee);
      // Cloud Firestore server is authoritative: immediately update state and local cache
      setEmployees(remoteList);
      try { localStorage.setItem('gmcc_employees', JSON.stringify(remoteList)); } catch {}

      setFirebaseSyncStatus(prev => ({
        ...prev,
        connected: true,
        isSyncing: false,
        lastSyncedAt: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      }));
    }, (err) => handleFirestoreError(err, OperationType.GET, 'employees'));

    const unsubContracts = onSnapshot(collection(db, 'contracts'), (snap) => {
      const remoteList: EmploymentContract[] = snap.docs.map(d => d.data() as EmploymentContract);
      setContracts(remoteList);
      try { localStorage.setItem('gmcc_contracts', JSON.stringify(remoteList)); } catch {}
    }, (err) => handleFirestoreError(err, OperationType.GET, 'contracts'));

    const unsubLeaveApps = onSnapshot(collection(db, 'leaveApplications'), (snap) => {
      const remoteList: LeaveApplication[] = snap.docs.map(d => d.data() as LeaveApplication);
      setLeaveApplications(remoteList);
      try { localStorage.setItem('gmcc_leave_applications', JSON.stringify(remoteList)); } catch {}
    }, (err) => handleFirestoreError(err, OperationType.GET, 'leaveApplications'));

    const unsubLeaveLedger = onSnapshot(collection(db, 'leaveLedger'), (snap) => {
      const remoteList: LeaveLedgerEntry[] = snap.docs.map(d => d.data() as LeaveLedgerEntry);
      setLeaveLedger(remoteList);
      try { localStorage.setItem('gmcc_leave_ledger', JSON.stringify(remoteList)); } catch {}
    }, (err) => handleFirestoreError(err, OperationType.GET, 'leaveLedger'));

    const unsubUserAccounts = onSnapshot(collection(db, 'userAccounts'), (snap) => {
      let remoteList: UserAccount[] = snap.docs.map(d => {
        const acc = d.data() as UserAccount;
        if (acc.userId === 'admin' || acc.id === 'USR-ADMIN') {
          return { ...acc, password: acc.password || 'GolomoriCC26' };
        }
        return acc;
      });

      if (remoteList.length > 0) {
        // Ensure standard administrator account always remains accessible
        if (!remoteList.some(u => u.id === 'USR-ADMIN' || u.userId === 'admin')) {
          remoteList = [INITIAL_USER_ACCOUNTS[0], ...remoteList];
        }
        setUserAccounts(remoteList);
        try { localStorage.setItem('gmcc_user_accounts', JSON.stringify(remoteList)); } catch {}
      }
    }, (err) => handleFirestoreError(err, OperationType.GET, 'userAccounts'));

    const unsubHolidays = onSnapshot(collection(db, 'holidays'), (snap) => {
      if (!snap.empty) {
        const remoteList: PublicHoliday[] = snap.docs.map(d => d.data() as PublicHoliday);
        setHolidays(remoteList);
      }
    }, (err) => handleFirestoreError(err, OperationType.GET, 'holidays'));

    const unsubDepartments = onSnapshot(collection(db, 'departments'), (snap) => {
      if (!snap.empty) {
        const remoteList: Department[] = snap.docs.map(d => d.data() as Department);
        setDepartments(remoteList);
      }
    }, (err) => handleFirestoreError(err, OperationType.GET, 'departments'));

    const unsubTrainingPlans = onSnapshot(collection(db, 'trainingPlans'), (snap) => {
      const remoteList: TrainingPlan[] = snap.docs.map(d => d.data() as TrainingPlan);
      setTrainingPlans(remoteList);
    }, (err) => handleFirestoreError(err, OperationType.GET, 'trainingPlans'));

    const unsubTrainingSessions = onSnapshot(collection(db, 'trainingSessions'), (snap) => {
      const remoteList: TrainingSession[] = snap.docs.map(d => d.data() as TrainingSession);
      setTrainingSessions(remoteList);
    }, (err) => handleFirestoreError(err, OperationType.GET, 'trainingSessions'));

    const unsubTrainingAttendance = onSnapshot(collection(db, 'trainingAttendance'), (snap) => {
      const remoteList: TrainingAttendance[] = snap.docs.map(d => d.data() as TrainingAttendance);
      setTrainingAttendance(remoteList);
    }, (err) => handleFirestoreError(err, OperationType.GET, 'trainingAttendance'));

    const unsubDocuments = onSnapshot(collection(db, 'documents'), (snap) => {
      const remoteList: EmployeeDocument[] = snap.docs.map(d => d.data() as EmployeeDocument);
      const deletedIds = getDeletedIds('gmcc_deleted_document_ids');

      setDocuments(prevLocal => {
        const mergedMap = new Map<string, EmployeeDocument>();
        remoteList.forEach(doc => {
          if (doc && doc.id && !deletedIds.has(doc.id)) {
            mergedMap.set(doc.id, doc);
          }
        });
        prevLocal.forEach(doc => {
          if (doc && doc.id && !deletedIds.has(doc.id)) {
            if (!mergedMap.has(doc.id)) {
              mergedMap.set(doc.id, doc);
              saveToFirestore('documents', doc);
            }
          }
        });
        const finalList = Array.from(mergedMap.values());
        try { localStorage.setItem('gmcc_documents', JSON.stringify(finalList)); } catch {}
        return finalList;
      });
    }, (err) => handleFirestoreError(err, OperationType.GET, 'documents'));

    return () => {
      unsubEmployees();
      unsubContracts();
      unsubLeaveApps();
      unsubLeaveLedger();
      unsubUserAccounts();
      unsubHolidays();
      unsubDepartments();
      unsubTrainingPlans();
      unsubTrainingSessions();
      unsubTrainingAttendance();
      unsubDocuments();
    };
  }, []);

  // Manual Bulk Push to Firebase Firestore
  const syncAllToFirebase = async (): Promise<void> => {
    if (!db) return;
    setFirebaseSyncStatus(prev => ({ ...prev, isSyncing: true }));
    try {
      for (const emp of employees) await saveToFirestore('employees', emp);
      for (const c of contracts) await saveToFirestore('contracts', c);
      for (const l of leaveLedger) await saveToFirestore('leaveLedger', l);
      for (const a of leaveApplications) await saveToFirestore('leaveApplications', a);
      for (const u of userAccounts) await saveToFirestore('userAccounts', u);
      for (const h of holidays) await saveToFirestore('holidays', h);
      for (const tp of trainingPlans) await saveToFirestore('trainingPlans', tp);
      for (const ts of trainingSessions) await saveToFirestore('trainingSessions', ts);
      setFirebaseSyncStatus(prev => ({
        ...prev,
        connected: true,
        isSyncing: false,
        lastSyncedAt: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      }));
    } catch (e) {
      console.warn('Sync all to Firebase error:', e);
      setFirebaseSyncStatus(prev => ({ ...prev, isSyncing: false }));
    }
  };

  // Direct Force Sync from Server (Bypasses any browser cache or IndexedDB)
  const forceServerSync = async (): Promise<{ success: boolean; message: string }> => {
    if (!db) return { success: false, message: 'Database Cloud Firestore belum terhubung.' };
    setFirebaseSyncStatus(prev => ({ ...prev, isSyncing: true }));
    try {
      // 1. Employees from Cloud Firestore
      const empSnap = await getDocsFromServer(collection(db, 'employees'));
      const empList: Employee[] = empSnap.docs.map(d => d.data() as Employee);
      setEmployees(empList);
      try { localStorage.setItem('gmcc_employees', JSON.stringify(empList)); } catch {}

      // 2. Contracts from Cloud Firestore
      const ctrSnap = await getDocsFromServer(collection(db, 'contracts'));
      const ctrList: EmploymentContract[] = ctrSnap.docs.map(d => d.data() as EmploymentContract);
      setContracts(ctrList);
      try { localStorage.setItem('gmcc_contracts', JSON.stringify(ctrList)); } catch {}

      // 3. Leave Applications
      const appSnap = await getDocsFromServer(collection(db, 'leaveApplications'));
      const appList: LeaveApplication[] = appSnap.docs.map(d => d.data() as LeaveApplication);
      setLeaveApplications(appList);
      try { localStorage.setItem('gmcc_leave_applications', JSON.stringify(appList)); } catch {}

      // 4. Leave Ledger
      const ledgSnap = await getDocsFromServer(collection(db, 'leaveLedger'));
      const ledgList: LeaveLedgerEntry[] = ledgSnap.docs.map(d => d.data() as LeaveLedgerEntry);
      setLeaveLedger(ledgList);
      try { localStorage.setItem('gmcc_leave_ledger', JSON.stringify(ledgList)); } catch {}

      // 5. User Accounts
      const userSnap = await getDocsFromServer(collection(db, 'userAccounts'));
      let userList: UserAccount[] = userSnap.docs.map(d => {
        const acc = d.data() as UserAccount;
        if (acc.userId === 'admin' || acc.id === 'USR-ADMIN') {
          return { ...acc, password: acc.password || 'GolomoriCC26' };
        }
        return acc;
      });
      if (userList.length > 0) {
        if (!userList.some(u => u.id === 'USR-ADMIN' || u.userId === 'admin')) {
          userList = [INITIAL_USER_ACCOUNTS[0], ...userList];
        }
        setUserAccounts(userList);
        try { localStorage.setItem('gmcc_user_accounts', JSON.stringify(userList)); } catch {}
      }

      const timeStr = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setFirebaseSyncStatus(prev => ({
        ...prev,
        connected: true,
        isSyncing: false,
        lastSyncedAt: timeStr
      }));
      return { 
        success: true, 
        message: `Berhasil memuat data terkini langsung dari Cloud Firestore (${empList.length} staff). Cache lokal telah diperbarui.` 
      };
    } catch (err: any) {
      console.warn('Force server sync error:', err);
      setFirebaseSyncStatus(prev => ({ ...prev, isSyncing: false }));
      return { success: false, message: err?.message || 'Gagal sinkronisasi data dari server.' };
    }
  };

  // Auto-refresh when tab gains visibility or when user navigates using Browser History (BFCache)
  useEffect(() => {
    const handlePageShow = (event: PageTransitionEvent) => {
      // If page was restored from browser history (Back-Forward Cache), bypass cache and sync from server
      if (event.persisted) {
        forceServerSync().catch(() => {});
      }
    };
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        forceServerSync().catch(() => {});
      }
    };
    window.addEventListener('pageshow', handlePageShow);
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      window.removeEventListener('pageshow', handlePageShow);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);

  // Audit Log helper
  const logAudit = (module: AuditLog['module'], action: string, description: string, targetId?: string) => {
    const newLog: AuditLog = {
      id: `AUD-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 8)}`,
      timestamp: new Date().toISOString(),
      actorId: currentUser.employeeId || currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      module,
      action,
      targetId,
      description,
      ipAddress: '192.168.10.15'
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Leave Balance Engine
  // Available Balance = Valid Credits - Valid Deductions - Expired Credits + Adjustments
  const getLeaveBalanceSummary = (employeeId: string, leaveType: LeaveType): LeaveBalanceSummary => {
    const employeeEntries = leaveLedger.filter(
      entry => entry.employeeId === employeeId && entry.leaveType === leaveType
    );

    let openingBalance = 0;
    let totalCredits = 0;
    let approvedUsage = 0;
    let adjustments = 0;
    let expiredCredits = 0;

    employeeEntries.forEach(entry => {
      switch (entry.transactionType) {
        case 'OPENING_BALANCE':
          openingBalance += entry.days;
          break;
        case 'ANNUAL_ENTITLEMENT_CREDIT':
        case 'OVERTIME_EXTRA_OFF_CREDIT':
        case 'HOLIDAY_DUTY_CREDIT':
          totalCredits += entry.days;
          break;
        case 'APPROVED_LEAVE_DEDUCTION':
          approvedUsage += Math.abs(entry.days);
          break;
        case 'EXPIRY_DEDUCTION':
          expiredCredits += Math.abs(entry.days);
          break;
        case 'REVERSAL_ADJUSTMENT':
        case 'CORRECTION_ADJUSTMENT':
          adjustments += entry.days;
          break;
      }
    });

    // For ANNUAL_LEAVE: If no explicit credit entry exists in the ledger,
    // auto-calculate entitlement based on join date and prorating
    const hasCreditEntry = employeeEntries.some(e => 
      ['OPENING_BALANCE', 'ANNUAL_ENTITLEMENT_CREDIT'].includes(e.transactionType)
    );

    if (leaveType === 'ANNUAL_LEAVE' && !hasCreditEntry) {
      const emp = employees.find(e => e.id === employeeId);
      if (emp && emp.employmentType !== 'DAILY_WORKER') {
        const sysDate = new Date(systemDate);
        const cYear = sysDate.getFullYear();
        const joinDateObj = new Date(emp.joinDate);
        const joinYear = joinDateObj.getFullYear();
        const joinMonth = joinDateObj.getMonth() + 1; // 1-12

        if (joinYear === cYear) {
          // Prorated from join month through December: 12 - joinMonth + 1 (e.g. Kristin April = 9 days)
          totalCredits = Math.max(1, Math.min(12, 12 - joinMonth + 1));
        } else if (joinYear < cYear) {
          totalCredits = 12;
        }
      }
    }

    const availableBalance = (openingBalance + totalCredits + adjustments) - approvedUsage - expiredCredits;

    // Calculate Pending Reservations (applications in approval workflow)
    const pendingApps = leaveApplications.filter(
      app => app.employeeId === employeeId &&
             app.leaveType === leaveType &&
             ['PENDING_DEPT_HEAD', 'PENDING_HC', 'PENDING_GM'].includes(app.status)
    );
    const pendingReservation = pendingApps.reduce((acc, curr) => acc + curr.totalDays, 0);
    const projectedBalance = availableBalance - pendingReservation;

    return {
      employeeId,
      leaveType,
      openingBalance,
      totalCredits,
      approvedUsage,
      adjustments,
      expiredCredits,
      availableBalance: Math.max(0, availableBalance),
      pendingReservation,
      projectedBalance
    };
  };

  // Access Permission Helper for Personal Files
  // Access Permission Helper for Personal Files (View/Open Folder)
  const canAccessCategory = (category: PersonalFileCategory, targetEmployeeId: string): boolean => {
    // Admin, HC, and GM have full view access across all 10 subfolders (including 07, 08, 09)
    if (currentUser.role === 'ADMIN' || currentUser.role === 'HC' || currentUser.role === 'GM') return true;

    const meta = PERSONAL_FILE_CATEGORIES.find(c => c.code === category);
    if (!meta) return false;

    // Staff can only access their own non-restricted folders
    if (currentUser.role === 'STAFF') {
      if (currentUser.employeeId !== targetEmployeeId) return false;
      return !meta.isRestricted;
    }

    // Dept Head can access/view all subfolders for their direct department staff, including folder 07, 08, 09
    if (currentUser.role === 'DEPT_HEAD') {
      const emp = employees.find(e => e.id === targetEmployeeId);
      if (!emp || emp.departmentId !== currentUser.departmentId) return false;
      return true; // Dept Head can VIEW folder 7 sd 9 and all folders of staff in their department!
    }

    // Auditor can view non-restricted compliance docs
    if (currentUser.role === 'AUDITOR') {
      return !meta.isRestricted;
    }

    return false;
  };

  // Modify Permission Helper (Add, Upload, Delete, Edit Documents)
  // Dept Head can view folders 7 to 9, but CANNOT edit or add (tidak dapat edit dan tambah)
  const canModifyCategory = (category: PersonalFileCategory, targetEmployeeId?: string): boolean => {
    // Auditor is strictly read-only
    if (currentUser.role === 'AUDITOR') return false;

    // Admin, HC, and GM have full upload, add, edit, and delete permissions across all folders
    if (currentUser.role === 'ADMIN' || currentUser.role === 'HC' || currentUser.role === 'GM') return true;

    // Dept Head: FOR FOLDERS 07, 08, 09 (Discipline, Compensation, Health), THEY ARE VIEW-ONLY (tidak dapat edit dan tambah)
    if (currentUser.role === 'DEPT_HEAD') {
      const restrictedCodes: PersonalFileCategory[] = ['07_DISCIPLINE', '08_COMPENSATION_BENEFITS', '09_HEALTH_WORK_REQUIREMENTS'];
      if (restrictedCodes.includes(category)) {
        return false; // Dept head can view but CANNOT edit or add!
      }
      // For general non-restricted folders of department staff:
      if (targetEmployeeId) {
        const emp = employees.find(e => e.id === targetEmployeeId);
        if (!emp || emp.departmentId !== currentUser.departmentId) return false;
      }
      return true;
    }

    // Staff can only upload to non-restricted folders of their own profile
    if (currentUser.role === 'STAFF') {
      const staffRestricted: PersonalFileCategory[] = [
        '02_RECRUITMENT', 
        '07_DISCIPLINE', 
        '08_COMPENSATION_BENEFITS', 
        '09_HEALTH_WORK_REQUIREMENTS', 
        '10_EXIT'
      ];
      return !staffRestricted.includes(category);
    }

    return false;
  };

  // Document Upload
  const uploadDocument = (docData: Omit<EmployeeDocument, 'id' | 'uploadedAt' | 'driveFileId' | 'drivePath'>): EmployeeDocument => {
    const emp = employees.find(e => e.id === docData.employeeId);
    const empName = emp ? emp.fullName : 'Employee';
    const catMeta = PERSONAL_FILE_CATEGORIES.find(c => c.code === docData.category);
    const folderName = catMeta ? catMeta.name : docData.category;

    const newDocId = `DOC-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;
    const newDoc: EmployeeDocument = {
      ...docData,
      id: newDocId,
      uploadedAt: new Date().toISOString(),
      driveFileId: `DRV-FILE-${newDocId}`,
      drivePath: `GMCC HUMAN CAPITAL/01 PERSONAL FILE/ACTIVE EMPLOYEE/${docData.employeeId} - ${empName}/${folderName}/${docData.fileName}`
    };

    setDocuments(prev => [newDoc, ...prev]);
    saveToFirestore('documents', newDoc);
    logAudit('PERSONAL_FILE', 'UPLOAD_DOCUMENT', `Uploaded ${docData.title} (${docData.fileName}) to folder ${folderName}`, newDocId);
    return newDoc;
  };

  const deleteDocument = (documentId: string) => {
    const docItem = documents.find(d => d.id === documentId);
    if (!docItem) return;
    recordDeletedId('gmcc_deleted_document_ids', documentId);
    setDocuments(prev => {
      const updated = prev.filter(d => d.id !== documentId);
      try { localStorage.setItem('gmcc_documents', JSON.stringify(updated)); } catch {}
      return updated;
    });
    deleteFromFirestore('documents', documentId);
    logAudit('PERSONAL_FILE', 'DELETE_DOCUMENT', `Deleted document ${docItem.title}`, documentId);
  };

  // Add Employee with Automatic Drive Folder Provisioning
  const addEmployee = (empData: Omit<Employee, 'id' | 'driveFolderId' | 'createdAt' | 'updatedAt'>): Employee => {
    // Generate sequential ID that doesn't conflict with existing or deleted IDs
    const deletedIds = getDeletedIds('gmcc_deleted_employee_ids');
    let highestNum = 0;
    employees.forEach(e => {
      const match = e.id?.match(/EMP-(\d+)/i) || e.employeeNumber?.match(/(\d+)$/);
      if (match) {
        const val = parseInt(match[1], 10);
        if (!isNaN(val) && val > highestNum) highestNum = val;
      }
    });
    deletedIds.forEach(id => {
      const match = id.match(/EMP-(\d+)/i);
      if (match) {
        const val = parseInt(match[1], 10);
        if (!isNaN(val) && val > highestNum) highestNum = val;
      }
    });

    const newNum = highestNum + 1;
    const empId = `EMP-${newNum.toString().padStart(4, '0')}`;
    const newEmp: Employee = {
      ...empData,
      id: empId,
      driveFolderId: `DRV-${empId}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Remove from tombstone set if re-creating
    removeDeletedId('gmcc_deleted_employee_ids', empId);

    // Save directly to localStorage immediately
    setEmployees(prev => {
      const updated = [...prev, newEmp];
      try { localStorage.setItem('gmcc_employees', JSON.stringify(updated)); } catch {}
      return updated;
    });

    // Save to Firestore with auto-sanitization (no rejection of undefined fields)
    saveToFirestore('employees', newEmp).catch(err => {
      console.warn('Async cloud save warning for employee:', err);
    });

    logAudit('EMPLOYEE', 'CREATE_EMPLOYEE', `Created new employee profile ${newEmp.fullName} (${empId}) with 10 standard personal file subfolders.`, empId);
    return newEmp;
  };

  const updateEmployee = (emp: Employee) => {
    const updatedEmp = { ...emp, updatedAt: new Date().toISOString() };
    setEmployees(prev => prev.map(e => e.id === emp.id ? updatedEmp : e));
    saveToFirestore('employees', updatedEmp);
    
    // Auto-sync linked user account role & status
    setUserAccounts(prev => prev.map(u => {
      if (u.employeeId === emp.id) {
        const titleLower = emp.jobTitle.toLowerCase();
        const isGM = titleLower.includes('general manager') || titleLower === 'gm' || emp.departmentId === 'DEP-EXEC';
        const isExEmployee = emp.employmentStatus === 'EX_EMPLOYEE' || emp.employmentStatus === 'INACTIVE';
        
        let newRole = u.role;
        if (isGM && emp.employmentStatus === 'ACTIVE') {
          newRole = 'GM';
        }

        const updatedUser = {
          ...u,
          name: emp.fullName,
          email: emp.companyEmail || u.email,
          role: newRole,
          status: isExEmployee ? ('SUSPENDED' as const) : u.status,
          updatedAt: new Date().toISOString()
        };
        saveToFirestore('userAccounts', updatedUser);
        return updatedUser;
      }
      return u;
    }));

    // Auto-sync contract status: jika karyawan NON AKTIF / EX_EMPLOYEE, kontrak aktif otomatis diubah menjadi TERMINATED
    if (emp.employmentStatus === 'INACTIVE' || emp.employmentStatus === 'EX_EMPLOYEE') {
      const today = new Date().toISOString().slice(0, 10);
      setContracts(prev => prev.map(c => {
        if (c.employeeId === emp.id && (c.status === 'ACTIVE' || c.status === 'EXPIRING_SOON')) {
          const terminatedC = {
            ...c,
            status: 'TERMINATED' as const,
            terminationDetails: {
              effectiveDate: today,
              reason: 'OTHER' as const,
              reasonLabel: `Status profil karyawan dinonaktifkan (${emp.employmentStatus === 'INACTIVE' ? 'Non-Aktif' : 'Mantan Pegawai'})`,
              notes: 'Otomatis diterminasi karena status kepegawaian dinonaktifkan.',
              terminatedAt: new Date().toISOString(),
              terminatedBy: currentUser.name
            },
            updatedAt: new Date().toISOString()
          };
          saveToFirestore('contracts', terminatedC);
          return terminatedC;
        }
        return c;
      }));
    }

    logAudit('EMPLOYEE', 'UPDATE_EMPLOYEE', `Updated profile information for ${emp.fullName}`, emp.id);
  };

  // Days until expiry
  const getDaysUntilExpiry = (endDate: string): number | null => {
    if (!endDate) return null;
    const current = new Date(systemDate);
    const end = new Date(endDate);
    const diffTime = end.getTime() - current.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  // Add & Renew Contract (Multi-Period Tracking: Periode 1, 2, dst)
  const addContract = (contractData: Omit<EmploymentContract, 'id' | 'version' | 'createdAt' | 'updatedAt'> & { version?: number }): EmploymentContract => {
    const existingEmpContracts = contracts.filter(c => c.employeeId === contractData.employeeId);
    const highestTerm = existingEmpContracts.reduce((max, c) => Math.max(max, c.termNumber || c.version || 1), 0);
    const calculatedTerm = contractData.termNumber || (highestTerm > 0 ? highestTerm + 1 : 1);
    const calculatedVersion = contractData.version || (highestTerm > 0 ? highestTerm + 1 : 1);

    const newId = `CTR-${new Date().getFullYear()}-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const newContract: EmploymentContract = {
      ...contractData,
      id: newId,
      version: calculatedVersion,
      termNumber: calculatedTerm,
      responsibleHc: contractData.responsibleHc || currentUser.name || 'Human Capital',
      status: contractData.status || 'ACTIVE',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // If there were previous active or expired contracts for this employee, mark them as RENEWED to preserve audit trail
    setContracts(prev => [
      newContract,
      ...prev.map(c => (c.employeeId === contractData.employeeId && (c.status === 'ACTIVE' || c.status === 'EXPIRING_SOON' || c.status === 'EXPIRED')) 
        ? { ...c, status: 'RENEWED' as const, updatedAt: new Date().toISOString() } 
        : c
      )
    ]);
    saveToFirestore('contracts', newContract);

    // Keep employee record up-to-date
    if (contractData.employeeId) {
      const calcMonths = (start: string, end: string) => {
        if (!start || !end) return 12;
        const d1 = new Date(start);
        const d2 = new Date(end);
        return Math.max(1, Math.round((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24 * 30.4375)));
      };
      setEmployees(prev => prev.map(e => {
        if (e.id === contractData.employeeId) {
          const updatedEmp = {
            ...e,
            employmentStatus: 'ACTIVE' as const,
            employmentType: contractData.employmentType,
            contractDurationMonths: calcMonths(contractData.startDate, contractData.endDate),
            updatedAt: new Date().toISOString()
          };
          saveToFirestore('employees', updatedEmp);
          return updatedEmp;
        }
        return e;
      }));
    }

    logAudit('CONTRACT', 'CREATE_CONTRACT', `Menerbitkan Kontrak Baru Periode ${calculatedTerm} (${newContract.contractNumber}) untuk ${newContract.employeeName}`, newId);
    return newContract;
  };

  const renewContract = (
    oldContractId: string, 
    newStartDate: string, 
    newEndDate: string, 
    notes: string,
    newContractNumber?: string,
    newTermNumber?: number,
    compensationData?: {
      compensationStatus?: 'DITERIMA' | 'BELUM';
      compensationAmount?: number;
      compensationPaidDate?: string;
      compensationNotes?: string;
    }
  ): EmploymentContract | undefined => {
    const oldContract = contracts.find(c => c.id === oldContractId);
    if (!oldContract) return undefined;

    // Update old contract status to RENEWED and store compensation data for the completed period
    const updatedOld: EmploymentContract = { 
      ...oldContract, 
      status: 'RENEWED', 
      compensationStatus: compensationData?.compensationStatus || oldContract.compensationStatus || 'BELUM',
      compensationAmount: compensationData?.compensationAmount !== undefined ? compensationData.compensationAmount : oldContract.compensationAmount,
      compensationPaidDate: compensationData?.compensationPaidDate || oldContract.compensationPaidDate,
      compensationNotes: compensationData?.compensationNotes || oldContract.compensationNotes,
      updatedAt: new Date().toISOString() 
    };
    setContracts(prev => prev.map(c => c.id === oldContractId ? updatedOld : c));
    saveToFirestore('contracts', updatedOld);

    const nextTerm = newTermNumber || (oldContract.termNumber || oldContract.version || 1) + 1;
    const finalContractNum = newContractNumber?.trim() 
      ? newContractNumber.trim() 
      : `${oldContract.contractNumber}-R${oldContract.version + 1}`;

    // Create renewed version
    const newId = `CTR-${new Date().getFullYear()}-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const renewedContract: EmploymentContract = {
      id: newId,
      contractNumber: finalContractNum,
      employeeId: oldContract.employeeId,
      employeeName: oldContract.employeeName,
      departmentId: oldContract.departmentId,
      position: oldContract.position,
      employmentType: oldContract.employmentType,
      startDate: newStartDate,
      endDate: newEndDate,
      status: 'ACTIVE',
      version: oldContract.version + 1,
      termNumber: nextTerm,
      renewalHistory: {
        renewedFromContractId: oldContract.id,
        renewedAt: new Date().toISOString(),
        renewedBy: currentUser.name,
        renewalNotes: notes
      },
      responsibleHc: currentUser.name,
      notes,
      compensationStatus: compensationData?.compensationStatus || 'BELUM',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setContracts(prev => [renewedContract, ...prev]);
    saveToFirestore('contracts', renewedContract);

    // Keep employee status ACTIVE and update contractDurationMonths
    const calcMonths = (start: string, end: string) => {
      if (!start || !end) return 12;
      const d1 = new Date(start);
      const d2 = new Date(end);
      return Math.max(1, Math.round((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24 * 30.4375)));
    };
    setEmployees(prev => prev.map(e => {
      if (e.id === oldContract.employeeId) {
        const updatedEmp = {
          ...e,
          employmentStatus: 'ACTIVE' as const,
          employmentType: oldContract.employmentType,
          contractDurationMonths: calcMonths(newStartDate, newEndDate),
          updatedAt: new Date().toISOString()
        };
        saveToFirestore('employees', updatedEmp);
        return updatedEmp;
      }
      return e;
    }));

    logAudit('CONTRACT', 'RENEW_CONTRACT', `Perpanjangan kontrak ke Periode ${nextTerm} untuk ${oldContract.employeeName}. Nomor: ${renewedContract.contractNumber} (v${renewedContract.version})`, newId);
    return renewedContract;
  };

  const terminateContract = (contractId: string, details: ContractTerminationDetails) => {
    const contract = contracts.find(c => c.id === contractId);
    if (!contract) return;

    const terminationInfo: ContractTerminationDetails = {
      ...details,
      terminatedAt: new Date().toISOString(),
      terminatedBy: currentUser.name
    };

    const terminatedContract: EmploymentContract = {
      ...contract,
      status: 'TERMINATED',
      terminationDetails: terminationInfo,
      updatedAt: new Date().toISOString()
    };

    setContracts(prev => prev.map(c => c.id === contractId ? terminatedContract : c));
    saveToFirestore('contracts', terminatedContract);

    // Update employee status if requested
    if (details.updateEmployeeStatus) {
      setEmployees(prev => prev.map(e => {
        if (e.id === contract.employeeId) {
          const updatedEmp = {
            ...e,
            employmentStatus: 'EX_EMPLOYEE' as const,
            updatedAt: new Date().toISOString()
          };
          saveToFirestore('employees', updatedEmp);
          return updatedEmp;
        }
        return e;
      }));
      logAudit('EMPLOYEE', 'UPDATE_EMPLOYEE_STATUS', `Status pegawai ${contract.employeeName} (${contract.employeeId}) diubah menjadi EX_EMPLOYEE karena terminasi kontrak.`, contract.employeeId);
    }

    logAudit('CONTRACT', 'TERMINATE_CONTRACT', `Terminated contract ${contract.contractNumber} (${contract.employeeName}). Alasan: ${details.reason} (${details.reasonLabel || details.reason}). Efektif: ${details.effectiveDate}`, contractId);

    // Notify HC and GM
    const notifId = `NOTIF-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;
    const newNotif: NotificationItem = {
      id: notifId,
      recipientRole: 'HC',
      title: `Terminasi Kontrak: ${contract.contractNumber}`,
      message: `Kontrak kerja ${contract.employeeName} (${contract.contractNumber}) telah diterminasi efektif tanggal ${details.effectiveDate}. Alasan: ${details.reasonLabel || details.reason}.`,
      type: 'CONTRACT_EXPIRY',
      linkModule: 'contracts',
      read: false,
      createdAt: new Date().toISOString()
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const attachSignedContract = (contractId: string, fileData: { fileName: string; fileUrl?: string; notes?: string }) => {
    const contract = contracts.find(c => c.id === contractId);
    if (!contract) return;
    const nowIso = new Date().toISOString();
    const updatedContract: EmploymentContract = {
      ...contract,
      signedContractFileName: fileData.fileName,
      signedContractFileUrl: fileData.fileUrl || contract.signedContractFileUrl,
      signedContractUploadedAt: nowIso,
      signedContractUploadedBy: currentUser.name,
      notes: fileData.notes ? `${contract.notes ? contract.notes + ' | ' : ''}${fileData.notes}` : contract.notes,
      updatedAt: nowIso
    };

    setContracts(prev => prev.map(c => c.id === contractId ? updatedContract : c));
    saveToFirestore('contracts', updatedContract);

    // Also auto-upload to employee personal files under Category 03 (Employment & Contracts)
    uploadDocument({
      employeeId: contract.employeeId,
      category: '03_EMPLOYMENT',
      title: `Signed Contract Attachment - ${contract.contractNumber}`,
      fileName: fileData.fileName,
      fileSize: '2.5 MB',
      fileType: fileData.fileName.endsWith('.pdf') ? 'pdf' : 'image',
      fileUrl: fileData.fileUrl,
      uploadedBy: currentUser.employeeId || currentUser.id,
      uploadedByName: currentUser.name,
      isConfidential: false,
      notes: `Salinan berkas copy kontrak kerja yang sudah ditandatangani untuk nomor ${contract.contractNumber}.`,
      driveFolderId: `DRV-${contract.employeeId}-03`
    });

    logAudit('CONTRACT', 'UPLOAD_SIGNED_CONTRACT', `HC mengunggah berkas copy kontrak kerja yang sudah ditandatangani (${fileData.fileName}) untuk ${contract.employeeName} (${contract.contractNumber})`, contractId);
  };

  // User Accounts & Password Management
  const addUserAccount = (userData: Omit<UserAccount, 'id' | 'createdAt' | 'updatedAt'>): UserAccount => {
    const newId = `USR-${(userAccounts.length + 1).toString().padStart(2, '0')}`;
    const newAccount: UserAccount = {
      ...userData,
      id: newId,
      username: userData.username || userData.userId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setUserAccounts(prev => [...prev, newAccount]);
    saveToFirestore('userAccounts', newAccount);
    logAudit('AUTH', 'CREATE_USER_ACCOUNT', `Dibuat akun login baru dengan User ID: ${newAccount.userId} untuk ${newAccount.name} (${newAccount.role})`, newId);
    return newAccount;
  };

  const updateUserAccount = (account: UserAccount) => {
    const updated = { 
      ...account, 
      username: account.username || account.userId, 
      updatedAt: new Date().toISOString() 
    };
    setUserAccounts(prev => prev.map(u => u.id === account.id ? updated : u));
    saveToFirestore('userAccounts', updated);
    logAudit('AUTH', 'UPDATE_USER_ACCOUNT', `Diperbarui kredensial akun User ID: ${account.userId} (${account.name})`, account.id);
  };

  const deleteUserAccount = (userId: string) => {
    const target = userAccounts.find(u => u.id === userId || u.userId === userId);
    if (!target) return;
    recordDeletedId('gmcc_deleted_user_ids', target.id);
    setUserAccounts(prev => {
      const updated = prev.filter(u => u.id !== target.id);
      try { localStorage.setItem('gmcc_user_accounts', JSON.stringify(updated)); } catch {}
      return updated;
    });
    deleteFromFirestore('userAccounts', target.id);
    logAudit('AUTH', 'DELETE_USER_ACCOUNT', `Dihapus akun pengguna User ID: ${target.userId} (${target.name})`, target.id);
  };

  const resetUserPassword = (userId: string, newPass: string) => {
    const target = userAccounts.find(u => u.id === userId || u.userId === userId);
    if (target) {
      const updated = { 
        ...target, 
        password: newPass, 
        updatedAt: new Date().toISOString() 
      };
      setUserAccounts(prev => prev.map(u => (u.id === userId || u.userId === userId) ? updated : u));
      saveToFirestore('userAccounts', updated);
    }
    logAudit('AUTH', 'RESET_PASSWORD', `Reset password berhasil untuk User ID: ${userId}`, userId);
  };

  const changeAdminPassword = (newPass: string): { success: boolean; message: string } => {
    const trimmed = newPass.trim();
    if (!trimmed || trimmed.length < 6) {
      return { success: false, message: 'Password baru minimal 6 karakter demi keamanan akun.' };
    }
    const adminAccount = userAccounts.find(u => u.userId === 'admin' || u.id === 'USR-ADMIN');
    if (!adminAccount) {
      return { success: false, message: 'Akun Administrator tidak ditemukan.' };
    }
    const updated: UserAccount = {
      ...adminAccount,
      password: trimmed,
      updatedAt: new Date().toISOString()
    };
    setUserAccounts(prev => prev.map(u => (u.userId === 'admin' || u.id === 'USR-ADMIN') ? updated : u));
    saveToFirestore('userAccounts', updated);
    logAudit('AUTH', 'CHANGE_PASSWORD', `Kata sandi administrator (admin) berhasil diubah dan disimpan ke database cloud.`, adminAccount.id);
    return { success: true, message: 'Password Administrator berhasil diubah dan tersimpan ke Cloud Firestore.' };
  };

  const getUserAccountByEmployeeId = (empId: string): UserAccount | undefined => {
    return userAccounts.find(u => u.employeeId === empId);
  };

  const loginWithCredentials = (userIdOrEmail: string, password: string): { success: boolean; message?: string } => {
    const q = userIdOrEmail.trim().toLowerCase();
    const account = userAccounts.find(u => 
      (u.userId.toLowerCase() === q || u.username.toLowerCase() === q || u.email.toLowerCase() === q)
    );

    if (!account) {
      return { success: false, message: 'User ID atau Email tidak terdaftar dalam sistem.' };
    }

    if (account.status === 'SUSPENDED') {
      return { success: false, message: 'Akun ini ditangguhkan / non-aktif. Silakan hubungi Administrator atau HC.' };
    }

    // Dynamic password verification:
    // For admin: accepts both 'GolomoriCC26' and legacy 'admin' to prevent lockout
    // For other staff users: verify strictly against account.password.
    const isPasswordValid = (account.userId === 'admin' || account.id === 'USR-ADMIN')
      ? (password === account.password || password === 'GolomoriCC26' || password === 'admin')
      : (password === account.password);

    if (!isPasswordValid) {
      return { success: false, message: 'Password salah. Periksa kembali atau hubungi Administrator untuk reset password.' };
    }

    const loggedInUser: CurrentUser = {
      id: account.id,
      name: account.name,
      role: account.role,
      employeeId: account.employeeId,
      departmentId: account.departmentId,
      email: account.email
    };
    setCurrentUser(loggedInUser);
    setIsAuthenticated(true);
    // Use sessionStorage ONLY so that when the user closes the browser/tab, they are automatically logged out!
    sessionStorage.setItem('gmcc_authenticated', 'true');
    sessionStorage.setItem('gmcc_current_user', JSON.stringify(loggedInUser));
    sessionStorage.setItem('gmcc_last_active_time', String(Date.now()));
    sessionStorage.removeItem('gmcc_logout_reason');
    setLogoutReason(null);
    // Ensure legacy localStorage credentials are not retained
    localStorage.removeItem('gmcc_authenticated');
    localStorage.removeItem('gmcc_current_user');

    setUserAccounts(prev => prev.map(u => u.id === account.id ? { 
      ...u, 
      lastLogin: new Date().toISOString() 
    } : u));
    logAudit('AUTH', 'LOGIN_SUCCESS', `Pengguna ${account.userId} (${account.name}) berhasil masuk ke sistem.`, account.id);

    return { success: true };
  };

  const logout = (reason?: string) => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('gmcc_authenticated');
    sessionStorage.removeItem('gmcc_current_user');
    sessionStorage.removeItem('gmcc_last_active_time');
    localStorage.removeItem('gmcc_authenticated');
    localStorage.removeItem('gmcc_current_user');

    if (reason) {
      sessionStorage.setItem('gmcc_logout_reason', reason);
      setLogoutReason(reason);
    } else {
      sessionStorage.removeItem('gmcc_logout_reason');
      setLogoutReason(null);
    }

    logAudit('AUTH', 'LOGOUT', `Pengguna ${currentUser.name} (${currentUser.role}) keluar dari sistem.`, currentUser.id);
  };

  const clearLogoutReason = () => {
    sessionStorage.removeItem('gmcc_logout_reason');
    setLogoutReason(null);
  };

  const syncToGoogleAppsScript = async (urlOverride?: string): Promise<{ success: boolean; message: string; details?: string }> => {
    const targetUrl = (urlOverride || gasWebAppUrl).trim();
    if (!targetUrl) {
      const err = {
        success: false,
        message: 'URL Google Apps Script Web App belum diisi.',
        details: 'Buka menu Google Apps Script (GAS), salin URL Web App hasil deploy Anda, lalu tempel di kolom URL.'
      };
      setSyncStatus(err);
      return err;
    }

    setIsSyncing(true);
    setSyncStatus(null);

    const payload = {
      action: 'SYNC_ALL',
      timestamp: new Date().toISOString(),
      data: {
        employees,
        contracts,
        leaveApplications,
        leaveLedger,
        userAccounts,
        departments,
        trainingPlans,
        auditLogs
      }
    };

    try {
      // Send to Google Apps Script Web App
      await fetch(targetUrl, {
        method: 'POST',
        mode: 'no-cors',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const now = new Date().toISOString();
      setLastSyncTime(now);
      localStorage.setItem('gmcc_last_sync_time', now);
      
      const successResult = {
        success: true,
        message: 'Sinkronisasi ke Google Sheets & Drive berhasil dikirim!',
        details: `${employees.length} Karyawan, ${contracts.length} Kontrak, dan folder Personal File di Google Drive berhasil diproses.`
      };
      setSyncStatus(successResult);
      logAudit('ADMIN', 'SYNC_GAS', `Sinkronisasi database & folder Drive ke Google Apps Script berhasil.`, 'CLOUD-SYNC');
      setIsSyncing(false);
      return successResult;
    } catch (error: any) {
      const failResult = {
        success: false,
        message: 'Gagal menghubungi Google Apps Script Web App.',
        details: error?.message || 'Pastikan Web App di-deploy dengan akses "Anyone" dan URL sudah benar.'
      };
      setSyncStatus(failResult);
      setIsSyncing(false);
      return failResult;
    }
  };

  const deleteEmployee = (employeeId: string) => {
    if (currentUser.role !== 'GM' && currentUser.role !== 'ADMIN') {
      console.warn('Unauthorized: Hanya General Manager (GM) dan System Administrator yang memiliki wewenang menghapus profil karyawan.');
      return;
    }
    const emp = employees.find(e => e.id === employeeId);
    if (!emp) return;

    // Record tombstone so it stays permanently deleted across refreshes and syncs
    recordDeletedId('gmcc_deleted_employee_ids', employeeId);

    setEmployees(prev => {
      const updated = prev.filter(e => e.id !== employeeId);
      try { localStorage.setItem('gmcc_employees', JSON.stringify(updated)); } catch {}
      return updated;
    });
    setContracts(prev => {
      const updated = prev.filter(c => c.employeeId !== employeeId);
      try { localStorage.setItem('gmcc_contracts', JSON.stringify(updated)); } catch {}
      return updated;
    });
    setDocuments(prev => {
      const updated = prev.filter(d => d.employeeId !== employeeId);
      try { localStorage.setItem('gmcc_documents', JSON.stringify(updated)); } catch {}
      return updated;
    });
    setLeaveApplications(prev => {
      const updated = prev.filter(a => a.employeeId !== employeeId);
      try { localStorage.setItem('gmcc_leave_applications', JSON.stringify(updated)); } catch {}
      return updated;
    });
    setLeaveLedger(prev => {
      const updated = prev.filter(l => l.employeeId !== employeeId);
      try { localStorage.setItem('gmcc_leave_ledger', JSON.stringify(updated)); } catch {}
      return updated;
    });
    setUserAccounts(prev => {
      const updated = prev.filter(u => u.employeeId !== employeeId);
      try { localStorage.setItem('gmcc_user_accounts', JSON.stringify(updated)); } catch {}
      return updated;
    });

    deleteFromFirestore('employees', employeeId);
    saveToFirestore('deletedRecords', {
      id: `DEL-${employeeId}`,
      entityId: employeeId,
      entityType: 'EMPLOYEE',
      deletedAt: new Date().toISOString(),
      deletedBy: currentUser.name
    });

    logAudit('EMPLOYEE', 'DELETE_EMPLOYEE', `Deleted employee profile and all associated data for ${emp.fullName} (${emp.employeeNumber})`, employeeId);
  };

  const updateContract = (contract: EmploymentContract) => {
    const updated = { ...contract, updatedAt: new Date().toISOString() };
    setContracts(prev => prev.map(c => c.id === contract.id ? updated : c));
    saveToFirestore('contracts', updated);
    logAudit('CONTRACT', 'UPDATE_CONTRACT', `Updated contract ${contract.contractNumber} for ${contract.employeeName}`, contract.id);
  };

  const deleteContract = (contractId: string) => {
    const c = contracts.find(ctr => ctr.id === contractId);
    if (!c) return;
    recordDeletedId('gmcc_deleted_contract_ids', contractId);
    setContracts(prev => {
      const updated = prev.filter(ctr => ctr.id !== contractId);
      try { localStorage.setItem('gmcc_contracts', JSON.stringify(updated)); } catch {}
      return updated;
    });
    deleteFromFirestore('contracts', contractId);
    logAudit('CONTRACT', 'DELETE_CONTRACT', `Deleted contract ${c.contractNumber} (${c.employeeName})`, contractId);
  };

  const addLedgerEntry = (entryData: Omit<LeaveLedgerEntry, 'id' | 'createdAt'>): LeaveLedgerEntry => {
    const newId = `TXN-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;
    const newEntry: LeaveLedgerEntry = {
      ...entryData,
      id: newId,
      createdAt: new Date().toISOString()
    };
    setLeaveLedger(prev => [newEntry, ...prev]);
    saveToFirestore('leaveLedger', newEntry);
    logAudit('LEAVE', 'MANUAL_LEDGER_ENTRY', `Added ledger entry ${newId}: ${newEntry.days > 0 ? '+' : ''}${newEntry.days} days ${newEntry.leaveType} for ${newEntry.employeeId}`, newId);
    return newEntry;
  };

  const updateLedgerEntry = (entry: LeaveLedgerEntry) => {
    setLeaveLedger(prev => prev.map(e => e.id === entry.id ? entry : e));
    saveToFirestore('leaveLedger', entry);
    logAudit('LEAVE', 'UPDATE_LEDGER_ENTRY', `Updated ledger entry ${entry.id} (${entry.reason})`, entry.id);
  };

  const deleteLedgerEntry = (entryId: string) => {
    const item = leaveLedger.find(e => e.id === entryId);
    if (!item) return;
    setLeaveLedger(prev => prev.filter(e => e.id !== entryId));
    deleteFromFirestore('leaveLedger', entryId);
    logAudit('LEAVE', 'DELETE_LEDGER_ENTRY', `Deleted ledger entry ${entryId} for ${item.employeeId}`, entryId);
  };

  const addHoliday = (hData: Omit<PublicHoliday, 'id'>): PublicHoliday => {
    const newId = `HOL-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const newH: PublicHoliday = { ...hData, id: newId };
    setHolidays(prev => [...prev, newH].sort((a, b) => a.date.localeCompare(b.date)));
    saveToFirestore('holidays', newH);
    logAudit('ADMIN', 'ADD_HOLIDAY', `Added public holiday: ${newH.name} (${newH.date})`, newId);
    return newH;
  };

  const updateHoliday = (h: PublicHoliday) => {
    setHolidays(prev => prev.map(item => item.id === h.id ? h : item).sort((a, b) => a.date.localeCompare(b.date)));
    saveToFirestore('holidays', h);
    logAudit('ADMIN', 'UPDATE_HOLIDAY', `Updated public holiday: ${h.name} (${h.date})`, h.id);
  };

  const deleteHoliday = (holidayId: string) => {
    const h = holidays.find(item => item.id === holidayId);
    if (!h) return;
    setHolidays(prev => prev.filter(item => item.id !== holidayId));
    deleteFromFirestore('holidays', holidayId);
    logAudit('ADMIN', 'DELETE_HOLIDAY', `Deleted public holiday: ${h.name} (${h.date})`, holidayId);
  };

  const updateDepartment = (dept: Department) => {
    setDepartments(prev => prev.map(d => d.id === dept.id ? dept : d));
    saveToFirestore('departments', dept);
    logAudit('ADMIN', 'UPDATE_DEPARTMENT', `Updated department info for ${dept.name}`, dept.id);
  };

  const getAnnualLeaveReviewData = (year: number, deptId?: string): EmployeeLeaveReviewReport[] => {
    const yearStr = String(year);
    const systemDateObj = new Date(systemDate);
    const currentYear = systemDateObj.getFullYear();
    const currentMonth = systemDateObj.getMonth() + 1; // 10 (October)
    const asOfMonth = (year === currentYear) ? currentMonth : 12;
    const monthNamesIndo = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

    const filteredEmployees = employees.filter(emp => {
      if (deptId && deptId !== 'ALL') {
        return emp.departmentId === deptId;
      }
      return true;
    });

    return filteredEmployees.map(emp => {
      const contract = contracts.find(c => c.employeeId === emp.id);

      if (emp.employmentType === 'DAILY_WORKER') {
        return {
          employee: emp,
          contract,
          year,
          entitlementDays: 0,
          proratedAccruedDays: 0,
          proratedRemainingDays: 0,
          takenDays: 0,
          remainingDays: 0,
          pendingDays: 0,
          previousYearCarryForward: 0,
          totalBalanceAL: 0,
          totalBalanceALExplanation: 'Daily Worker tidak memiliki hak cuti tahunan (Upah harian lepas)',
          nextYearEntitlement: 0,
          nextYearCarryForward: 0,
          nextYearProjectedTotal: 0,
          prorateMonths: 0,
          prorateExplanation: 'Daily Worker tidak memiliki hak cuti tahunan (Upah harian lepas)',
          asOfMonth,
          asOfMonthName: monthNamesIndo[asOfMonth]
        };
      }

      const empEntries = leaveLedger.filter(l => l.employeeId === emp.id && l.leaveType === 'ANNUAL_LEAVE');

      // Helper to compute cumulative leave balance across years from joinYear to targetYear
      const getYearStats = (targetYear: number) => {
        const joinDateObj = new Date(emp.joinDate);
        const joinYear = joinDateObj.getFullYear();
        const joinMonth = joinDateObj.getMonth() + 1; // 1 to 12

        if (joinYear > targetYear) {
          return {
            entitlement: 0,
            prorateMonths: 0,
            taken: 0,
            adjustments: 0,
            carryForward: 0,
            remainingThisYear: 0,
            totalBalanceAL: 0,
            explanation: `Belum bergabung pada tahun ${targetYear} (Tanggal Masuk: ${emp.joinDate})`,
            totalBalanceALExplanation: `Belum bergabung pada tahun ${targetYear}`
          };
        }

        let accumulatedCarryForward = 0;
        let statsForTarget = {
          entitlement: 0,
          prorateMonths: 0,
          taken: 0,
          adjustments: 0,
          carryForward: 0,
          remainingThisYear: 0,
          totalBalanceAL: 0,
          explanation: '',
          totalBalanceALExplanation: ''
        };

        // Trace forward from joinYear to targetYear to accumulate leave and carry-forwards
        for (let y = joinYear; y <= targetYear; y++) {
          const yStr = String(y);
          const isCurrentActiveYear = (y === currentYear);
          const runningEndMonth = isCurrentActiveYear ? currentMonth : 12;

          let startMonth = 1;
          if (y === joinYear) {
            startMonth = joinMonth;
          }

          // Check contract start date in year y if applicable
          const empContractsForEmp = contracts.filter(c => c.employeeId === emp.id);
          const contractInYear = empContractsForEmp.find(c => {
            const cDate = new Date(c.startDate);
            return cDate.getFullYear() === y;
          });
          if (contractInYear && y === joinYear) {
            const cStartMonth = new Date(contractInYear.startDate).getMonth() + 1;
            startMonth = Math.max(startMonth, cStartMonth);
          }

          // Compute active working months: prorate up to bulan berjalan (currentMonth = 10) for current year, or up to Dec for past years
          let months = Math.max(1, Math.min(12, runningEndMonth - startMonth + 1));

          let explanation = isCurrentActiveYear
            ? (startMonth > 1
                ? `Prorate masuk kontrak (${monthNamesIndo[startMonth]} s/d ${monthNamesIndo[runningEndMonth]} ${y}): ${months} bln = ${months} hari`
                : `Prorate s/d bulan berjalan (${monthNamesIndo[runningEndMonth]} ${y}): ${months} bln = ${months} hari (bukan full 12)`)
            : (y === joinYear
                ? `Prorate tahun awal (${monthNamesIndo[startMonth]} - Des ${y}): ${months}/12 bln = ${months} hari`
                : 'Masa kerja penuh 12 bulan (12 hari)');

          // Check if there are explicit ledger credits for year y
          const yearCredits = empEntries.filter(e => {
            const isMatch = e.effectiveDate.startsWith(yStr) || (e.reason && e.reason.includes(yStr));
            return isMatch && ['OPENING_BALANCE', 'ANNUAL_ENTITLEMENT_CREDIT'].includes(e.transactionType);
          });

          const entitlement = yearCredits.length > 0
            ? yearCredits.reduce((sum, e) => sum + e.days, 0)
            : months;

          // Check explicit carry forward in ledger
          const explicitCF = empEntries.filter(e => 
            e.effectiveDate.startsWith(yStr) && e.transactionType === 'CARRY_FORWARD_CREDIT'
          );
          const carryForward = explicitCF.length > 0
            ? explicitCF.reduce((sum, e) => sum + e.days, 0)
            : accumulatedCarryForward;

          // Approved leave taken in year y
          const yearDeductions = empEntries.filter(e => {
            const isMatch = e.effectiveDate.startsWith(yStr);
            return isMatch && e.transactionType === 'APPROVED_LEAVE_DEDUCTION';
          });
          const taken = Math.abs(yearDeductions.reduce((sum, e) => sum + e.days, 0));

          // Adjustments in year y
          const yearAdjustments = empEntries.filter(e => {
            const isMatch = e.effectiveDate.startsWith(yStr);
            return isMatch && ['REVERSAL_ADJUSTMENT', 'CORRECTION_ADJUSTMENT'].includes(e.transactionType);
          });
          const adjustments = yearAdjustments.reduce((sum, e) => sum + e.days, 0);

          const remainingThisYear = Math.max(0, (entitlement + adjustments) - taken);
          // Total Balance AL = Akumulasi dari tahun sebelumnya + Hak Cuti Prorate tahun ini - Diambil tahun ini
          const totalBalanceAL = Math.max(0, carryForward + entitlement - taken + adjustments);

          const totalBalanceALExplanation = carryForward > 0
            ? `Akumulasi: Sisa Th Lalu (${carryForward} hr) + Hak Prorate (${entitlement} hr) - Diambil (${taken} hr) = ${totalBalanceAL} hr`
            : `Hak Prorate (${entitlement} hr) - Diambil (${taken} hr) = ${totalBalanceAL} hr`;

          // Carry forward to next year is the total accumulated balance
          accumulatedCarryForward = totalBalanceAL;

          if (y === targetYear) {
            statsForTarget = {
              entitlement,
              prorateMonths: months,
              taken,
              adjustments,
              carryForward,
              remainingThisYear,
              totalBalanceAL,
              explanation,
              totalBalanceALExplanation
            };
          }
        }

        return statsForTarget;
      };

      // Stats for the currently selected year
      const targetStats = getYearStats(year);

      // Pending applications in approval workflow
      const pendingApps = leaveApplications.filter(
        app => app.employeeId === emp.id &&
               app.leaveType === 'ANNUAL_LEAVE' &&
               app.startDate.startsWith(yearStr) &&
               ['PENDING_DEPT_HEAD', 'PENDING_HC', 'PENDING_GM'].includes(app.status)
      );
      const pendingDays = pendingApps.reduce((acc, curr) => acc + curr.totalDays, 0);

      // Tahun berikutnya: diganti dengan total balance AL dan akumulasi dari tahun sebelumnya
      // 1. Akumulasi dari tahun sebelumnya yang dibawa ke tahun depan = totalBalanceAL
      const nextYearCarryForward = targetStats.totalBalanceAL;
      // 2. Hak cuti tahun berikutnya = 12 hari (penuh)
      const nextYearEntitlement = 12;
      // 3. Proyeksi total balance AL tahun berikutnya = hak baru 12 hari + akumulasi tahun sebelumnya
      const nextYearProjectedTotal = nextYearEntitlement + nextYearCarryForward;

      return {
        employee: emp,
        contract,
        year,
        entitlementDays: targetStats.entitlement,
        proratedAccruedDays: targetStats.entitlement,
        proratedRemainingDays: targetStats.remainingThisYear,
        takenDays: targetStats.taken,
        remainingDays: targetStats.remainingThisYear,
        pendingDays,
        previousYearCarryForward: targetStats.carryForward,
        totalBalanceAL: targetStats.totalBalanceAL,
        totalBalanceALExplanation: targetStats.totalBalanceALExplanation,
        nextYearEntitlement,
        nextYearCarryForward,
        nextYearProjectedTotal,
        prorateMonths: targetStats.prorateMonths,
        prorateExplanation: targetStats.explanation,
        asOfMonth,
        asOfMonthName: monthNamesIndo[asOfMonth]
      };
    });
  };

  // Leave Management - Workflow & Deductions

  const submitLeaveApplication = (appData: {
    employeeId: string;
    leaveType: LeaveType;
    startDate: string;
    endDate: string;
    totalDays: number;
    reason: string;
    contactDuringLeave?: string;
    handoverToEmployeeId?: string;
  }): { success: boolean; message: string } => {
    const emp = employees.find(e => e.id === appData.employeeId);
    if (!emp) return { success: false, message: 'Employee not found.' };

    const balance = getLeaveBalanceSummary(appData.employeeId, appData.leaveType);
    if (balance.projectedBalance < appData.totalDays) {
      return { 
        success: false, 
        message: `Insufficient leave balance! Available: ${balance.availableBalance} days, Pending: ${balance.pendingReservation} days. Requested: ${appData.totalDays} days.` 
      };
    }

    const newId = `LV-${new Date().getFullYear()}-${(leaveApplications.length + 1).toString().padStart(4, '0')}`;
    const newApp: LeaveApplication = {
      id: newId,
      employeeId: emp.id,
      employeeName: emp.fullName,
      departmentId: emp.departmentId,
      departmentName: emp.departmentId,
      position: emp.jobTitle,
      leaveType: appData.leaveType,
      startDate: appData.startDate,
      endDate: appData.endDate,
      totalDays: appData.totalDays,
      isHalfDay: false,
      reason: appData.reason,
      contactDuringLeave: appData.contactDuringLeave,
      handoverToEmployeeId: appData.handoverToEmployeeId,
      status: 'PENDING_DEPT_HEAD', // Stage 1 completes -> Sent to Dept Head
      approvalHistory: [],
      submittedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setLeaveApplications(prev => [newApp, ...prev]);
    saveToFirestore('leaveApplications', newApp);
    logAudit('LEAVE', 'SUBMIT_LEAVE', `Employee ${emp.fullName} submitted ${appData.leaveType} for ${appData.totalDays} days. Status: Pending Department Head.`, newId);

    // Notify Dept Head
    const notif: NotificationItem = {
      id: `NOTIF-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`,
      recipientRole: 'DEPT_HEAD',
      title: 'New Leave Application for Review',
      message: `${emp.fullName} requested ${appData.totalDays} days ${appData.leaveType} (${appData.startDate} to ${appData.endDate}).`,
      type: 'LEAVE_APPROVAL',
      linkModule: 'leave',
      read: false,
      createdAt: new Date().toISOString()
    };
    setNotifications(prev => [notif, ...prev]);

    return { success: true, message: `Leave application ${newId} submitted successfully and routed to Department Head.` };
  };

  // Sequential 4-Stage Approval Workflow
  const processLeaveApproval = (
    applicationId: string, 
    action: 'APPROVE' | 'REJECT' | 'RETURN', 
    comment: string
  ): { success: boolean; message: string } => {
    const app = leaveApplications.find(a => a.id === applicationId);
    if (!app) return { success: false, message: 'Application not found.' };

    const newApprovalAction = {
      stage: currentUser.role as 'DEPT_HEAD' | 'HC' | 'GM',
      actorId: currentUser.employeeId || currentUser.id,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action,
      timestamp: new Date().toISOString(),
      comment
    };

    let nextStatus: LeaveStatus = app.status;

    // STAGE 2: Department Head
    if (app.status === 'PENDING_DEPT_HEAD') {
      if (currentUser.role !== 'DEPT_HEAD' && currentUser.role !== 'ADMIN') {
        return { success: false, message: 'Only authorized Department Head can approve this initial stage.' };
      }
      if (action === 'APPROVE') {
        nextStatus = 'PENDING_HC'; // Proceeds to HC
      } else if (action === 'REJECT') {
        nextStatus = 'REJECTED_BY_DEPT_HEAD';
      } else {
        nextStatus = 'RETURNED_TO_EMPLOYEE';
      }
    } 
    // STAGE 3: Human Capital
    else if (app.status === 'PENDING_HC') {
      if (currentUser.role !== 'HC' && currentUser.role !== 'ADMIN') {
        return { success: false, message: 'Only Human Capital (HC) can approve at Stage 2.' };
      }
      if (action === 'APPROVE') {
        nextStatus = 'PENDING_GM'; // Proceeds to GM
      } else if (action === 'REJECT') {
        nextStatus = 'REJECTED_BY_HC';
      } else {
        nextStatus = 'RETURNED_TO_EMPLOYEE';
      }
    }
    // STAGE 4: General Manager (Final Stage)
    else if (app.status === 'PENDING_GM') {
      if (currentUser.role !== 'GM' && currentUser.role !== 'ADMIN') {
        return { success: false, message: 'Only the General Manager can provide final leave sanction.' };
      }
      if (action === 'APPROVE') {
        nextStatus = 'APPROVED'; // FINAL APPROVAL!
      } else if (action === 'REJECT') {
        nextStatus = 'REJECTED_BY_GM';
      } else {
        nextStatus = 'RETURNED_TO_EMPLOYEE';
      }
    } else {
      return { success: false, message: `Application is in ${app.status} status and cannot be processed.` };
    }

    // MANDATORY BUSINESS RULE:
    // Deduct leave ONLY and EXACTLY after General Manager approves!
    let deductionTxnId: string | undefined = undefined;
    if (nextStatus === 'APPROVED') {
      deductionTxnId = `TXN-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;
      const deductionEntry: LeaveLedgerEntry = {
        id: deductionTxnId,
        employeeId: app.employeeId,
        leaveType: app.leaveType,
        transactionType: 'APPROVED_LEAVE_DEDUCTION',
        days: -app.totalDays, // Negative deduction
        effectiveDate: app.startDate,
        relatedApplicationId: app.id,
        authorizedBy: currentUser.employeeId || currentUser.id,
        authorizedByName: currentUser.name,
        referenceDocNumber: app.id,
        reason: `Final GM Approval for Leave Application ${app.id} (${app.startDate} to ${app.endDate})`,
        createdAt: new Date().toISOString()
      };

      setLeaveLedger(prev => [...prev, deductionEntry]);
      saveToFirestore('leaveLedger', deductionEntry);
      logAudit('LEAVE', 'FINAL_LEAVE_DEDUCTION', `Created deduction transaction ${deductionTxnId} for ${app.totalDays} days ${app.leaveType} for ${app.employeeName}`, deductionTxnId);
    }

    // Update the leave application record
    const updatedAppRecord: LeaveApplication = {
      ...app,
      status: nextStatus,
      deductionTransactionId: deductionTxnId || app.deductionTransactionId,
      approvalHistory: [...app.approvalHistory, newApprovalAction],
      updatedAt: new Date().toISOString()
    };
    setLeaveApplications(prev => prev.map(a => a.id === applicationId ? updatedAppRecord : a));
    saveToFirestore('leaveApplications', updatedAppRecord);

    logAudit('LEAVE', `LEAVE_${action}`, `${currentUser.role} executed ${action} on leave request ${applicationId}. New status: ${nextStatus}. Reason: ${comment || 'N/A'}`, applicationId);

    return { 
      success: true, 
      message: nextStatus === 'APPROVED' 
        ? `Application ${applicationId} fully approved by General Manager. Official deduction of ${app.totalDays} days posted to ledger.`
        : `Application ${applicationId} updated to ${nextStatus}.`
    };
  };

  const cancelLeaveApplication = (applicationId: string, reason: string): { success: boolean; message: string } => {
    const app = leaveApplications.find(a => a.id === applicationId);
    if (!app) return { success: false, message: 'Application not found.' };

    // If it was already approved and deducted, post a reversal transaction
    if (app.status === 'APPROVED' && app.deductionTransactionId) {
      const reversalTxnId = `TXN-REV-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;
      const reversalEntry: LeaveLedgerEntry = {
        id: reversalTxnId,
        employeeId: app.employeeId,
        leaveType: app.leaveType,
        transactionType: 'REVERSAL_ADJUSTMENT',
        days: app.totalDays, // Positive reversal restoring balance
        effectiveDate: new Date().toISOString().split('T')[0],
        relatedApplicationId: app.id,
        authorizedBy: currentUser.employeeId || currentUser.id,
        authorizedByName: currentUser.name,
        referenceDocNumber: app.deductionTransactionId,
        reason: `Reversal of approved leave ${app.id}. Reason: ${reason}`,
        createdAt: new Date().toISOString()
      };
      setLeaveLedger(prev => [...prev, reversalEntry]);
      saveToFirestore('leaveLedger', reversalEntry);
      logAudit('LEAVE', 'LEAVE_REVERSAL', `Reversed ${app.totalDays} days leave deduction for ${app.employeeName} (Txn: ${reversalTxnId})`, reversalTxnId);
    }

    const cancelledApp: LeaveApplication = { 
      ...app, 
      status: 'CANCELLED', 
      updatedAt: new Date().toISOString() 
    };
    setLeaveApplications(prev => prev.map(a => a.id === applicationId ? cancelledApp : a));
    saveToFirestore('leaveApplications', cancelledApp);
    logAudit('LEAVE', 'CANCEL_LEAVE', `Cancelled leave application ${applicationId}. Reason: ${reason}`, applicationId);
    return { success: true, message: `Application ${applicationId} cancelled.` };
  };

  // Training Plan Management
  const submitTrainingPlan = (planData: Omit<TrainingPlan, 'id' | 'status' | 'submittedBy' | 'submittedByName' | 'submittedAt' | 'createdAt' | 'updatedAt'>) => {
    const newId = `TRP-${new Date().getFullYear()}-${(trainingPlans.length + 1).toString().padStart(4, '0')}`;
    const newPlan: TrainingPlan = {
      ...planData,
      id: newId,
      status: 'SUBMITTED_BY_DEPT_HEAD',
      submittedBy: currentUser.employeeId || currentUser.id,
      submittedByName: currentUser.name,
      submittedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setTrainingPlans(prev => [newPlan, ...prev]);
    saveToFirestore('trainingPlans', newPlan);
    logAudit('TRAINING', 'SUBMIT_TRAINING_PLAN', `Dept Head ${currentUser.name} submitted training plan: ${planData.title}`, newId);
  };

  const updateTrainingPlanStatus = (planId: string, status: TrainingPlan['status'], notes?: string) => {
    setTrainingPlans(prev => prev.map(p => {
      if (p.id === planId) {
        const updated = { ...p, status, updatedAt: new Date().toISOString() };
        if (currentUser.role === 'HC') {
          updated.hcReviewNotes = notes;
          updated.hcReviewedBy = currentUser.name;
          updated.hcReviewedAt = new Date().toISOString();
        } else if (currentUser.role === 'GM') {
          updated.gmApprovalNotes = notes;
          updated.gmApprovedBy = currentUser.name;
          updated.gmApprovedAt = new Date().toISOString();
        }
        saveToFirestore('trainingPlans', updated);
        return updated;
      }
      return p;
    }));
    logAudit('TRAINING', 'UPDATE_PLAN_STATUS', `Updated training plan ${planId} status to ${status}`, planId);
  };

  const addTrainingSession = (sessionData: Omit<TrainingSession, 'id'>): TrainingSession => {
    const newId = `TRS-${new Date().getFullYear()}-${(trainingSessions.length + 1).toString().padStart(4, '0')}`;
    const newSession: TrainingSession = {
      ...sessionData,
      id: newId
    };
    setTrainingSessions(prev => [newSession, ...prev]);
    saveToFirestore('trainingSessions', newSession);
    logAudit('TRAINING', 'CREATE_SESSION', `Created scheduled training session: ${sessionData.title}`, newId);
    return newSession;
  };

  const recordTrainingAttendance = (data: {
    sessionId: string;
    sessionTitle: string;
    trainingScope: TrainingScope;
    photoProofUrl: string;
    notes?: string;
    location?: string;
    trainingHours?: number;
    employeeId?: string;
  }): { success: boolean; message: string; attendance?: TrainingAttendance } => {
    if (!data.photoProofUrl || data.photoProofUrl.trim() === '') {
      return { success: false, message: 'Foto bukti kehadiran (photo proof) wajib diunggah/diambil untuk absensi training.' };
    }

    const targetEmpId = data.employeeId || currentUser.employeeId || '';
    const targetEmp = employees.find(e => e.id === targetEmpId);
    const targetDept = departments.find(d => d.id === targetEmp?.departmentId);

    // Check if staff already checked in for this session
    const existing = trainingAttendance.find(a => a.sessionId === data.sessionId && a.employeeId === targetEmpId);
    if (existing) {
      return { success: false, message: `Anda sudah melakukan presensi untuk sesi training "${data.sessionTitle}".` };
    }

    const session = trainingSessions.find(s => s.id === data.sessionId);
    const hours = data.trainingHours || session?.trainingHours || 4;

    const newAttendance: TrainingAttendance = {
      id: `ATT-${new Date().getFullYear()}-${(trainingAttendance.length + 1).toString().padStart(4, '0')}`,
      sessionId: data.sessionId,
      sessionTitle: data.sessionTitle,
      trainingScope: data.trainingScope,
      employeeId: targetEmpId,
      employeeName: targetEmp?.fullName || currentUser.name,
      departmentId: targetEmp?.departmentId || currentUser.departmentId || 'DEP-FB',
      departmentName: targetDept?.name || 'Department',
      attendanceDate: CURRENT_SYSTEM_DATE,
      checkInTime: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      photoProofUrl: data.photoProofUrl,
      trainingHours: hours,
      status: 'VERIFIED',
      location: data.location || session?.venue || 'GMCC Training Center',
      notes: data.notes || 'Hadir tepat waktu dengan bukti foto verifikasi.',
      verifiedBy: currentUser.role === 'HC' || currentUser.role === 'DEPT_HEAD' || currentUser.role === 'GM' ? currentUser.name : 'System Auto-Verified with Photo Proof',
      verifiedAt: new Date().toISOString()
    };

    setTrainingAttendance(prev => [newAttendance, ...prev]);
    saveToFirestore('trainingAttendance', newAttendance);

    // Also update session participantIds if not already included
    setTrainingSessions(prev => prev.map(s => {
      if (s.id === data.sessionId && !s.participantIds.includes(targetEmpId)) {
        const updatedS = { ...s, participantIds: [...s.participantIds, targetEmpId] };
        saveToFirestore('trainingSessions', updatedS);
        return updatedS;
      }
      return s;
    }));

    logAudit('TRAINING', 'ATTENDANCE_CHECKIN', `Presensi training ${data.sessionTitle} berhasil direkam untuk ${newAttendance.employeeName} (${hours} jam)`, newAttendance.id);

    return { 
      success: true, 
      message: `Presensi training berhasil! ${hours} jam pelatihan telah tercatat ke portofolio kompetensi Anda.`,
      attendance: newAttendance 
    };
  };

  const verifyTrainingAttendance = (attendanceId: string, status: 'VERIFIED' | 'REJECTED', notes?: string) => {
    setTrainingAttendance(prev => prev.map(a => {
      if (a.id === attendanceId) {
        const updated = {
          ...a,
          status,
          notes: notes || a.notes,
          verifiedBy: currentUser.role === 'HC' || currentUser.role === 'DEPT_HEAD' || currentUser.role === 'GM' ? currentUser.name : 'System Verified',
          verifiedAt: new Date().toISOString()
        };
        saveToFirestore('trainingAttendance', updated);
        return updated;
      }
      return a;
    }));
    logAudit('TRAINING', 'VERIFY_ATTENDANCE', `Verifikasi absensi training ${attendanceId} status: ${status}`, attendanceId);
  };

  const updateAnnualKpiTarget = (targetUpdate: Partial<AnnualTrainingKpiTarget>): { success: boolean; message: string } => {
    if (currentUser.role !== 'GM' && currentUser.role !== 'ADMIN') {
      return { 
        success: false, 
        message: 'Akses Ditolak: Hanya General Manager (GM) yang berwenang menetapkan dan mengesahkan Target KPI Pelatihan Karyawan GMCC.' 
      };
    }

    const updated: AnnualTrainingKpiTarget = {
      ...annualKpiTarget,
      ...targetUpdate,
      gmEmployeeId: currentUser.employeeId || '',
      gmName: currentUser.name,
      sanctionDate: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setAnnualKpiTarget(updated);
    logAudit('TRAINING', 'UPDATE_GM_KPI_TARGET', `General Manager ${currentUser.name} mengesahkan Target KPI Pelatihan Tahunan: ${updated.annualTargetHoursPerStaff} Jam/Staf (Tahun ${updated.year})`, updated.id);

    return { 
      success: true, 
      message: `Target KPI Pelatihan GMCC Tahun ${updated.year} (${updated.annualTargetHoursPerStaff} Jam/Staf) berhasil disahkan oleh General Manager!` 
    };
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const resetDemoData = () => {
    localStorage.removeItem('gmcc_employees');
    localStorage.removeItem('gmcc_documents');
    localStorage.removeItem('gmcc_contracts');
    localStorage.removeItem('gmcc_leave_applications');
    localStorage.removeItem('gmcc_leave_ledger');
    localStorage.removeItem('gmcc_holidays');
    localStorage.removeItem('gmcc_training_plans');
    localStorage.removeItem('gmcc_training_sessions');
    localStorage.removeItem('gmcc_training_attendance');
    localStorage.removeItem('gmcc_annual_kpi_target');
    localStorage.removeItem('gmcc_audit_logs');
    localStorage.removeItem('gmcc_notifications');
    localStorage.removeItem('gmcc_departments');
    localStorage.removeItem('gmcc_user_accounts');

    setEmployees(INITIAL_EMPLOYEES);
    setDocuments(INITIAL_DOCUMENTS);
    setContracts(INITIAL_CONTRACTS);
    setLeaveApplications(INITIAL_LEAVE_APPLICATIONS);
    setLeaveLedger(INITIAL_LEAVE_LEDGER);
    setHolidays(INITIAL_HOLIDAYS);
    setTrainingPlans(INITIAL_TRAINING_PLANS);
    setTrainingSessions(INITIAL_TRAINING_SESSIONS);
    setTrainingParticipants(INITIAL_TRAINING_PARTICIPANTS);
    setTrainingAttendance(INITIAL_TRAINING_ATTENDANCE);
    setAnnualKpiTarget(INITIAL_GM_KPI_TARGET);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setNotifications(INITIAL_NOTIFICATIONS);
    setDepartments(GMCC_DEPARTMENTS);
    setUserAccounts(INITIAL_USER_ACCOUNTS);
    setCurrentUser(DEMO_USERS[0]);
  };

  const exportBackupData = () => {
    const backupPayload = {
      system: 'GMCC Human Capital Management System (HCMS)',
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      exportedBy: `${currentUser.name} (${currentUser.role})`,
      employees,
      contracts,
      documents,
      leaveApplications,
      leaveLedger,
      holidays,
      trainingPlans,
      trainingSessions,
      trainingParticipants,
      trainingAttendance,
      annualKpiTarget,
      departments,
      userAccounts,
      auditLogs
    };

    const blob = new Blob([JSON.stringify(backupPayload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const dateStr = new Date().toISOString().split('T')[0];
    link.download = `GMCC_HCMS_Database_Backup_${dateStr}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    logAudit('ADMIN', 'SYSTEM_BACKUP_EXPORTED', `Exported full database backup (${employees.length} employees, ${contracts.length} contracts)`);
  };

  const importBackupData = (jsonData: string): { success: boolean; message: string } => {
    try {
      const data = JSON.parse(jsonData);
      if (!data || typeof data !== 'object') {
        return { success: false, message: 'Format file JSON tidak valid.' };
      }
      if (Array.isArray(data.employees)) {
        setEmployees(data.employees);
        localStorage.setItem('gmcc_employees', JSON.stringify(data.employees));
      }
      if (Array.isArray(data.contracts)) {
        setContracts(data.contracts);
        localStorage.setItem('gmcc_contracts', JSON.stringify(data.contracts));
      }
      if (Array.isArray(data.documents)) {
        setDocuments(data.documents);
        localStorage.setItem('gmcc_documents', JSON.stringify(data.documents));
      }
      if (Array.isArray(data.leaveApplications)) {
        setLeaveApplications(data.leaveApplications);
        localStorage.setItem('gmcc_leave_applications', JSON.stringify(data.leaveApplications));
      }
      if (Array.isArray(data.leaveLedger)) {
        setLeaveLedger(data.leaveLedger);
        localStorage.setItem('gmcc_leave_ledger', JSON.stringify(data.leaveLedger));
      }
      if (Array.isArray(data.holidays)) {
        setHolidays(data.holidays);
        localStorage.setItem('gmcc_holidays', JSON.stringify(data.holidays));
      }
      if (Array.isArray(data.trainingPlans)) {
        setTrainingPlans(data.trainingPlans);
        localStorage.setItem('gmcc_training_plans', JSON.stringify(data.trainingPlans));
      }
      if (Array.isArray(data.trainingSessions)) {
        setTrainingSessions(data.trainingSessions);
        localStorage.setItem('gmcc_training_sessions', JSON.stringify(data.trainingSessions));
      }
      if (Array.isArray(data.trainingParticipants)) {
        setTrainingParticipants(data.trainingParticipants);
        localStorage.setItem('gmcc_training_participants', JSON.stringify(data.trainingParticipants));
      }
      if (Array.isArray(data.trainingAttendance)) {
        setTrainingAttendance(data.trainingAttendance);
        localStorage.setItem('gmcc_training_attendance', JSON.stringify(data.trainingAttendance));
      }
      if (data.annualKpiTarget && typeof data.annualKpiTarget === 'object') {
        setAnnualKpiTarget(data.annualKpiTarget);
        localStorage.setItem('gmcc_annual_kpi_target', JSON.stringify(data.annualKpiTarget));
      }
      if (Array.isArray(data.departments)) {
        setDepartments(data.departments);
        localStorage.setItem('gmcc_departments', JSON.stringify(data.departments));
      }
      if (Array.isArray(data.userAccounts)) {
        setUserAccounts(data.userAccounts);
        localStorage.setItem('gmcc_user_accounts', JSON.stringify(data.userAccounts));
      }
      if (Array.isArray(data.auditLogs)) {
        setAuditLogs(data.auditLogs);
        localStorage.setItem('gmcc_audit_logs', JSON.stringify(data.auditLogs));
      }

      logAudit('ADMIN', 'SYSTEM_BACKUP_RESTORED', `Restored database from JSON file successfully`);
      return { 
        success: true, 
        message: `Berhasil memulihkan data: ${data.employees?.length || 0} karyawan, ${data.contracts?.length || 0} kontrak, ${data.leaveLedger?.length || 0} ledger cuti.` 
      };
    } catch (err: any) {
      return { success: false, message: `Gagal membaca file: ${err.message || 'Format tidak valid'}` };
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        systemDate,
        employees,
        documents,
        contracts,
        leaveApplications,
        leaveLedger,
        holidays,
        trainingPlans,
        trainingSessions,
        trainingParticipants,
        trainingAttendance,
        annualKpiTarget,
        auditLogs,
        notifications,
        departments,
        userAccounts,
        getLeaveBalanceSummary,
        addEmployee,
        updateEmployee,
        deleteEmployee,
        uploadDocument,
        deleteDocument,
        canAccessCategory,
        canModifyCategory,
        addContract,
        updateContract,
        deleteContract,
        renewContract,
        terminateContract,
        attachSignedContract,
        getDaysUntilExpiry,
        addUserAccount,
        updateUserAccount,
        deleteUserAccount,
        resetUserPassword,
        changeAdminPassword,
        getUserAccountByEmployeeId,
        loginWithCredentials,
        isAuthenticated,
        logout,
        logoutReason,
        clearLogoutReason,
        gasWebAppUrl,
        setGasWebAppUrl,
        isSyncing,
        lastSyncTime,
        syncStatus,
        syncToGoogleAppsScript,
        addLedgerEntry,
        updateLedgerEntry,
        deleteLedgerEntry,
        getAnnualLeaveReviewData,
        addHoliday,
        updateHoliday,
        deleteHoliday,
        updateDepartment,
        submitLeaveApplication,
        processLeaveApproval,
        cancelLeaveApplication,
        submitTrainingPlan,
        updateTrainingPlanStatus,
        addTrainingSession,
        recordTrainingAttendance,
        verifyTrainingAttendance,
        updateAnnualKpiTarget,
        markNotificationAsRead,
        resetDemoData,
        exportBackupData,
        importBackupData,
        firebaseSyncStatus,
        syncAllToFirebase,
        forceServerSync
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
