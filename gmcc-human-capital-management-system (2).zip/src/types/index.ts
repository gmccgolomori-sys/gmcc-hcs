export type UserRole = 
  | 'STAFF' 
  | 'DEPT_HEAD' 
  | 'HC' 
  | 'GM' 
  | 'ADMIN' 
  | 'AUDITOR';

export type EmploymentType = 'PKWT' | 'DAILY_WORKER' | 'PKWTT';
export type EmploymentStatus = 'ACTIVE' | 'PROBATION' | 'INACTIVE' | 'EX_EMPLOYEE';

export interface Employee {
  id: string; // EMP-0001
  employeeNumber: string; // GMCC-2024-001
  fullName: string;
  preferredName: string;
  email: string;
  companyEmail: string;
  phone: string;
  departmentId: string;
  jobTitle: string;
  employmentType: EmploymentType;
  employmentStatus: EmploymentStatus;
  joinDate: string; // YYYY-MM-DD
  probationEndDate?: string;
  directSupervisorId?: string; // Department Head ID
  directSupervisorName?: string;
  location: string;
  workSchedule: string; // e.g. "5/2 Roster (Mon-Fri 08:30-17:30)" or "Shift A MICE"
  avatarUrl?: string;
  
  // Restricted fields (HC, Admin, GM, self only)
  dateOfBirth?: string;
  gender?: 'MALE' | 'FEMALE';
  nationality?: string;
  idCardType?: 'KTP' | 'PASSPORT';
  idCardNumber?: string;
  address?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelation?: string;
  notes?: string;
  
  // Specific fields for Contract Staff & Daily Worker (DW)
  dailyRate?: number; // e.g. 250000 (IDR / day for Daily Worker)
  assignedEvent?: string; // e.g. "ASEAN Maritime Ministerial Summit 2026"
  dwAgreementNumber?: string; // SPK-DW/GMCC/2026/089
  contractDurationMonths?: number; // For PKWT contract staff
  
  driveFolderId: string;
  createdAt: string;
  updatedAt: string;
}

export type PersonalFileCategory = 
  | '01_IDENTITY'
  | '02_RECRUITMENT'
  | '03_EMPLOYMENT'
  | '04_TRAINING'
  | '05_PERFORMANCE'
  | '06_ATTENDANCE_LEAVE'
  | '07_DISCIPLINE'
  | '08_COMPENSATION_BENEFITS'
  | '09_HEALTH_WORK_REQUIREMENTS'
  | '10_EXIT';

export interface PersonalFileCategoryMeta {
  code: PersonalFileCategory;
  folderNumber: string;
  name: string;
  description: string;
  isRestricted: boolean; // Only HC / Admin (e.g. Compensation, Health, Discipline investigation)
  allowedRoles: UserRole[];
}

export interface EmployeeDocument {
  id: string; // DOC-0001
  employeeId: string;
  category: PersonalFileCategory;
  title: string;
  fileName: string;
  fileSize: string;
  fileType: string; // 'pdf' | 'docx' | 'image' | 'xlsx'
  driveFileId: string;
  driveFolderId: string;
  drivePath: string; // e.g. "GMCC HUMAN CAPITAL/01 PERSONAL FILE/ACTIVE EMPLOYEE/[EMP_ID] - [EMPLOYEE_NAME]/03 Employment/PKWT_Agreement.pdf"
  uploadedBy: string;
  uploadedByName: string;
  uploadedAt: string;
  isConfidential: boolean;
  notes?: string;
  fileUrl?: string;
}

export type ContractStatus = 
  | 'DRAFT'
  | 'ACTIVE'
  | 'EXPIRING_SOON' // <= 90 days
  | 'EXPIRED'
  | 'RENEWED'
  | 'TERMINATED'
  | 'SUPERSEDED';

export interface EmploymentContract {
  id: string; // CTR-2026-0001
  contractNumber: string; // 012/GMCC-HC/PKWT/I/2026
  employeeId: string;
  employeeName: string;
  departmentId: string;
  position: string;
  employmentType: EmploymentType;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  status: ContractStatus;
  documentId?: string;
  documentName?: string;
  driveFileId?: string;
  version: number;
  termNumber?: number; // Term 1, Term 2, Term 3
  durationMonths?: number;
  signedContractFileName?: string;
  signedContractFileUrl?: string;
  signedContractUploadedAt?: string;
  signedContractUploadedBy?: string;
  renewalHistory?: {
    renewedFromContractId?: string;
    renewedAt?: string;
    renewedBy?: string;
    renewalNotes?: string;
  };
  terminationDetails?: ContractTerminationDetails;
  notes?: string;
  responsibleHc?: string;
  // Gaji / Uang Kompensasi PKWT (Sesuai PP 35/2021)
  compensationStatus?: 'DITERIMA' | 'BELUM';
  compensationAmount?: number;
  compensationPaidDate?: string;
  compensationNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export type TerminationReason = 
  | 'RESIGNATION'
  | 'END_OF_CONTRACT'
  | 'MUTUAL_AGREEMENT'
  | 'DISMISSAL_PHK'
  | 'RETIREMENT'
  | 'DISCIPLINARY'
  | 'OTHER';

export interface ContractTerminationDetails {
  terminatedAt?: string;
  terminatedBy?: string;
  effectiveDate: string;
  reason: TerminationReason;
  reasonLabel?: string;
  notes?: string;
  severanceNotes?: string;
  updateEmployeeStatus?: boolean;
}

export interface UserAccount {
  id: string; // USR-01, USR-02...
  userId: string; // User ID / Username (unique identifier for login)
  username: string; // Synced with userId
  password: string; // Password
  name: string;
  email: string;
  role: UserRole;
  employeeId?: string;
  departmentId?: string;
  status: 'ACTIVE' | 'SUSPENDED';
  createdAt: string;
  updatedAt: string;
  lastLogin?: string;
}

export type LeaveType = 
  | 'ANNUAL_LEAVE'
  | 'EXTRA_OFF'
  | 'PUBLIC_HOLIDAY_COMPENSATORY'
  | 'SPECIAL_LEAVE'
  | 'UNPAID_LEAVE';

export type LeaveStatus = 
  | 'DRAFT'
  | 'PENDING_DEPT_HEAD'
  | 'PENDING_HC'
  | 'PENDING_GM'
  | 'APPROVED'
  | 'REJECTED_BY_DEPT_HEAD'
  | 'REJECTED_BY_HC'
  | 'REJECTED_BY_GM'
  | 'RETURNED_TO_EMPLOYEE'
  | 'CANCELLED';

export interface ApprovalAction {
  stage: 'DEPT_HEAD' | 'HC' | 'GM';
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: 'APPROVE' | 'REJECT' | 'RETURN';
  timestamp: string;
  comment?: string;
}

export interface LeaveApplication {
  id: string; // LV-2026-0001
  employeeId: string;
  employeeName: string;
  departmentId: string;
  departmentName: string;
  position: string;
  leaveType: LeaveType;
  startDate: string;
  endDate: string;
  totalDays: number;
  isHalfDay: boolean;
  halfDayPeriod?: 'FIRST_HALF' | 'SECOND_HALF';
  reason: string;
  contactDuringLeave?: string;
  handoverToEmployeeId?: string;
  handoverToEmployeeName?: string;
  attachmentId?: string;
  attachmentName?: string;
  
  status: LeaveStatus;
  approvalHistory: ApprovalAction[];
  
  // Ledger link - created ONLY upon final GM approval
  deductionTransactionId?: string;
  
  submittedAt: string;
  updatedAt: string;
}

export type LedgerTransactionType = 
  | 'OPENING_BALANCE'
  | 'ANNUAL_ENTITLEMENT_CREDIT'
  | 'CARRY_FORWARD_CREDIT'
  | 'OVERTIME_EXTRA_OFF_CREDIT'
  | 'HOLIDAY_DUTY_CREDIT'
  | 'APPROVED_LEAVE_DEDUCTION'
  | 'EXPIRY_DEDUCTION'
  | 'REVERSAL_ADJUSTMENT'
  | 'CORRECTION_ADJUSTMENT';

export interface LeaveLedgerEntry {
  id: string; // TXN-0001
  employeeId: string;
  leaveType: LeaveType;
  transactionType: LedgerTransactionType;
  days: number; // positive for credit, negative for debit
  effectiveDate: string;
  expiryDate?: string; // For Extra Off or carry-forward
  relatedApplicationId?: string; // If linked to an approved leave
  relatedApprovalId?: string;
  authorizedBy: string;
  authorizedByName: string;
  referenceDocNumber?: string;
  reason: string;
  createdAt: string;
}

export interface LeaveBalanceSummary {
  employeeId: string;
  leaveType: LeaveType;
  openingBalance: number;
  totalCredits: number;
  approvedUsage: number;
  adjustments: number;
  expiredCredits: number;
  availableBalance: number; // Valid Credits - Valid Deductions - Expired + Adjustments
  pendingReservation: number; // Pending applications currently awaiting approval
  projectedBalance: number; // Available - Pending
}

export interface PublicHoliday {
  id: string;
  date: string;
  name: string;
  type: 'NATIONAL' | 'COLLECTIVE_LEAVE' | 'COMPANY_SPECIAL';
  isOfficial: boolean;
  notes?: string;
}

export type TrainingPlanStatus = 
  | 'DRAFT'
  | 'SUBMITTED_BY_DEPT_HEAD'
  | 'RETURNED_BY_HC'
  | 'CONSOLIDATED_BY_HC'
  | 'SUBMITTED_TO_GM'
  | 'APPROVED_BY_GM'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'CANCELLED';

export type TrainingScope = 'DEPARTMENTAL' | 'GENERIC_ALL_STAFF';

export interface TrainingPlan {
  id: string; // TRP-2026-0001
  title: string;
  departmentId: string;
  departmentName: string;
  trainingScope: TrainingScope; // Departmental vs Generic all staff
  category: string; // Manual category entered by Dept Head / HC
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  objectives: string;
  targetAudience: string;
  estimatedParticipants: number;
  estimatedCost: number; // in IDR
  proposedStartDate: string;
  proposedEndDate: string;
  startTime?: string;
  endTime?: string;
  trainingHours: number; // e.g. 4, 8, 16 hours
  providerType: 'INTERNAL_TRAINER' | 'EXTERNAL_VENDOR';
  trainerName?: string;
  status: TrainingPlanStatus;
  submittedBy: string;
  submittedByName: string;
  submittedAt?: string;
  hcReviewNotes?: string;
  hcReviewedBy?: string;
  hcReviewedAt?: string;
  gmApprovalNotes?: string;
  gmApprovedBy?: string;
  gmApprovedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TrainingSession {
  id: string; // TRS-2026-0001
  planId: string;
  title: string;
  departmentId: string;
  trainingScope: TrainingScope;
  sessionDate: string;
  startTime: string;
  endTime: string;
  trainingHours: number;
  venue: string; // e.g. "GMCC Flores Ballroom B"
  instructor: string;
  actualCost: number;
  status: 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
  participantIds: string[];
}

export interface TrainingParticipantRecord {
  id: string; // TPA-0001
  sessionId: string;
  employeeId: string;
  employeeName: string;
  departmentName: string;
  attended: boolean;
  preTestScore?: number;
  postTestScore?: number;
  passed: boolean;
  certificateNumber?: string;
  certificateDocumentId?: string;
  feedbackSubmitted: boolean;
  feedbackComments?: string;
}

export interface TrainingAttendance {
  id: string; // ATT-2026-0001
  planId?: string;
  sessionId: string;
  sessionTitle: string;
  trainingScope: TrainingScope;
  employeeId: string;
  employeeName: string;
  departmentId: string;
  departmentName: string;
  attendanceDate: string;
  checkInTime: string;
  photoProofUrl: string; // Mandatory proof image (data url or image path)
  trainingHours: number;
  status: 'VERIFIED' | 'PENDING' | 'REJECTED';
  location: string;
  notes?: string;
  verifiedBy?: string;
  verifiedAt?: string;
}

export interface AnnualTrainingKpiTarget {
  id: string;
  year: number;
  annualTargetHoursPerStaff: number; // e.g. 20 hours / year
  gmEmployeeId: string;
  gmName: string;
  sanctionDate: string;
  status: 'ACTIVE' | 'ARCHIVED';
  strategicObjectives: string;
  notes: string;
  departmentTargets?: {
    departmentId: string;
    departmentName: string;
    targetHoursPerStaff: number;
  }[];
  updatedAt: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  headEmployeeId: string;
  headName: string;
  totalStaff: number;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  module: 'EMPLOYEE' | 'PERSONAL_FILE' | 'CONTRACT' | 'LEAVE' | 'TRAINING' | 'ADMIN' | 'AUTH';
  targetId?: string;
  description: string;
  ipAddress?: string;
}

export interface NotificationItem {
  id: string;
  recipientEmployeeId?: string;
  recipientRole?: UserRole;
  title: string;
  message: string;
  type: 'CONTRACT_EXPIRY' | 'LEAVE_APPROVAL' | 'TRAINING_PLAN' | 'SYSTEM';
  linkModule?: string;
  read: boolean;
  createdAt: string;
}

export interface EmployeeLeaveReviewReport {
  employee: Employee;
  contract?: EmploymentContract;
  year: number;
  entitlementDays: number; // Hak Cuti tahun ini (Total Credits / Prorate Berjalan)
  proratedAccruedDays: number; // Hak Cuti Prorate Berjalan (1 hari/bulan masa kerja s/d bulan berjalan)
  proratedRemainingDays: number; // Sisa Cuti Prorate Berjalan (Prorated - Taken)
  takenDays: number; // Sudah Diambil (Approved usage)
  remainingDays: number; // Sisa Cuti tahun ini (Entitlement - Taken + Adjustments)
  pendingDays: number; // Sedang diajukan (Pending approvals)
  previousYearCarryForward: number; // Sisa carry forward dari tahun sebelumnya
  totalBalanceAL: number; // Total Balance AL (Akumulasi carry forward tahun sebelumnya + hak prorate berjalan tahun ini - diambil)
  totalBalanceALExplanation?: string; // Penjelasan formula Total Balance AL
  nextYearEntitlement: number; // Hak Cuti tahun berikutnya
  nextYearCarryForward: number; // Sisa cuti yang dapat di-carry forward
  nextYearProjectedTotal: number; // Proyeksi total saldo tahun berikutnya
  prorateMonths?: number; // Jumlah bulan aktif bekerja tahun berjalan
  prorateExplanation?: string; // Penjelasan formula perhitungan prorate
  asOfMonth?: number; // Bulan cut-off prorate berjalan (misal 10 untuk Oktober)
  asOfMonthName?: string; // Nama bulan cut-off (e.g. "Oktober")
}

