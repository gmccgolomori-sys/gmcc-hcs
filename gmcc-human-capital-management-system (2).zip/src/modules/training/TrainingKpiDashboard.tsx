import React, { useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  BarChart3, 
  Target, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  Users, 
  Clock, 
  Award, 
  ShieldCheck, 
  Building, 
  Layers, 
  Calendar,
  Sparkles,
  ArrowUpRight,
  PieChart
} from 'lucide-react';

interface Props {
  onGoToGmTargetTab: () => void;
  onGoToReportTab: () => void;
}

export const TrainingKpiDashboard: React.FC<Props> = ({ 
  onGoToGmTargetTab,
  onGoToReportTab
}) => {
  const { 
    employees, 
    departments, 
    trainingAttendance, 
    annualKpiTarget, 
    currentUser,
    trainingPlans 
  } = useApp();

  // Metrics computation
  const stats = useMemo(() => {
    const totalStaff = employees.length;
    const targetHoursPerStaff = annualKpiTarget.annualTargetHoursPerStaff || 20;
    const companyTotalTargetHours = totalStaff * targetHoursPerStaff;

    // Sum all verified training attendance hours
    const verifiedAttendances = trainingAttendance.filter(a => a.status === 'VERIFIED');
    const totalCompletedHours = verifiedAttendances.reduce((acc, a) => acc + (a.trainingHours || 0), 0);

    const genericHours = verifiedAttendances
      .filter(a => a.trainingScope === 'GENERIC_ALL_STAFF')
      .reduce((acc, a) => acc + (a.trainingHours || 0), 0);

    const deptHours = verifiedAttendances
      .filter(a => a.trainingScope === 'DEPARTMENTAL')
      .reduce((acc, a) => acc + (a.trainingHours || 0), 0);

    const companyAchievementRate = companyTotalTargetHours > 0
      ? Math.round((totalCompletedHours / companyTotalTargetHours) * 100)
      : 0;

    // Per department performance
    const deptPerformance = departments.map(dept => {
      const deptStaff = employees.filter(e => e.departmentId === dept.id);
      const staffIds = deptStaff.map(e => e.id);
      
      const deptTargetPerStaff = annualKpiTarget.departmentTargets?.find(d => d.departmentId === dept.id)?.targetHoursPerStaff || targetHoursPerStaff;
      const deptTotalTarget = deptStaff.length * deptTargetPerStaff;

      const deptCompletedHours = verifiedAttendances
        .filter(a => staffIds.includes(a.employeeId))
        .reduce((acc, a) => acc + (a.trainingHours || 0), 0);

      const deptRate = deptTotalTarget > 0 ? Math.round((deptCompletedHours / deptTotalTarget) * 100) : 0;

      return {
        department: dept,
        staffCount: deptStaff.length,
        targetPerStaff: deptTargetPerStaff,
        totalTargetHours: deptTotalTarget,
        completedHours: deptCompletedHours,
        achievementRate: deptRate,
        isAhead: deptRate >= 100
      };
    });

    // Staff Distribution
    let tier100Plus = 0; // >=100%
    let tier75To99 = 0;  // 75-99%
    let tier50To74 = 0;  // 50-74%
    let tierBelow50 = 0; // <50%

    employees.forEach(emp => {
      const empAttendances = verifiedAttendances.filter(a => a.employeeId === emp.id);
      const empHours = empAttendances.reduce((sum, a) => sum + (a.trainingHours || 0), 0);
      const target = annualKpiTarget.departmentTargets?.find(d => d.departmentId === emp.departmentId)?.targetHoursPerStaff || targetHoursPerStaff;
      const pct = target > 0 ? (empHours / target) * 100 : 0;

      if (pct >= 100) tier100Plus++;
      else if (pct >= 75) tier75To99++;
      else if (pct >= 50) tier50To74++;
      else tierBelow50++;
    });

    // Category Distribution
    const categoryCounts: Record<string, number> = {
      HOSPITALITY_SERVICE: 0,
      MICE_OPERATION: 0,
      SAFETY_SECURITY: 0,
      TECHNICAL_FACILITY: 0,
      COMPLIANCE: 0,
      LEADERSHIP: 0
    };

    trainingPlans.forEach(p => {
      if (categoryCounts[p.category] !== undefined) {
        categoryCounts[p.category] += p.trainingHours || 4;
      }
    });

    return {
      totalStaff,
      targetHoursPerStaff,
      companyTotalTargetHours,
      totalCompletedHours,
      genericHours,
      deptHours,
      companyAchievementRate,
      deptPerformance,
      tier100Plus,
      tier75To99,
      tier50To74,
      tierBelow50,
      categoryCounts
    };
  }, [employees, departments, trainingAttendance, annualKpiTarget, trainingPlans]);

  const CATEGORY_LABELS: Record<string, { label: string; color: string }> = {
    HOSPITALITY_SERVICE: { label: 'Hospitality & Service Excellence', color: 'bg-emerald-500 text-white' },
    MICE_OPERATION: { label: 'MICE & Summit Operations', color: 'bg-blue-500 text-white' },
    SAFETY_SECURITY: { label: 'Safety, Security & Basarnas', color: 'bg-rose-500 text-white' },
    TECHNICAL_FACILITY: { label: 'Technical & Facility Systems', color: 'bg-amber-500 text-white' },
    COMPLIANCE: { label: 'HACCP & Food Hygiene Compliance', color: 'bg-indigo-500 text-white' },
    LEADERSHIP: { label: 'Leadership & Supervisory', color: 'bg-purple-500 text-white' }
  };

  return (
    <div className="space-y-6">
      {/* Top Hero Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 text-white rounded-2xl p-6 shadow-lg border border-emerald-900/50">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                General Manager Sanctioned KPI · Tahun {annualKpiTarget.year}
              </span>
              <span className="text-xs text-slate-400">
                Disahkan oleh GM Bambang Wijaya, CHA
              </span>
            </div>
            <h1 className="text-2xl font-black tracking-tight text-white">
              Training Hours vs Target KPI Dashboard
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Monitoring real-time pemenuhan jam pelatihan karyawan GMCC terhadap target formal yang ditetapkan oleh General Manager.
            </p>
          </div>

          {/* Quick Action Button for GM KPI Target */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={onGoToReportTab}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-white hover:bg-slate-100 rounded-xl shadow-xs transition-colors"
            >
              <BarChart3 className="w-4 h-4 text-emerald-700" />
              Lihat Matriks Laporan
            </button>
            <button
              onClick={onGoToGmTargetTab}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all border border-emerald-500"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-200" />
              {currentUser.role === 'GM' ? 'Kelola / Sahkan Target KPI (GM)' : 'Lihat Dokumen Target GM'}
            </button>
          </div>
        </div>

        {/* 4 Executive KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6 pt-5 border-t border-slate-700/60">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/10">
            <div className="flex items-center justify-between text-slate-300 text-xs mb-1">
              <span>Target Tahunan GM</span>
              <Target className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black font-mono text-emerald-400">
              {annualKpiTarget.annualTargetHoursPerStaff} Jam / Staf
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Total Kuota: {stats.companyTotalTargetHours} Jam Perusahaan
            </span>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/10">
            <div className="flex items-center justify-between text-slate-300 text-xs mb-1">
              <span>Realisasi Jam Pelatihan</span>
              <Clock className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-black font-mono text-blue-300">
              {stats.totalCompletedHours} Jam
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Tercatat dari presensi foto proof
            </span>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/10">
            <div className="flex items-center justify-between text-slate-300 text-xs mb-1">
              <span>Tingkat Capaian GMCC</span>
              <TrendingUp className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black font-mono text-white">
              {stats.companyAchievementRate}%
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              Progress akumulatif tahun berjalan
            </span>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/10">
            <div className="flex items-center justify-between text-slate-300 text-xs mb-1">
              <span>Staf Lulus Target KPI</span>
              <Users className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black font-mono text-emerald-300">
              {stats.tier100Plus} / {stats.totalStaff} Staf
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              {Math.round((stats.tier100Plus / stats.totalStaff) * 100)}% Karyawan penuhi kuota
            </span>
          </div>
        </div>
      </div>

      {/* Grid: Department Performance vs Target & Training Scope Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Department Benchmark Comparison */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Building className="w-4 h-4 text-emerald-700" />
                Capaian Jam Pelatihan per Departemen vs Target KPI
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Perbandingan jam pelatihan terlaksana terhadap kuota masing-masing departemen.
              </p>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {stats.deptPerformance.length} Departemen
            </span>
          </div>

          <div className="space-y-4 pt-1">
            {stats.deptPerformance.map(dp => (
              <div key={dp.department.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-800">{dp.department.name}</span>
                    <span className="text-[10px] text-slate-400">({dp.staffCount} Staf)</span>
                    {dp.achievementRate >= 100 && (
                      <span className="px-1.5 py-0.2 bg-emerald-100 text-emerald-800 font-bold text-[9px] rounded-sm">
                        TARGET TERCAPAI
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 font-mono">
                    <span className="font-bold text-slate-900">{dp.completedHours} / {dp.totalTargetHours} Jam</span>
                    <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                      dp.achievementRate >= 100 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : dp.achievementRate >= 50 
                          ? 'bg-blue-100 text-blue-800' 
                          : 'bg-amber-100 text-amber-800'
                    }`}>
                      {dp.achievementRate}%
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden flex">
                  <div 
                    className={`h-full rounded-full transition-all duration-700 ${
                      dp.achievementRate >= 100 
                        ? 'bg-emerald-600' 
                        : dp.achievementRate >= 50 
                          ? 'bg-blue-600' 
                          : 'bg-amber-500'
                    }`}
                    style={{ width: `${Math.min(dp.achievementRate, 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Training Scope Breakdown (Generic vs Departmental) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-700" />
              Komposisi Pelatihan (Training Scope)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Distribusi jam generic all staff vs departmental
            </p>
          </div>

          <div className="space-y-4">
            {/* Generic Training Card */}
            <div className="bg-purple-50/70 border border-purple-200 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-purple-950 text-xs">Generic Training (All Staff)</span>
                <span className="text-xs font-mono font-bold text-purple-900 bg-purple-100 px-2 py-0.5 rounded">
                  {stats.genericHours} Jam
                </span>
              </div>
              <p className="text-[11px] text-purple-800 leading-relaxed">
                Pelatihan wajib seluruh karyawan (Hospitality Excellence, Evakuasi Kebakaran & Basarnas, Budaya Kerja).
              </p>
              <div className="w-full h-2 bg-purple-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-purple-700 rounded-full"
                  style={{ width: `${stats.totalCompletedHours > 0 ? (stats.genericHours / stats.totalCompletedHours) * 100 : 50}%` }}
                />
              </div>
            </div>

            {/* Departmental Training Card */}
            <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-blue-950 text-xs">Departmental Training</span>
                <span className="text-xs font-mono font-bold text-blue-900 bg-blue-100 px-2 py-0.5 rounded">
                  {stats.deptHours} Jam
                </span>
              </div>
              <p className="text-[11px] text-blue-800 leading-relaxed">
                Pelatihan spesifik divisi (HACCP Kitchen, Yamaha Sound Console, Diplomatic VIP Protocol).
              </p>
              <div className="w-full h-2 bg-blue-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-700 rounded-full"
                  style={{ width: `${stats.totalCompletedHours > 0 ? (stats.deptHours / stats.totalCompletedHours) * 100 : 50}%` }}
                />
              </div>
            </div>

            {/* Note on Parallel Schedules */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-[11px] text-slate-600 space-y-1">
              <span className="font-bold text-slate-800 block">Jadwal Sesi Paralel:</span>
              <p>
                Sistem mendukung pelaksanaan training pada <strong>hari dan jam yang sama</strong> antara generic training dan training departemen.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Staff KPI Achievement Distribution & Training Category Distribution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Staff Achievement Tier Distribution */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-700" />
              Distribusi Karyawan Berdasarkan Capaian Target KPI
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Kategorisasi {stats.totalStaff} karyawan terhadap kuota {annualKpiTarget.annualTargetHoursPerStaff} jam pelatihan.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-3.5">
              <div className="flex items-center justify-between text-xs font-semibold text-emerald-800">
                <span>Target Tercapai (100%+)</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-bold font-mono text-emerald-950 mt-1">
                {stats.tier100Plus} Staf
              </div>
              <span className="text-[10px] text-emerald-700 font-medium">
                {Math.round((stats.tier100Plus / stats.totalStaff) * 100)}% dari total karyawan
              </span>
            </div>

            <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-3.5">
              <div className="flex items-center justify-between text-xs font-semibold text-blue-800">
                <span>On-Track (75% - 99%)</span>
                <Clock className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-2xl font-bold font-mono text-blue-950 mt-1">
                {stats.tier75To99} Staf
              </div>
              <span className="text-[10px] text-blue-700 font-medium">
                {Math.round((stats.tier75To99 / stats.totalStaff) * 100)}% dari total karyawan
              </span>
            </div>

            <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3.5">
              <div className="flex items-center justify-between text-xs font-semibold text-amber-800">
                <span>Sedang Berjalan (50% - 74%)</span>
                <TrendingUp className="w-4 h-4 text-amber-600" />
              </div>
              <div className="text-2xl font-bold font-mono text-amber-950 mt-1">
                {stats.tier50To74} Staf
              </div>
              <span className="text-[10px] text-amber-700 font-medium">
                {Math.round((stats.tier50To74 / stats.totalStaff) * 100)}% dari total karyawan
              </span>
            </div>

            <div className="bg-rose-50/70 border border-rose-200 rounded-xl p-3.5">
              <div className="flex items-center justify-between text-xs font-semibold text-rose-800">
                <span>Perlu Percepatan (&lt; 50%)</span>
                <AlertTriangle className="w-4 h-4 text-rose-600" />
              </div>
              <div className="text-2xl font-bold font-mono text-rose-950 mt-1">
                {stats.tierBelow50} Staf
              </div>
              <span className="text-[10px] text-rose-700 font-medium">
                {Math.round((stats.tierBelow50 / stats.totalStaff) * 100)}% dari total karyawan
              </span>
            </div>
          </div>
        </div>

        {/* Training Modules by Domain */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-blue-700" />
              Distribusi Jam Pelatihan per Kategori Kompetensi
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Rincian program pelatihan berdasarkan klaster keahlian MICE & Hospitality.
            </p>
          </div>

          <div className="space-y-3 pt-1">
            {Object.entries(CATEGORY_LABELS).map(([key, config]) => {
              const hours = stats.categoryCounts[key] || 0;
              const maxHours = 20;
              const pct = Math.min(Math.round((hours / maxHours) * 100), 100);

              return (
                <div key={key} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-700">{config.label}</span>
                    <span className="font-mono font-bold text-slate-900">{hours} Jam</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${config.color.split(' ')[0]}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
