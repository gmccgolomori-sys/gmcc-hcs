import React, { useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Department, TrainingAttendance, Employee, AnnualTrainingKpiTarget } from '../../types';
import { 
  Printer, 
  X, 
  Download, 
  Building2, 
  Calendar, 
  CheckCircle2, 
  Award,
  Layers,
  Sparkles,
  TrendingUp,
  Clock
} from 'lucide-react';

export interface EmployeeTrainingReportItem {
  employee: Employee;
  departmentName: string;
  genericHours: number;
  deptHours: number;
  totalActualHours: number;
  targetHours: number;
  achievementPercentage: number;
  status: 'ACHIEVED' | 'ON_TRACK' | 'BEHIND';
  attendances: TrainingAttendance[];
  sessionCount: number;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  year: number;
  reportData: EmployeeTrainingReportItem[];
  departments: Department[];
  deptFilterId?: string;
  annualKpiTarget: AnnualTrainingKpiTarget;
  printedByName: string;
  printedByRole: string;
}

export const TrainingReportPrintModal: React.FC<Props> = ({
  isOpen,
  onClose,
  year,
  reportData,
  departments,
  deptFilterId,
  annualKpiTarget,
  printedByName,
  printedByRole
}) => {
  const printAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      document.body.classList.add('print-modal-active');
    } else {
      document.body.classList.remove('print-modal-active');
    }
    return () => {
      document.body.classList.remove('print-modal-active');
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const currentDeptName = deptFilterId && deptFilterId !== 'ALL'
    ? departments.find(d => d.id === deptFilterId)?.name || deptFilterId
    : 'Seluruh Departemen (Company-Wide)';

  const currentDateStr = new Date().toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const currentTimeStr = new Date().toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    timeZoneName: 'short'
  });

  // Analytics
  const totalStaff = reportData.length;
  const totalHoursDelivered = reportData.reduce((sum, r) => sum + r.totalActualHours, 0);
  const avgHours = totalStaff > 0 ? (totalHoursDelivered / totalStaff).toFixed(1) : '0';
  const staffAchieved = reportData.filter(r => r.status === 'ACHIEVED').length;
  const staffOnTrack = reportData.filter(r => r.status === 'ON_TRACK').length;
  const overallAchievePct = totalStaff > 0 ? Math.round((staffAchieved / totalStaff) * 100) : 0;

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    const headers = [
      'No',
      'NIK',
      'Nama Karyawan',
      'Departemen',
      'Jabatan',
      'Tipe Hubungan Kerja',
      'Generic Training (Jam)',
      'Departmental Training (Jam)',
      'Total Jam Diikuti',
      'Target KPI Tahunan (Jam)',
      '% Capaian KPI',
      'Status Evaluasi'
    ];

    const rows = reportData.map((item, index) => [
      index + 1,
      `"${item.employee.employeeNumber || item.employee.id}"`,
      `"${item.employee.fullName}"`,
      `"${item.departmentName}"`,
      `"${item.employee.jobTitle}"`,
      `"${item.employee.employmentType}"`,
      item.genericHours,
      item.deptHours,
      item.totalActualHours,
      item.targetHours,
      `"${item.achievementPercentage}%"`,
      `"${item.status === 'ACHIEVED' ? 'Tercapai (>=100%)' : item.status === 'ON_TRACK' ? 'On-Track (>=50%)' : 'Di Bawah Target'}"`
    ].join(','));

    // Excel UTF-8 BOM
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `GMCC_Laporan_Training_Hours_${year}_${deptFilterId || 'ALL'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return createPortal(
    <div className="gmcc-print-portal fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto print:static print:p-0 print:m-0 print:bg-white print:overflow-visible">
      <div className="gmcc-print-sheet bg-white rounded-2xl shadow-2xl max-w-6xl w-full max-h-[95vh] flex flex-col overflow-hidden border border-slate-300 print:max-h-none print:shadow-none print:border-none print:w-full print:overflow-visible print:rounded-none">
        
        {/* Top Control Bar (Screen Only - Hidden during print) */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0 print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center">
              <Printer className="w-4 h-4 text-emerald-200" />
            </div>
            <div>
              <h3 className="font-bold text-sm tracking-tight text-white flex items-center gap-2">
                <span>Pratinjau Cetak Laporan Jam Pelatihan & KPI GMCC</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  Target KPI: {annualKpiTarget.annualTargetHoursPerStaff} Jam/Staf
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Format Cetak Resmi A4 Landscape · Full Width Tanpa Navigasi Samping
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
              title="Unduh data dalam format file Excel / CSV rapi"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export Excel / CSV</span>
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak Sekarang (Print / PDF)</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div 
          ref={printAreaRef}
          id="gmcc-training-report-print"
          className="gmcc-printable-area p-6 sm:p-8 overflow-y-auto space-y-5 text-slate-900 bg-white font-sans text-xs print:p-0 print:overflow-visible print:m-0 print:w-full"
        >
          {/* GMCC Formal Letterhead */}
          <div className="border-b-2 border-slate-900 pb-3 flex items-center justify-between">
            <div className="space-y-0.5">
              <h1 className="text-xl font-black tracking-tight text-emerald-950 uppercase">
                Golo Mori Convention Center (GMCC)
              </h1>
              <p className="text-[10px] text-slate-500">
                Kawasan Pariwisata The Golo Mori by ITDC, Golo Mori, Labuan Bajo, Kabupaten Manggarai Barat, Nusa Tenggara Tim. 86763
              </p>
            </div>

            <div className="text-right text-[10px] space-y-0.5 border-l border-slate-300 pl-4">
              <div className="font-bold text-slate-900 text-[11px] uppercase tracking-wider">
                Human Capital Department
              </div>
              <div className="text-slate-600 font-mono">
                Doc Ref: GMCC-HC/TRN-REP/{year}
              </div>
              <div className="text-slate-500">
                Dicetak: {currentDateStr}, {currentTimeStr}
              </div>
              <div className="text-emerald-800 font-semibold">
                Oleh: {printedByName} ({printedByRole})
              </div>
            </div>
          </div>

          {/* Report Title & Metadata Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 border border-slate-300 p-3 rounded-lg print:border-slate-400">
            <div>
              <h2 className="text-sm font-bold text-slate-950 tracking-tight uppercase">
                Laporan Realisasi Jam Pelatihan & Target KPI Tahunan Karyawan
              </h2>
              <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-600">
                <span>Tahun Anggaran: <strong className="text-slate-900">{year}</strong></span>
                <span>•</span>
                <span>Departemen: <strong className="text-emerald-900">{currentDeptName}</strong></span>
                <span>•</span>
                <span>SK Target GM: <strong className="text-blue-900">{annualKpiTarget.annualTargetHoursPerStaff} Jam/Staf</strong></span>
              </div>
            </div>

            <div className="flex items-center gap-4 text-center">
              <div className="border-r border-slate-300 pr-3">
                <span className="text-[10px] text-slate-500 block">Total Staf</span>
                <span className="font-black text-slate-900 text-sm">{totalStaff}</span>
              </div>
              <div className="border-r border-slate-300 pr-3">
                <span className="text-[10px] text-slate-500 block">Jam Terlaksana</span>
                <span className="font-black text-emerald-800 text-sm">{totalHoursDelivered} Jam</span>
              </div>
              <div className="border-r border-slate-300 pr-3">
                <span className="text-[10px] text-slate-500 block">Rata-rata/Staf</span>
                <span className="font-black text-blue-900 text-sm">{avgHours} Jam</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block">Capaian Target</span>
                <span className="font-black text-emerald-700 text-sm">{overallAchievePct}%</span>
              </div>
            </div>
          </div>

          {/* Clean Official Table */}
          <div className="border border-slate-300 rounded-lg overflow-hidden print:border-slate-400">
            <table className="w-full border-collapse text-left text-[10px]">
              <thead>
                <tr className="bg-slate-800 text-white font-bold text-[9.5px] uppercase tracking-wider print:bg-slate-900">
                  <th className="py-2.5 px-2 text-center w-8 border-r border-slate-700">No</th>
                  <th className="py-2.5 px-2.5 border-r border-slate-700">NIK</th>
                  <th className="py-2.5 px-3 border-r border-slate-700">Nama Karyawan</th>
                  <th className="py-2.5 px-3 border-r border-slate-700">Departemen</th>
                  <th className="py-2.5 px-3 border-r border-slate-700">Jabatan</th>
                  <th className="py-2.5 px-2 border-r border-slate-700 text-center">Tipe</th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-700">Generic (Jam)</th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-700">Dept (Jam)</th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-700 bg-slate-900">Total Aktual</th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-700">Target KPI</th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-700">% Capaian</th>
                  <th className="py-2.5 px-2.5 text-center">Status Evaluasi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {reportData.length === 0 ? (
                  <tr>
                    <td colSpan={12} className="py-8 text-center text-slate-400 italic">
                      Tidak ada rekaman data pelatihan pada filter yang dipilih.
                    </td>
                  </tr>
                ) : (
                  reportData.map((item, idx) => {
                    const emp = item.employee;
                    const isAchieved = item.status === 'ACHIEVED';
                    const isOnTrack = item.status === 'ON_TRACK';

                    return (
                      <tr 
                        key={emp.id} 
                        className={`hover:bg-slate-50 transition-colors ${
                          idx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'
                        }`}
                      >
                        <td className="py-2 px-2 text-center font-mono text-slate-500 border-r border-slate-200">
                          {idx + 1}
                        </td>
                        <td className="py-2 px-2.5 font-mono font-bold text-slate-800 border-r border-slate-200 whitespace-nowrap">
                          {emp.employeeNumber || emp.id}
                        </td>
                        <td className="py-2 px-3 font-bold text-slate-900 border-r border-slate-200">
                          {emp.fullName}
                        </td>
                        <td className="py-2 px-3 text-slate-700 border-r border-slate-200">
                          {item.departmentName}
                        </td>
                        <td className="py-2 px-3 text-slate-600 border-r border-slate-200">
                          {emp.jobTitle}
                        </td>
                        <td className="py-2 px-2 text-center border-r border-slate-200">
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                            emp.employmentType === 'PKWT'
                              ? 'bg-amber-100 text-amber-900'
                              : emp.employmentType === 'DAILY_WORKER'
                                ? 'bg-purple-100 text-purple-900'
                                : 'bg-blue-100 text-blue-900'
                          }`}>
                            {emp.employmentType}
                          </span>
                        </td>
                        <td className="py-2 px-2 text-center font-mono text-slate-700 border-r border-slate-200">
                          {item.genericHours} Jam
                        </td>
                        <td className="py-2 px-2 text-center font-mono text-slate-700 border-r border-slate-200">
                          {item.deptHours} Jam
                        </td>
                        <td className="py-2 px-2 text-center font-mono font-bold text-emerald-950 bg-emerald-50/50 border-r border-slate-200">
                          {item.totalActualHours} Jam
                        </td>
                        <td className="py-2 px-2 text-center font-mono text-slate-700 border-r border-slate-200">
                          {item.targetHours} Jam
                        </td>
                        <td className="py-2 px-2 text-center font-mono font-bold border-r border-slate-200">
                          <span className={isAchieved ? 'text-emerald-700' : isOnTrack ? 'text-blue-700' : 'text-rose-700'}>
                            {item.achievementPercentage}%
                          </span>
                        </td>
                        <td className="py-2 px-2.5 text-center">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[9px] font-bold border ${
                            isAchieved
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : isOnTrack
                                ? 'bg-blue-100 text-blue-800 border-blue-300'
                                : 'bg-rose-100 text-rose-800 border-rose-300'
                          }`}>
                            {isAchieved ? 'Tercapai (100%+)' : isOnTrack ? 'On-Track (>=50%)' : 'Di Bawah Target'}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
              <tfoot className="bg-slate-100 border-t-2 border-slate-300 font-bold text-slate-900">
                <tr>
                  <td colSpan={6} className="py-2.5 px-3 text-right uppercase tracking-wider text-[10px]">
                    Total Realisasi Seluruh Staf:
                  </td>
                  <td className="py-2.5 px-2 text-center font-mono">
                    {reportData.reduce((sum, r) => sum + r.genericHours, 0)} Jam
                  </td>
                  <td className="py-2.5 px-2 text-center font-mono">
                    {reportData.reduce((sum, r) => sum + r.deptHours, 0)} Jam
                  </td>
                  <td className="py-2.5 px-2 text-center font-mono text-emerald-900 bg-emerald-100/70">
                    {totalHoursDelivered} Jam
                  </td>
                  <td className="py-2.5 px-2 text-center font-mono">
                    {reportData.reduce((sum, r) => sum + r.targetHours, 0)} Jam
                  </td>
                  <td className="py-2.5 px-2 text-center font-mono text-emerald-900">
                    {overallAchievePct}%
                  </td>
                  <td className="py-2.5 px-2 text-center text-[9px] text-slate-600">
                    {staffAchieved} / {totalStaff} Tercapai
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Official Signatures (3 Kolom Formal) */}
          <div className="pt-6 border-t border-slate-300 grid grid-cols-3 gap-6 text-center text-[10px] break-inside-avoid">
            <div className="space-y-14">
              <div>
                <p className="text-slate-500">Disiapkan & Diverifikasi Oleh:</p>
                <p className="font-bold text-slate-800 mt-0.5">Human Capital Officer / Admin</p>
              </div>
              <div className="border-t border-slate-400 mx-4 pt-1">
                <p className="font-bold text-slate-900">Sarah Handayani, S.Psi.</p>
                <p className="text-[9.5px] text-slate-500">HC Manager GMCC</p>
              </div>
            </div>

            <div className="space-y-14">
              <div>
                <p className="text-slate-500">Mengetahui & Menyetujui:</p>
                <p className="font-bold text-slate-800 mt-0.5">Head of Department Terkait</p>
              </div>
              <div className="border-t border-slate-400 mx-4 pt-1">
                <p className="font-bold text-slate-900">
                  {deptFilterId && deptFilterId !== 'ALL'
                    ? departments.find(d => d.id === deptFilterId)?.headName || 'Department Head'
                    : 'Para Kepala Departemen'}
                </p>
                <p className="text-[9.5px] text-slate-500">Head of Department</p>
              </div>
            </div>

            <div className="space-y-14">
              <div>
                <p className="text-slate-500">Disahkan & Ditetapkan Oleh:</p>
                <p className="font-bold text-slate-800 mt-0.5">General Manager GMCC</p>
              </div>
              <div className="border-t border-slate-400 mx-4 pt-1">
                <p className="font-bold text-slate-900">Bambang Wijaya, CHA</p>
                <p className="text-[9.5px] text-slate-500">General Manager</p>
              </div>
            </div>
          </div>

          {/* Footer Verifikasi */}
          <div className="pt-3 text-center text-[9px] text-slate-400 border-t border-slate-200">
            <span>
              Dokumen ini dihasilkan secara otomatis dan sah dari Human Capital Management System (HCMS) Golo Mori Convention Center (GMCC) Labuan Bajo.
            </span>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
