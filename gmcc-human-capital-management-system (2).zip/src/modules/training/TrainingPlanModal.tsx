import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { GMCC_DEPARTMENTS } from '../../data/categories';
import { X, Send, CheckCircle2 } from 'lucide-react';

import { TrainingScope } from '../../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const TrainingPlanModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { currentUser, submitTrainingPlan, addTrainingSession } = useApp();

  const [title, setTitle] = useState('');
  const [trainingScope, setTrainingScope] = useState<TrainingScope>('DEPARTMENTAL');
  const [departmentId, setDepartmentId] = useState(currentUser.departmentId || GMCC_DEPARTMENTS[1].id);
  const [category, setCategory] = useState<string>('Hospitality & Service Excellence');
  const [priority, setPriority] = useState<'HIGH' | 'MEDIUM' | 'LOW'>('HIGH');
  const [objectives, setObjectives] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [estimatedParticipants, setEstimatedParticipants] = useState(16);
  const [estimatedCost, setEstimatedCost] = useState(12000000); // 12jt IDR
  const [proposedStartDate, setProposedStartDate] = useState('2026-10-15');
  const [proposedEndDate, setProposedEndDate] = useState('2026-10-15');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('13:00');
  const [trainingHours, setTrainingHours] = useState(4);
  const [venue, setVenue] = useState('GMCC Flores Grand Ballroom');
  const [autoCreateSession, setAutoCreateSession] = useState(true);
  const [providerType, setProviderType] = useState<'INTERNAL_TRAINER' | 'EXTERNAL_VENDOR'>('EXTERNAL_VENDOR');
  const [trainerName, setTrainerName] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  React.useEffect(() => {
    if (trainingScope === 'GENERIC_ALL_STAFF') {
      setTargetAudience('Seluruh Karyawan GMCC (All Staff & Daily Workers)');
      setEstimatedParticipants(85);
      setVenue('GMCC Flores Grand Ballroom / Plenary');
    } else {
      if (currentUser.role === 'DEPT_HEAD' && currentUser.departmentId) {
        setDepartmentId(currentUser.departmentId);
      }
      setTargetAudience('Staf & Supervisor Departemen Terkait');
      setEstimatedParticipants(16);
    }
  }, [trainingScope, currentUser]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !objectives) return;

    const dept = GMCC_DEPARTMENTS.find(d => d.id === departmentId);
    const resolvedDeptName = trainingScope === 'GENERIC_ALL_STAFF' 
      ? 'Company-Wide (All Departments)' 
      : (dept ? dept.name : departmentId);

    submitTrainingPlan({
      title,
      departmentId: trainingScope === 'GENERIC_ALL_STAFF' ? 'DEP-HC' : departmentId,
      departmentName: resolvedDeptName,
      trainingScope,
      category,
      priority,
      objectives,
      targetAudience: targetAudience || (trainingScope === 'GENERIC_ALL_STAFF' ? 'Seluruh Karyawan GMCC' : 'Staf Departemen'),
      estimatedParticipants: Number(estimatedParticipants),
      estimatedCost: Number(estimatedCost),
      proposedStartDate,
      proposedEndDate,
      startTime,
      endTime,
      trainingHours: Number(trainingHours),
      providerType,
      trainerName: trainerName || (trainingScope === 'GENERIC_ALL_STAFF' ? 'HC Master Trainer & Hospitality Specialist' : 'TBD Certified Trainer')
    });

    if (autoCreateSession) {
      addTrainingSession({
        planId: `TRP-TEMP-${Date.now()}`,
        title,
        departmentId: trainingScope === 'GENERIC_ALL_STAFF' ? 'DEP-HC' : departmentId,
        trainingScope,
        sessionDate: proposedStartDate,
        startTime,
        endTime,
        trainingHours: Number(trainingHours),
        venue: venue || 'GMCC Training Hall',
        instructor: trainerName || 'Lead Trainer',
        actualCost: Number(estimatedCost),
        status: 'SCHEDULED',
        participantIds: []
      });
    }

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto border border-slate-200">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h3 className="font-semibold text-slate-900 text-lg">Propose Department Training Plan</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Submitted by Department Head to Human Capital for consolidation & GM sanction
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-3">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="font-semibold text-slate-900 text-base">Training Plan Submitted</h4>
            <p className="text-xs text-slate-500 mt-1">Routed to Human Capital for budget and schedule consolidation.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Training Program Title *</label>
              <input
                type="text"
                required
                placeholder="e.g. VIP Protocol & Silver Service Standards"
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600"
              />
            </div>

            {/* Training Scope Selection */}
            <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl space-y-2">
              <label className="block font-bold text-slate-800 text-xs">
                Cakupan Pelatihan (Training Scope) *
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-all ${
                  trainingScope === 'DEPARTMENTAL' 
                    ? 'bg-emerald-50/70 border-emerald-500 ring-1 ring-emerald-500' 
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}>
                  <input
                    type="radio"
                    name="scope"
                    checked={trainingScope === 'DEPARTMENTAL'}
                    onChange={() => setTrainingScope('DEPARTMENTAL')}
                    className="mt-0.5 text-emerald-600 focus:ring-emerald-500"
                  />
                  <div>
                    <span className="font-bold text-slate-900 block text-xs">Training Departemen</span>
                    <span className="text-[11px] text-slate-500 block leading-tight mt-0.5">
                      Khusus keterampilan teknis departemen tertentu (F&B, AV, Engineering, dsb).
                    </span>
                  </div>
                </label>

                <label className={`flex items-start gap-2.5 p-2.5 rounded-lg border cursor-pointer transition-all ${
                  trainingScope === 'GENERIC_ALL_STAFF' 
                    ? 'bg-purple-50/70 border-purple-500 ring-1 ring-purple-500' 
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}>
                  <input
                    type="radio"
                    name="scope"
                    checked={trainingScope === 'GENERIC_ALL_STAFF'}
                    onChange={() => setTrainingScope('GENERIC_ALL_STAFF')}
                    className="mt-0.5 text-purple-600 focus:ring-purple-500"
                  />
                  <div>
                    <span className="font-bold text-slate-900 block text-xs">Generic Training (All Staff)</span>
                    <span className="text-[11px] text-slate-500 block leading-tight mt-0.5">
                      Dihadiri seluruh staf perusahaan (Hospitality Excellence, K3, Drill, Core Values).
                    </span>
                  </div>
                </label>
              </div>

              <div className="text-[11px] text-emerald-800 bg-emerald-50/60 p-2 rounded-md border border-emerald-200/60">
                ✨ <strong>Fitur Fleksibilitas Jadwal:</strong> Training plan dan sesi dapat dibuat pada <strong>hari dan jam yang sama</strong> untuk berbagai departemen secara paralel (misal Ruang Plenary & Kitchen Lab).
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  {trainingScope === 'GENERIC_ALL_STAFF' ? 'Penyelenggara / Unit' : 'Departemen *'}
                </label>
                {trainingScope === 'GENERIC_ALL_STAFF' ? (
                  <input
                    type="text"
                    disabled
                    value="Company-Wide (All GMCC Departments)"
                    className="w-full text-xs rounded-lg border border-slate-200 px-3 py-2 bg-slate-100 text-slate-600 font-semibold"
                  />
                ) : (
                  <select
                    value={departmentId}
                    onChange={e => setDepartmentId(e.target.value)}
                    disabled={currentUser.role === 'DEPT_HEAD'}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden"
                  >
                    {GMCC_DEPARTMENTS.map(d => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>
                )}
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1 flex items-center justify-between">
                  <span>Kategori Pelatihan (Training Category) *</span>
                  <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                    Input Manual Bebas
                  </span>
                </label>
                <input
                  type="text"
                  list="training-category-list"
                  required
                  placeholder="Ketik manual kategori pelatihan (contoh: Hospitality Excellence, HACCP Food Safety, Housekeeping)..."
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                />
                <datalist id="training-category-list">
                  <option value="Hospitality & Service Excellence" />
                  <option value="HACCP & Food Hygiene Safety" />
                  <option value="Housekeeping Room Attendant Standards" />
                  <option value="MICE Summit & VIP Protocol Operations" />
                  <option value="Barista, Mixology & Wine Etiquette" />
                  <option value="Technical Facility & AV Console Tuning" />
                  <option value="Safety, Fire Evacuation & Basarnas" />
                  <option value="Leadership & Supervisory Skills" />
                  <option value="Legal & Labor Compliance" />
                </datalist>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Dept Head dapat mengetik nama kategori pelatihan khusus secara manual sesuai kebutuhan departemen.
                </p>
              </div>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Learning Objectives & Business Impact *</label>
              <textarea
                rows={3}
                required
                placeholder="Define specific competencies to acquire and expected operational outcomes..."
                value={objectives}
                onChange={e => setObjectives(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
              />
            </div>

            {/* Schedule, Venue & Hours - Kolom Tanggal Pelaksanaan & Durasi Jam Dikecilkan */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wide">
                  Jadwal & Waktu Pelaksanaan
                </span>
                <span className="text-[10px] text-slate-400">Kolom Kompak</span>
              </div>

              <div className="flex flex-wrap items-end gap-2.5">
                {/* Tanggal Pelaksanaan - Dikecilkan */}
                <div className="w-36">
                  <label className="block font-medium text-slate-700 mb-1 text-[11px]">Tanggal *</label>
                  <input
                    type="date"
                    required
                    value={proposedStartDate}
                    onChange={e => {
                      setProposedStartDate(e.target.value);
                      setProposedEndDate(e.target.value);
                    }}
                    className="w-full text-xs rounded-lg border border-slate-300 px-2 py-1.5 text-slate-900 bg-white"
                  />
                </div>

                {/* Jam Mulai - Selesai - Dikecilkan */}
                <div className="w-36">
                  <label className="block font-medium text-slate-700 mb-1 text-[11px]">Jam Pelaksanaan *</label>
                  <div className="flex items-center gap-1">
                    <input
                      type="time"
                      value={startTime}
                      onChange={e => setStartTime(e.target.value)}
                      className="w-16 text-[11px] rounded-lg border border-slate-300 px-1 py-1.5 text-slate-900 bg-white text-center"
                    />
                    <span className="text-slate-400">–</span>
                    <input
                      type="time"
                      value={endTime}
                      onChange={e => setEndTime(e.target.value)}
                      className="w-16 text-[11px] rounded-lg border border-slate-300 px-1 py-1.5 text-slate-900 bg-white text-center"
                    />
                  </div>
                </div>

                {/* Durasi Jam Pelatihan - Dikecilkan */}
                <div className="w-24">
                  <label className="block font-medium text-slate-700 mb-1 text-[11px]">Durasi Jam *</label>
                  <div className="relative">
                    <input
                      type="number"
                      min={1}
                      max={40}
                      value={trainingHours}
                      onChange={e => setTrainingHours(Number(e.target.value))}
                      className="w-full text-xs rounded-lg border border-slate-300 px-2 py-1.5 text-slate-900 bg-white font-mono font-bold text-center"
                    />
                    <span className="absolute right-1.5 top-1.5 text-[10px] text-slate-400 pointer-events-none">Jam</span>
                  </div>
                </div>

                {/* Lokasi / Venue */}
                <div className="flex-1 min-w-[170px]">
                  <label className="block font-medium text-slate-700 mb-1 text-[11px]">Lokasi / Ruangan Venue *</label>
                  <input
                    type="text"
                    required
                    placeholder="misal: GMCC Ballroom / Training Lab"
                    value={venue}
                    onChange={e => setVenue(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-2.5 py-1.5 text-slate-900 bg-white"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Target Peserta</label>
                <input
                  type="text"
                  placeholder="e.g. Banquet Captains, Supervisors"
                  value={targetAudience}
                  onChange={e => setTargetAudience(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Perkiraan Jumlah Peserta</label>
                <input
                  type="number"
                  min={1}
                  value={estimatedParticipants}
                  onChange={e => setEstimatedParticipants(Number(e.target.value))}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Estimasi Anggaran (IDR Rp) *</label>
                <input
                  type="number"
                  min={0}
                  step={500000}
                  value={estimatedCost}
                  onChange={e => setEstimatedCost(Number(e.target.value))}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden font-mono"
                />
                <span className="text-[10px] text-slate-500 mt-0.5 block">
                  Rp {estimatedCost.toLocaleString('id-ID')}
                </span>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Tingkat Prioritas</label>
                <select
                  value={priority}
                  onChange={e => setPriority(e.target.value as any)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden"
                >
                  <option value="HIGH">High Priority (Immediate Need)</option>
                  <option value="MEDIUM">Medium Priority</option>
                  <option value="LOW">Low Priority (Elective)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Tipe Instruktur / Vendor</label>
                <select
                  value={providerType}
                  onChange={e => setProviderType(e.target.value as any)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden"
                >
                  <option value="EXTERNAL_VENDOR">External Certified Vendor</option>
                  <option value="INTERNAL_TRAINER">Internal Subject Matter Expert</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Nama Trainer / Lembaga</label>
                <input
                  type="text"
                  placeholder="e.g. Indonesian Protocol Institute"
                  value={trainerName}
                  onChange={e => setTrainerName(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
                />
              </div>
            </div>

            {/* Checkbox auto session */}
            <div className="bg-emerald-50/70 border border-emerald-200 p-3 rounded-lg">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-emerald-900">
                <input
                  type="checkbox"
                  checked={autoCreateSession}
                  onChange={e => setAutoCreateSession(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span>Aktifkan langsung sesi training agar karyawan dapat melakukan presensi kehadiran (Training Attendance)</span>
              </label>
            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                Submit Plan to Human Capital
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
