import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TrainingPlan, TrainingSession, TrainingAttendance } from '../../types';
import { 
  GraduationCap, 
  Plus, 
  Search, 
  Filter, 
  Calendar, 
  Award, 
  CheckCircle2, 
  Clock, 
  Banknote, 
  ChevronRight,
  Send,
  Building,
  RotateCcw,
  BarChart3,
  FileText,
  Camera,
  Target,
  ShieldCheck,
  MapPin,
  Eye,
  UserCheck,
  Check,
  X,
  Layers
} from 'lucide-react';
import { TrainingPlanModal } from './TrainingPlanModal';
import { TrainingAttendanceModal } from './TrainingAttendanceModal';
import { TrainingReportView } from './TrainingReportView';
import { TrainingKpiDashboard } from './TrainingKpiDashboard';
import { GmKpiTargetManager } from './GmKpiTargetManager';

type TrainingTab = 'DASHBOARD' | 'REPORT' | 'ATTENDANCE' | 'PLANS' | 'SESSIONS' | 'GM_TARGET';

export const TrainingManager: React.FC = () => {
  const { 
    currentUser, 
    trainingPlans, 
    trainingSessions, 
    trainingAttendance,
    annualKpiTarget,
    updateTrainingPlanStatus,
    verifyTrainingAttendance 
  } = useApp();

  const [activeTab, setActiveTab] = useState<TrainingTab>('DASHBOARD');
  const [search, setSearch] = useState('');
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  const [isAttendanceModalOpen, setIsAttendanceModalOpen] = useState(false);
  const [sessionForAttendance, setSessionForAttendance] = useState<TrainingSession | null>(null);
  const [selectedPhotoProof, setSelectedPhotoProof] = useState<TrainingAttendance | null>(null);

  // Filter plans based on role
  const visiblePlans = trainingPlans.filter(p => {
    if (currentUser.role === 'DEPT_HEAD') {
      return p.departmentId === currentUser.departmentId || p.trainingScope === 'GENERIC_ALL_STAFF';
    }
    return true; // HC, GM, Admin, Staff, Auditor see all
  });

  const filteredPlans = visiblePlans.filter(p => {
    if (search.trim()) {
      const q = search.toLowerCase();
      return p.title.toLowerCase().includes(q) || p.departmentName.toLowerCase().includes(q);
    }
    return true;
  });

  // Calculate training analytics
  const totalBudget = trainingPlans.reduce((acc, p) => acc + p.estimatedCost, 0);
  const approvedBudget = trainingPlans.filter(p => p.status === 'APPROVED_BY_GM').reduce((acc, p) => acc + p.estimatedCost, 0);
  const totalHoursDelivered = trainingAttendance
    .filter(a => a.status === 'VERIFIED')
    .reduce((acc, a) => acc + (a.trainingHours || 0), 0);

  const handleOpenAttendance = (session?: TrainingSession) => {
    setSessionForAttendance(session || null);
    setIsAttendanceModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Human Capital</span>
            <ChevronRight className="w-3 h-3" />
            <span>Training & Employee Development</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Training Management</h1>
          <p className="text-xs text-slate-500 mt-1">
            Training plans, mandatory photo proof attendance, training hours report vs GM KPI target, and executive sanctions.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
          {/* Attendance Check-in button */}
          <button
            onClick={() => handleOpenAttendance()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors"
          >
            <Camera className="w-4 h-4" />
            Presensi Training (Wajib Foto Proof)
          </button>

          {(currentUser.role === 'DEPT_HEAD' || currentUser.role === 'HC' || currentUser.role === 'GM' || currentUser.role === 'ADMIN') && (
            <button
              onClick={() => setIsPlanModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              Propose Training Plan
            </button>
          )}
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-slate-200 flex flex-wrap items-center gap-2 sm:gap-4 overflow-x-auto pb-px">
        <button
          onClick={() => setActiveTab('DASHBOARD')}
          className={`pb-3 text-xs font-semibold transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'DASHBOARD'
              ? 'border-emerald-700 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          KPI Dashboard (Hours vs Target)
        </button>

        <button
          onClick={() => setActiveTab('REPORT')}
          className={`pb-3 text-xs font-semibold transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'REPORT'
              ? 'border-emerald-700 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          Training Hours Report
        </button>

        <button
          onClick={() => setActiveTab('ATTENDANCE')}
          className={`pb-3 text-xs font-semibold transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'ATTENDANCE'
              ? 'border-emerald-700 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Camera className="w-4 h-4" />
          Presensi & Bukti Foto ({trainingAttendance.length})
        </button>

        <button
          onClick={() => setActiveTab('PLANS')}
          className={`pb-3 text-xs font-semibold transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'PLANS'
              ? 'border-emerald-700 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <GraduationCap className="w-4 h-4" />
          Annual Training Plans ({filteredPlans.length})
        </button>

        <button
          onClick={() => setActiveTab('SESSIONS')}
          className={`pb-3 text-xs font-semibold transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'SESSIONS'
              ? 'border-emerald-700 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Calendar className="w-4 h-4" />
          Scheduled Sessions ({trainingSessions.length})
        </button>

        <button
          onClick={() => setActiveTab('GM_TARGET')}
          className={`pb-3 text-xs font-semibold transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'GM_TARGET'
              ? 'border-emerald-700 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          Target KPI Pelatihan (GM Sanction)
        </button>
      </div>

      {/* Tab 1: KPI Dashboard (Image 2) */}
      {activeTab === 'DASHBOARD' && (
        <TrainingKpiDashboard 
          onGoToGmTargetTab={() => setActiveTab('GM_TARGET')}
          onGoToReportTab={() => setActiveTab('REPORT')}
        />
      )}

      {/* Tab 2: Training Hours Report (Image 1) */}
      {activeTab === 'REPORT' && (
        <TrainingReportView />
      )}

      {/* Tab 3: Attendance & Mandatory Photo Proofs */}
      {activeTab === 'ATTENDANCE' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Camera className="w-4 h-4 text-emerald-700" />
                Presensi Pelatihan & Galeri Bukti Foto (Photo Proof Attendance)
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Karyawan wajib melakukan presensi dan melampirkan foto verifikasi fisik saat hari pelatihan. Jam pelatihan otomatis dihitung ke target KPI setelah presensi terkonfirmasi.
              </p>
            </div>

            <button
              onClick={() => handleOpenAttendance()}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors shrink-0"
            >
              <Camera className="w-4 h-4" />
              Presensi Sekarang (Upload Foto Bukti)
            </button>
          </div>

          {/* Attendance Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {trainingAttendance.map(att => (
              <div 
                key={att.id}
                className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col justify-between hover:border-slate-300 transition-all group"
              >
                <div>
                  {/* Photo Proof Header */}
                  <div 
                    onClick={() => setSelectedPhotoProof(att)}
                    className="relative h-44 bg-slate-900 overflow-hidden cursor-pointer group-hover:brightness-95 transition-all"
                  >
                    {att.photoProofUrl ? (
                      <img 
                        src={att.photoProofUrl} 
                        alt="Photo Proof" 
                        className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-500 text-xs">
                        Tidak ada foto
                      </div>
                    )}

                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/30" />

                    <div className="absolute top-2.5 left-2.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold shadow-xs ${
                        att.trainingScope === 'GENERIC_ALL_STAFF'
                          ? 'bg-purple-600 text-white'
                          : 'bg-emerald-600 text-white'
                      }`}>
                        {att.trainingScope === 'GENERIC_ALL_STAFF' ? 'Generic (All Staff)' : 'Departmental'}
                      </span>
                    </div>

                    <div className="absolute top-2.5 right-2.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-900/80 backdrop-blur-xs text-white border border-white/20">
                        +{att.trainingHours} Jam
                      </span>
                    </div>

                    <div className="absolute bottom-2.5 left-2.5 right-2.5 text-white">
                      <span className="text-[10px] text-emerald-300 font-semibold uppercase block">
                        {att.departmentName}
                      </span>
                      <h4 className="font-bold text-xs leading-snug line-clamp-1 text-white">
                        {att.employeeName}
                      </h4>
                    </div>
                  </div>

                  {/* Attendance Details */}
                  <div className="p-4 space-y-2.5">
                    <h5 className="font-bold text-slate-900 text-xs line-clamp-2 leading-snug">
                      {att.sessionTitle}
                    </h5>

                    <div className="space-y-1 text-[11px] text-slate-500">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{new Date(att.attendanceDate).toLocaleDateString('id-ID', { dateStyle: 'medium' })}</span>
                        <span>·</span>
                        <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{att.checkInTime} WITA</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{att.location}</span>
                      </div>
                    </div>

                    {att.notes && (
                      <p className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100 italic">
                        "{att.notes}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Footer status */}
                <div className="px-4 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1 text-[11px] text-emerald-700 font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Foto Terverifikasi</span>
                  </div>

                  <button
                    onClick={() => setSelectedPhotoProof(att)}
                    className="text-[11px] font-semibold text-slate-600 hover:text-emerald-700 flex items-center gap-1"
                  >
                    <Eye className="w-3 h-3" />
                    <span>Lihat Foto Penuh</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Annual Training Plans */}
      {activeTab === 'PLANS' && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Cari judul pelatihan, departemen..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-hidden"
              />
            </div>

            <div className="text-xs text-slate-500">
              Menampilkan {filteredPlans.length} program pelatihan kerja
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredPlans.map(plan => {
              const isGmApproved = plan.status === 'APPROVED_BY_GM';

              return (
                <div 
                  key={plan.id}
                  className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className="text-[10px] font-mono text-emerald-700 font-semibold">{plan.id}</span>
                          <span className={`px-2 py-0.2 rounded text-[9px] font-bold ${
                            plan.trainingScope === 'GENERIC_ALL_STAFF' 
                              ? 'bg-purple-100 text-purple-800' 
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {plan.trainingScope === 'GENERIC_ALL_STAFF' ? 'Generic (All Staff)' : 'Departmental'}
                          </span>
                        </div>
                        <h3 className="text-sm font-bold text-slate-900 mt-0.5">{plan.title}</h3>
                        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                          <Building className="w-3.5 h-3.5" />
                          <span>{plan.departmentName}</span>
                          <span>·</span>
                          <span className="font-semibold text-slate-700">{plan.priority} Priority</span>
                        </div>
                      </div>

                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold border shrink-0 ${
                        isGmApproved 
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                          : plan.status === 'CONSOLIDATED_BY_HC'
                            ? 'bg-blue-50 text-blue-700 border-blue-200'
                            : 'bg-amber-50 text-amber-700 border-amber-200'
                      }`}>
                        {plan.status.replace(/_/g, ' ')}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2">
                      {plan.objectives}
                    </p>

                    <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-lg border border-slate-100">
                      <div>
                        <span className="text-slate-400 block text-[10px]">Alokasi Anggaran</span>
                        <span className="font-bold text-slate-900 font-mono">
                          Rp {plan.estimatedCost.toLocaleString('id-ID')}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Durasi Jam Pelatihan</span>
                        <span className="font-bold text-emerald-700 font-mono">
                          {plan.trainingHours || 4} Jam / Sesi
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Tanggal & Waktu</span>
                        <span className="text-slate-700">
                          {new Date(plan.proposedStartDate).toLocaleDateString('id-ID')} ({plan.startTime || '09:00'} – {plan.endTime || '13:00'})
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Trainer / Provider</span>
                        <span className="text-slate-700 truncate block">
                          {plan.trainerName}
                        </span>
                      </div>
                    </div>

                    {plan.hcReviewNotes && (
                      <div className="text-[11px] bg-blue-50/70 border border-blue-200 p-2 rounded text-blue-900">
                        <span className="font-semibold">Catatan Konsolidasi HC:</span> {plan.hcReviewNotes}
                      </div>
                    )}

                    {plan.gmApprovalNotes && (
                      <div className="text-[11px] bg-emerald-50/70 border border-emerald-200 p-2 rounded text-emerald-900">
                        <span className="font-semibold">Pengesahan General Manager:</span> {plan.gmApprovalNotes}
                      </div>
                    )}
                  </div>

                  {/* Actions based on role */}
                  <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-[10px] text-slate-400">
                      Diajukan oleh {plan.submittedByName}
                    </span>

                    <div className="flex items-center gap-2">
                      {/* HC Consolidation Action */}
                      {currentUser.role === 'HC' && plan.status === 'SUBMITTED_BY_DEPT_HEAD' && (
                        <button
                          onClick={() => {
                            const notes = prompt('Masukkan catatan review konsolidasi HC:');
                            if (notes) updateTrainingPlanStatus(plan.id, 'CONSOLIDATED_BY_HC', notes);
                          }}
                          className="px-2.5 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md border border-blue-200"
                        >
                          Konsolidasi & Teruskan ke GM
                        </button>
                      )}

                      {/* GM Final Approval Action */}
                      {currentUser.role === 'GM' && (plan.status === 'CONSOLIDATED_BY_HC' || plan.status === 'SUBMITTED_BY_DEPT_HEAD') && (
                        <button
                          onClick={() => {
                            const notes = prompt('Masukkan catatan pengesahan Executive Approval GM:');
                            if (notes) updateTrainingPlanStatus(plan.id, 'APPROVED_BY_GM', notes);
                          }}
                          className="px-3 py-1 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-md shadow-xs"
                        >
                          Sahkan Rencana (GM Approval)
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 5: Scheduled Sessions */}
      {activeTab === 'SESSIONS' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-slate-900 text-sm">Sesi Pelatihan Terjadwal</h3>
              <p className="text-xs text-slate-500">
                Sesi paralel dapat berlangsung di waktu yang sama di berbagai ruangan/departemen.
              </p>
            </div>
            <button
              onClick={() => handleOpenAttendance()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
            >
              <Camera className="w-3.5 h-3.5" />
              Presensi Sesi
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {trainingSessions.map(s => (
              <div key={s.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50 transition-colors">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      s.trainingScope === 'GENERIC_ALL_STAFF'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {s.trainingScope === 'GENERIC_ALL_STAFF' ? 'Generic (All Staff)' : 'Departmental'}
                    </span>
                    <h4 className="font-bold text-slate-900 text-xs">{s.title}</h4>
                    <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      +{s.trainingHours} Jam
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      Venue: <strong className="text-slate-800">{s.venue}</strong>
                    </span>
                    <span>·</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {new Date(s.sessionDate).toLocaleDateString('id-ID')} ({s.startTime} – {s.endTime} WITA)
                    </span>
                    <span>·</span>
                    <span>Trainer: <strong className="text-slate-800">{s.instructor}</strong></span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-xs text-right">
                    <span className="text-slate-500 block">Peserta Terdaftar:</span>
                    <span className="font-bold text-slate-900 block">{s.participantIds.length} staf</span>
                  </div>

                  <button
                    onClick={() => handleOpenAttendance(s)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>Presensi</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 6: GM KPI Target Sanction */}
      {activeTab === 'GM_TARGET' && (
        <GmKpiTargetManager />
      )}

      {/* Modal Propose Training Plan */}
      <TrainingPlanModal
        isOpen={isPlanModalOpen}
        onClose={() => setIsPlanModalOpen(false)}
      />

      {/* Modal Attendance Check-in with Mandatory Photo Proof */}
      <TrainingAttendanceModal
        isOpen={isAttendanceModalOpen}
        onClose={() => setIsAttendanceModalOpen(false)}
        preselectedSession={sessionForAttendance}
      />

      {/* Lightbox Modal for Photo Proof */}
      {selectedPhotoProof && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-700">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h4 className="font-bold text-xs">{selectedPhotoProof.employeeName}</h4>
                <p className="text-[10px] text-slate-400">
                  {selectedPhotoProof.sessionTitle} · {selectedPhotoProof.trainingHours} Jam
                </p>
              </div>
              <button 
                onClick={() => setSelectedPhotoProof(null)}
                className="p-1 rounded text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="bg-slate-950 p-2 flex items-center justify-center">
              <img 
                src={selectedPhotoProof.photoProofUrl} 
                alt="Full Photo Proof" 
                className="max-h-[65vh] w-auto object-contain rounded"
              />
            </div>
            <div className="p-3 bg-slate-50 border-t border-slate-200 text-xs flex items-center justify-between">
              <span className="text-slate-600 text-[11px]">
                📍 {selectedPhotoProof.location} · {selectedPhotoProof.checkInTime} WITA
              </span>
              <span className="text-emerald-700 font-bold text-[11px] bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200">
                ✓ Otentik Terverifikasi
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
