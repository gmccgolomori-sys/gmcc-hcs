import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Employee, TrainingAttendance } from '../../types';
import { 
  FileText, 
  Search, 
  Filter, 
  Download, 
  Printer, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Award, 
  ChevronRight, 
  Eye, 
  X, 
  Camera, 
  MapPin, 
  Calendar,
  Layers,
  TrendingUp,
  Building
} from 'lucide-react';
import { TrainingReportPrintModal } from './TrainingReportPrintModal';

export const TrainingReportView: React.FC = () => {
  const { 
    employees, 
    departments, 
    trainingAttendance, 
    annualKpiTarget,
    currentUser 
  } = useApp();

  const [selectedDeptId, setSelectedDeptId] = useState<string>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<'ALL' | 'ACHIEVED' | 'ON_TRACK' | 'BEHIND'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedEmployeeForDetails, setSelectedEmployeeForDetails] = useState<Employee | null>(null);
  const [selectedAttendancePhoto, setSelectedAttendancePhoto] = useState<TrainingAttendance | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState<boolean>(false);

  // Compute training hours per employee
  const employeeTrainingData = useMemo(() => {
    return employees.map(emp => {
      const attendances = trainingAttendance.filter(a => a.employeeId === emp.id && a.status === 'VERIFIED');
      
      const genericHours = attendances
        .filter(a => a.trainingScope === 'GENERIC_ALL_STAFF')
        .reduce((sum, a) => sum + (a.trainingHours || 0), 0);

      const deptHours = attendances
        .filter(a => a.trainingScope === 'DEPARTMENTAL')
        .reduce((sum, a) => sum + (a.trainingHours || 0), 0);

      const totalActualHours = genericHours + deptHours;

      // Department target or default company target
      const deptTarget = annualKpiTarget.departmentTargets?.find(d => d.departmentId === emp.departmentId);
      const targetHours = deptTarget?.targetHoursPerStaff || annualKpiTarget.annualTargetHoursPerStaff || 20;

      const achievementPercentage = targetHours > 0 
        ? Math.round((totalActualHours / targetHours) * 100) 
        : 0;

      let status: 'ACHIEVED' | 'ON_TRACK' | 'BEHIND' = 'BEHIND';
      if (achievementPercentage >= 100) {
        status = 'ACHIEVED';
      } else if (achievementPercentage >= 50) {
        status = 'ON_TRACK';
      }

      const dept = departments.find(d => d.id === emp.departmentId);

      return {
        employee: emp,
        departmentName: dept?.name || 'Department',
        genericHours,
        deptHours,
        totalActualHours,
        targetHours,
        achievementPercentage,
        status,
        attendances,
        sessionCount: attendances.length
      };
    });
  }, [employees, departments, trainingAttendance, annualKpiTarget]);

  // Filtered dataset
  const filteredData = useMemo(() => {
    return employeeTrainingData.filter(item => {
      // Dept filter
      if (selectedDeptId !== 'ALL' && item.employee.departmentId !== selectedDeptId) {
        return false;
      }
      // Status filter
      if (selectedStatusFilter !== 'ALL' && item.status !== selectedStatusFilter) {
        return false;
      }
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = item.employee.fullName.toLowerCase().includes(q);
        const matchesNik = item.employee.employeeNumber.toLowerCase().includes(q);
        const matchesJob = item.employee.jobTitle.toLowerCase().includes(q);
        if (!matchesName && !matchesNik && !matchesJob) return false;
      }
      return true;
    });
  }, [employeeTrainingData, selectedDeptId, selectedStatusFilter, searchQuery]);

  // Aggregate statistics
  const totalEmployees = employeeTrainingData.length;
  const totalHoursDelivered = employeeTrainingData.reduce((acc, i) => acc + i.totalActualHours, 0);
  const averageHoursPerStaff = totalEmployees > 0 ? (totalHoursDelivered / totalEmployees).toFixed(1) : '0';
  const staffAchievedTarget = employeeTrainingData.filter(i => i.achievementPercentage >= 100).length;
  const overallTargetRate = totalEmployees > 0 ? Math.round((staffAchievedTarget / totalEmployees) * 100) : 0;

  // Export to CSV
  const handleExportCsv = () => {
    const headers = [
      'No',
      'NIK',
      'Nama Karyawan',
      'Departemen',
      'Jabatan',
      'Tipe Hubungan Kerja',
      'Generic Training (Jam)',
      'Departmental Training (Jam)',
      'Total Jam Diikuti',
      'Target KPI Tahunan (Jam)',
      '% Capaian KPI',
      'Status Evaluasi'
    ];

    const rows = filteredData.map((item, index) => [
      index + 1,
      `"${item.employee.employeeNumber || item.employee.id}"`,
      `"${item.employee.fullName}"`,
      `"${item.departmentName}"`,
      `"${item.employee.jobTitle}"`,
      `"${item.employee.employmentType}"`,
      item.genericHours,
      item.deptHours,
      item.totalActualHours,
      item.targetHours,
      `"${item.achievementPercentage}%"`,
      `"${item.status === 'ACHIEVED' ? 'Tercapai (>=100%)' : item.status === 'ON_TRACK' ? 'On-Track (>=50%)' : 'Di Bawah Target'}"`
    ].join(','));

    // Excel UTF-8 BOM (\uFEFF) ensures proper rendering in MS Excel and Google Sheets without extra columns
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `GMCC_Laporan_Training_Hours_${annualKpiTarget.year}_${selectedDeptId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    setIsPrintModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Summary KPI */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-6 shadow-md border border-slate-700">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-emerald-400 font-semibold tracking-wide uppercase">
              <Award className="w-4 h-4" />
              <span>Official Executive Training Hours Report · Tahun {annualKpiTarget.year}</span>
            </div>
            <h2 className="text-xl font-extrabold tracking-tight mt-1 text-white">
              Laporan Jam Pelatihan & Realisasi Target KPI Karyawan
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Matriks pemenuhan target jam pelatihan staf GMCC (Generic Service Excellence & Departmental Technical Training) berdasarkan SK Target KPI disahkan oleh General Manager Bambang Wijaya ({annualKpiTarget.annualTargetHoursPerStaff} Jam/Tahun/Staf).
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto shrink-0">
            <button
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white hover:bg-slate-100 rounded-lg shadow-sm transition-all"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              Export CSV / Excel
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm transition-all"
            >
              <Printer className="w-4 h-4" />
              Cetak Laporan
            </button>
          </div>
        </div>

        {/* 4 Key Performance Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-700/80">
          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-slate-300 block">Total Jam Terlaksana</span>
            <div className="text-xl font-bold font-mono text-emerald-300 mt-0.5">
              {totalHoursDelivered} Jam
            </div>
            <span className="text-[10px] text-slate-400">Seluruh sesi terverifikasi</span>
          </div>

          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-slate-300 block">Rata-rata Jam / Staf</span>
            <div className="text-xl font-bold font-mono text-blue-300 mt-0.5">
              {averageHoursPerStaff} Jam
            </div>
            <span className="text-[10px] text-slate-400">Target GM: {annualKpiTarget.annualTargetHoursPerStaff} Jam</span>
          </div>

          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-slate-300 block">Tercapai KPI (100%+)</span>
            <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">
              {staffAchievedTarget} / {totalEmployees} Staf
            </div>
            <span className="text-[10px] text-slate-400">{overallTargetRate}% Staf telah capai target</span>
          </div>

          <div className="bg-white/10 backdrop-blur-xs rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-slate-300 block">Total Bukti Kehadiran</span>
            <div className="text-xl font-bold font-mono text-amber-300 mt-0.5">
              {trainingAttendance.length} Foto Proof
            </div>
            <span className="text-[10px] text-slate-400">Wajib verifikasi foto fisik</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Departemen Filter */}
          <div className="flex items-center gap-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedDeptId}
              onChange={e => setSelectedDeptId(e.target.value)}
              className="text-xs rounded-lg border border-slate-300 px-3 py-1.5 bg-white text-slate-700 font-semibold focus:outline-hidden"
            >
              <option value="ALL">Semua Departemen</option>
              {departments.map(d => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>

          {/* Status KPI Filter */}
          <select
            value={selectedStatusFilter}
            onChange={e => setSelectedStatusFilter(e.target.value as any)}
            className="text-xs rounded-lg border border-slate-300 px-3 py-1.5 bg-white text-slate-700 font-semibold focus:outline-hidden"
          >
            <option value="ALL">Semua Status KPI</option>
            <option value="ACHIEVED">✅ Tercapai (&gt;= 100%)</option>
            <option value="ON_TRACK">⏳ On-Track (50% - 99%)</option>
            <option value="BEHIND">⚠️ Perlu Peningkatan (&lt; 50%)</option>
          </select>
        </div>

        {/* Search */}
        <div className="relative w-full md:w-72">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nama karyawan, NIK, jabatan..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700"
          />
        </div>
      </div>

      {/* Main Report Table (like Image 1) */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-700" />
            <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
              Tabel Matriks Pelatihan Karyawan ({filteredData.length} Staf Terdata)
            </h3>
          </div>
          <span className="text-[11px] text-slate-500">
            Target Standar GM: <strong>{annualKpiTarget.annualTargetHoursPerStaff} Jam/Karyawan</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
                <th className="py-3 px-3 w-12 text-center">No</th>
                <th className="py-3 px-3">Karyawan / NIK</th>
                <th className="py-3 px-3">Departemen</th>
                <th className="py-3 px-3 text-center">Hub. Kerja</th>
                <th className="py-3 px-3 text-center bg-purple-50/50 text-purple-900 border-x border-purple-100">
                  Generic Training<br />(Jam)
                </th>
                <th className="py-3 px-3 text-center bg-blue-50/50 text-blue-900 border-r border-blue-100">
                  Dept Training<br />(Jam)
                </th>
                <th className="py-3 px-3 text-center font-bold bg-slate-50">
                  Total Jam<br />(Actual)
                </th>
                <th className="py-3 px-3 text-center text-slate-500">
                  Target KPI<br />(GM)
                </th>
                <th className="py-3 px-3 w-40">Capaian Target KPI (%)</th>
                <th className="py-3 px-3 text-center">Status KPI</th>
                <th className="py-3 px-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredData.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-8 text-center text-slate-400">
                    Tidak ditemukan data karyawan sesuai kriteria filter.
                  </td>
                </tr>
              ) : (
                filteredData.map((row, idx) => (
                  <tr key={row.employee.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-3 text-center text-slate-400 font-mono text-[11px]">
                      {idx + 1}
                    </td>

                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2.5">
                        {row.employee.avatarUrl ? (
                          <img 
                            src={row.employee.avatarUrl} 
                            alt={row.employee.fullName} 
                            className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0" 
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0">
                            {row.employee.fullName.charAt(0)}
                          </div>
                        )}
                        <div>
                          <span className="font-bold text-slate-900 block leading-tight hover:text-emerald-700">
                            {row.employee.fullName}
                          </span>
                          <span className="text-[10px] font-mono text-slate-400 block mt-0.5">
                            {row.employee.employeeNumber} · {row.employee.jobTitle}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-3">
                      <span className="text-slate-700 block font-medium">
                        {row.departmentName}
                      </span>
                    </td>

                    <td className="py-3 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        row.employee.employmentType === 'DAILY_WORKER'
                          ? 'bg-amber-50 text-amber-700'
                          : 'bg-blue-50 text-blue-700'
                      }`}>
                        {row.employee.employmentType === 'DAILY_WORKER' ? 'Daily Worker' : 'PKWT'}
                      </span>
                    </td>

                    {/* Generic Training Hours */}
                    <td className="py-3 px-3 text-center font-mono font-semibold text-purple-800 bg-purple-50/30 border-x border-purple-100">
                      {row.genericHours} Jam
                    </td>

                    {/* Departmental Training Hours */}
                    <td className="py-3 px-3 text-center font-mono font-semibold text-blue-800 bg-blue-50/30 border-r border-blue-100">
                      {row.deptHours} Jam
                    </td>

                    {/* Total Hours */}
                    <td className="py-3 px-3 text-center font-mono font-bold text-slate-900 bg-slate-50">
                      {row.totalActualHours} Jam
                    </td>

                    {/* Target KPI */}
                    <td className="py-3 px-3 text-center font-mono text-slate-500">
                      {row.targetHours} Jam
                    </td>

                    {/* Progress Bar Capaian */}
                    <td className="py-3 px-3">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="font-mono font-bold text-slate-800">
                            {row.achievementPercentage}%
                          </span>
                          <span className="text-slate-400">
                            {row.totalActualHours}/{row.targetHours} Jam
                          </span>
                        </div>
                        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              row.status === 'ACHIEVED'
                                ? 'bg-emerald-600'
                                : row.status === 'ON_TRACK'
                                  ? 'bg-blue-600'
                                  : 'bg-amber-500'
                            }`}
                            style={{ width: `${Math.min(row.achievementPercentage, 100)}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    {/* Status Badge */}
                    <td className="py-3 px-3 text-center">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border ${
                        row.status === 'ACHIEVED'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : row.status === 'ON_TRACK'
                            ? 'bg-blue-50 text-blue-800 border-blue-200'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                      }`}>
                        {row.status === 'ACHIEVED' && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                        {row.status === 'ON_TRACK' && <Clock className="w-3 h-3 text-blue-600" />}
                        {row.status === 'BEHIND' && <AlertTriangle className="w-3 h-3 text-amber-600" />}
                        {row.status === 'ACHIEVED' ? 'Tercapai' : row.status === 'ON_TRACK' ? 'On-Track' : 'Kurang'}
                      </span>
                    </td>

                    {/* Action: View Attendances & Photo Proofs */}
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => setSelectedEmployeeForDetails(row.employee)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-md border border-emerald-200 transition-colors"
                        title="Lihat Rincian Sesi & Foto Bukti"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Bukti Foto ({row.sessionCount})</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drilldown Modal: Employee's Training History & Photo Proofs */}
      {selectedEmployeeForDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white rounded-t-2xl">
              <div className="flex items-center gap-3">
                {selectedEmployeeForDetails.avatarUrl ? (
                  <img 
                    src={selectedEmployeeForDetails.avatarUrl} 
                    alt={selectedEmployeeForDetails.fullName}
                    className="w-10 h-10 rounded-full object-cover border-2 border-emerald-400"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold">
                    {selectedEmployeeForDetails.fullName.charAt(0)}
                  </div>
                )}
                <div>
                  <h3 className="font-bold text-sm tracking-tight text-white">
                    Portofolio Pelatihan: {selectedEmployeeForDetails.fullName}
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    {selectedEmployeeForDetails.employeeNumber} · {selectedEmployeeForDetails.jobTitle}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedEmployeeForDetails(null)} 
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              {/* Summary Stats */}
              {(() => {
                const item = employeeTrainingData.find(i => i.employee.id === selectedEmployeeForDetails.id);
                if (!item) return null;

                return (
                  <div className="grid grid-cols-3 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold">Total Jam Diikuti</span>
                      <div className="text-xl font-bold font-mono text-slate-900 mt-0.5">
                        {item.totalActualHours} Jam
                      </div>
                      <span className="text-[10px] text-slate-500">
                        Generic: {item.genericHours}h | Dept: {item.deptHours}h
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold">Target GM KPI</span>
                      <div className="text-xl font-bold font-mono text-emerald-700 mt-0.5">
                        {item.targetHours} Jam
                      </div>
                      <span className="text-[10px] text-slate-500">Target Tahunan</span>
                    </div>

                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold">Status Capaian</span>
                      <div className="text-xl font-bold font-mono text-slate-900 mt-0.5">
                        {item.achievementPercentage}%
                      </div>
                      <span className={`text-[10px] font-bold ${
                        item.status === 'ACHIEVED' ? 'text-emerald-700' : 'text-amber-700'
                      }`}>
                        {item.status === 'ACHIEVED' ? 'Tercapai 100%' : 'Sedang Berjalan'}
                      </span>
                    </div>
                  </div>
                );
              })()}

              {/* Attendances List with Photo Proofs */}
              <div>
                <h4 className="font-bold text-slate-900 text-xs mb-3 flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-emerald-700" />
                  Daftar Sesi Pelatihan & Bukti Foto Kehadiran (Photo Proof)
                </h4>

                {(() => {
                  const empAttendances = trainingAttendance.filter(
                    a => a.employeeId === selectedEmployeeForDetails.id
                  );

                  if (empAttendances.length === 0) {
                    return (
                      <div className="p-8 text-center text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                        Belum ada presensi sesi pelatihan tercatat untuk staf ini.
                      </div>
                    );
                  }

                  return (
                    <div className="space-y-3">
                      {empAttendances.map(att => (
                        <div 
                          key={att.id}
                          className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs hover:border-slate-300 transition-all flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between"
                        >
                          <div className="space-y-1.5 flex-1">
                            <div className="flex items-center gap-2">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                att.trainingScope === 'GENERIC_ALL_STAFF'
                                  ? 'bg-purple-50 text-purple-800 border-purple-200'
                                  : 'bg-blue-50 text-blue-800 border-blue-200'
                              }`}>
                                {att.trainingScope === 'GENERIC_ALL_STAFF' ? 'Generic (All Staff)' : 'Departmental'}
                              </span>
                              <span className="text-[10px] font-mono text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                                +{att.trainingHours} Jam Pelatihan
                              </span>
                            </div>

                            <h5 className="font-bold text-slate-900 text-xs">
                              {att.sessionTitle}
                            </h5>

                            <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500">
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3 text-slate-400" />
                                {new Date(att.attendanceDate).toLocaleDateString('id-ID', { dateStyle: 'medium' })}
                              </span>
                              <span>·</span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-400" />
                                Pukul {att.checkInTime} WITA
                              </span>
                              <span>·</span>
                              <span className="flex items-center gap-1">
                                <MapPin className="w-3 h-3 text-slate-400" />
                                {att.location}
                              </span>
                            </div>

                            {att.notes && (
                              <p className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded border border-slate-100">
                                💬 <em>"{att.notes}"</em>
                              </p>
                            )}

                            {att.verifiedBy && (
                              <span className="text-[10px] text-emerald-700 font-semibold block">
                                ✓ Diverifikasi oleh {att.verifiedBy}
                              </span>
                            )}
                          </div>

                          {/* Photo Proof Thumbnail */}
                          {att.photoProofUrl && (
                            <div className="shrink-0 flex flex-col items-center">
                              <div 
                                onClick={() => setSelectedAttendancePhoto(att)}
                                className="w-24 h-24 rounded-lg overflow-hidden border-2 border-emerald-500 cursor-pointer shadow-xs hover:scale-105 transition-transform relative group bg-slate-900"
                              >
                                <img 
                                  src={att.photoProofUrl} 
                                  alt="Bukti Kehadiran" 
                                  className="w-full h-full object-cover object-center"
                                />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-[10px] font-bold">
                                  Perbesar
                                </div>
                              </div>
                              <span className="text-[10px] text-slate-500 mt-1">Photo Proof</span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  type="button"
                  onClick={() => setSelectedEmployeeForDetails(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lightbox Modal for Photo Proof */}
      {selectedAttendancePhoto && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-700">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h4 className="font-bold text-xs">Bukti Foto Kehadiran (Photo Proof)</h4>
                <p className="text-[10px] text-slate-400">
                  {selectedAttendancePhoto.employeeName} · {selectedAttendancePhoto.sessionTitle}
                </p>
              </div>
              <button 
                onClick={() => setSelectedAttendancePhoto(null)}
                className="p-1 rounded text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="bg-slate-950 p-2 flex items-center justify-center">
              <img 
                src={selectedAttendancePhoto.photoProofUrl} 
                alt="Full Photo Proof" 
                className="max-h-[65vh] w-auto object-contain rounded"
              />
            </div>
            <div className="p-3 bg-slate-50 border-t border-slate-200 text-xs flex items-center justify-between">
              <span className="text-slate-600 text-[11px]">
                📍 {selectedAttendancePhoto.location} · {selectedAttendancePhoto.checkInTime} WITA
              </span>
              <span className="text-emerald-700 font-bold text-[11px] bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200">
                ✓ Otentik Terverifikasi
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Official A4 Landscape Printable Report Modal */}
      <TrainingReportPrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        year={annualKpiTarget.year}
        reportData={filteredData}
        departments={departments}
        deptFilterId={selectedDeptId}
        annualKpiTarget={annualKpiTarget}
        printedByName={currentUser.name}
        printedByRole={currentUser.role}
      />
    </div>
  );
};
