import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { TrainingSession } from '../../types';
import { 
  X, 
  Camera, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  MapPin, 
  User, 
  Calendar, 
  Sparkles,
  ShieldCheck,
  Building
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  preselectedSession?: TrainingSession | null;
}

export const TrainingAttendanceModal: React.FC<Props> = ({ 
  isOpen, 
  onClose,
  preselectedSession 
}) => {
  const { 
    currentUser, 
    trainingSessions, 
    recordTrainingAttendance, 
    trainingAttendance,
    employees 
  } = useApp();

  const [selectedSessionId, setSelectedSessionId] = useState<string>(
    preselectedSession?.id || trainingSessions[0]?.id || ''
  );
  const [targetEmployeeId, setTargetEmployeeId] = useState<string>(
    currentUser.employeeId || employees[0]?.id || ''
  );
  const [photoProofUrl, setPhotoProofUrl] = useState<string>('');
  const [photoFileName, setPhotoFileName] = useState<string>('');
  const [location, setLocation] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [agreed, setAgreed] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [successInfo, setSuccessInfo] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync session selection if preselectedSession changes
  React.useEffect(() => {
    if (preselectedSession) {
      setSelectedSessionId(preselectedSession.id);
      setLocation(preselectedSession.venue);
    } else if (trainingSessions.length > 0 && !selectedSessionId) {
      setSelectedSessionId(trainingSessions[0].id);
      setLocation(trainingSessions[0].venue);
    }
  }, [preselectedSession, trainingSessions]);

  const activeSession = trainingSessions.find(s => s.id === selectedSessionId);

  // Update location when session changes
  React.useEffect(() => {
    if (activeSession) {
      setLocation(activeSession.venue);
    }
  }, [activeSession]);

  if (!isOpen) return null;

  // Handle file upload and convert to base64 data url for realistic photo proof
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setPhotoFileName(file.name);
    const reader = new FileReader();
    reader.onloadend = () => {
      setPhotoProofUrl(reader.result as string);
      setErrorMsg('');
    };
    reader.readAsDataURL(file);
  };

  // Sample quick proofs for demo testing
  const SAMPLE_PROOF_PHOTOS = [
    {
      label: 'Foto Peserta di Ruang Plenary',
      url: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80'
    },
    {
      label: 'Foto Peserta Hospitality Uniform',
      url: 'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?w=600&auto=format&fit=crop&q=80'
    },
    {
      label: 'Foto Kitchen Lab & HACCP Apron',
      url: 'https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=600&auto=format&fit=crop&q=80'
    },
    {
      label: 'Foto AV Console & ID Card',
      url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80'
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!selectedSessionId || !activeSession) {
      setErrorMsg('Pilih sesi pelatihan yang valid.');
      return;
    }

    if (!photoProofUrl || photoProofUrl.trim() === '') {
      setErrorMsg('Bukti foto kehadiran (photo proof) WAJIB dilampirkan!');
      return;
    }

    if (!agreed) {
      setErrorMsg('Anda wajib menyetujui pernyataan konfirmasi kehadiran.');
      return;
    }

    const res = recordTrainingAttendance({
      sessionId: activeSession.id,
      sessionTitle: activeSession.title,
      trainingScope: activeSession.trainingScope || 'DEPARTMENTAL',
      photoProofUrl,
      location: location || activeSession.venue,
      notes: notes || 'Hadir tepat waktu dan mengikuti sesi training.',
      trainingHours: activeSession.trainingHours || 4,
      employeeId: currentUser.role === 'HC' || currentUser.role === 'ADMIN' ? targetEmployeeId : (currentUser.employeeId || targetEmployeeId || '')
    });

    if (!res.success) {
      setErrorMsg(res.message);
      return;
    }

    setSuccessInfo(res.message);
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1800);
  };

  const currentEmpRecord = employees.find(e => e.id === (currentUser.employeeId || targetEmployeeId));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[92vh] overflow-y-auto border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white rounded-t-2xl">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600/30 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm tracking-tight">Presensi Kehadiran Pelatihan (Attendance)</h3>
              <p className="text-[11px] text-slate-400">
                Wajib melampirkan foto verifikasi kehadiran (Photo Proof)
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center flex flex-col items-center justify-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shadow-inner">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-slate-900 text-base">Presensi Pelatihan Berhasil!</h4>
            <p className="text-xs text-slate-600 max-w-md">
              {successInfo}
            </p>
            <div className="text-[11px] text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-200">
              ✓ Bukti Foto Terverifikasi & Jam Pelatihan Tercatat ke KPI
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            {errorMsg && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span className="font-medium text-[11px]">{errorMsg}</span>
              </div>
            )}

            {/* Target Employee Selection */}
            {(currentUser.role === 'HC' || currentUser.role === 'ADMIN') ? (
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <label className="block font-bold text-slate-700 mb-1">
                  Karyawan yang Melakukan Presensi (HC Admin Mode) *
                </label>
                <select
                  value={targetEmployeeId}
                  onChange={e => setTargetEmployeeId(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 font-semibold"
                >
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.fullName} ({emp.employeeNumber}) — {emp.jobTitle}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-sm shrink-0 border border-emerald-200">
                  {currentUser.name.charAt(0)}
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Peserta Pelatihan</span>
                  <h4 className="font-bold text-slate-900 text-xs">{currentUser.name}</h4>
                  <p className="text-[11px] text-slate-500">
                    {currentEmpRecord?.jobTitle || 'Staff'} · {currentEmpRecord?.employeeNumber || 'GMCC-STAFF'}
                  </p>
                </div>
              </div>
            )}

            {/* Select Scheduled Training Session */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Pilih Sesi Pelatihan Terjadwal Hari Ini *
              </label>
              <select
                value={selectedSessionId}
                onChange={e => setSelectedSessionId(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 font-semibold focus:outline-hidden focus:border-emerald-700"
              >
                {trainingSessions.map(s => (
                  <option key={s.id} value={s.id}>
                    [{s.trainingScope === 'GENERIC_ALL_STAFF' ? 'GENERIC (ALL STAFF)' : 'DEPARTEMEN'}] {s.title} ({s.trainingHours} Jam) — {s.venue}
                  </option>
                ))}
              </select>
            </div>

            {/* Active Session Info Card */}
            {activeSession && (
              <div className="bg-emerald-50/50 border border-emerald-200/80 rounded-xl p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                    activeSession.trainingScope === 'GENERIC_ALL_STAFF'
                      ? 'bg-purple-100 text-purple-800 border-purple-200'
                      : 'bg-emerald-100 text-emerald-800 border-emerald-200'
                  }`}>
                    {activeSession.trainingScope === 'GENERIC_ALL_STAFF' ? 'Generic Training (All Staff)' : 'Departmental Training'}
                  </span>
                  <span className="text-[11px] font-mono font-bold text-emerald-800">
                    +{activeSession.trainingHours} Jam Kredit KPI
                  </span>
                </div>

                <h4 className="font-bold text-slate-900 text-xs leading-snug">
                  {activeSession.title}
                </h4>

                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 pt-1 border-t border-emerald-100">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{new Date(activeSession.sessionDate).toLocaleDateString('id-ID', { dateStyle: 'medium' })}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{activeSession.startTime} – {activeSession.endTime} WITA</span>
                  </div>
                  <div className="flex items-center gap-1.5 col-span-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{activeSession.venue}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Mandatory Photo Proof Upload Section */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                  <Camera className="w-4 h-4 text-emerald-700" />
                  Foto Bukti Kehadiran (Photo Proof) <span className="text-rose-500 font-bold">*WAJIB</span>
                </label>
                {photoProofUrl && (
                  <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Foto Terlampir
                  </span>
                )}
              </div>

              {photoProofUrl ? (
                <div className="relative rounded-xl overflow-hidden border-2 border-emerald-500 bg-slate-900 group">
                  <img 
                    src={photoProofUrl} 
                    alt="Photo Proof Preview" 
                    className="w-full h-48 object-cover object-center"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-1.5 bg-white text-slate-900 font-semibold text-xs rounded-lg shadow-md hover:bg-slate-100"
                    >
                      Ganti Foto
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPhotoProofUrl('');
                        setPhotoFileName('');
                      }}
                      className="px-3 py-1.5 bg-rose-600 text-white font-semibold text-xs rounded-lg shadow-md hover:bg-rose-700"
                    >
                      Hapus
                    </button>
                  </div>
                  <div className="absolute bottom-2 left-2 right-2 bg-slate-900/80 backdrop-blur-xs text-white px-2.5 py-1 rounded-md text-[10px] flex items-center justify-between">
                    <span className="truncate">{photoFileName || 'Foto Bukti Kehadiran Terverifikasi'}</span>
                    <span className="text-emerald-400 font-bold">Siap Disimpan</span>
                  </div>
                </div>
              ) : (
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-300 hover:border-emerald-500 rounded-xl p-5 text-center cursor-pointer transition-all bg-slate-50 hover:bg-emerald-50/30 flex flex-col items-center justify-center space-y-2"
                >
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-800 block text-xs">
                      Klik untuk Unggah Foto Bukti Kehadiran
                    </span>
                    <span className="text-[11px] text-slate-500 block mt-0.5">
                      Ambil foto selfie di ruang training atau upload file foto (JPG, PNG, WebP)
                    </span>
                  </div>
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-700 text-white text-[11px] font-medium rounded-lg shadow-xs">
                    <Camera className="w-3.5 h-3.5" /> Buka Kamera / Pilih File
                  </span>
                </div>
              )}

              <input 
                ref={fileInputRef}
                type="file" 
                accept="image/*" 
                capture="user"
                onChange={handleFileUpload} 
                className="hidden" 
              />

              {/* Sample Photo selector for fast testing */}
              <div className="pt-1">
                <span className="text-[10px] text-slate-400 block mb-1">
                  Atau pilih contoh foto training cepat (Simulasi Demo):
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  {SAMPLE_PROOF_PHOTOS.map((sp, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setPhotoProofUrl(sp.url);
                        setPhotoFileName(sp.label);
                        setErrorMsg('');
                      }}
                      className="text-left px-2 py-1 text-[10px] bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 rounded border border-slate-200 truncate transition-colors"
                    >
                      📷 {sp.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Location & Notes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Lokasi Presensi</label>
                <input
                  type="text"
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  placeholder="misal: GMCC Ballroom / Kitchen Lab"
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Catatan / Topik Dipelajari</label>
                <input
                  type="text"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="misal: Memahami SOP pelayanan VIP"
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 bg-white"
                />
              </div>
            </div>

            {/* Mandatory Declaration Checkbox */}
            <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  required
                  checked={agreed}
                  onChange={e => setAgreed(e.target.checked)}
                  className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span className="text-[11px] text-slate-600 leading-tight">
                  Saya menyatakan dengan sesungguhnya bahwa saya hadir secara fisik dan mengikuti seluruh rangkaian sesi pelatihan ini. Bukti foto yang saya lampirkan adalah otentik dan benar.
                </span>
              </label>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                disabled={!photoProofUrl}
                className={`inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold rounded-lg shadow-xs transition-colors ${
                  photoProofUrl
                    ? 'text-white bg-emerald-700 hover:bg-emerald-800 cursor-pointer'
                    : 'text-slate-400 bg-slate-200 cursor-not-allowed'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                Kirim Presensi & Bukti Foto
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
