import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  ShieldCheck, 
  Award, 
  Lock, 
  Save, 
  Building, 
  Target, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  AlertCircle, 
  FileText,
  User,
  Sparkles,
  Info
} from 'lucide-react';

export const GmKpiTargetManager: React.FC = () => {
  const { 
    currentUser, 
    annualKpiTarget, 
    updateAnnualKpiTarget, 
    departments,
    employees 
  } = useApp();

  const isGm = currentUser.role === 'GM' || currentUser.role === 'ADMIN';

  const [year, setYear] = useState<number>(annualKpiTarget.year || 2026);
  const [annualTargetHours, setAnnualTargetHours] = useState<number>(
    annualKpiTarget.annualTargetHoursPerStaff || 20
  );
  const [strategicObjectives, setStrategicObjectives] = useState<string>(
    annualKpiTarget.strategicObjectives || ''
  );
  const [notes, setNotes] = useState<string>(annualKpiTarget.notes || '');
  const [deptTargets, setDeptTargets] = useState<{ [deptId: string]: number }>({});
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  // Initialize department targets from state or defaults
  useEffect(() => {
    const map: { [deptId: string]: number } = {};
    departments.forEach(dept => {
      const existing = annualKpiTarget.departmentTargets?.find(d => d.departmentId === dept.id);
      map[dept.id] = existing ? existing.targetHoursPerStaff : (annualKpiTarget.annualTargetHoursPerStaff || 20);
    });
    setDeptTargets(map);
  }, [departments, annualKpiTarget]);

  const handleDeptTargetChange = (deptId: string, val: number) => {
    setDeptTargets(prev => ({ ...prev, [deptId]: val }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!isGm) {
      setErrorMessage('Akses Ditolak: Hanya General Manager (GM) yang berwenang menetapkan dan mengesahkan Target KPI Pelatihan Karyawan.');
      return;
    }

    const formattedDeptTargets = departments.map(d => ({
      departmentId: d.id,
      departmentName: d.name,
      targetHoursPerStaff: Number(deptTargets[d.id] || annualTargetHours)
    }));

    const result = updateAnnualKpiTarget({
      year: Number(year),
      annualTargetHoursPerStaff: Number(annualTargetHours),
      strategicObjectives,
      notes,
      departmentTargets: formattedDeptTargets
    });

    if (!result.success) {
      setErrorMessage(result.message);
      return;
    }

    setStatusMessage(result.message);
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
    }, 4000);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white rounded-2xl p-6 shadow-md border border-emerald-800/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                GM Executive Authority Module
              </span>
              <span className="text-xs text-slate-300">
                Khusus Penetapan Target Pelatihan Keseluruhan Staf
              </span>
            </div>
            <h1 className="text-xl font-extrabold tracking-tight text-white">
              Penetapan Target KPI Pelatihan Tahunan (GM Sanction)
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Sesuai kebijakan tata kelola SDM GMCC, target jam pelatihan untuk seluruh staf hanya dapat disahkan dan diubah oleh <strong>General Manager</strong>. Target ini menjadi acuan evaluasi kinerja dan kepatuhan MICE internasional.
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10 text-right shrink-0">
            <span className="text-[10px] text-slate-400 block uppercase">Pejabat Pengesah</span>
            <span className="font-bold text-emerald-300 text-xs block">
              {annualKpiTarget.gmName || 'Bambang Wijaya, CHA'}
            </span>
            <span className="text-[10px] text-slate-400 block">
              General Manager GMCC
            </span>
          </div>
        </div>
      </div>

      {/* Role permission status banner */}
      {!isGm ? (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-amber-900 flex items-start gap-3 shadow-xs">
          <Lock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <h4 className="font-bold text-amber-950">
              Akses Mode Lihat (Read-Only)
            </h4>
            <p className="text-amber-800 leading-relaxed">
              Anda sedang masuk sebagai <strong>{currentUser.name} ({currentUser.role})</strong>. Formulir penetapan target di bawah ini dikunci karena kewenangan menetapkan target jam pelatihan karyawan berada secara eksklusif di tangan <strong>General Manager (GM)</strong>.
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-emerald-900 flex items-start gap-3 shadow-xs">
          <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="text-xs space-y-1">
            <h4 className="font-bold text-emerald-950">
              Hak Akses General Manager Terverifikasi
            </h4>
            <p className="text-emerald-800 leading-relaxed">
              Selamat datang, Pak Bambang. Anda memiliki hak penuh untuk menetapkan kuota target jam pelatihan tahunan, memberikan petunjuk strategis, dan mengesahkan target departemen.
            </p>
          </div>
        </div>
      )}

      {/* Success Notification */}
      {isSuccess && (
        <div className="bg-emerald-600 text-white p-4 rounded-xl shadow-lg flex items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span className="text-xs font-semibold">{statusMessage}</span>
          </div>
          <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded font-mono">
            TERSINKRONISASI KE DASHBOARD
          </span>
        </div>
      )}

      {/* Error Message */}
      {errorMessage && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl flex items-center gap-2.5 text-xs">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main KPI Configuration Form */}
      <form onSubmit={handleSave} className="space-y-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Target className="w-4 h-4 text-emerald-700" />
                1. Target Pelatihan Utama Perusahaan (Company-Wide Base Target)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Target minimum jam pelatihan per karyawan per tahun kalender.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Tahun Anggaran Pelatihan *
              </label>
              <input
                type="number"
                disabled={!isGm}
                value={year}
                onChange={e => setYear(Number(e.target.value))}
                className={`w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 font-bold ${
                  !isGm ? 'bg-slate-100 cursor-not-allowed' : 'bg-white focus:border-emerald-700'
                }`}
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Target Jam Pelatihan per Karyawan (Jam/Tahun) *
              </label>
              <div className="relative">
                <input
                  type="number"
                  min={1}
                  max={100}
                  disabled={!isGm}
                  value={annualTargetHours}
                  onChange={e => setAnnualTargetHours(Number(e.target.value))}
                  className={`w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 font-bold font-mono text-base ${
                    !isGm ? 'bg-slate-100 cursor-not-allowed text-slate-700' : 'bg-white focus:border-emerald-700 text-emerald-700'
                  }`}
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-medium">
                  Jam / Staf
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Estimasi Total Kuota GMCC
              </label>
              <div className="w-full text-xs rounded-lg border border-slate-200 px-3 py-2 bg-slate-50 text-slate-700 font-mono font-bold flex items-center justify-between">
                <span>{employees.length} Karyawan</span>
                <span className="text-emerald-700 font-bold text-sm">
                  {employees.length * annualTargetHours} Jam
                </span>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Arah Kebijakan Strategis GM (Strategic Objectives) *
            </label>
            <textarea
              rows={3}
              disabled={!isGm}
              required
              value={strategicObjectives}
              onChange={e => setStrategicObjectives(e.target.value)}
              placeholder="Jelaskan fokus kompetensi yang ingin dicapai melalui pelatihan tahun ini..."
              className={`w-full text-xs rounded-lg border border-slate-300 p-3 text-slate-900 leading-relaxed ${
                !isGm ? 'bg-slate-100 cursor-not-allowed' : 'bg-white focus:border-emerald-700'
              }`}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Catatan & Petunjuk Pelaksanaan GM untuk Human Capital
            </label>
            <input
              type="text"
              disabled={!isGm}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Prioritaskan sertifikasi HACCP dan kesiapan protocol VIP Summit."
              className={`w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 ${
                !isGm ? 'bg-slate-100 cursor-not-allowed' : 'bg-white focus:border-emerald-700'
              }`}
            />
          </div>
        </div>

        {/* Department-Specific Target Adjustments */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <Building className="w-4 h-4 text-emerald-700" />
                2. Penyesuaian Target Jam per Departemen (Departmental KPI Target)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                GM dapat menyesuaikan target jam khusus untuk departemen dengan kebutuhan operasional tinggi (seperti F&B atau Safety).
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {departments.map(dept => {
              const currentVal = deptTargets[dept.id] !== undefined ? deptTargets[dept.id] : annualTargetHours;
              const deptStaffCount = employees.filter(e => e.departmentId === dept.id).length;

              return (
                <div 
                  key={dept.id}
                  className="bg-slate-50/80 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between gap-3"
                >
                  <div>
                    <span className="font-bold text-xs text-slate-900 block">{dept.name}</span>
                    <span className="text-[11px] text-slate-500 block">
                      Kepala: {dept.headName} · {deptStaffCount} Staf
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <input
                      type="number"
                      min={1}
                      max={80}
                      disabled={!isGm}
                      value={currentVal}
                      onChange={e => handleDeptTargetChange(dept.id, Number(e.target.value))}
                      className={`w-20 text-xs font-mono font-bold text-center rounded-lg border border-slate-300 px-2 py-1.5 ${
                        !isGm ? 'bg-slate-100 cursor-not-allowed' : 'bg-white focus:border-emerald-700'
                      }`}
                    />
                    <span className="text-[11px] text-slate-500 font-medium">Jam/Staf</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Official Sanction Footer / Submit Button */}
        <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block">
              Digital Executive Ratification
            </span>
            <h4 className="font-bold text-sm text-white">
              Pengesahan Surat Keputusan Target KPI Pelatihan GMCC
            </h4>
            <p className="text-xs text-slate-400">
              Terakhir disahkan pada: {new Date(annualKpiTarget.sanctionDate || new Date().toISOString()).toLocaleDateString('id-ID', { dateStyle: 'full' })}
            </p>
          </div>

          {isGm && (
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-lg transition-all border border-emerald-500 cursor-pointer self-stretch sm:self-auto justify-center"
            >
              <Save className="w-4 h-4" />
              Sahkan & Terbitkan Target KPI Resmi
            </button>
          )}
        </div>
      </form>
    </div>
  );
};
