import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Employee, EmploymentType, EmploymentStatus, UserRole } from '../../types';
import { 
  X, 
  Save, 
  User, 
  Shield, 
  Briefcase, 
  Calendar, 
  Phone, 
  Mail, 
  MapPin,
  KeyRound,
  Eye,
  EyeOff,
  RefreshCw,
  Copy,
  Check,
  Upload,
  Camera,
  Image as ImageIcon
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  employeeToEdit?: Employee | null;
}

export const AdminEmployeeModal: React.FC<Props> = ({
  isOpen,
  onClose,
  employeeToEdit
}) => {
  const { 
    addEmployee, 
    updateEmployee, 
    departments, 
    employees, 
    addUserAccount, 
    updateUserAccount, 
    getUserAccountByEmployeeId 
  } = useApp();

  const existingAccount = employeeToEdit ? getUserAccountByEmployeeId(employeeToEdit.id) : undefined;

  const [fullName, setFullName] = useState(employeeToEdit?.fullName || '');
  const [preferredName, setPreferredName] = useState(employeeToEdit?.preferredName || '');
  const [employeeNumber, setEmployeeNumber] = useState(employeeToEdit?.employeeNumber || `GMCC-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`);
  const [companyEmail, setCompanyEmail] = useState(employeeToEdit?.companyEmail || '');
  const [phone, setPhone] = useState(employeeToEdit?.phone || '+62 812 ');
  const [departmentId, setDepartmentId] = useState(employeeToEdit?.departmentId || departments[0]?.id || 'DEP-FB');
  const [jobTitle, setJobTitle] = useState(employeeToEdit?.jobTitle || '');
  const [employmentType, setEmploymentType] = useState<EmploymentType>(employeeToEdit?.employmentType || 'PKWT');
  const [employmentStatus, setEmploymentStatus] = useState<EmploymentStatus>(employeeToEdit?.employmentStatus || 'ACTIVE');
  const [joinDate, setJoinDate] = useState(employeeToEdit?.joinDate || '2025-01-01');
  const [probationEndDate, setProbationEndDate] = useState(employeeToEdit?.probationEndDate || '');
  const [directSupervisorId, setDirectSupervisorId] = useState(employeeToEdit?.directSupervisorId || '');
  const [location, setLocation] = useState(employeeToEdit?.location || 'GMCC Convention Center');
  const [workSchedule, setWorkSchedule] = useState(employeeToEdit?.workSchedule || '5/2 Hospitality Roster');
  const [avatarUrl, setAvatarUrl] = useState(employeeToEdit?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80');

  // Daily worker & Contract specific fields
  const [dailyRate, setDailyRate] = useState<number>(employeeToEdit?.dailyRate || 250000);
  const [assignedEvent, setAssignedEvent] = useState(employeeToEdit?.assignedEvent || '');
  const [dwAgreementNumber, setDwAgreementNumber] = useState(employeeToEdit?.dwAgreementNumber || '');
  const [contractDurationMonths, setContractDurationMonths] = useState<number>(employeeToEdit?.contractDurationMonths || 12);

  // Identity / restricted fields
  const [idCardNumber, setIdCardNumber] = useState(employeeToEdit?.idCardNumber || '');
  const [address, setAddress] = useState(employeeToEdit?.address || '');
  const [emergencyContactName, setEmergencyContactName] = useState(employeeToEdit?.emergencyContactName || '');
  const [emergencyContactPhone, setEmergencyContactPhone] = useState(employeeToEdit?.emergencyContactPhone || '');
  const [emergencyContactRelation, setEmergencyContactRelation] = useState(employeeToEdit?.emergencyContactRelation || '');

  // User Account Credentials fields
  const [createAccount, setCreateAccount] = useState(true);
  const [accountUserId, setAccountUserId] = useState(
    existingAccount?.userId || (employeeToEdit ? employeeToEdit.employeeNumber.toLowerCase() : '')
  );
  const [accountPassword, setAccountPassword] = useState(existingAccount?.password || '');
  const [showPassword, setShowPassword] = useState(false);
  const [accountRole, setAccountRole] = useState<UserRole>(existingAccount?.role || 'STAFF');
  const [accountStatus, setAccountStatus] = useState<'ACTIVE' | 'SUSPENDED'>(existingAccount?.status || 'ACTIVE');
  const [copied, setCopied] = useState(false);

  // Auto-generate suggested User ID when typing preferredName if not set
  useEffect(() => {
    if (!employeeToEdit && (!accountUserId || accountUserId.startsWith('staff'))) {
      const clean = preferredName ? preferredName.toLowerCase().replace(/[^a-z0-9]/g, '') : '';
      if (clean) {
        setAccountUserId(`${clean}.${employeeNumber.slice(-3)}`);
      }
    }
  }, [preferredName, employeeNumber, employeeToEdit]);

  // Auto suggest role based on job title
  useEffect(() => {
    if (!existingAccount) {
      const t = jobTitle.toLowerCase();
      if (t.includes('general manager') || t.includes('gm')) {
        setAccountRole('GM');
      } else if (t.includes('human capital') || t.includes('hc') || t.includes('hr')) {
        setAccountRole('HC');
      } else if (t.includes('head') || t.includes('director') || t.includes('manager')) {
        setAccountRole('DEPT_HEAD');
      } else {
        setAccountRole('STAFF');
      }
    }
  }, [jobTitle, existingAccount]);

  const generatePassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*';
    let res = '';
    for (let i = 0; i < 8; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setAccountPassword(`Gmcc@${res.slice(0, 4)}!`);
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const supervisor = employees.find(emp => emp.id === directSupervisorId);
    const finalCompanyEmail = companyEmail || `${preferredName.toLowerCase() || 'staff'}@golomoricc.com`;

    const payload = {
      fullName,
      preferredName: preferredName || fullName.split(' ')[0],
      employeeNumber,
      companyEmail: finalCompanyEmail,
      email: employeeToEdit?.email || `${preferredName.toLowerCase() || 'staff'}@gmail.com`,
      phone,
      departmentId,
      jobTitle,
      employmentType,
      employmentStatus,
      joinDate,
      probationEndDate: probationEndDate || undefined,
      directSupervisorId: directSupervisorId || undefined,
      directSupervisorName: supervisor?.fullName || undefined,
      location,
      workSchedule,
      avatarUrl,
      dailyRate: employmentType === 'DAILY_WORKER' ? Number(dailyRate) : undefined,
      assignedEvent: employmentType === 'DAILY_WORKER' ? assignedEvent : undefined,
      dwAgreementNumber: employmentType === 'DAILY_WORKER' ? dwAgreementNumber : undefined,
      contractDurationMonths: employmentType === 'PKWT' ? Number(contractDurationMonths) : undefined,
      idCardType: 'KTP' as const,
      idCardNumber: idCardNumber || undefined,
      address: address || undefined,
      emergencyContactName: emergencyContactName || undefined,
      emergencyContactPhone: emergencyContactPhone || undefined,
      emergencyContactRelation: emergencyContactRelation || undefined
    };

    if (employeeToEdit) {
      updateEmployee({
        ...employeeToEdit,
        ...payload
      });

      // Update or create user account if checked
      if (createAccount && accountUserId.trim()) {
        if (existingAccount) {
          updateUserAccount({
            ...existingAccount,
            userId: accountUserId.trim(),
            username: accountUserId.trim(),
            password: accountPassword.trim(),
            name: fullName,
            email: finalCompanyEmail,
            role: accountRole,
            departmentId,
            status: accountStatus,
            updatedAt: new Date().toISOString()
          });
        } else {
          addUserAccount({
            userId: accountUserId.trim(),
            username: accountUserId.trim(),
            password: accountPassword.trim(),
            name: fullName,
            email: finalCompanyEmail,
            role: accountRole,
            employeeId: employeeToEdit.id,
            departmentId,
            status: accountStatus
          });
        }
      }
    } else {
      const newEmp = addEmployee(payload);

      // Create login account for new employee
      if (createAccount && accountUserId.trim()) {
        addUserAccount({
          userId: accountUserId.trim(),
          username: accountUserId.trim(),
          password: accountPassword.trim(),
          name: newEmp.fullName,
          email: newEmp.companyEmail,
          role: accountRole,
          employeeId: newEmp.id,
          departmentId: newEmp.departmentId,
          status: accountStatus
        });
      }
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden border border-slate-200 max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div>
            <h3 className="font-bold text-sm tracking-tight">
              {employeeToEdit ? `Edit Profil Karyawan: ${employeeToEdit.fullName}` : 'Tambah Karyawan Baru (Visual No-Code)'}
            </h3>
            <p className="text-[11px] text-slate-400">
              Kelola data staf PKWT dan Daily Worker (DW) GMCC Labuan Bajo.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 text-xs flex-1">
          {/* Section: Basic Identity */}
          <div className="space-y-3">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
              <User className="w-4 h-4 text-emerald-700" />
              1. Informasi Identitas Pokok
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Nama Lengkap & Gelar <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700"
                  placeholder="misal: Budi Pratama Setyadi"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Nama Panggilan (Preferred Name)
                </label>
                <input
                  type="text"
                  value={preferredName}
                  onChange={e => setPreferredName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700"
                  placeholder="misal: Budi"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Nomor Induk Karyawan (NIK) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={employeeNumber}
                  onChange={e => setEmployeeNumber(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 font-mono"
                  placeholder="GMCC-2025-045"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Email Perusahaan
                </label>
                <input
                  type="email"
                  value={companyEmail}
                  onChange={e => setCompanyEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 font-mono"
                  placeholder="budi.pratama@golomoricc.com"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Nomor HP / WhatsApp <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700"
                />
              </div>

              <div className="sm:col-span-2 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                <label className="block text-slate-800 font-bold mb-2 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-emerald-700" />
                    Foto Profil Karyawan (Profile Photo)
                  </span>
                  {avatarUrl && (
                    <button
                      type="button"
                      onClick={() => setAvatarUrl('')}
                      className="text-[10px] text-rose-600 hover:text-rose-700 font-semibold"
                    >
                      Hapus Foto
                    </button>
                  )}
                </label>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  {/* Photo Preview Thumbnail */}
                  <div className="relative shrink-0">
                    {avatarUrl ? (
                      <img 
                        src={avatarUrl} 
                        alt="Profile Preview" 
                        className="w-16 h-16 rounded-full object-cover border-2 border-emerald-600 shadow-sm"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-full bg-slate-200 text-slate-500 flex flex-col items-center justify-center border-2 border-dashed border-slate-300">
                        <User className="w-6 h-6 text-slate-400" />
                      </div>
                    )}
                  </div>

                  {/* Upload button & presets */}
                  <div className="space-y-2 flex-1 w-full">
                    <div className="flex flex-wrap items-center gap-2">
                      <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs rounded-lg shadow-xs cursor-pointer transition-colors">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Unggah Foto dari Perangkat</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={e => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onloadend = () => {
                                setAvatarUrl(reader.result as string);
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                      </label>

                      <input
                        type="text"
                        placeholder="atau paste URL foto di sini..."
                        value={avatarUrl}
                        onChange={e => setAvatarUrl(e.target.value)}
                        className="flex-1 min-w-[180px] px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white"
                      />
                    </div>

                    {/* Presets */}
                    <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-slate-500">
                      <span>Pilihan Cepat:</span>
                      {[
                        { label: 'Pria Formal 1', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80' },
                        { label: 'Pria Formal 2', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80' },
                        { label: 'Wanita Formal 1', url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80' },
                        { label: 'Wanita Formal 2', url: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&auto=format&fit=crop&q=80' }
                      ].map((preset, pIdx) => (
                        <button
                          key={pIdx}
                          type="button"
                          onClick={() => setAvatarUrl(preset.url)}
                          className="px-2 py-0.5 bg-slate-200/80 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 rounded border border-slate-300 transition-colors"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Section: Employment & Position */}
          <div className="space-y-3">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
              <Briefcase className="w-4 h-4 text-emerald-700" />
              2. Departemen, Jabatan & Tipe Karyawan
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Departemen <span className="text-rose-500">*</span>
                </label>
                <select
                  value={departmentId}
                  onChange={e => setDepartmentId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white"
                >
                  {departments.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.name} ({d.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Jabatan / Posisi <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={jobTitle}
                  onChange={e => setJobTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700"
                  placeholder="misal: Banquet Supervisor"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Jenis Hubungan Kerja <span className="text-rose-500">*</span>
                </label>
                <select
                  value={employmentType}
                  onChange={e => setEmploymentType(e.target.value as EmploymentType)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white font-bold"
                >
                  <option value="PKWT">PKWT (Kontrak Waktu Tertentu)</option>
                  <option value="DAILY_WORKER">Daily Worker (Pekerja Harian Lepas)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Status Karyawan <span className="text-rose-500">*</span>
                </label>
                <select
                  value={employmentStatus}
                  onChange={e => setEmploymentStatus(e.target.value as EmploymentStatus)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white"
                >
                  <option value="ACTIVE">ACTIVE (Aktif Bekerja)</option>
                  <option value="PROBATION">PROBATION (Masa Percobaan)</option>
                  <option value="INACTIVE">INACTIVE (Non-aktif)</option>
                  <option value="EX_EMPLOYEE">EX_EMPLOYEE (Resign/Keluar)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Tanggal Bergabung (Join Date) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  required
                  value={joinDate}
                  onChange={e => setJoinDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Atasan Langsung (Dept Head)
                </label>
                <select
                  value={directSupervisorId}
                  onChange={e => setDirectSupervisorId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white"
                >
                  <option value="">-- Tanpa Atasan Langsung --</option>
                  {employees.filter(e => e.id !== employeeToEdit?.id).map(e => (
                    <option key={e.id} value={e.id}>
                      {e.fullName} ({e.jobTitle})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Section: Specific for Daily Worker (DW) or PKWT */}
          {employmentType === 'DAILY_WORKER' && (
            <div className="p-3.5 rounded-xl bg-purple-50 border border-purple-200 space-y-3">
              <h4 className="font-bold text-purple-900 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-purple-700" />
                Data Khusus Daily Worker (DW)
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-purple-900 font-semibold mb-1">
                    Upah Harian (Daily Rate IDR) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    value={dailyRate}
                    onChange={e => setDailyRate(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-purple-300 focus:outline-hidden bg-white font-bold"
                    placeholder="250000"
                  />
                </div>

                <div>
                  <label className="block text-purple-900 font-semibold mb-1">
                    Nomor SPK Daily Worker
                  </label>
                  <input
                    type="text"
                    value={dwAgreementNumber}
                    onChange={e => setDwAgreementNumber(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-purple-300 focus:outline-hidden bg-white font-mono"
                    placeholder="SPK-DW/GMCC/FB/2026/044"
                  />
                </div>

                <div>
                  <label className="block text-purple-900 font-semibold mb-1">
                    Event / Tugas yang Ditugaskan
                  </label>
                  <input
                    type="text"
                    value={assignedEvent}
                    onChange={e => setAssignedEvent(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-purple-300 focus:outline-hidden bg-white"
                    placeholder="ASEAN Maritime Summit"
                  />
                </div>
              </div>
            </div>
          )}

          {employmentType === 'PKWT' && (
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 space-y-2">
              <h4 className="font-bold text-amber-900 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-amber-700" />
                Ketentuan Kontrak PKWT
              </h4>
              <div className="w-full sm:w-48">
                <label className="block text-amber-900 font-semibold mb-1">
                  Durasi Kontrak (Bulan)
                </label>
                <input
                  type="number"
                  value={contractDurationMonths}
                  onChange={e => setContractDurationMonths(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-amber-300 focus:outline-hidden bg-white font-bold"
                  placeholder="12"
                />
              </div>
            </div>
          )}

          {/* Section: Sensitive & Emergency Identity */}
          <div className="space-y-3">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
              <Shield className="w-4 h-4 text-emerald-700" />
              3. Data Personal & Kontak Darurat (Restricted)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  No. KTP / Paspor
                </label>
                <input
                  type="text"
                  value={idCardNumber}
                  onChange={e => setIdCardNumber(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden font-mono"
                  placeholder="5315025804850001"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Alamat Domisili
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden"
                  placeholder="Desa Golo Mori, Labuan Bajo"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Nama Kontak Darurat
                </label>
                <input
                  type="text"
                  value={emergencyContactName}
                  onChange={e => setEmergencyContactName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  No. HP & Hubungan Kontak Darurat
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={emergencyContactPhone}
                    onChange={e => setEmergencyContactPhone(e.target.value)}
                    placeholder="No. Telepon"
                    className="flex-1 px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden"
                  />
                  <input
                    type="text"
                    value={emergencyContactRelation}
                    onChange={e => setEmergencyContactRelation(e.target.value)}
                    placeholder="Hubungan (Orang Tua / Pasangan)"
                    className="w-36 px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section: User ID & Password Account Credentials */}
          <div className="space-y-3 p-4 bg-emerald-50/50 border border-emerald-200 rounded-2xl">
            <div className="flex items-center justify-between border-b border-emerald-200/70 pb-2">
              <h4 className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                <KeyRound className="w-4 h-4 text-emerald-700" />
                4. Akun Login Karyawan (User ID & Password)
              </h4>
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={createAccount}
                  onChange={e => setCreateAccount(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                />
                <span className="text-[11px] font-semibold text-emerald-950">
                  {employeeToEdit ? 'Kelola Akun Login' : 'Buat Akun Login Staff Ini'}
                </span>
              </label>
            </div>

            {createAccount && (
              <div className="space-y-3 pt-1">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      User ID / Username Login <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required={createAccount}
                      value={accountUserId}
                      onChange={e => setAccountUserId(e.target.value)}
                      placeholder="misal: budi.pratama / EMP-0010"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white font-mono font-bold text-slate-900"
                    />
                    <span className="text-[10px] text-slate-500 mt-0.5 block">
                      ID unik untuk staf masuk ke portal HRIS.
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-slate-700 font-bold">
                        Password Karyawan <span className="text-rose-500">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={generatePassword}
                        className="text-[10px] text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1"
                      >
                        <RefreshCw className="w-2.5 h-2.5" />
                        Acak Password
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required={createAccount}
                        value={accountPassword}
                        onChange={e => setAccountPassword(e.target.value)}
                        placeholder="Password login"
                        className="w-full pl-3 pr-8 py-2 rounded-xl border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white font-mono font-semibold"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                      >
                        {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <span className="text-[10px] text-slate-500 mt-0.5 block">
                      Berikan kredensial ini ke karyawan saat orientasi.
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Hak Akses Portal (Role)
                    </label>
                    <select
                      value={accountRole}
                      onChange={e => setAccountRole(e.target.value as UserRole)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden bg-white font-semibold"
                    >
                      <option value="STAFF">STAFF (Hanya Cuti & Dokumen Pribadi)</option>
                      <option value="DEPT_HEAD">DEPT_HEAD (Review & Approval Dept Head)</option>
                      <option value="HC">HC (Human Capital Manager)</option>
                      <option value="GM">GM (General Manager)</option>
                      <option value="ADMIN">ADMIN (System Administrator)</option>
                      <option value="AUDITOR">AUDITOR (Internal Auditor)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Status Akun Login
                    </label>
                    <select
                      value={accountStatus}
                      onChange={e => setAccountStatus(e.target.value as 'ACTIVE' | 'SUSPENDED')}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden bg-white"
                    >
                      <option value="ACTIVE">ACTIVE (Aktif Dapat Login)</option>
                      <option value="SUSPENDED">SUSPENDED (Ditangguhkan)</option>
                    </select>
                  </div>
                </div>

                {/* Quick Copy summary */}
                {accountUserId && (
                  <div className="p-2.5 bg-white/80 border border-emerald-200 rounded-xl flex items-center justify-between">
                    <span className="font-mono text-[11px] text-slate-700">
                      User ID: <strong>{accountUserId}</strong> | Password: <strong>{showPassword ? accountPassword : '••••••••'}</strong>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(`Akun HRIS GMCC:\nUser ID: ${accountUserId}\nPassword: ${accountPassword}\nRole: ${accountRole}`);
                        setCopied(true);
                        setTimeout(() => setCopied(false), 2000);
                      }}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-medium"
                    >
                      {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-slate-500" />}
                      {copied ? 'Tersalin' : 'Salin Info Akun'}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-medium"
            >
              Batal
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold shadow-xs"
            >
              <Save className="w-4 h-4" />
              {employeeToEdit ? 'Simpan Perubahan Karyawan' : 'Daftarkan Karyawan Baru'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
