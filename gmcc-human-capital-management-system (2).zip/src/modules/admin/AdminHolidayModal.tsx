import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PublicHoliday } from '../../types';
import { X, Save, Calendar } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  holidayToEdit?: PublicHoliday | null;
}

export const AdminHolidayModal: React.FC<Props> = ({
  isOpen,
  onClose,
  holidayToEdit
}) => {
  const { addHoliday, updateHoliday } = useApp();

  const [date, setDate] = useState(holidayToEdit?.date || '2026-01-01');
  const [name, setName] = useState(holidayToEdit?.name || '');
  const [type, setType] = useState<'NATIONAL' | 'COLLECTIVE_LEAVE' | 'COMPANY_SPECIAL'>(
    holidayToEdit?.type || 'NATIONAL'
  );
  const [notes, setNotes] = useState(holidayToEdit?.notes || '');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (holidayToEdit) {
      updateHoliday({
        ...holidayToEdit,
        date,
        name,
        type,
        notes: notes || undefined
      });
    } else {
      addHoliday({
        date,
        name,
        type,
        isOfficial: true,
        notes: notes || undefined
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-slate-200">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm tracking-tight">
              {holidayToEdit ? 'Edit Hari Libur' : 'Tambah Hari Libur Nasional / Cuti Bersama'}
            </h3>
            <p className="text-[11px] text-slate-400">
              Kelola kalender resmi GMCC untuk acuan kompensasi kerja.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Tanggal Libur <span className="text-rose-500">*</span>
            </label>
            <input
              type="date"
              required
              value={date}
              onChange={e => setDate(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Nama Hari Libur <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="misal: Hari Raya Idul Fitri 1447 H"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Kategori Libur <span className="text-rose-500">*</span>
            </label>
            <select
              value={type}
              onChange={e => setType(e.target.value as any)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden bg-white"
            >
              <option value="NATIONAL">Libur Nasional Resmi (SKB 3 Menteri)</option>
              <option value="COLLECTIVE_LEAVE">Cuti Bersama Resmi</option>
              <option value="COMPANY_SPECIAL">Hari Libur Khusus GMCC</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Catatan / SKB
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="misal: SKB No. 1022 Tahun 2026"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-medium"
            >
              Batal
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold shadow-xs"
            >
              <Save className="w-4 h-4" />
              {holidayToEdit ? 'Simpan' : 'Tambahkan'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
