import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { EmploymentContract, EmploymentType, ContractStatus, TerminationReason } from '../../types';
import { X, Save, FileCheck2, Calendar, UserX, AlertTriangle } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  contractToEdit?: EmploymentContract | null;
}

export const AdminContractModal: React.FC<Props> = ({
  isOpen,
  onClose,
  contractToEdit
}) => {
  const { employees, addContract, updateContract, currentUser } = useApp();

  const [employeeId, setEmployeeId] = useState(
    contractToEdit?.employeeId || employees[0]?.id || ''
  );
  const [contractNumber, setContractNumber] = useState(
    contractToEdit?.contractNumber || `${Math.floor(100 + Math.random() * 900)}/GMCC-HC/PKWT/${new Date().getFullYear()}`
  );
  const [employmentType, setEmploymentType] = useState<EmploymentType>(
    contractToEdit?.employmentType || 'PKWT'
  );
  const [startDate, setStartDate] = useState(contractToEdit?.startDate || '2025-01-01');
  const [endDate, setEndDate] = useState(contractToEdit?.endDate || '2025-12-31');
  const [status, setStatus] = useState<ContractStatus>(contractToEdit?.status || 'ACTIVE');
  const [responsibleHc, setResponsibleHc] = useState(contractToEdit?.responsibleHc || currentUser.name);
  const [notes, setNotes] = useState(contractToEdit?.notes || '');

  // Termination specifics
  const [terminationReason, setTerminationReason] = useState<TerminationReason>(
    contractToEdit?.terminationDetails?.reason || 'END_OF_CONTRACT'
  );
  const [terminationEffectiveDate, setTerminationEffectiveDate] = useState(
    contractToEdit?.terminationDetails?.effectiveDate || contractToEdit?.endDate || new Date().toISOString().split('T')[0]
  );
  const [severanceNotes, setSeveranceNotes] = useState(
    contractToEdit?.terminationDetails?.severanceNotes || ''
  );

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const emp = employees.find(e => e.id === employeeId);
    if (!emp) return;

    const terminationInfo = status === 'TERMINATED' ? {
      terminatedAt: contractToEdit?.terminationDetails?.terminatedAt || new Date().toISOString(),
      terminatedBy: contractToEdit?.terminationDetails?.terminatedBy || currentUser.name,
      effectiveDate: terminationEffectiveDate,
      reason: terminationReason,
      reasonLabel: terminationReason.replace('_', ' '),
      notes,
      severanceNotes: severanceNotes.trim() || undefined
    } : undefined;

    if (contractToEdit) {
      updateContract({
        ...contractToEdit,
        contractNumber,
        employeeId,
        employeeName: emp.fullName,
        departmentId: emp.departmentId,
        position: emp.jobTitle,
        employmentType,
        startDate,
        endDate,
        status,
        terminationDetails: terminationInfo,
        responsibleHc,
        notes,
        updatedAt: new Date().toISOString()
      });
    } else {
      addContract({
        contractNumber,
        employeeId,
        employeeName: emp.fullName,
        departmentId: emp.departmentId,
        position: emp.jobTitle,
        employmentType,
        startDate,
        endDate,
        status,
        responsibleHc,
        notes
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm tracking-tight">
              {contractToEdit ? 'Edit Kontrak Kerja' : 'Buat Kontrak Kerja Baru (No-Code)'}
            </h3>
            <p className="text-[11px] text-slate-400">
              Modul visual untuk mengelola masa berlaku kontrak PKWT & SPK Daily Worker.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Pilih Karyawan <span className="text-rose-500">*</span>
            </label>
            <select
              value={employeeId}
              onChange={e => setEmployeeId(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white"
            >
              {employees.map(emp => (
                <option key={emp.id} value={emp.id}>
                  {emp.fullName} ({emp.employeeNumber} - {emp.jobTitle})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Nomor Kontrak <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={contractNumber}
                onChange={e => setContractNumber(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 font-mono"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Tipe Hubungan Kerja <span className="text-rose-500">*</span>
              </label>
              <select
                value={employmentType}
                onChange={e => setEmploymentType(e.target.value as EmploymentType)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white font-bold"
              >
                <option value="PKWT">PKWT (Kontrak Waktu Tertentu)</option>
                <option value="DAILY_WORKER">Daily Worker (SPK Harian Lepas)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Tanggal Mulai <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                required
                value={startDate}
                onChange={e => setStartDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Tanggal Berakhir <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                required
                value={endDate}
                onChange={e => setEndDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Status Kontrak <span className="text-rose-500">*</span>
              </label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as ContractStatus)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden bg-white"
              >
                <option value="ACTIVE">ACTIVE (Aktif)</option>
                <option value="EXPIRING_SOON">EXPIRING_SOON (Segera Habis)</option>
                <option value="EXPIRED">EXPIRED (Kadaluarsa)</option>
                <option value="DRAFT">DRAFT (Konsep)</option>
                <option value="RENEWED">RENEWED (Diperpanjang)</option>
                <option value="TERMINATED">TERMINATED (Dihentikan)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                PIC Human Capital
              </label>
              <input
                type="text"
                value={responsibleHc}
                onChange={e => setResponsibleHc(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden"
              />
            </div>
          </div>

          {status === 'TERMINATED' && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl space-y-3">
              <h4 className="font-bold text-rose-900 flex items-center gap-1.5 text-xs">
                <UserX className="w-4 h-4 text-rose-700" />
                Detail Pengakhiran / Terminasi Kontrak
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Alasan Terminasi <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={terminationReason}
                    onChange={e => setTerminationReason(e.target.value as TerminationReason)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden bg-white text-xs"
                  >
                    <option value="END_OF_CONTRACT">Habis Masa Kontrak / Selesai</option>
                    <option value="RESIGNATION">Pengunduran Diri (Resignation)</option>
                    <option value="MUTUAL_AGREEMENT">Kesepakatan Bersama</option>
                    <option value="DISMISSAL_PHK">Pemutusan Hubungan Kerja (PHK)</option>
                    <option value="DISCIPLINARY">Pelanggaran Disiplin (SP3)</option>
                    <option value="RETIREMENT">Pensiun / Alasan Kesehatan</option>
                    <option value="OTHER">Alasan Lainnya</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Tanggal Efektif Berakhir <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={terminationEffectiveDate}
                    onChange={e => setTerminationEffectiveDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Kompensasi PKWT / Hak Pesangon (PP No. 35/2021)
                </label>
                <input
                  type="text"
                  value={severanceNotes}
                  onChange={e => setSeveranceNotes(e.target.value)}
                  placeholder="misal: Kompensasi 1x gaji pokok (Rp 4.500.000) + sisa cuti 3 hari"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden text-xs"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Catatan Kontrak / Rekomendasi
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden"
              placeholder="Catatan evaluasi kinerja, rekomendasi perpanjangan, atau pasal khusus..."
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-medium"
            >
              Batal
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold shadow-xs"
            >
              <Save className="w-4 h-4" />
              {contractToEdit ? 'Simpan Perubahan' : 'Buat Kontrak'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
