import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LeaveType, LedgerTransactionType, LeaveLedgerEntry } from '../../types';
import { X, Save, AlertCircle, Calendar, Plus, RefreshCw } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  entryToEdit?: LeaveLedgerEntry | null;
  initialEmployeeId?: string;
  initialYear?: number;
}

export const AdminLedgerModal: React.FC<Props> = ({
  isOpen,
  onClose,
  entryToEdit,
  initialEmployeeId,
  initialYear
}) => {
  const { employees, addLedgerEntry, updateLedgerEntry, currentUser } = useApp();

  const [employeeId, setEmployeeId] = useState(
    entryToEdit ? entryToEdit.employeeId : (initialEmployeeId || employees[0]?.id || '')
  );
  const [leaveType, setLeaveType] = useState<LeaveType>(
    entryToEdit ? entryToEdit.leaveType : 'ANNUAL_LEAVE'
  );
  const [transactionType, setTransactionType] = useState<LedgerTransactionType>(
    entryToEdit ? entryToEdit.transactionType : 'ANNUAL_ENTITLEMENT_CREDIT'
  );
  const [days, setDays] = useState<number>(
    entryToEdit ? entryToEdit.days : 12
  );
  const [effectiveDate, setEffectiveDate] = useState(
    entryToEdit 
      ? entryToEdit.effectiveDate 
      : (initialYear ? `${initialYear}-01-01` : '2025-01-01')
  );
  const [expiryDate, setExpiryDate] = useState(entryToEdit?.expiryDate || '');
  const [referenceDocNumber, setReferenceDocNumber] = useState(
    entryToEdit?.referenceDocNumber || (initialYear ? `HC/POL/${initialYear}/001` : 'HC/POL/2025/001')
  );
  const [reason, setReason] = useState(
    entryToEdit 
      ? entryToEdit.reason 
      : (initialYear ? `Penyesuaian Hak Cuti Tahunan ${initialYear}` : 'Penyesuaian Hak Cuti Tahunan 2025')
  );

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const targetEmp = employees.find(emp => emp.id === employeeId);
    if (!targetEmp) return;

    if (entryToEdit) {
      updateLedgerEntry({
        ...entryToEdit,
        employeeId,
        leaveType,
        transactionType,
        days: Number(days),
        effectiveDate,
        expiryDate: expiryDate || undefined,
        referenceDocNumber: referenceDocNumber || undefined,
        reason
      });
    } else {
      addLedgerEntry({
        employeeId,
        leaveType,
        transactionType,
        days: Number(days),
        effectiveDate,
        expiryDate: expiryDate || undefined,
        authorizedBy: currentUser.employeeId || currentUser.id,
        authorizedByName: currentUser.name,
        referenceDocNumber: referenceDocNumber || undefined,
        reason
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm tracking-tight">
              {entryToEdit ? 'Edit Transaksi Ledger Cuti' : 'Tambah / Kredit Jatah Cuti (No-Code)'}
            </h3>
            <p className="text-[11px] text-slate-400">
              Modul visual untuk mengedit kuota, jatah tahunan, atau koreksi cuti tanpa koding.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Employee Selector */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Pilih Karyawan <span className="text-rose-500">*</span>
            </label>
            <select
              value={employeeId}
              onChange={e => setEmployeeId(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white"
            >
              {employees.map(emp => (
                <option key={emp.id} value={emp.id}>
                  {emp.fullName} ({emp.employeeNumber} - {emp.jobTitle}) [{emp.employmentType}]
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Leave Type */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Jenis Cuti <span className="text-rose-500">*</span>
              </label>
              <select
                value={leaveType}
                onChange={e => setLeaveType(e.target.value as LeaveType)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white"
              >
                <option value="ANNUAL_LEAVE">Cuti Tahunan (Annual Leave)</option>
                <option value="EXTRA_OFF">Extra Off / Lembur</option>
                <option value="PUBLIC_HOLIDAY_COMPENSATORY">Kompensasi Libur Nasional</option>
                <option value="SPECIAL_LEAVE">Cuti Khusus</option>
                <option value="UNPAID_LEAVE">Unpaid Leave</option>
              </select>
            </div>

            {/* Transaction Type */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Tipe Transaksi <span className="text-rose-500">*</span>
              </label>
              <select
                value={transactionType}
                onChange={e => setTransactionType(e.target.value as LedgerTransactionType)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white"
              >
                <option value="ANNUAL_ENTITLEMENT_CREDIT">Kredit Jatah Cuti Baru (+)</option>
                <option value="OPENING_BALANCE">Saldo Awal / Opening Balance (+)</option>
                <option value="OVERTIME_EXTRA_OFF_CREDIT">Kredit Extra Off (+)</option>
                <option value="HOLIDAY_DUTY_CREDIT">Kredit Tugas Libur Nasional (+)</option>
                <option value="CORRECTION_ADJUSTMENT">Koreksi / Adjustment (+/-)</option>
                <option value="REVERSAL_ADJUSTMENT">Pembatalan / Reversal (+)</option>
                <option value="APPROVED_LEAVE_DEDUCTION">Potongan Cuti (-)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Days Amount */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Jumlah Hari <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                step="0.5"
                value={days}
                onChange={e => setDays(parseFloat(e.target.value) || 0)}
                required
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white font-bold"
                placeholder="misal: 12 atau -2"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Gunakan angka positif untuk penambahan saldo, negatif untuk pengurangan.
              </span>
            </div>

            {/* Effective Date */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Tanggal Efektif <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                value={effectiveDate}
                onChange={e => setEffectiveDate(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Expiry Date */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Tanggal Kadaluarsa (Opsional)
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={e => setExpiryDate(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white"
              />
            </div>

            {/* Reference Document */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                No. Ref Dokumen
              </label>
              <input
                type="text"
                value={referenceDocNumber}
                onChange={e => setReferenceDocNumber(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white font-mono"
                placeholder="misal: HC/POL/2025/001"
              />
            </div>
          </div>

          {/* Reason / Notes */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              Keterangan & Alasan Transaksi <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={2}
              value={reason}
              onChange={e => setReason(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700 bg-white"
              placeholder="Jelaskan alasan penambahan/penyesuaian saldo cuti..."
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 font-medium"
            >
              Batal
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold shadow-xs"
            >
              <Save className="w-4 h-4" />
              {entryToEdit ? 'Simpan Perubahan' : 'Posting ke Ledger'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
