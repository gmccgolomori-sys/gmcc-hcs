import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { UserAccount, UserRole } from '../../types';
import { 
  X, 
  Save, 
  KeyRound, 
  User, 
  ShieldCheck, 
  RefreshCw, 
  Eye, 
  EyeOff, 
  Mail, 
  Building2,
  Copy,
  Check
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  userToEdit?: UserAccount | null;
}

export const AdminUserModal: React.FC<Props> = ({
  isOpen,
  onClose,
  userToEdit
}) => {
  const { employees, addUserAccount, updateUserAccount, departments } = useApp();

  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('STAFF');
  const [employeeId, setEmployeeId] = useState<string>('');
  const [departmentId, setDepartmentId] = useState<string>('');
  const [status, setStatus] = useState<'ACTIVE' | 'SUSPENDED'>('ACTIVE');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (userToEdit) {
      setUserId(userToEdit.userId);
      setPassword(userToEdit.password);
      setName(userToEdit.name);
      setEmail(userToEdit.email);
      setRole(userToEdit.role);
      setEmployeeId(userToEdit.employeeId || '');
      setDepartmentId(userToEdit.departmentId || '');
      setStatus(userToEdit.status);
    } else {
      // New user defaults
      setUserId('');
      setPassword(generatePassword());
      setName('');
      setEmail('');
      setRole('STAFF');
      setEmployeeId('');
      setDepartmentId('');
      setStatus('ACTIVE');
    }
    setError(null);
  }, [userToEdit, isOpen]);

  if (!isOpen) return null;

  function generatePassword() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*';
    let res = '';
    for (let i = 0; i < 10; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return `Gmcc@${res.slice(0, 4)}!`;
  }

  const handleSelectEmployee = (empId: string) => {
    setEmployeeId(empId);
    if (!empId) return;

    const emp = employees.find(e => e.id === empId);
    if (emp) {
      if (!name) setName(emp.fullName);
      if (!email) setEmail(emp.companyEmail || emp.email);
      if (!userId) {
        const cleanName = emp.preferredName.toLowerCase().replace(/[^a-z0-9]/g, '');
        setUserId(cleanName ? `${cleanName}.${emp.employeeNumber.slice(-3)}` : emp.id.toLowerCase());
      }
      setDepartmentId(emp.departmentId);

      // Smart role suggestion based on position
      const title = emp.jobTitle.toLowerCase();
      if (title.includes('general manager') || title.includes('gm')) {
        setRole('GM');
      } else if (title.includes('human capital') || title.includes('hc') || title.includes('hr')) {
        setRole('HC');
      } else if (title.includes('head') || title.includes('director') || title.includes('manager')) {
        setRole('DEPT_HEAD');
      } else {
        setRole('STAFF');
      }
    }
  };

  const handleCopyCredentials = () => {
    const text = `Akun GMCC HRIS:\nUser ID / Username: ${userId}\nPassword: ${password}\nRole: ${role}\nLink: http://localhost:3000`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId.trim()) {
      setError('User ID / Username wajib diisi.');
      return;
    }
    if (!password.trim()) {
      setError('Password wajib diisi.');
      return;
    }

    if (userToEdit) {
      updateUserAccount({
        ...userToEdit,
        userId: userId.trim(),
        username: userId.trim(),
        password: password.trim(),
        name: name.trim() || userId.trim(),
        email: email.trim() || `${userId.trim()}@golomoricc.com`,
        role,
        employeeId: employeeId || undefined,
        departmentId: departmentId || undefined,
        status,
        updatedAt: new Date().toISOString()
      });
    } else {
      addUserAccount({
        userId: userId.trim(),
        username: userId.trim(),
        password: password.trim(),
        name: name.trim() || userId.trim(),
        email: email.trim() || `${userId.trim()}@golomoricc.com`,
        role,
        employeeId: employeeId || undefined,
        departmentId: departmentId || undefined,
        status
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200">
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-bold">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm tracking-tight">
                {userToEdit ? `Edit Akun & Password: ${userToEdit.userId}` : 'Buat Akun User ID & Password Baru'}
              </h3>
              <p className="text-[11px] text-slate-400">
                Kredensial login mandiri staf untuk modul absensi, cuti, dan profil kerja
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-[11px]">
              {error}
            </div>
          )}

          {/* Link to Employee */}
          <div>
            <label className="block text-slate-700 font-bold mb-1">
              Tautkan ke Karyawan (Opsional / Recommended)
            </label>
            <select
              value={employeeId}
              onChange={e => handleSelectEmployee(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden bg-white"
            >
              <option value="">-- Akun Non-Karyawan / Administrator Luar --</option>
              {employees.map(emp => (
                <option key={emp.id} value={emp.id}>
                  {emp.fullName} ({emp.employeeNumber} - {emp.jobTitle})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* User ID / Username */}
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                User ID / Username <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={userId}
                  onChange={e => setUserId(e.target.value)}
                  placeholder="Masukkan User ID atau Username"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden focus:border-emerald-600 font-mono font-bold"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-0.5 block">Digunakan karyawan untuk login.</span>
            </div>

            {/* Password with generator */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-slate-700 font-bold">
                  Password <span className="text-rose-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={() => setPassword(generatePassword())}
                  className="text-[10px] text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1"
                >
                  <RefreshCw className="w-2.5 h-2.5" />
                  Acak Password
                </button>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Masukkan password akun"
                  className="w-full pl-3 pr-8 py-2 rounded-xl border border-slate-300 focus:outline-hidden focus:border-emerald-600 font-mono font-semibold"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
              <span className="text-[10px] text-slate-400 mt-0.5 block">Contoh: Gmcc@2026!</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Display Name */}
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Nama Pengguna / Tampilan <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="misal: Budi Pratama"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden"
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Email Akun <span className="text-rose-500">*</span>
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="budi.pratama@golomoricc.com"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Role */}
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Hak Akses (Role) <span className="text-rose-500">*</span>
              </label>
              <select
                value={role}
                onChange={e => setRole(e.target.value as UserRole)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden bg-white font-semibold"
              >
                <option value="STAFF">STAFF (Hanya Cuti & Dokumen Pribadi)</option>
                <option value="DEPT_HEAD">DEPT_HEAD (Approval Tahap 1 & Cuti Dept)</option>
                <option value="HC">HC (Human Capital Manager - Approval Tahap 2)</option>
                <option value="GM">GM (General Manager - Approval Final Tahap 3)</option>
                <option value="ADMIN">ADMIN (Full Access Master & No-Code)</option>
                <option value="AUDITOR">AUDITOR (Read-Only Audit & Compliance)</option>
              </select>
            </div>

            {/* Status */}
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Status Akun <span className="text-rose-500">*</span>
              </label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value as 'ACTIVE' | 'SUSPENDED')}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-hidden bg-white"
              >
                <option value="ACTIVE">ACTIVE (Dapat Login)</option>
                <option value="SUSPENDED">SUSPENDED (Ditangguhkan / Karyawan Keluar)</option>
              </select>
            </div>
          </div>

          {/* Quick Copy Card */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Ringkasan Kredensial:</span>
              <div className="text-[11px] font-mono text-slate-800">
                ID: <strong>{userId || '-'}</strong> | Pass: <strong>{showPassword ? password : '••••••••'}</strong>
              </div>
            </div>
            <button
              type="button"
              onClick={handleCopyCredentials}
              disabled={!userId}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 text-[11px] font-medium"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
              {copied ? 'Tersalin' : 'Salin Kredensial'}
            </button>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-medium"
            >
              Batal
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold shadow-xs"
            >
              <Save className="w-4 h-4" />
              {userToEdit ? 'Simpan Akun' : 'Buat Akun User'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
