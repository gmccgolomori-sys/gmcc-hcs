import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DEMO_USERS } from '../../context/AppContext';
import { Employee, EmploymentContract, LeaveLedgerEntry, PublicHoliday, UserAccount, UserRole } from '../../types';
import { 
  ShieldAlert, 
  ShieldCheck,
  Users, 
  Settings, 
  FileText, 
  History, 
  RotateCcw,
  CheckCircle2,
  ChevronRight,
  Database,
  Plus,
  Pencil,
  Trash2,
  Search,
  Calendar,
  FileCheck2,
  Layers,
  Sparkles,
  Building2,
  AlertCircle,
  KeyRound,
  Eye,
  EyeOff,
  UserX,
  Copy,
  Check,
  LogIn,
  RefreshCw,
  Download,
  Upload,
  Globe,
  Server,
  AlertTriangle
} from 'lucide-react';
import { AdminEmployeeModal } from './AdminEmployeeModal';
import { AdminContractModal } from './AdminContractModal';
import { AdminLedgerModal } from './AdminLedgerModal';
import { AdminHolidayModal } from './AdminHolidayModal';
import { AdminUserModal } from './AdminUserModal';
import { ContractTerminationModal } from '../contracts/ContractTerminationModal';

export const AdminManager: React.FC = () => {
  const { 
    auditLogs, 
    resetDemoData, 
    currentUser,
    setCurrentUser,
    employees,
    deleteEmployee,
    contracts,
    deleteContract,
    leaveLedger,
    deleteLedgerEntry,
    holidays,
    deleteHoliday,
    departments,
    userAccounts,
    deleteUserAccount,
    resetUserPassword,
    leaveApplications,
    exportBackupData,
    importBackupData,
    firebaseSyncStatus,
    syncAllToFirebase
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'EMPLOYEES' | 'CONTRACTS' | 'LEAVE_LEDGER' | 'HOLIDAYS' | 'USERS_ROLES' | 'AUDIT_LOGS' | 'SYSTEM_SETTINGS'
  >('EMPLOYEES');

  const [importStatus, setImportStatus] = useState<{ success: boolean; message: string } | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const res = importBackupData(content);
        setImportStatus(res);
        if (res.success) {
          setAdminToast(res.message);
        }
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Search & Filter States
  const [searchEmployee, setSearchEmployee] = useState('');
  const [filterEmpType, setFilterEmpType] = useState('ALL');
  const [filterEmpDept, setFilterEmpDept] = useState('ALL');

  const [searchContract, setSearchContract] = useState('');
  const [filterContractStatus, setFilterContractStatus] = useState('ALL');

  const [searchLedger, setSearchLedger] = useState('');
  const [filterLedgerYear, setFilterLedgerYear] = useState('ALL');
  const [filterLedgerEmp, setFilterLedgerEmp] = useState('ALL');

  const [searchAudit, setSearchAudit] = useState('');

  // Modals state
  const [employeeModalOpen, setEmployeeModalOpen] = useState(false);
  const [employeeToEdit, setEmployeeToEdit] = useState<Employee | null>(null);

  const [contractModalOpen, setContractModalOpen] = useState(false);
  const [contractToEdit, setContractToEdit] = useState<EmploymentContract | null>(null);

  const [ledgerModalOpen, setLedgerModalOpen] = useState(false);
  const [ledgerToEdit, setLedgerToEdit] = useState<LeaveLedgerEntry | null>(null);

  const [holidayModalOpen, setHolidayModalOpen] = useState(false);
  const [holidayToEdit, setHolidayToEdit] = useState<PublicHoliday | null>(null);

  // User Accounts & Password Management states
  const [searchUser, setSearchUser] = useState('');
  const [filterUserRole, setFilterUserRole] = useState('ALL');
  const [filterUserStatus, setFilterUserStatus] = useState('ALL');
  const [adminToast, setAdminToast] = useState<string | null>(null);
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [userToEdit, setUserToEdit] = useState<UserAccount | null>(null);

  // Quick Password Reset State
  const [resetPasswordUser, setResetPasswordUser] = useState<UserAccount | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [revealedPasswords, setRevealedPasswords] = useState<{ [key: string]: boolean }>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Contract Termination state
  const [contractToTerminate, setContractToTerminate] = useState<EmploymentContract | null>(null);

  const filteredEmployees = employees.filter(emp => {
    if (filterEmpType !== 'ALL' && emp.employmentType !== filterEmpType) return false;
    if (filterEmpDept !== 'ALL' && emp.departmentId !== filterEmpDept) return false;
    if (searchEmployee.trim()) {
      const q = searchEmployee.toLowerCase();
      return (
        emp.fullName.toLowerCase().includes(q) ||
        emp.employeeNumber.toLowerCase().includes(q) ||
        emp.jobTitle.toLowerCase().includes(q)
      );
    }
    return true;
  }).sort((a, b) => {
    const aActive = a.employmentStatus === 'ACTIVE';
    const bActive = b.employmentStatus === 'ACTIVE';
    if (aActive && !bActive) return -1;
    if (!aActive && bActive) return 1;
    return a.fullName.localeCompare(b.fullName);
  });

  const filteredContracts = contracts.filter(c => {
    if (filterContractStatus !== 'ALL' && c.status !== filterContractStatus) return false;
    if (searchContract.trim()) {
      const q = searchContract.toLowerCase();
      return (
        c.contractNumber.toLowerCase().includes(q) ||
        c.employeeName.toLowerCase().includes(q) ||
        c.position.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const filteredLedger = leaveLedger.filter(entry => {
    if (filterLedgerEmp !== 'ALL' && entry.employeeId !== filterLedgerEmp) return false;
    if (filterLedgerYear !== 'ALL') {
      const isYear = entry.effectiveDate.startsWith(filterLedgerYear) || (entry.reason && entry.reason.includes(filterLedgerYear));
      if (!isYear) return false;
    }
    if (searchLedger.trim()) {
      const q = searchLedger.toLowerCase();
      const empName = employees.find(e => e.id === entry.employeeId)?.fullName.toLowerCase() || '';
      return (
        entry.id.toLowerCase().includes(q) ||
        entry.employeeId.toLowerCase().includes(q) ||
        empName.includes(q) ||
        entry.reason.toLowerCase().includes(q) ||
        entry.leaveType.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const filteredUsers = userAccounts.filter(u => {
    if (filterUserRole !== 'ALL' && u.role !== filterUserRole) return false;
    if (filterUserStatus !== 'ALL' && u.status !== filterUserStatus) return false;
    if (searchUser.trim()) {
      const q = searchUser.toLowerCase();
      const empName = u.employeeId ? (employees.find(e => e.id === u.employeeId)?.fullName.toLowerCase() || '') : '';
      return (
        u.userId.toLowerCase().includes(q) ||
        u.name.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.role.toLowerCase().includes(q) ||
        empName.includes(q)
      );
    }
    return true;
  });

  const filteredLogs = auditLogs.filter(log => {
    if (searchAudit.trim()) {
      const q = searchAudit.toLowerCase();
      return (
        log.action.toLowerCase().includes(q) ||
        log.actorName.toLowerCase().includes(q) ||
        log.description.toLowerCase().includes(q) ||
        log.module.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Administration</span>
            <ChevronRight className="w-3 h-3" />
            <span className="font-semibold text-emerald-800">Visual No-Code Master Studio</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            System Administration & Master Data
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Edit profil karyawan, kontrak kerja, jatah cuti 2025/2026, dan kalender libur langsung dari UI tanpa coding.
          </p>
        </div>

        <button
          onClick={() => {
            if (confirm('Kembalikan seluruh data ke konfigurasi default GMCC? Semua perubahan kustom akan direset.')) {
              resetDemoData();
            }
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-xs transition-colors self-start sm:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
          Reset Demo Data
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-slate-200 flex items-center gap-2 overflow-x-auto pb-1 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('EMPLOYEES')}
          className={`px-3 py-2.5 transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'EMPLOYEES'
              ? 'border-emerald-700 text-emerald-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          Karyawan & Profil ({employees.length})
        </button>

        <button
          onClick={() => setActiveTab('CONTRACTS')}
          className={`px-3 py-2.5 transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'CONTRACTS'
              ? 'border-emerald-700 text-emerald-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileCheck2 className="w-4 h-4" />
          Kontrak Kerja ({contracts.length})
        </button>

        <button
          onClick={() => setActiveTab('LEAVE_LEDGER')}
          className={`px-3 py-2.5 transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'LEAVE_LEDGER'
              ? 'border-emerald-700 text-emerald-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Database className="w-4 h-4" />
          Jatah Cuti & Ledger ({leaveLedger.length})
        </button>

        <button
          onClick={() => setActiveTab('HOLIDAYS')}
          className={`px-3 py-2.5 transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'HOLIDAYS'
              ? 'border-emerald-700 text-emerald-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Calendar className="w-4 h-4" />
          Libur Nasional ({holidays.length})
        </button>

        <button
          onClick={() => setActiveTab('USERS_ROLES')}
          className={`px-3 py-2.5 transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'USERS_ROLES'
              ? 'border-emerald-700 text-emerald-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <KeyRound className="w-4 h-4" />
          User ID & Password ({userAccounts.length})
        </button>

        <button
          onClick={() => setActiveTab('AUDIT_LOGS')}
          className={`px-3 py-2.5 transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'AUDIT_LOGS'
              ? 'border-emerald-700 text-emerald-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <History className="w-4 h-4" />
          Audit Trail ({auditLogs.length})
        </button>

        <button
          onClick={() => setActiveTab('SYSTEM_SETTINGS')}
          className={`px-3 py-2.5 transition-colors border-b-2 flex items-center gap-1.5 shrink-0 ${
            activeTab === 'SYSTEM_SETTINGS'
              ? 'border-emerald-700 text-emerald-800 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Settings className="w-4 h-4" />
          Integrasi & Kebijakan
        </button>
      </div>

      {/* ==================================================================== */}
      {/* TAB 1: EMPLOYEES MASTER DATA EDITOR                                  */}
      {/* ==================================================================== */}
      {activeTab === 'EMPLOYEES' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden space-y-4">
          <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                Master Data Karyawan (Tanpa Coding)
              </h3>
              <p className="text-xs text-slate-500">
                Tambah atau perbarui profil staf, NIK, jabatan, tipe (PKWT Kontrak, Daily Worker), dan data personal.
              </p>
            </div>

            <button
              onClick={() => {
                setEmployeeToEdit(null);
                setEmployeeModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs shadow-xs self-start md:self-auto"
            >
              <Plus className="w-4 h-4" />
              Tambah Karyawan Baru
            </button>
          </div>

          {/* Filters */}
          <div className="px-4 flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari nama, NIK, jabatan..."
                value={searchEmployee}
                onChange={e => setSearchEmployee(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden"
              />
            </div>

            <select
              value={filterEmpType}
              onChange={e => setFilterEmpType(e.target.value)}
              className="w-full sm:w-44 text-xs px-3 py-2 rounded-lg border border-slate-200 bg-slate-50"
            >
              <option value="ALL">Semua Tipe Hubungan</option>
              <option value="PKWT">PKWT (Kontrak)</option>
              <option value="DAILY_WORKER">Daily Worker (DW)</option>
            </select>

            <select
              value={filterEmpDept}
              onChange={e => setFilterEmpDept(e.target.value)}
              className="w-full sm:w-48 text-xs px-3 py-2 rounded-lg border border-slate-200 bg-slate-50"
            >
              <option value="ALL">Semua Departemen</option>
              {departments.map(d => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-y border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-2.5 px-4">NIK</th>
                  <th className="py-2.5 px-3">Nama Karyawan</th>
                  <th className="py-2.5 px-3">Departemen</th>
                  <th className="py-2.5 px-3">Jabatan</th>
                  <th className="py-2.5 px-3">Tipe</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Join Date</th>
                  <th className="py-2.5 px-4 text-right">Aksi Admin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredEmployees.map(emp => {
                  const dept = departments.find(d => d.id === emp.departmentId);
                  return (
                    <tr key={emp.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-2.5 px-4 font-mono font-semibold text-slate-800">
                        {emp.employeeNumber}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-2">
                          <img
                            src={emp.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                            alt={emp.fullName}
                            className="w-6 h-6 rounded-full object-cover shrink-0"
                          />
                          <span className="font-semibold text-slate-900">{emp.fullName}</span>
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-slate-700">
                        {dept?.name || emp.departmentId}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        {emp.jobTitle}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          emp.employmentType === 'DAILY_WORKER'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {emp.employmentType === 'DAILY_WORKER' ? 'Daily Worker' : 'PKWT Kontrak'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          emp.employmentStatus === 'ACTIVE'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-600'
                        }`}>
                          {emp.employmentStatus}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-500">
                        {emp.joinDate}
                      </td>
                      <td className="py-2.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setEmployeeToEdit(emp);
                              setEmployeeModalOpen(true);
                            }}
                            className="p-1 rounded text-slate-600 hover:text-emerald-700 hover:bg-slate-100 transition-colors"
                            title="Edit profil karyawan"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Yakin ingin menghapus data karyawan ${emp.fullName}? Tindakan ini akan dicatat di audit log.`)) {
                                deleteEmployee(emp.id);
                              }
                            }}
                            className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            title="Hapus karyawan"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 2: CONTRACTS MASTER DATA EDITOR                                  */}
      {/* ==================================================================== */}
      {activeTab === 'CONTRACTS' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden space-y-4">
          <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                Master Kontrak Kerja (PKWT & SPK Daily Worker)
              </h3>
              <p className="text-xs text-slate-500">
                Kelola nomor kontrak, masa berlaku, dan status pembaharuan tanpa koding.
              </p>
            </div>

            <button
              onClick={() => {
                setContractToEdit(null);
                setContractModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs shadow-xs self-start md:self-auto"
            >
              <Plus className="w-4 h-4" />
              Buat Kontrak Baru
            </button>
          </div>

          {/* Filters */}
          <div className="px-4 flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari no kontrak, karyawan, posisi..."
                value={searchContract}
                onChange={e => setSearchContract(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden"
              />
            </div>

            <select
              value={filterContractStatus}
              onChange={e => setFilterContractStatus(e.target.value)}
              className="w-full sm:w-48 text-xs px-3 py-2 rounded-lg border border-slate-200 bg-slate-50"
            >
              <option value="ALL">Semua Status Kontrak</option>
              <option value="ACTIVE">ACTIVE</option>
              <option value="EXPIRING_SOON">EXPIRING_SOON</option>
              <option value="RENEWED">RENEWED</option>
              <option value="TERMINATED">TERMINATED (Dihentikan / PHK)</option>
              <option value="EXPIRED">EXPIRED</option>
            </select>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-y border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-2.5 px-4">No Kontrak</th>
                  <th className="py-2.5 px-3">Karyawan</th>
                  <th className="py-2.5 px-3">Posisi</th>
                  <th className="py-2.5 px-3">Tipe</th>
                  <th className="py-2.5 px-3">Mulai</th>
                  <th className="py-2.5 px-3">Berakhir</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredContracts.map(c => (
                  <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2.5 px-4 font-mono font-semibold text-slate-900">
                      {c.contractNumber}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-800">
                      {c.employeeName}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {c.position}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {c.employmentType}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-500">
                      {c.startDate}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-700 font-medium">
                      {c.endDate || '-'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        c.status === 'TERMINATED'
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : c.status === 'EXPIRING_SOON'
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : c.status === 'ACTIVE'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-slate-100 text-slate-600'
                      }`}>
                        {c.status}
                      </span>
                      {c.terminationDetails?.effectiveDate && (
                        <span className="block text-[10px] text-rose-600 font-mono mt-0.5">
                          Eff: {c.terminationDetails.effectiveDate}
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setContractToEdit(c);
                            setContractModalOpen(true);
                          }}
                          className="p-1 rounded text-slate-600 hover:text-emerald-700 hover:bg-slate-100 transition-colors"
                          title="Edit kontrak"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        {c.status !== 'TERMINATED' && c.status !== 'RENEWED' && (
                          <button
                            onClick={() => setContractToTerminate(c)}
                            className="p-1 rounded text-rose-600 hover:text-rose-800 hover:bg-rose-50 transition-colors"
                            title="Terminasi / Pengakhiran kontrak"
                          >
                            <UserX className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => {
                            if (confirm(`Hapus kontrak ${c.contractNumber}?`)) {
                              deleteContract(c.id);
                            }
                          }}
                          className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Hapus kontrak"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 3: MASTER JATAH CUTI & LEDGER EDITOR (2025/2026/ALL)             */}
      {/* ==================================================================== */}
      {activeTab === 'LEAVE_LEDGER' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden space-y-4">
          <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                Master Jatah Cuti & Ledger Transaksi (No-Code)
              </h3>
              <p className="text-xs text-slate-500">
                Atur jatah cuti 2025/2026 per staf, berikan kredit lembur/extra off, atau koreksi saldo langsung di sini.
              </p>
            </div>

            <button
              onClick={() => {
                setLedgerToEdit(null);
                setLedgerModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs shadow-xs self-start md:self-auto"
            >
              <Plus className="w-4 h-4" />
              Kredit / Koreksi Jatah Cuti
            </button>
          </div>

          {/* Filters */}
          <div className="px-4 flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari ID transaksi, karyawan, keterangan..."
                value={searchLedger}
                onChange={e => setSearchLedger(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden"
              />
            </div>

            <select
              value={filterLedgerYear}
              onChange={e => setFilterLedgerYear(e.target.value)}
              className="w-full sm:w-36 text-xs px-3 py-2 rounded-lg border border-slate-200 bg-slate-50 font-semibold"
            >
              <option value="ALL">Semua Tahun</option>
              <option value="2025">Tahun 2025</option>
              <option value="2026">Tahun 2026</option>
            </select>

            <select
              value={filterLedgerEmp}
              onChange={e => setFilterLedgerEmp(e.target.value)}
              className="w-full sm:w-56 text-xs px-3 py-2 rounded-lg border border-slate-200 bg-slate-50"
            >
              <option value="ALL">Semua Karyawan</option>
              {employees.map(emp => (
                <option key={emp.id} value={emp.id}>{emp.fullName}</option>
              ))}
            </select>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-y border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-2.5 px-4">Txn ID</th>
                  <th className="py-2.5 px-3">Karyawan</th>
                  <th className="py-2.5 px-3">Tipe Cuti</th>
                  <th className="py-2.5 px-3">Tipe Mutasi</th>
                  <th className="py-2.5 px-3 text-center">Hari</th>
                  <th className="py-2.5 px-3">Tgl Efektif</th>
                  <th className="py-2.5 px-4">Alasan / Ref</th>
                  <th className="py-2.5 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLedger.map(entry => {
                  const emp = employees.find(e => e.id === entry.employeeId);
                  return (
                    <tr key={entry.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">
                        {entry.id}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-800">
                        {emp?.fullName || entry.employeeId}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">
                        {entry.leaveType.replace('_', ' ')}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-600">
                        {entry.transactionType}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`inline-flex px-2 py-0.5 rounded font-mono font-bold text-xs ${
                          entry.days > 0 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : 'bg-rose-100 text-rose-800'
                        }`}>
                          {entry.days > 0 ? `+${entry.days}` : entry.days} hari
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-500">
                        {entry.effectiveDate}
                      </td>
                      <td className="py-2.5 px-4 text-slate-600 max-w-xs truncate" title={entry.reason}>
                        {entry.reason}
                      </td>
                      <td className="py-2.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setLedgerToEdit(entry);
                              setLedgerModalOpen(true);
                            }}
                            className="p-1 rounded text-slate-600 hover:text-emerald-700 hover:bg-slate-100 transition-colors"
                            title="Edit transaksi"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Hapus transaksi ${entry.id} (${entry.days} hari)? Saldo karyawan akan otomatis dihitung ulang.`)) {
                                deleteLedgerEntry(entry.id);
                              }
                            }}
                            className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            title="Hapus transaksi"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 4: PUBLIC HOLIDAYS & CUTI BERSAMA                                 */}
      {/* ==================================================================== */}
      {activeTab === 'HOLIDAYS' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden space-y-4">
          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                Master Libur Nasional & Cuti Bersama Resmi
              </h3>
              <p className="text-xs text-slate-500">
                Data hari libur resmi untuk perhitungan kompensasi tugas saat hari raya dan tanggal merah.
              </p>
            </div>

            <button
              onClick={() => {
                setHolidayToEdit(null);
                setHolidayModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs shadow-xs self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              Tambah Hari Libur
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-y border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-2.5 px-4">Tanggal</th>
                  <th className="py-2.5 px-4">Nama Hari Libur</th>
                  <th className="py-2.5 px-4">Kategori</th>
                  <th className="py-2.5 px-4">Catatan / SKB</th>
                  <th className="py-2.5 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {holidays.map(h => (
                  <tr key={h.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2.5 px-4 font-mono font-bold text-slate-900">
                      {h.date}
                    </td>
                    <td className="py-2.5 px-4 font-semibold text-slate-800">
                      {h.name}
                    </td>
                    <td className="py-2.5 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        h.type === 'NATIONAL'
                          ? 'bg-rose-100 text-rose-800'
                          : h.type === 'COLLECTIVE_LEAVE'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {h.type}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-500">
                      {h.notes || 'SKB 3 Menteri'}
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setHolidayToEdit(h);
                            setHolidayModalOpen(true);
                          }}
                          className="p-1 rounded text-slate-600 hover:text-emerald-700 hover:bg-slate-100 transition-colors"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Hapus hari libur ${h.name}?`)) {
                              deleteHoliday(h.id);
                            }
                          }}
                          className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 5: USER ACCOUNTS & PASSWORD MANAGEMENT                           */}
      {/* ==================================================================== */}
      {activeTab === 'USERS_ROLES' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden space-y-4">
          {/* Header */}
          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1 rounded-md bg-emerald-100 text-emerald-800">
                  <KeyRound className="w-4 h-4" />
                </span>
                <h3 className="font-bold text-slate-900 text-sm">
                  Manajemen Akun User ID & Password Karyawan
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Kelola User ID login staf, setel sandi, reset password, dan tentukan otorisasi hak akses peran (Role).
              </p>
            </div>

            <button
              onClick={() => {
                setUserToEdit(null);
                setUserModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs shadow-xs self-start sm:self-auto transition-colors"
            >
              <Plus className="w-4 h-4" />
              Buat Akun User Baru
            </button>
          </div>

          {/* Quick Stats Banner */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 px-4">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <span className="text-[11px] text-slate-500 block">Total Akun Terdaftar</span>
              <span className="text-lg font-bold text-slate-900 mt-0.5 block">{userAccounts.length} Akun</span>
            </div>
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
              <span className="text-[11px] text-emerald-800 block">Akun Aktif (Active)</span>
              <span className="text-lg font-bold text-emerald-950 mt-0.5 block">
                {userAccounts.filter(u => u.status === 'ACTIVE').length}
              </span>
            </div>
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
              <span className="text-[11px] text-blue-800 block">Akun Staff Lapangan</span>
              <span className="text-lg font-bold text-blue-950 mt-0.5 block">
                {userAccounts.filter(u => u.role === 'STAFF').length}
              </span>
            </div>
            <div className="p-3 bg-purple-50 border border-purple-200 rounded-xl">
              <span className="text-[11px] text-purple-800 block">Management & Dept Head</span>
              <span className="text-lg font-bold text-purple-950 mt-0.5 block">
                {userAccounts.filter(u => ['GM', 'HC', 'DEPT_HEAD', 'ADMIN'].includes(u.role)).length}
              </span>
            </div>
          </div>

          {/* Filters */}
          <div className="px-4 flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari User ID, nama staff, email..."
                value={searchUser}
                onChange={e => setSearchUser(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden"
              />
            </div>

            <select
              value={filterUserRole}
              onChange={e => setFilterUserRole(e.target.value)}
              className="w-full sm:w-44 text-xs px-3 py-2 rounded-lg border border-slate-200 bg-slate-50"
            >
              <option value="ALL">Semua Role</option>
              <option value="STAFF">STAFF</option>
              <option value="DEPT_HEAD">DEPT_HEAD</option>
              <option value="HC">HC (Human Capital)</option>
              <option value="GM">GM (General Manager)</option>
              <option value="ADMIN">ADMIN</option>
              <option value="AUDITOR">AUDITOR</option>
            </select>

            <select
              value={filterUserStatus}
              onChange={e => setFilterUserStatus(e.target.value)}
              className="w-full sm:w-36 text-xs px-3 py-2 rounded-lg border border-slate-200 bg-slate-50"
            >
              <option value="ALL">Semua Status</option>
              <option value="ACTIVE">ACTIVE</option>
              <option value="SUSPENDED">SUSPENDED</option>
            </select>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-y border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-2.5 px-4">User ID / Username</th>
                  <th className="py-2.5 px-3">Nama Karyawan</th>
                  <th className="py-2.5 px-3">Role Akses</th>
                  <th className="py-2.5 px-3">Password (Kredensial)</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Terakhir Login</th>
                  <th className="py-2.5 px-4 text-right">Aksi & Simulasi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredUsers.map(u => {
                  const isCurrent = currentUser.email === u.email || currentUser.id === u.id;
                  const isRevealed = !!revealedPasswords[u.id];
                  const linkedEmp = u.employeeId ? employees.find(e => e.id === u.employeeId) : undefined;

                  return (
                    <tr key={u.id} className="hover:bg-slate-50/70 transition-colors">
                      {/* User ID */}
                      <td className="py-2.5 px-4">
                        <div className="flex items-center gap-1.5 font-mono font-bold text-slate-900 text-xs">
                          <span>{u.userId}</span>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(u.userId);
                              setCopiedId(`uid-${u.id}`);
                              setTimeout(() => setCopiedId(null), 1500);
                            }}
                            className="p-0.5 text-slate-400 hover:text-slate-700"
                            title="Salin User ID"
                          >
                            {copiedId === `uid-${u.id}` ? (
                              <Check className="w-3 h-3 text-emerald-600" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">{u.email}</span>
                      </td>

                      {/* Employee Name */}
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-slate-900">{u.name}</div>
                        {linkedEmp ? (
                          <div className="text-[10px] text-slate-500">
                            {linkedEmp.employeeNumber} · {linkedEmp.jobTitle}
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-400 italic">Akun Sistem / Admin</span>
                        )}
                      </td>

                      {/* Role */}
                      <td className="py-2.5 px-3">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${
                          u.role === 'GM'
                            ? 'bg-purple-50 text-purple-800 border-purple-200'
                            : u.role === 'HC'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : u.role === 'DEPT_HEAD'
                            ? 'bg-blue-50 text-blue-800 border-blue-200'
                            : u.role === 'ADMIN'
                            ? 'bg-rose-50 text-rose-800 border-rose-200'
                            : u.role === 'AUDITOR'
                            ? 'bg-amber-50 text-amber-800 border-amber-200'
                            : 'bg-slate-100 text-slate-700 border-slate-200'
                        }`}>
                          {u.role}
                        </span>
                      </td>

                      {/* Password */}
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-1.5 font-mono text-xs">
                          <span className="font-semibold text-slate-800">
                            {isRevealed ? u.password : '••••••••'}
                          </span>
                          <button
                            onClick={() => {
                              setRevealedPasswords(prev => ({ ...prev, [u.id]: !prev[u.id] }));
                            }}
                            className="p-1 rounded text-slate-400 hover:text-slate-600"
                            title={isRevealed ? 'Sembunyikan password' : 'Lihat password'}
                          >
                            {isRevealed ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                          </button>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(u.password);
                              setCopiedId(`pw-${u.id}`);
                              setTimeout(() => setCopiedId(null), 1500);
                            }}
                            className="p-1 rounded text-slate-400 hover:text-emerald-700"
                            title="Salin password"
                          >
                            {copiedId === `pw-${u.id}` ? (
                              <Check className="w-3 h-3 text-emerald-600" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-2.5 px-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold ${
                          u.status === 'ACTIVE'
                            ? 'bg-emerald-50 text-emerald-700'
                            : 'bg-rose-50 text-rose-700'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${u.status === 'ACTIVE' ? 'bg-emerald-600' : 'bg-rose-600'}`}></span>
                          {u.status}
                        </span>
                      </td>

                      {/* Last Login */}
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500">
                        {u.lastLogin ? new Date(u.lastLogin).toLocaleDateString('id-ID', {
                          day: '2-digit',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit'
                        }) : 'Belum Pernah'}
                      </td>

                      {/* Actions */}
                      <td className="py-2.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Quick Switch Persona / Login as */}
                          <button
                            onClick={() => {
                              setCurrentUser({
                                id: u.id,
                                name: u.name,
                                role: u.role,
                                employeeId: u.employeeId,
                                departmentId: u.departmentId,
                                email: u.email
                              });
                            }}
                            className={`inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium transition-colors ${
                              isCurrent
                                ? 'bg-emerald-700 text-white font-bold'
                                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                            }`}
                            title="Simulasikan login sebagai user ini"
                          >
                            <LogIn className="w-3 h-3" />
                            {isCurrent ? 'Aktif' : 'Login'}
                          </button>

                          {/* Edit User Account */}
                          <button
                            onClick={() => {
                              setUserToEdit(u);
                              setUserModalOpen(true);
                            }}
                            className="p-1 rounded text-slate-500 hover:text-emerald-700 hover:bg-slate-100 transition-colors"
                            title="Edit akun dan User ID"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>

                          {/* Quick Reset / Change Password */}
                          <button
                            onClick={() => {
                              setResetPasswordUser(u);
                              setNewPasswordInput(u.userId === 'admin' ? '' : 'Gmcc@2026!');
                            }}
                            className="p-1 rounded text-slate-500 hover:text-amber-700 hover:bg-amber-50 transition-colors"
                            title={u.userId === 'admin' ? "Ubah password administrator" : "Reset password staf"}
                          >
                            <KeyRound className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete Account (Protected: Admin cannot be deleted) */}
                          {u.userId !== 'admin' && u.id !== 'USR-ADMIN' ? (
                            <button
                              onClick={() => {
                                if (confirm(`Hapus akun login untuk ${u.userId} (${u.name})?`)) {
                                  deleteUserAccount(u.id);
                                }
                              }}
                              className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              title="Hapus akun pengguna"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <span className="p-1 text-slate-300 cursor-not-allowed" title="Akun Administrator Utama tidak dapat dihapus">
                              <ShieldCheck className="w-3.5 h-3.5 text-slate-300" />
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {filteredUsers.length === 0 && (
              <div className="p-8 text-center text-slate-400 text-xs">
                Tidak ada akun pengguna yang cocok dengan kriteria filter.
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 6: AUDIT TRAIL                                                   */}
      {/* ==================================================================== */}
      {activeTab === 'AUDIT_LOGS' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-semibold text-slate-900 text-sm">Security & Transaction Audit Trail</h3>
              <p className="text-xs text-slate-500">Setiap perubahan admin, pembuatan kontrak, dan persetujuan dicatat permanen.</p>
            </div>

            <input
              type="text"
              placeholder="Search audit trail..."
              value={searchAudit}
              onChange={e => setSearchAudit(e.target.value)}
              className="text-xs px-3 py-1.5 rounded-lg border border-slate-300 w-full sm:w-64 focus:outline-hidden"
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-2.5 px-4">Log ID</th>
                  <th className="py-2.5 px-4">Timestamp</th>
                  <th className="py-2.5 px-4">Actor</th>
                  <th className="py-2.5 px-4">Module</th>
                  <th className="py-2.5 px-4">Action</th>
                  <th className="py-2.5 px-4">Description</th>
                  <th className="py-2.5 px-4">IP Address</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                {filteredLogs.map((log, idx) => (
                  <tr key={`${log.id}-${idx}`} className="hover:bg-slate-50/70">
                    <td className="py-2.5 px-4 font-semibold text-slate-900">{log.id}</td>
                    <td className="py-2.5 px-4 text-slate-500">
                      {new Date(log.timestamp).toLocaleString('en-GB')}
                    </td>
                    <td className="py-2.5 px-4 font-sans">
                      <span className="font-medium text-slate-900">{log.actorName}</span>
                      <span className="text-[10px] text-slate-400 block">Role: {log.actorRole}</span>
                    </td>
                    <td className="py-2.5 px-4 font-sans text-slate-700">
                      {log.module}
                    </td>
                    <td className="py-2.5 px-4 text-emerald-800 font-semibold">
                      {log.action}
                    </td>
                    <td className="py-2.5 px-4 font-sans text-slate-600 max-w-sm truncate" title={log.description}>
                      {log.description}
                    </td>
                    <td className="py-2.5 px-4 text-slate-400">
                      {log.ipAddress || '192.168.10.15'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 7: SYSTEM SETTINGS                                               */}
      {/* ==================================================================== */}
      {activeTab === 'SYSTEM_SETTINGS' && (
        <div className="space-y-6">
          {/* Card 0: Koneksi Database Cloud Realtime Firebase */}
          <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 text-white rounded-xl border border-emerald-800/60 shadow-lg p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-800/40 pb-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="flex h-3 w-3 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                  </span>
                  <h3 className="font-bold text-white text-sm flex items-center gap-2">
                    <Database className="w-4 h-4 text-emerald-400" />
                    <span>Database Online Realtime (Firebase Firestore)</span>
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-900 text-emerald-300 border border-emerald-700">
                    Spark Plan 100% Free
                  </span>
                </div>
                <p className="text-xs text-slate-300">
                  Data tersimpan online di Google Cloud Firestore. Setiap perubahan yang dilakukan di komputer A langsung tersinkronisasi otomatis ke komputer B dan smartphone secara realtime.
                </p>
              </div>

              <button
                type="button"
                onClick={syncAllToFirebase}
                disabled={firebaseSyncStatus.isSyncing}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-all cursor-pointer shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${firebaseSyncStatus.isSyncing ? 'animate-spin' : ''}`} />
                <span>{firebaseSyncStatus.isSyncing ? 'Menyinkronkan...' : 'Kirim / Sinkronkan ke Cloud'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-700/80">
                <span className="text-[10px] text-slate-400 block font-medium">Status Sinkronisasi</span>
                <span className="font-semibold text-emerald-400 flex items-center gap-1.5 mt-0.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Aktif (Realtime Listener On)</span>
                </span>
              </div>
              <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-700/80">
                <span className="text-[10px] text-slate-400 block font-medium">Project ID Firebase</span>
                <span className="font-mono text-slate-200 mt-0.5 block truncate">{firebaseSyncStatus.projectId}</span>
              </div>
              <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-700/80">
                <span className="text-[10px] text-slate-400 block font-medium">Terakhir Terhubung</span>
                <span className="font-mono text-slate-200 mt-0.5 block">{firebaseSyncStatus.lastSyncedAt || 'Baru Saja'}</span>
              </div>
            </div>
          </div>

          {/* Card 1: Pusat Backup, Ekspor & Migrasi Data Antar Perangkat */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-700" />
                  <span>Pusat Backup & Migrasi Data Database HCMS</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Ekspor seluruh data sistem ke file JSON terenkripsi/terstruktur atau pulihkan data ke komputer/browser lain tanpa risiko kehilangan data.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={exportBackupData}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs shadow-xs transition-colors"
                  title="Unduh seluruh data karyawan, kontrak, cuti, KPI, dan user account ke file JSON"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh Backup (.JSON)</span>
                </button>

                <a
                  href="/gmcc-hcms-deploy.zip"
                  download="gmcc-hcms-deploy.zip"
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs shadow-xs transition-colors"
                  title="Unduh paket ZIP lengkap (seluruh source code React/TS, build dist, dan routing SPA _redirects)"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh gmcc-hcms-deploy.zip</span>
                </a>

                <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs cursor-pointer shadow-xs transition-colors">
                  <Upload className="w-4 h-4 text-emerald-700" />
                  <span>Pulihkan / Migrasi File</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {importStatus && (
              <div className={`p-3 rounded-lg text-xs font-semibold flex items-center gap-2 ${
                importStatus.success ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}>
                {importStatus.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" /> : <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />}
                <span>{importStatus.message}</span>
              </div>
            )}

            {/* Rekap Ringkasan Data Aktif Saat Ini */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-1">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
                <span className="text-[10px] text-slate-500 font-semibold uppercase block">Karyawan</span>
                <span className="text-lg font-mono font-bold text-slate-900">{employees.length}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
                <span className="text-[10px] text-slate-500 font-semibold uppercase block">Kontrak PKWT</span>
                <span className="text-lg font-mono font-bold text-slate-900">{contracts.length}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
                <span className="text-[10px] text-slate-500 font-semibold uppercase block">Buku Kas Cuti</span>
                <span className="text-lg font-mono font-bold text-slate-900">{leaveLedger.length}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
                <span className="text-[10px] text-slate-500 font-semibold uppercase block">Pengajuan Cuti</span>
                <span className="text-lg font-mono font-bold text-slate-900">{leaveApplications.length}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
                <span className="text-[10px] text-slate-500 font-semibold uppercase block">Akun Login</span>
                <span className="text-lg font-mono font-bold text-slate-900">{userAccounts.length}</span>
              </div>
            </div>
          </div>

          {/* Card 2: Laporan Audit Deployment & Solusi Error 403 Akses Multi-Device */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Server className="w-4 h-4 text-blue-700" />
              <span>Audit Akses Perangkat, Jaringan & Penyebab Error 403 Cloud Run</span>
            </h3>

            <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-lg text-xs space-y-2 text-amber-950">
              <div className="font-bold flex items-center gap-1.5 text-amber-900">
                <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                <span>Penyebab Error 403 Forbidden di Komputer / Browser Lain:</span>
              </div>
              <p className="leading-relaxed">
                URL pengembangan <code className="font-mono bg-white px-1.5 py-0.5 rounded border border-amber-200 text-amber-900">ais-dev-*.run.app</code> merupakan internal instance Google Cloud Run yang terikat dengan Google Cloud IAM Policy (hanya akun Google pembuat di sesi Google AI Studio yang diberi izin ingress). Jika dibuka di browser lain atau jendela Incognito tanpa cookie autentikasi Cloud Run, Google Cloud akan menolak permintaan dengan kode <strong>HTTP 403 Forbidden</strong>.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
                <div className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-emerald-700" />
                  <span>1. Solusi Cloud Run Publik</span>
                </div>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  Buka Google Cloud Console &rarr; Cloud Run &rarr; Pilih Service &rarr; Tab Security/Permissions &rarr; Berikan role <strong>Cloud Run Invoker</strong> ke principal <code className="font-mono text-emerald-800">allUsers</code>.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
                <div className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-blue-700" />
                  <span>2. Hosting Produksi Resmi</span>
                </div>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  Deploy folder hasil build (<code className="font-mono">npm run build &rarr; dist/</code>) ke <strong>Firebase Hosting</strong> atau <strong>Vercel / Netlify</strong> untuk mendapatkan domain permanen resmi (misal: <code className="font-mono text-blue-800">hcms.golomoricc.com</code>).
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5">
                <div className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-purple-700" />
                  <span>3. Google Workspace Web App</span>
                </div>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  Gunakan modul Google Apps Script (GAS) yang terintegrasi di sistem ini untuk deploy sebagai Google Workspace Web App internal dengan akses akun Google organisasi GMCC.
                </p>
              </div>
            </div>
          </div>

          {/* Card 3: Google Drive & Workspace Integration Status */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-700" />
              <span>Spesifikasi Identitas & Integrasi Workspace GMCC</span>
            </h3>
            
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <span className="font-semibold text-slate-800 block">Nama Entitas Resmi</span>
                  <span className="text-slate-600">Golo Mori Convention Center (GMCC)</span>
                </div>
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Terverifikasi
                </span>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <span className="font-semibold text-slate-800 block">Alamat Kantor Resmi</span>
                  <span className="text-slate-600">
                    Kawasan Pariwisata The Golo Mori by ITDC, Golo Mori, Labuan Bajo, Kabupaten Manggarai Barat, Nusa Tenggara Tim. 86763
                  </span>
                </div>
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Sesuai Master Data
                </span>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <span className="font-semibold text-slate-800 block">Root Drive Folder</span>
                  <span className="font-mono text-slate-500">GMCC HUMAN CAPITAL /</span>
                </div>
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Active
                </span>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <span className="font-semibold text-slate-800 block">Server Timezone</span>
                  <span className="font-mono text-slate-500">Asia/Makassar (WITA, UTC+8)</span>
                </div>
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4" />
                  Enforced
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Admin Modals */}
      {employeeModalOpen && (
        <AdminEmployeeModal
          isOpen={employeeModalOpen}
          onClose={() => setEmployeeModalOpen(false)}
          employeeToEdit={employeeToEdit}
        />
      )}

      {contractModalOpen && (
        <AdminContractModal
          isOpen={contractModalOpen}
          onClose={() => setContractModalOpen(false)}
          contractToEdit={contractToEdit}
        />
      )}

      {ledgerModalOpen && (
        <AdminLedgerModal
          isOpen={ledgerModalOpen}
          onClose={() => setLedgerModalOpen(false)}
          entryToEdit={ledgerToEdit}
        />
      )}

      {holidayModalOpen && (
        <AdminHolidayModal
          isOpen={holidayModalOpen}
          onClose={() => setHolidayModalOpen(false)}
          holidayToEdit={holidayToEdit}
        />
      )}

      {/* User Account Modal */}
      {userModalOpen && (
        <AdminUserModal
          isOpen={userModalOpen}
          onClose={() => setUserModalOpen(false)}
          userToEdit={userToEdit}
        />
      )}

      {/* Contract Termination Modal */}
      {contractToTerminate && (
        <ContractTerminationModal
          contract={contractToTerminate}
          onClose={() => setContractToTerminate(null)}
        />
      )}

      {/* Quick Reset Password Modal */}
      {resetPasswordUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">Reset Password Staf</h4>
                  <p className="text-[10px] text-slate-500 font-mono">User ID: {resetPasswordUser.userId}</p>
                </div>
              </div>
              <button
                onClick={() => setResetPasswordUser(null)}
                className="p-1 rounded-md text-slate-400 hover:text-slate-600 text-lg leading-none"
              >
                &times;
              </button>
            </div>

            <div className="space-y-3">
              <p className="text-slate-600 text-[11px]">
                Masukkan sandi baru untuk <strong>{resetPasswordUser.name}</strong> ({resetPasswordUser.email}).
              </p>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-bold text-slate-800">Password Baru</label>
                  <button
                    type="button"
                    onClick={() => {
                      const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%';
                      let res = '';
                      for (let i = 0; i < 8; i++) {
                        res += chars.charAt(Math.floor(Math.random() * chars.length));
                      }
                      setNewPasswordInput(`Gmcc@${res.slice(0, 4)}!`);
                    }}
                    className="text-[10px] text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1"
                  >
                    <RefreshCw className="w-2.5 h-2.5" />
                    Acak Sandi
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={newPasswordInput}
                  onChange={e => setNewPasswordInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-slate-900 focus:outline-hidden focus:border-amber-600"
                  placeholder="Gmcc@2026!"
                />
              </div>

              <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900">
                Sandi ini langsung aktif dan dapat digunakan staf untuk login.
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setResetPasswordUser(null)}
                className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-100 font-medium"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!newPasswordInput.trim()) return;
                  resetUserPassword(resetPasswordUser.id, newPasswordInput.trim());
                  navigator.clipboard.writeText(`Akun HRIS GMCC:\nUser ID: ${resetPasswordUser.userId}\nPassword Baru: ${newPasswordInput.trim()}`);
                  setAdminToast(`Password untuk ${resetPasswordUser.userId} berhasil diubah dan disalin ke clipboard!`);
                  setTimeout(() => setAdminToast(null), 4000);
                  setResetPasswordUser(null);
                }}
                className="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold transition-colors"
              >
                Simpan & Salin Password
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Admin Toast */}
      {adminToast && (
        <div className="fixed bottom-20 right-4 sm:bottom-8 sm:right-8 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs font-medium">{adminToast}</span>
          <button 
            onClick={() => setAdminToast(null)}
            className="text-slate-400 hover:text-white ml-2 text-xs"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
};
