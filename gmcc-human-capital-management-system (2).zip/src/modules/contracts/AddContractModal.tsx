import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { EmploymentType } from '../../types';
import { 
  X, 
  Plus, 
  FileCheck2, 
  Calendar, 
  User, 
  CheckCircle2, 
  AlertCircle, 
  FileText,
  Upload,
  Clock,
  Sparkles,
  Coins
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  initialEmployeeId?: string;
}

export const AddContractModal: React.FC<Props> = ({ isOpen, onClose, initialEmployeeId }) => {
  const { employees, contracts, addContract, departments, attachSignedContract } = useApp();

  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>(initialEmployeeId || '');
  const [employmentType, setEmploymentType] = useState<EmploymentType>('PKWT');
  const [contractNumber, setContractNumber] = useState('');
  const [termNumber, setTermNumber] = useState<number>(1);
  const [position, setPosition] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedDurationMonths, setSelectedDurationMonths] = useState<number>(12);
  const [notes, setNotes] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  // Gaji / Uang Kompensasi PKWT (PP 35/2021)
  const [compensationStatus, setCompensationStatus] = useState<'DITERIMA' | 'BELUM'>('BELUM');
  const [compensationAmount, setCompensationAmount] = useState<number | undefined>(undefined);
  const [compensationPaidDate, setCompensationPaidDate] = useState<string>('');
  const [compensationNotes, setCompensationNotes] = useState<string>('');

  // Signed document attachment
  const [signedFileName, setSignedFileName] = useState('');
  const [signedFileUrl, setSignedFileUrl] = useState('');

  // Selected employee metadata
  const selectedEmployee = employees.find(e => e.id === selectedEmployeeId);
  const empContracts = contracts
    .filter(c => c.employeeId === selectedEmployeeId)
    .sort((a, b) => (a.termNumber || a.version || 1) - (b.termNumber || b.version || 1));

  const computeEndDateFromDuration = (startDateStr: string, months: number) => {
    if (!startDateStr) return '';
    const date = new Date(startDateStr);
    date.setMonth(date.getMonth() + months);
    date.setDate(date.getDate() - 1);
    return date.toISOString().split('T')[0];
  };

  useEffect(() => {
    if (initialEmployeeId) {
      setSelectedEmployeeId(initialEmployeeId);
    }
  }, [initialEmployeeId, isOpen]);

  useEffect(() => {
    if (selectedEmployee) {
      setPosition(selectedEmployee.jobTitle || '');
      setDepartmentId(selectedEmployee.departmentId || 'DEP-FBS');
      setEmploymentType(selectedEmployee.employmentType === 'DAILY_WORKER' ? 'DAILY_WORKER' : 'PKWT');

      // Check existing contracts for this employee to determine termNumber
      const highestTerm = empContracts.reduce((max, c) => Math.max(max, c.termNumber || c.version || 1), 0);
      const nextTerm = highestTerm > 0 ? highestTerm + 1 : 1;
      setTermNumber(nextTerm);

      // Default start date
      let defaultStart = new Date().toISOString().split('T')[0];
      const latestContract = empContracts[empContracts.length - 1];
      if (latestContract?.endDate) {
        const nextDay = new Date(latestContract.endDate);
        nextDay.setDate(nextDay.getDate() + 1);
        defaultStart = nextDay.toISOString().split('T')[0];
      }
      setStartDate(defaultStart);
      setEndDate(computeEndDateFromDuration(defaultStart, 12));
      setSelectedDurationMonths(12);

      // Auto-suggest contract number
      const year = new Date().getFullYear();
      const code = selectedEmployee.departmentId ? selectedEmployee.departmentId.replace('DEP-', '') : 'HC';
      const termTag = nextTerm > 1 ? `-P${nextTerm}` : '-P1';
      setContractNumber(`GMCC-${code}/PKWT/${year}/${selectedEmployee.employeeNumber || '001'}${termTag}`);

      if (nextTerm > 1) {
        setNotes(`Perpanjangan Kontrak Baru Periode ${nextTerm} setelah masa kontrak sebelumnya berakhir`);
      } else {
        setNotes('Penerbitan Kontrak Awal (Periode 1)');
      }
    }
  }, [selectedEmployeeId]);

  if (!isOpen) return null;

  const handleDurationSelect = (months: number) => {
    setSelectedDurationMonths(months);
    if (startDate) {
      setEndDate(computeEndDateFromDuration(startDate, months));
    }
  };

  const handleStartDateChange = (val: string) => {
    setStartDate(val);
    if (selectedDurationMonths && val) {
      setEndDate(computeEndDateFromDuration(val, selectedDurationMonths));
    }
  };

  const handleSimulateFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSignedFileName(file.name);
      setSignedFileUrl(URL.createObjectURL(file));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmployeeId || !startDate || !endDate || !contractNumber) return;

    const createdContract = addContract({
      contractNumber,
      employeeId: selectedEmployeeId,
      employeeName: selectedEmployee?.fullName || 'Karyawan',
      departmentId: departmentId || selectedEmployee?.departmentId || 'DEP-FBS',
      position: position || selectedEmployee?.jobTitle || '-',
      employmentType,
      startDate,
      endDate,
      status: 'ACTIVE',
      termNumber,
      version: termNumber,
      notes: notes || `Kontrak Baru Periode ${termNumber}`,
      signedContractFileName: signedFileName || undefined,
      signedContractFileUrl: signedFileUrl || undefined,
      signedContractUploadedAt: signedFileName ? new Date().toISOString() : undefined,
      compensationStatus,
      compensationAmount,
      compensationPaidDate: compensationPaidDate || undefined,
      compensationNotes: compensationNotes || undefined
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
              <Plus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Terbitkan Kontrak Kerja Baru</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Mencatat kontrak awal atau penambahan periode berikutnya (Periode 1, Periode 2, dst)
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-10 text-center flex flex-col items-center justify-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-slate-900 text-lg">Kontrak Periode {termNumber} Berhasil Diterbitkan!</h4>
            <p className="text-xs text-slate-600 max-w-md">
              Kontrak baru untuk <strong>{selectedEmployee?.fullName}</strong> telah aktif dan otomatis tercatat dalam <strong>Laporan Rekapitulasi Riwayat Periode Kontrak</strong>.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            {/* 1. Pilih Karyawan */}
            <div>
              <label className="block font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-emerald-700" />
                Pilih Karyawan Penerima Kontrak *
              </label>
              <select
                required
                value={selectedEmployeeId}
                onChange={e => setSelectedEmployeeId(e.target.value)}
                className="w-full text-xs rounded-xl border border-slate-300 px-3.5 py-2.5 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
              >
                <option value="">-- Pilih Pegawai GMCC --</option>
                {employees.map(emp => {
                  const empExistingContracts = contracts.filter(c => c.employeeId === emp.id);
                  const activeContract = empExistingContracts.find(c => c.status === 'ACTIVE' || c.status === 'EXPIRING_SOON');
                  const expiredContract = empExistingContracts.find(c => c.status === 'EXPIRED');

                  let contractTag = 'Belum Ada Kontrak';
                  if (activeContract) {
                    contractTag = `Aktif di Periode ${activeContract.termNumber || 1}`;
                  } else if (expiredContract) {
                    contractTag = `Kontrak Periode ${expiredContract.termNumber || 1} Habis`;
                  } else if (empExistingContracts.length > 0) {
                    contractTag = `${empExistingContracts.length} Periode Tercatat`;
                  }

                  return (
                    <option key={emp.id} value={emp.id}>
                      {emp.fullName} ({emp.employeeNumber || emp.id}) — {emp.jobTitle} [{contractTag}]
                    </option>
                  );
                })}
              </select>
            </div>

            {/* Smart Detection Banner */}
            {selectedEmployee && (
              <div className="p-3.5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-700" />
                    <span className="font-bold text-emerald-950 text-xs">Deteksi Otomatis Riwayat Kontrak</span>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-700 text-white font-bold text-[10px] shadow-2xs">
                    Target: Periode {termNumber}
                  </span>
                </div>

                <p className="text-[11px] text-emerald-900 leading-relaxed">
                  {empContracts.length === 0 ? (
                    <span>Karyawan ini belum memiliki kontrak. Kontrak ini akan didaftarkan sebagai <strong>Periode 1 (Kontrak Awal)</strong>.</span>
                  ) : (
                    <span>
                      Karyawan ini memiliki <strong>{empContracts.length} periode kontrak terdahulu</strong>. Kontrak terakhir ({empContracts[empContracts.length - 1].contractNumber}) berakhir pada <strong>{empContracts[empContracts.length - 1].endDate || '-'}</strong>. Kontrak baru ini otomatis dilanjutkan ke <strong className="text-emerald-800">Periode {termNumber}</strong>.
                    </span>
                  )}
                </p>

                {empContracts.length > 0 && (
                  <div className="pt-2 border-t border-emerald-200/80 space-y-1">
                    <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wide">
                      Runtutan Periode Sebelumnya:
                    </span>
                    <div className="space-y-1 max-h-20 overflow-y-auto">
                      {empContracts.map(c => (
                        <div key={c.id} className="flex items-center justify-between bg-white/90 px-2 py-0.5 rounded text-[10px] border border-emerald-100">
                          <span className="font-bold text-slate-800">Periode {c.termNumber || c.version || 1}</span>
                          <span className="font-mono text-slate-600">{c.contractNumber}</span>
                          <span className="text-slate-500">{c.startDate} s/d {c.endDate}</span>
                          <span className={`px-1 rounded text-[9px] font-bold ${
                            c.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {c.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Contract Type & Term Number */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-800 mb-1">Tipe Perjanjian Kerja *</label>
                <select
                  value={employmentType}
                  onChange={e => setEmploymentType(e.target.value as EmploymentType)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
                >
                  <option value="PKWT">PKWT (Perjanjian Kerja Waktu Tertentu)</option>
                  <option value="DAILY_WORKER">SPK Daily Worker (Harian Lepas Event)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-800 mb-1">
                  Urutan Periode Kontrak (Term) *
                </label>
                <div className="flex items-center gap-2">
                  <select
                    value={termNumber}
                    onChange={e => {
                      const val = Number(e.target.value);
                      setTermNumber(val);
                      if (contractNumber) {
                        const baseNum = contractNumber.replace(/-P\d+$/i, '');
                        setContractNumber(`${baseNum}-P${val}`);
                      }
                    }}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-bold"
                  >
                    {[1, 2, 3, 4, 5, 6].map(num => (
                      <option key={num} value={num}>
                        Periode {num} {num === 1 ? '(Kontrak Awal)' : `(Perpanjangan ke-${num - 1})`}
                      </option>
                    ))}
                  </select>
                  <span className="text-xs font-mono font-bold px-2.5 py-1.5 bg-slate-100 rounded-lg text-slate-700 border border-slate-200 shrink-0">
                    P{termNumber}
                  </span>
                </div>
              </div>
            </div>

            {/* Nomor Kontrak */}
            <div>
              <label className="block font-semibold text-slate-800 mb-1">
                Nomor Surat Perjanjian Kontrak *
              </label>
              <div className="relative">
                <FileText className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={contractNumber}
                  onChange={e => setContractNumber(e.target.value)}
                  placeholder="Misal: 015/GMCC-HC/PKWT/IV/2026-P2"
                  className="w-full text-xs rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-slate-900 font-mono font-semibold focus:outline-hidden focus:border-emerald-700"
                />
              </div>
            </div>

            {/* Quick Duration Buttons */}
            <div>
              <label className="block font-semibold text-slate-800 mb-1.5">
                Pilih Durasi Kontrak
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: '3 Bulan', months: 3 },
                  { label: '6 Bulan', months: 6 },
                  { label: '1 Tahun', months: 12 },
                  { label: '2 Tahun', months: 24 }
                ].map(item => (
                  <button
                    key={item.months}
                    type="button"
                    onClick={() => handleDurationSelect(item.months)}
                    className={`py-1.5 px-2 rounded-lg font-bold text-center border text-[11px] transition-all ${
                      selectedDurationMonths === item.months
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Start and End Date */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tanggal Mulai Berlaku *</label>
                <input
                  type="date"
                  required
                  value={startDate}
                  onChange={e => handleStartDateChange(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tanggal Berakhir Kontrak *</label>
                <input
                  type="date"
                  required
                  value={endDate}
                  onChange={e => {
                    setEndDate(e.target.value);
                    setSelectedDurationMonths(0);
                  }}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:border-emerald-700 font-bold text-emerald-900"
                />
              </div>
            </div>

            {/* Jabatan & Departemen */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Jabatan dalam Kontrak</label>
                <input
                  type="text"
                  value={position}
                  onChange={e => setPosition(e.target.value)}
                  placeholder="Misal: Banquet Captain"
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:border-emerald-700"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Departemen Penugasan</label>
                <select
                  value={departmentId}
                  onChange={e => setDepartmentId(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
                >
                  {departments.map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Kolom Informasi Gaji Kompensasi PKWT (PP 35/2021) */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                  <Coins className="w-4 h-4 text-emerald-700" />
                  Informasi Gaji Kompensasi PKWT (PP 35/2021)
                </label>
                <span className="text-[10px] text-slate-500 font-medium">Kompensasi Hak Finansial</span>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <label className={`flex items-center gap-2.5 p-3 rounded-xl border cursor-pointer transition-all ${
                  compensationStatus === 'DITERIMA' 
                    ? 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-bold shadow-2xs' 
                    : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                }`}>
                  <input
                    type="radio"
                    name="add_compensationStatus"
                    value="DITERIMA"
                    checked={compensationStatus === 'DITERIMA'}
                    onChange={() => setCompensationStatus('DITERIMA')}
                    className="w-4 h-4 text-emerald-600 focus:ring-emerald-500"
                  />
                  <div>
                    <span className="block text-xs font-bold text-slate-900">Diterima</span>
                    <span className="block text-[10px] text-emerald-700 font-normal">Sudah dibayarkan kepada staf</span>
                  </div>
                </label>

                <label className={`flex items-center gap-2.5 p-3 rounded-xl border cursor-pointer transition-all ${
                  compensationStatus === 'BELUM' 
                    ? 'border-amber-500 bg-amber-50/80 text-amber-950 font-bold shadow-2xs' 
                    : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                }`}>
                  <input
                    type="radio"
                    name="add_compensationStatus"
                    value="BELUM"
                    checked={compensationStatus === 'BELUM'}
                    onChange={() => setCompensationStatus('BELUM')}
                    className="w-4 h-4 text-amber-600 focus:ring-amber-500"
                  />
                  <div>
                    <span className="block text-xs font-bold text-slate-900">Belum</span>
                    <span className="block text-[10px] text-amber-700 font-normal">Belum cair / proses pengajuan</span>
                  </div>
                </label>
              </div>

              {/* Rincian Tambahan jika Diterima */}
              {compensationStatus === 'DITERIMA' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Nominal Uang Kompensasi (Rp)
                    </label>
                    <input
                      type="number"
                      value={compensationAmount || ''}
                      onChange={e => setCompensationAmount(e.target.value ? Number(e.target.value) : undefined)}
                      placeholder="Contoh: 4500000"
                      className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Tanggal Pembayaran
                    </label>
                    <input
                      type="date"
                      value={compensationPaidDate}
                      onChange={e => setCompensationPaidDate(e.target.value)}
                      className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 font-mono"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Notes */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Dasar Perjanjian & Catatan Ketentuan</label>
              <textarea
                rows={2}
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Misal: Perpanjangan PKWT Periode 2 sesuai rekomendasi HOD dan evaluasi performa tahun berjalan..."
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:border-emerald-700"
              />
            </div>

            {/* Optional Signed Contract Upload */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <label className="block font-semibold text-slate-800">
                Salinan Berkas Kontrak Bertandatangan (Opsional)
              </label>
              <div className="flex items-center gap-3">
                <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 font-semibold transition-colors shadow-2xs">
                  <Upload className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Pilih Dokumen PDF TTD</span>
                  <input
                    type="file"
                    accept=".pdf,image/*"
                    onChange={handleSimulateFileUpload}
                    className="hidden"
                  />
                </label>
                {signedFileName ? (
                  <span className="font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 text-[11px] truncate max-w-xs">
                    ✓ {signedFileName}
                  </span>
                ) : (
                  <span className="text-[11px] text-slate-400 italic">
                    Dapat diunggah sekarang atau nanti melalui tombol lampirkan TTD.
                  </span>
                )}
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">
                Tercatat otomatis dalam riwayat periode kontrak karyawan.
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={!selectedEmployeeId}
                  className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-sm transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  Terbitkan Kontrak Periode {termNumber}
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
