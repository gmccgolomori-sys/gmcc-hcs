import React, { useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useApp } from '../../context/AppContext';
import { EmploymentContract, Employee } from '../../types';
import { Printer, X, Download, ShieldCheck, Building2, Calendar, FileText } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  filteredContracts: EmploymentContract[];
  departments: { id: string; name: string; code: string }[];
  deptFilter: string;
  typeFilter: string;
}

export const ContractReportPrintModal: React.FC<Props> = ({
  isOpen,
  onClose,
  filteredContracts,
  departments,
  deptFilter,
  typeFilter
}) => {
  const { employees, currentUser } = useApp();
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      document.body.classList.add('print-modal-active');
    } else {
      document.body.classList.remove('print-modal-active');
    }
    return () => {
      document.body.classList.remove('print-modal-active');
    };
  }, [isOpen]);

  if (!isOpen) return null;

  // Group contracts by employee
  const groupedByEmployee: {
    employee: Employee;
    contracts: EmploymentContract[];
    activeContract?: EmploymentContract;
  }[] = [];

  // Grouping
  const empMap = new Map<string, EmploymentContract[]>();
  filteredContracts.forEach(c => {
    const list = empMap.get(c.employeeId) || [];
    list.push(c);
    empMap.set(c.employeeId, list);
  });

  empMap.forEach((contractsList, empId) => {
    const emp = employees.find(e => e.id === empId);
    if (emp) {
      // Sort contracts chronologically by termNumber or version
      const sorted = [...contractsList].sort(
        (a, b) => (a.termNumber || a.version || 1) - (b.termNumber || b.version || 1)
      );
      const activeContract = sorted.find(c => c.status === 'ACTIVE' || c.status === 'EXPIRING_SOON');
      groupedByEmployee.push({
        employee: emp,
        contracts: sorted,
        activeContract
      });
    }
  });

  const deptLabel = deptFilter && deptFilter !== 'ALL' 
    ? departments.find(d => d.id === deptFilter)?.name || deptFilter
    : 'Seluruh Departemen (Company-Wide)';

  const formattedDate = new Date().toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    const headers = [
      'No',
      'NIK',
      'Nama Karyawan',
      'Departemen',
      'Jabatan',
      'Tipe Kontrak',
      'Periode Kontrak',
      'Nomor Kontrak',
      'Tanggal Mulai',
      'Tanggal Selesai',
      'Status Kontrak',
      'Gaji Kompensasi (PP 35/2021)',
      'Salinan TTD',
      'Catatan / Dasar Kontrak'
    ];

    const rows: string[][] = [];
    let counter = 1;

    groupedByEmployee.forEach(item => {
      const emp = item.employee;
      const deptName = departments.find(d => d.id === emp.departmentId)?.name || emp.departmentId;

      item.contracts.forEach(c => {
        rows.push([
          String(counter++),
          `"${emp.employeeNumber || emp.id}"`,
          `"${emp.fullName}"`,
          `"${deptName}"`,
          `"${c.position || emp.jobTitle}"`,
          `"${c.employmentType}"`,
          `"Periode ${c.termNumber || c.version || 1}"`,
          `"${c.contractNumber}"`,
          `"${c.startDate}"`,
          `"${c.endDate || '-'}"`,
          `"${c.status}"`,
          `"${c.compensationStatus === 'DITERIMA' ? 'DITERIMA' : 'BELUM'}"`,
          `"${c.signedContractFileName ? 'ADA' : 'BELUM'}"`,
          `"${(c.notes || '').replace(/"/g, '""')}"`
        ]);
      });
    });

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Laporan_Riwayat_Kontrak_GMCC_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return createPortal(
    <div className="gmcc-print-portal fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto">
      <div className="gmcc-print-sheet bg-white rounded-2xl shadow-2xl max-w-5xl w-full max-h-[95vh] flex flex-col overflow-hidden border border-slate-300">
        {/* Top Action Bar (Hidden when printing) */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0 print:hidden">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-sm tracking-tight text-white">
                Pratinjau Cetak Laporan Rekapitulasi Riwayat Periode Kontrak
              </h3>
              <p className="text-[11px] text-slate-400">
                Golo Mori Convention Center · Format Cetak Resmi A4 (Periode 1, Periode 2, dst)
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Ekspor CSV</span>
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak / Simpan PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Sheet */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-100 flex justify-center">
          <div 
            ref={printRef}
            className="bg-white w-full max-w-4xl p-8 sm:p-10 shadow-lg border border-slate-200 text-slate-900 print:shadow-none print:border-none print:p-0 print:max-w-none print:w-full"
            style={{ minHeight: '297mm' }}
          >
            {/* Header Perusahaan Resmi */}
            <div className="border-b-2 border-slate-900 pb-4 mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-xl font-extrabold tracking-tight text-slate-900 uppercase">
                    Golo Mori Convention Center
                  </h1>
                  <h2 className="text-xs font-bold text-emerald-800 uppercase tracking-wider mt-0.5">
                    Human Capital & People Development Department
                  </h2>
                  <p className="text-[10px] text-slate-600 mt-1 max-w-lg leading-tight">
                    Kawasan Pariwisata The Golo Mori by ITDC, Golo Mori, Labuan Bajo, Kabupaten Manggarai Barat, Nusa Tenggara Tim. 86763
                  </p>
                </div>
                <div className="text-right">
                  <div className="inline-block border-2 border-slate-900 px-3 py-1 rounded text-center">
                    <span className="block text-[9px] font-bold text-slate-500 uppercase tracking-widest">
                      KODE DOKUMEN
                    </span>
                    <span className="block text-xs font-mono font-black text-slate-900">
                      GMCC-HC-RPT-CTR
                    </span>
                  </div>
                  <span className="block text-[9px] text-slate-400 mt-1 italic">
                    Rahasia / Terbatas (Audit HC)
                  </span>
                </div>
              </div>
            </div>

            {/* Judul Laporan */}
            <div className="text-center mb-6">
              <h3 className="text-base font-black text-slate-900 uppercase tracking-wide">
                LAPORAN REKAPITULASI RIWAYAT KONTRAK KERJA KARYAWAN
              </h3>
              <p className="text-xs text-slate-600 mt-0.5 font-medium">
                Pencatatan Berjenjang: Periode 1 (Awal), Periode 2 (Perpanjangan ke-1), Periode 3, dan Seterusnya
              </p>
            </div>

            {/* Parameter Laporan */}
            <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-3.5 rounded-lg border border-slate-200 mb-6">
              <div>
                <div className="flex justify-between py-0.5">
                  <span className="text-slate-500">Departemen:</span>
                  <span className="font-bold text-slate-800">{deptLabel}</span>
                </div>
                <div className="flex justify-between py-0.5">
                  <span className="text-slate-500">Tipe Kontrak:</span>
                  <span className="font-bold text-slate-800">
                    {typeFilter === 'ALL' ? 'Semua Tipe (PKWT & Daily Worker)' : typeFilter}
                  </span>
                </div>
              </div>
              <div>
                <div className="flex justify-between py-0.5">
                  <span className="text-slate-500">Tanggal Dicetak:</span>
                  <span className="font-bold text-slate-800">{formattedDate}</span>
                </div>
                <div className="flex justify-between py-0.5">
                  <span className="text-slate-500">Petugas / Otorisasi:</span>
                  <span className="font-bold text-slate-800">{currentUser.name} ({currentUser.role})</span>
                </div>
              </div>
            </div>

            {/* Tabel Riwayat Kontrak Multi-Periode */}
            <div className="space-y-4 mb-8">
              {groupedByEmployee.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs italic">
                  Tidak ada catatan kontrak untuk filter yang dipilih.
                </div>
              ) : (
                groupedByEmployee.map((item, idx) => {
                  const emp = item.employee;
                  const dept = departments.find(d => d.id === emp.departmentId)?.name || emp.departmentId;

                  return (
                    <div key={emp.id} className="border border-slate-300 rounded-lg overflow-hidden text-[11px] break-inside-avoid">
                      {/* Baris Karyawan Header */}
                      <div className="bg-slate-100 px-3 py-2 border-b border-slate-300 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-slate-800 text-white font-bold text-[10px] flex items-center justify-center shrink-0">
                            {idx + 1}
                          </span>
                          <span className="font-bold text-slate-900 text-xs">{emp.fullName}</span>
                          <span className="font-mono text-[10px] text-slate-500">({emp.employeeNumber || emp.id})</span>
                          <span className="text-slate-400">·</span>
                          <span className="text-slate-700 font-medium">{emp.jobTitle}</span>
                          <span className="text-slate-400">·</span>
                          <span className="text-slate-600">{dept}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-500">
                            Total {item.contracts.length} Periode Tercatat
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            item.activeContract 
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : 'bg-rose-100 text-rose-800 border border-rose-300'
                          }`}>
                            {item.activeContract ? `Aktif di Periode ${item.activeContract.termNumber || 1}` : 'Kontrak Habis'}
                          </span>
                        </div>
                      </div>

                      {/* Detail Kontrak per Periode */}
                      <table className="w-full text-left">
                        <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 text-[10px] uppercase font-semibold">
                          <tr>
                            <th className="py-1.5 px-3 w-20">Periode</th>
                            <th className="py-1.5 px-3">Nomor Kontrak</th>
                            <th className="py-1.5 px-3">Tipe</th>
                            <th className="py-1.5 px-3">Masa Berlaku</th>
                            <th className="py-1.5 px-3">Status</th>
                            <th className="py-1.5 px-3">Gaji Kompensasi</th>
                            <th className="py-1.5 px-3">Salinan TTD</th>
                            <th className="py-1.5 px-3">Catatan / Ketentuan</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {item.contracts.map(c => (
                            <tr key={c.id} className="hover:bg-slate-50/50">
                              <td className="py-2 px-3 font-bold text-slate-900">
                                Periode {c.termNumber || c.version || 1}
                              </td>
                              <td className="py-2 px-3 font-mono font-medium text-slate-800">
                                {c.contractNumber}
                              </td>
                              <td className="py-2 px-3">
                                <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                                  c.employmentType === 'DAILY_WORKER' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                                }`}>
                                  {c.employmentType}
                                </span>
                              </td>
                              <td className="py-2 px-3 text-slate-700">
                                {c.startDate} s/d {c.endDate || '-'}
                              </td>
                              <td className="py-2 px-3">
                                <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                                  c.status === 'ACTIVE' 
                                    ? 'bg-emerald-100 text-emerald-800' 
                                    : c.status === 'RENEWED'
                                      ? 'bg-slate-100 text-slate-600'
                                      : 'bg-rose-100 text-rose-800'
                                }`}>
                                  {c.status}
                                </span>
                              </td>
                              <td className="py-2 px-3">
                                <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                                  c.compensationStatus === 'DITERIMA' 
                                    ? 'bg-emerald-100 text-emerald-800' 
                                    : 'bg-amber-100 text-amber-800'
                                }`}>
                                  {c.compensationStatus === 'DITERIMA' ? 'Diterima' : 'Belum'}
                                </span>
                              </td>
                              <td className="py-2 px-3">
                                {c.signedContractFileName ? (
                                  <span className="text-emerald-700 font-semibold text-[10px]">
                                    ✓ Terlampir
                                  </span>
                                ) : (
                                  <span className="text-slate-400 text-[10px] italic">
                                    Belum
                                  </span>
                                )}
                              </td>
                              <td className="py-2 px-3 text-slate-600 text-[10px] max-w-xs truncate">
                                {c.notes || '-'}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  );
                })
              )}
            </div>

            {/* Tanda Tangan Resmi Pengesahan */}
            <div className="pt-6 border-t border-slate-300 break-inside-avoid">
              <div className="grid grid-cols-2 gap-12 text-center text-xs">
                <div>
                  <span className="block text-slate-500 mb-1">Dibuat & Diverifikasi Oleh:</span>
                  <span className="block font-bold text-slate-800 uppercase">Human Capital Department</span>
                  <div className="h-16 flex items-center justify-center">
                    <span className="text-slate-300 italic text-[11px]">[Tanda Tangan Digital HC]</span>
                  </div>
                  <span className="block font-bold text-slate-900 border-t border-slate-400 pt-1 w-48 mx-auto">
                    {currentUser.name}
                  </span>
                  <span className="block text-[10px] text-slate-500">HC Manager / Specialist</span>
                </div>

                <div>
                  <span className="block text-slate-500 mb-1">Mengetahui & Menyetujui:</span>
                  <span className="block font-bold text-slate-800 uppercase">General Manager</span>
                  <div className="h-16 flex items-center justify-center">
                    <span className="text-slate-300 italic text-[11px]">[Tanda Tangan General Manager]</span>
                  </div>
                  <span className="block font-bold text-slate-900 border-t border-slate-400 pt-1 w-48 mx-auto">
                    General Manager GMCC
                  </span>
                  <span className="block text-[10px] text-slate-500">Executive Leadership</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
