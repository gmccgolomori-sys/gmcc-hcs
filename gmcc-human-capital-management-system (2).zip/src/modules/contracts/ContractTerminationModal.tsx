import React, { useState } from 'react';
import { EmploymentContract, TerminationReason } from '../../types';
import { useApp } from '../../context/AppContext';
import { 
  X, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  Calendar, 
  FileText, 
  UserX,
  DollarSign,
  HelpCircle
} from 'lucide-react';

interface Props {
  contract: EmploymentContract | null;
  onClose: () => void;
}

const TERMINATION_REASONS: { value: TerminationReason; label: string; description: string }[] = [
  {
    value: 'END_OF_CONTRACT',
    label: 'Habis Masa Kontrak / Tidak Diperpanjang',
    description: 'Masa berlaku PKWT telah selesai dan disepakati untuk tidak dilakukan perpanjangan (PP 35/2021).'
  },
  {
    value: 'RESIGNATION',
    label: 'Pengunduran Diri Karyawan (Resignation)',
    description: 'Karyawan mengajukan surat pengunduran diri secara sukarela dengan notice period yang disepakati.'
  },
  {
    value: 'MUTUAL_AGREEMENT',
    label: 'Kesepakatan Pengakhiran Bersama (Bipartit)',
    description: 'Kedua belah pihak sepakat mengakhiri hubungan kerja sebelum masa kontrak berakhir.'
  },
  {
    value: 'DISMISSAL_PHK',
    label: 'Pemutusan Hubungan Kerja (PHK / Rasionalisasi)',
    description: 'Pengakhiran kerja oleh manajemen GMCC karena restrukturisasi operasional atau efisiensi.'
  },
  {
    value: 'DISCIPLINARY',
    label: 'Pelanggaran Disiplin Berat (SP3 / Indisipliner)',
    description: 'Pengakhiran akibat pelanggaran SOP GMCC, tata tertib perusahaan, atau akumulasi sanksi SP3.'
  },
  {
    value: 'RETIREMENT',
    label: 'Pensiun / Alasan Kesehatan (Medical / Retirement)',
    description: 'Mencapai batas usia kerja atau kondisi kesehatan kronis tidak memungkinkan berlanjut.'
  },
  {
    value: 'OTHER',
    label: 'Alasan Khusus Lainnya',
    description: 'Keperluan khusus yang telah dikonsultasikan dengan Human Capital dan General Manager.'
  }
];

export const ContractTerminationModal: React.FC<Props> = ({ contract, onClose }) => {
  const { terminateContract, systemDate } = useApp();

  const [reason, setReason] = useState<TerminationReason>('END_OF_CONTRACT');
  const [effectiveDate, setEffectiveDate] = useState<string>(
    contract?.endDate || new Date(systemDate).toISOString().split('T')[0]
  );
  const [notes, setNotes] = useState('');
  const [severanceNotes, setSeveranceNotes] = useState('');
  const [updateEmployeeStatus, setUpdateEmployeeStatus] = useState(true);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!contract) return null;

  const selectedReasonObj = TERMINATION_REASONS.find(r => r.value === reason);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!effectiveDate) return;

    terminateContract(contract.id, {
      effectiveDate,
      reason,
      reasonLabel: selectedReasonObj?.label,
      notes: notes.trim() || `Pengakhiran kontrak ${contract.contractNumber} (${selectedReasonObj?.label})`,
      severanceNotes: severanceNotes.trim() || undefined,
      updateEmployeeStatus
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-200 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-rose-100 flex items-center justify-between bg-rose-50/80 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
              <UserX className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Terminasi & Pengakhiran Kontrak</h3>
              <p className="text-xs text-rose-700 font-medium">
                Pencatatan resmi pengakhiran masa kerja dan kompensasi PKWT / SPK
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-rose-100/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center flex flex-col items-center justify-center">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-3">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-slate-900 text-lg">Kontrak Berhasil Diterminasi</h4>
            <p className="text-xs text-slate-600 mt-1 max-w-sm">
              Status kontrak telah diubah menjadi <strong>TERMINATED</strong> dan tercatat pada audit trail Human Capital.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs overflow-y-auto flex-1">
            {/* Contract Snapshot */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-medium">Nama Karyawan:</span>
                <span className="font-bold text-slate-900 text-sm">{contract.employeeName}</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Nomor Kontrak:</span>
                <span className="font-mono font-bold text-slate-800">{contract.contractNumber} (v{contract.version})</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Departemen & Jabatan:</span>
                <span className="text-slate-700">{contract.position} · {contract.departmentId.replace('DEP-', '')}</span>
              </div>
              <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-200">
                <span className="text-slate-500">Periode Kontrak:</span>
                <span className="text-slate-700 font-mono">
                  {new Date(contract.startDate).toLocaleDateString('id-ID')} s/d {contract.endDate ? new Date(contract.endDate).toLocaleDateString('id-ID') : '-'}
                </span>
              </div>
            </div>

            {/* Termination Reason */}
            <div>
              <label className="block font-bold text-slate-800 mb-1.5">
                Alasan Pengakhiran Kontrak (Termination Reason) <span className="text-rose-500">*</span>
              </label>
              <select
                value={reason}
                onChange={e => setReason(e.target.value as TerminationReason)}
                className="w-full text-xs rounded-xl border border-slate-300 px-3.5 py-2.5 text-slate-900 focus:outline-hidden focus:border-rose-600 bg-white"
                required
              >
                {TERMINATION_REASONS.map(r => (
                  <option key={r.value} value={r.value}>
                    {r.label}
                  </option>
                ))}
              </select>
              {selectedReasonObj && (
                <p className="text-[11px] text-slate-500 mt-1 italic bg-slate-50 p-2 rounded-lg border border-slate-100">
                  {selectedReasonObj.description}
                </p>
              )}
            </div>

            {/* Effective Termination Date */}
            <div>
              <label className="block font-bold text-slate-800 mb-1.5">
                Tanggal Efektif Pengakhiran <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  required
                  value={effectiveDate}
                  onChange={e => setEffectiveDate(e.target.value)}
                  className="w-full text-xs rounded-xl border border-slate-300 px-3.5 py-2 text-slate-900 focus:outline-hidden focus:border-rose-600"
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Hari terakhir bekerja / tanggal cutoff kewajiban kerja dan absensi.
              </p>
            </div>

            {/* Kompensasi PKWT / Hak Finansial PP 35/2021 */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="font-bold text-slate-800 flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                  Kompensasi PKWT / Hak Finansial Karyawan
                </label>
                <span className="text-[10px] text-slate-500 font-mono">Sesuai PP No. 35/2021</span>
              </div>
              <textarea
                rows={2}
                value={severanceNotes}
                onChange={e => setSeveranceNotes(e.target.value)}
                placeholder="Rincian uang kompensasi PKWT (Masa kerja / 12 x 1 bulan upah), sisa cuti tahunan yang diuangkan, atau uang pisah..."
                className="w-full text-xs rounded-xl border border-slate-300 px-3.5 py-2 focus:outline-hidden focus:border-rose-600"
              />
            </div>

            {/* Handover & Exit Clearance Notes */}
            <div>
              <label className="block font-bold text-slate-800 mb-1.5">
                Catatan Serah Terima Tugas & Inventaris (Exit Clearance)
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Pengembalian ID badge, seragam kerja, serah terima berkas/kunci, dan konfirmasi Dept Head..."
                className="w-full text-xs rounded-xl border border-slate-300 px-3.5 py-2 focus:outline-hidden focus:border-rose-600"
              />
            </div>

            {/* Toggle Employee Status */}
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3">
              <input
                type="checkbox"
                id="updateEmpStatusCheck"
                checked={updateEmployeeStatus}
                onChange={e => setUpdateEmployeeStatus(e.target.checked)}
                className="mt-0.5 rounded text-rose-600 focus:ring-rose-500 w-4 h-4 cursor-pointer"
              />
              <label htmlFor="updateEmpStatusCheck" className="text-xs text-amber-950 cursor-pointer">
                <strong className="block font-semibold">Ubah status kepegawaian menjadi EX_EMPLOYEE</strong>
                <span className="text-[11px] text-amber-800">
                  Secara otomatis menandai profil staf sebagai mantan karyawan (non-aktif) pada direktori dan rekap absensi.
                </span>
              </label>
            </div>

            {/* Warning Callout */}
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2.5 text-xs text-rose-800">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>
                Terminasi kontrak akan dicatat permanen dalam Audit Log HC dan menonaktifkan perpanjangan otomatis.
              </span>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
              >
                Batal
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-rose-700 hover:bg-rose-800 text-white font-bold shadow-md shadow-rose-700/20 transition-colors"
              >
                <ShieldAlert className="w-4 h-4" />
                Konfirmasi Terminasi Kontrak
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
