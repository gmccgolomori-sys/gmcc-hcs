import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { EmploymentContract, ContractStatus } from '../../types';
import { 
  FileCheck2, 
  AlertTriangle, 
  Clock, 
  Calendar, 
  Search, 
  Filter, 
  RefreshCw, 
  FileText, 
  ChevronRight,
  Plus,
  UserX,
  Info,
  Upload,
  Layers,
  FileSpreadsheet,
  Trash2,
  Coins
} from 'lucide-react';
import { ContractRenewalModal } from './ContractRenewalModal';
import { ContractTerminationModal } from './ContractTerminationModal';
import { SignedContractUploadModal } from './SignedContractUploadModal';
import { AddContractModal } from './AddContractModal';
import { ContractReportView } from './ContractReportView';

export const ContractManager: React.FC = () => {
  const { contracts, employees, currentUser, getDaysUntilExpiry, deleteContract } = useApp();

  const [activeTab, setActiveTab] = useState<'contracts-list' | 'period-report'>('contracts-list');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  
  // Modals state
  const [isAddContractModalOpen, setIsAddContractModalOpen] = useState(false);
  const [initialEmployeeForAdd, setInitialEmployeeForAdd] = useState<string | undefined>(undefined);
  const [selectedContractForRenewal, setSelectedContractForRenewal] = useState<EmploymentContract | null>(null);
  const [selectedContractForTermination, setSelectedContractForTermination] = useState<EmploymentContract | null>(null);
  const [selectedContractForSignedUpload, setSelectedContractForSignedUpload] = useState<EmploymentContract | null>(null);
  const [viewTerminationContract, setViewTerminationContract] = useState<EmploymentContract | null>(null);
  const [contractToDelete, setContractToDelete] = useState<EmploymentContract | null>(null);
  const [deleteToast, setDeleteToast] = useState<string | null>(null);

  // Role based filtering:
  // - Staff: only sees their own contract
  // - Dept Head: only sees contracts belonging to staff in their department
  // - HC, GM, Admin, Auditor: see all contracts
  const visibleContracts = contracts.filter(c => {
    if (currentUser.role === 'STAFF') {
      return c.employeeId === currentUser.employeeId;
    }
    if (currentUser.role === 'DEPT_HEAD') {
      const emp = employees.find(e => e.id === c.employeeId);
      return emp?.departmentId === currentUser.departmentId;
    }
    return true; // HC, GM, ADMIN, AUDITOR see all
  });

  const filteredContracts = visibleContracts.filter(c => {
    if (statusFilter !== 'ALL' && c.status !== statusFilter) return false;
    if (typeFilter !== 'ALL' && c.employmentType !== typeFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        c.contractNumber.toLowerCase().includes(q) ||
        c.employeeName.toLowerCase().includes(q) ||
        c.position.toLowerCase().includes(q)
      );
    }
    return true;
  }).sort((a, b) => {
    const aActive = a.status === 'ACTIVE' || a.status === 'EXPIRING_SOON';
    const bActive = b.status === 'ACTIVE' || b.status === 'EXPIRING_SOON';
    if (aActive && !bActive) return -1;
    if (!aActive && bActive) return 1;
    return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
  });

  // Calculate reminder counts (90, 60, 30, 14, 7 days)
  const expiringWithin30Days = contracts.filter(c => {
    if (c.status !== 'ACTIVE' && c.status !== 'EXPIRING_SOON') return false;
    const days = getDaysUntilExpiry(c.endDate);
    return days !== null && days >= 0 && days <= 30;
  });

  const expiringWithin60Days = contracts.filter(c => {
    if (c.status !== 'ACTIVE' && c.status !== 'EXPIRING_SOON') return false;
    const days = getDaysUntilExpiry(c.endDate);
    return days !== null && days > 30 && days <= 60;
  });

  const expiringWithin90Days = contracts.filter(c => {
    if (c.status !== 'ACTIVE' && c.status !== 'EXPIRING_SOON') return false;
    const days = getDaysUntilExpiry(c.endDate);
    return days !== null && days > 60 && days <= 90;
  });

  const handleOpenAddContractWithEmployee = (empId?: string) => {
    setInitialEmployeeForAdd(empId);
    setIsAddContractModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Human Capital</span>
            <ChevronRight className="w-3 h-3" />
            <span>PKWT & SPK Agreements</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Manajemen Kontrak Kerja</h1>
          <p className="text-xs text-slate-500 mt-1">
            Pengelolaan Perjanjian Kerja Waktu Tertentu (PKWT) dan SPK Daily Worker dengan pelacakan berjenjang (Periode 1, Periode 2, dst).
          </p>
        </div>

        {/* Global Action Button */}
        {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && (
          <button
            onClick={() => handleOpenAddContractWithEmployee()}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-sm transition-all hover:shadow-md"
          >
            <Plus className="w-4 h-4" />
            <span>+ Terbitkan Kontrak Baru</span>
          </button>
        )}
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('contracts-list')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'contracts-list'
              ? 'border-emerald-700 text-emerald-800 bg-emerald-50/50 rounded-t-lg'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Daftar Berkas Kontrak</span>
          <span className="ml-1 px-2 py-0.2 rounded-full text-[10px] bg-slate-200 text-slate-700 font-semibold">
            {visibleContracts.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('period-report')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-bold border-b-2 transition-all ${
            activeTab === 'period-report'
              ? 'border-emerald-700 text-emerald-800 bg-emerald-50/50 rounded-t-lg'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Layers className="w-4 h-4 text-emerald-700" />
          <span>Laporan Riwayat Periode Kontrak (Periode 1, 2, dst)</span>
        </button>
      </div>

      {/* If Tab is Report View */}
      {activeTab === 'period-report' ? (
        <ContractReportView
          onOpenAddContractModal={handleOpenAddContractWithEmployee}
          onOpenRenewalModal={c => setSelectedContractForRenewal(c)}
          onOpenSignedUploadModal={c => setSelectedContractForSignedUpload(c)}
          onViewTermination={c => setViewTerminationContract(c)}
        />
      ) : (
        /* Tab 1: Daftar Berkas Kontrak Table */
        <div className="space-y-6">
          {/* Role Scoping Banner */}
          {currentUser.role === 'STAFF' && (
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900">
              <strong>Akses Staf:</strong> Anda hanya dapat melihat dokumen kontrak kerja pribadi Anda.
            </div>
          )}

          {currentUser.role === 'DEPT_HEAD' && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-950">
              <strong>Akses Kepala Departemen:</strong> Menampilkan daftar kontrak kerja dan SPK Daily Worker staf di bawah supervisi departemen Anda.
            </div>
          )}

          {/* Contract Expiry Monitoring Bar (For HC, GM, Admin) */}
          {(currentUser.role === 'HC' || currentUser.role === 'GM' || currentUser.role === 'ADMIN') && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-rose-800 uppercase tracking-wide">
                    Expiring ≤ 30 Days (Urgent)
                  </div>
                  <div className="text-xl font-bold text-rose-950 mt-0.5">
                    {expiringWithin30Days.length} contract{expiringWithin30Days.length !== 1 ? 's' : ''}
                  </div>
                  <p className="text-[11px] text-rose-600 mt-0.5">Memerlukan keputusan perpanjangan periode atau exit clearance segera.</p>
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-amber-800 uppercase tracking-wide">
                    Expiring 31 - 60 Days
                  </div>
                  <div className="text-xl font-bold text-amber-950 mt-0.5">
                    {expiringWithin60Days.length} contract{expiringWithin60Days.length !== 1 ? 's' : ''}
                  </div>
                  <p className="text-[11px] text-amber-600 mt-0.5">Siapkan evaluasi kinerja appraisal bersama HOD.</p>
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-blue-800 uppercase tracking-wide">
                    Expiring 61 - 90 Days
                  </div>
                  <div className="text-xl font-bold text-blue-950 mt-0.5">
                    {expiringWithin90Days.length} contract{expiringWithin90Days.length !== 1 ? 's' : ''}
                  </div>
                  <p className="text-[11px] text-blue-600 mt-0.5">Terjadwal untuk evaluasi triwulanan Human Capital.</p>
                </div>
              </div>
            </div>
          )}

          {/* Filter and Search */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Cari nomor kontrak, nama, atau posisi..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700"
              />
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <select
                value={typeFilter}
                onChange={e => setTypeFilter(e.target.value)}
                className="text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-700 focus:outline-hidden"
              >
                <option value="ALL">Semua Tipe Kontrak</option>
                <option value="PKWT">PKWT (Kontrak Staff)</option>
                <option value="DAILY_WORKER">Daily Worker (SPK Harian Lepas)</option>
              </select>

              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                className="text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-700 focus:outline-hidden"
              >
                <option value="ALL">Semua Status Kontrak</option>
                <option value="ACTIVE">Aktif</option>
                <option value="EXPIRING_SOON">Segera Habis (Alert)</option>
                <option value="RENEWED">Renewed (Diperpanjang ke Periode Baru)</option>
                <option value="TERMINATED">Terminasi (Pengakhiran / PHK)</option>
                <option value="EXPIRED">Habis (Expired)</option>
              </select>
            </div>
          </div>

          {/* Contracts Table with Multi-Period Badge */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-3 px-4">Periode</th>
                    <th className="py-3 px-4">Nomor Kontrak</th>
                    <th className="py-3 px-4">Karyawan</th>
                    <th className="py-3 px-4">Tipe</th>
                    <th className="py-3 px-4">Masa Berlaku</th>
                    <th className="py-3 px-4">Sisa Hari</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Gaji Kompensasi</th>
                    <th className="py-3 px-4">Salinan TTD</th>
                    <th className="py-3 px-4 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredContracts.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-10 text-center text-slate-400 italic">
                        Tidak ada berkas kontrak yang ditemukan.
                      </td>
                    </tr>
                  ) : (
                    filteredContracts.map(c => {
                      const daysLeft = getDaysUntilExpiry(c.endDate);
                      const term = c.termNumber || c.version || 1;

                      return (
                        <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                          {/* Periode Badge */}
                          <td className="py-3 px-4">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${
                              term === 1
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : term === 2
                                  ? 'bg-blue-50 text-blue-800 border-blue-200'
                                  : 'bg-purple-50 text-purple-800 border-purple-200'
                            }`}>
                              Periode {term}
                            </span>
                          </td>

                          {/* Nomor Kontrak */}
                          <td className="py-3 px-4">
                            <div className="font-mono font-medium text-slate-900">{c.contractNumber}</div>
                            <span className="text-[10px] text-slate-400">v{c.version}</span>
                          </td>

                          {/* Karyawan */}
                          <td className="py-3 px-4">
                            <div className="font-medium text-slate-900">{c.employeeName}</div>
                            <div className="text-[10px] text-slate-500">{c.position} · {c.departmentId.replace('DEP-', '')}</div>
                          </td>

                          {/* Tipe */}
                          <td className="py-3 px-4">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${
                              c.employmentType === 'DAILY_WORKER'
                                ? 'bg-amber-50 text-amber-800 border-amber-300'
                                : 'bg-blue-50 text-blue-800 border-blue-200'
                            }`}>
                              {c.employmentType === 'DAILY_WORKER' ? 'SPK Daily Worker' : 'PKWT Kontrak'}
                            </span>
                          </td>

                          {/* Masa Berlaku */}
                          <td className="py-3 px-4 text-slate-600">
                            <div>{c.startDate} s/d</div>
                            <div className="font-medium text-slate-800">{c.endDate || '-'}</div>
                          </td>

                          {/* Sisa Hari */}
                          <td className="py-3 px-4">
                            {c.status === 'TERMINATED' ? (
                              <span className="text-rose-600 font-semibold text-[11px]">
                                Diterminasi ({c.terminationDetails?.effectiveDate || 'Selesai'})
                              </span>
                            ) : c.endDate ? (
                              daysLeft !== null && daysLeft <= 30 ? (
                                <span className="text-rose-700 font-bold bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                                  {daysLeft} hari lagi
                                </span>
                              ) : (
                                <span className="text-slate-600 font-medium">
                                  {daysLeft} hari
                                </span>
                              )
                            ) : (
                              <span className="text-slate-400 italic">No expiry</span>
                            )}
                          </td>

                          {/* Status */}
                          <td className="py-3 px-4">
                            {c.status === 'TERMINATED' ? (
                              <span className="inline-flex flex-col gap-0.5">
                                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                                  TERMINATED
                                </span>
                              </span>
                            ) : (
                              <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium border ${
                                c.status === 'EXPIRING_SOON' 
                                  ? 'bg-rose-50 text-rose-700 border-rose-200'
                                  : c.status === 'ACTIVE'
                                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                    : c.status === 'RENEWED'
                                      ? 'bg-slate-100 text-slate-600 border-slate-200'
                                      : 'bg-amber-50 text-amber-700 border-amber-200'
                              }`}>
                                 {c.status.replace('_', ' ')}
                              </span>
                            )}
                          </td>

                          {/* Gaji Kompensasi */}
                          <td className="py-3 px-4">
                            {c.compensationStatus === 'DITERIMA' ? (
                              <div className="space-y-0.5">
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-300">
                                  <FileCheck2 className="w-3 h-3 text-emerald-600" />
                                  Diterima
                                </span>
                                {c.compensationAmount ? (
                                  <span className="block text-[10px] font-mono font-semibold text-emerald-950">
                                    Rp {c.compensationAmount.toLocaleString('id-ID')}
                                  </span>
                                ) : null}
                              </div>
                            ) : c.employmentType === 'DAILY_WORKER' ? (
                              <span className="text-[10px] text-slate-400 italic">N/A (DW)</span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-amber-50 text-amber-800 border border-amber-300">
                                <Clock className="w-3 h-3 text-amber-600" />
                                Belum
                              </span>
                            )}
                          </td>

                          {/* Salinan TTD */}
                          <td className="py-3 px-4">
                            {c.signedContractFileName ? (
                              <div className="space-y-1">
                                <div className="flex items-center gap-1.5 text-emerald-800 bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-200">
                                  <FileCheck2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                                  <span className="font-semibold truncate max-w-[140px] text-[11px]" title={c.signedContractFileName}>
                                    {c.signedContractFileName}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2 text-[10px]">
                                  {c.signedContractFileUrl && (
                                    <a
                                      href={c.signedContractFileUrl}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="text-emerald-700 hover:text-emerald-900 hover:underline font-bold"
                                    >
                                      Preview TTD
                                    </a>
                                  )}
                                  {(currentUser.role === 'HC' || currentUser.role === 'ADMIN') && (
                                    <button
                                      onClick={() => setSelectedContractForSignedUpload(c)}
                                      className="text-slate-500 hover:text-slate-800 underline"
                                    >
                                      Ganti Berkas
                                    </button>
                                  )}
                                </div>
                              </div>
                            ) : (
                              (currentUser.role === 'HC' || currentUser.role === 'ADMIN') ? (
                                <button
                                  onClick={() => setSelectedContractForSignedUpload(c)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-300 transition-colors shadow-2xs"
                                  title="Upload copy berkas kontrak bertandatangan"
                                >
                                  <Upload className="w-3 h-3 text-emerald-700" />
                                  + Lampirkan TTD
                                </button>
                              ) : (
                                <span className="text-slate-400 italic text-[11px]">Belum Dilampirkan</span>
                              )
                            )}
                          </td>

                          {/* Aksi */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5 flex-wrap">
                              {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && 
                               c.status !== 'RENEWED' && c.status !== 'TERMINATED' && (
                                <>
                                  <button
                                    onClick={() => setSelectedContractForRenewal(c)}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-md transition-colors border border-emerald-200"
                                    title={`Perpanjang ke Periode ${term + 1}`}
                                  >
                                    <RefreshCw className="w-3 h-3" />
                                    <span>Renew (P{term + 1})</span>
                                  </button>
                                  <button
                                    onClick={() => setSelectedContractForTermination(c)}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md transition-colors border border-rose-200"
                                    title="Terminasi / Akhiri kontrak kerja"
                                  >
                                    <UserX className="w-3 h-3" />
                                    Terminasi
                                  </button>
                                </>
                              )}

                              {c.status === 'TERMINATED' && (
                                <button
                                  onClick={() => setViewTerminationContract(c)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors border border-slate-200"
                                  title="Lihat detail terminasi kontrak"
                                >
                                  <Info className="w-3 h-3 text-rose-600" />
                                  Detail Terminasi
                                </button>
                              )}

                              {/* Hapus Data Ini */}
                              {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && (
                                <button
                                  onClick={() => setContractToDelete(c)}
                                  className="inline-flex items-center gap-1 px-2 py-1 text-xs font-semibold text-rose-700 bg-rose-50/70 hover:bg-rose-100 rounded-md transition-colors border border-rose-200"
                                  title="Hapus data kontrak ini dari sistem"
                                >
                                  <Trash2 className="w-3 h-3 text-rose-600" />
                                  <span>Hapus</span>
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Add Contract Modal (Initial or Subsequent Period) */}
      <AddContractModal
        isOpen={isAddContractModalOpen}
        onClose={() => {
          setIsAddContractModalOpen(false);
          setInitialEmployeeForAdd(undefined);
        }}
        initialEmployeeId={initialEmployeeForAdd}
      />

      {/* Renewal Modal */}
      <ContractRenewalModal
        contract={selectedContractForRenewal}
        onClose={() => setSelectedContractForRenewal(null)}
      />

      {/* Termination Modal */}
      <ContractTerminationModal
        contract={selectedContractForTermination}
        onClose={() => setSelectedContractForTermination(null)}
      />

      {/* View Termination Details Modal */}
      {viewTerminationContract && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
                  <UserX className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-900">Catatan Terminasi Kontrak</h4>
                  <p className="text-[11px] text-slate-500 font-mono">{viewTerminationContract.contractNumber}</p>
                </div>
              </div>
              <button 
                onClick={() => setViewTerminationContract(null)}
                className="p-1 rounded-md text-slate-400 hover:text-slate-600"
              >
                &times;
              </button>
            </div>

            <div className="space-y-3">
              <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Karyawan:</span>
                  <span className="font-bold text-slate-800">{viewTerminationContract.employeeName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Tanggal Efektif Pengakhiran:</span>
                  <span className="font-bold text-rose-700">
                    {viewTerminationContract.terminationDetails?.effectiveDate || 'N/A'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Alasan Terminasi:</span>
                  <span className="font-semibold text-slate-800">
                    {viewTerminationContract.terminationDetails?.reasonLabel || viewTerminationContract.terminationDetails?.reason || 'Terminated'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Didaftarkan Oleh:</span>
                  <span className="text-slate-700">{viewTerminationContract.terminationDetails?.terminatedBy || 'Human Capital'}</span>
                </div>
              </div>

              {viewTerminationContract.terminationDetails?.severanceNotes && (
                <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-xl">
                  <span className="font-bold text-emerald-950 block mb-1">Kompensasi PKWT / Hak Finansial:</span>
                  <p className="text-emerald-900 text-[11px] whitespace-pre-line leading-relaxed">
                    {viewTerminationContract.terminationDetails.severanceNotes}
                  </p>
                </div>
              )}

              {viewTerminationContract.terminationDetails?.notes && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                  <span className="font-bold text-slate-800 block mb-1">Catatan Exit Clearance / Handover:</span>
                  <p className="text-slate-600 text-[11px] whitespace-pre-line leading-relaxed">
                    {viewTerminationContract.terminationDetails.notes}
                  </p>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setViewTerminationContract(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-white font-medium hover:bg-slate-900"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Signed Contract Upload Modal */}
      <SignedContractUploadModal
        contract={selectedContractForSignedUpload}
        onClose={() => setSelectedContractForSignedUpload(null)}
      />

      {/* Modal Konfirmasi Hapus Data Kontrak */}
      {contractToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 text-xs animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 border-b border-slate-200 pb-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-900">Konfirmasi Hapus Data Kontrak</h4>
                <p className="text-[11px] text-slate-500">Tindakan ini akan menghapus data kontrak dari sistem</p>
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl space-y-2 border border-slate-200">
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Karyawan:</span>
                <span className="font-bold text-slate-900">{contractToDelete.employeeName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Nomor Kontrak:</span>
                <span className="font-mono font-semibold text-slate-800">{contractToDelete.contractNumber}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Periode & Tipe:</span>
                <span className="font-semibold text-slate-800">
                  Periode {contractToDelete.termNumber || contractToDelete.version || 1} · {contractToDelete.employmentType}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Masa Berlaku:</span>
                <span className="font-mono text-slate-700">{contractToDelete.startDate} s/d {contractToDelete.endDate || '-'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Gaji Kompensasi:</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  contractToDelete.compensationStatus === 'DITERIMA' 
                    ? 'bg-emerald-100 text-emerald-800' 
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {contractToDelete.compensationStatus === 'DITERIMA' ? 'Diterima' : 'Belum'}
                </span>
              </div>
            </div>

            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-rose-900">
              <AlertTriangle className="w-4 h-4 text-rose-600 mt-0.5 shrink-0" />
              <p className="text-[11px] leading-relaxed">
                Apakah Anda yakin ingin <strong>menghapus data ini</strong>? Berkas kontrak dan riwayat terkait kontrak ini akan dihapus dari basis data GMCC.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setContractToDelete(null)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteContract(contractToDelete.id);
                  setDeleteToast(`Data kontrak ${contractToDelete.contractNumber} (${contractToDelete.employeeName}) berhasil dihapus.`);
                  setTimeout(() => setDeleteToast(null), 3500);
                  setContractToDelete(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold transition-colors shadow-2xs flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Ya, Hapus Data Ini</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {deleteToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2 duration-200 text-xs font-medium">
          <Trash2 className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{deleteToast}</span>
          <button onClick={() => setDeleteToast(null)} className="text-slate-400 hover:text-white ml-2">✕</button>
        </div>
      )}
    </div>
  );
};
