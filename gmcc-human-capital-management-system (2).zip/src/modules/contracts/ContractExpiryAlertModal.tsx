import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { EmploymentContract } from '../../types';
import { 
  AlertTriangle, 
  Clock, 
  X, 
  ChevronRight, 
  FileCheck2, 
  ArrowRight,
  ShieldAlert,
  BellRing
} from 'lucide-react';

interface Props {
  onNavigateToContracts: () => void;
}

export const ContractExpiryAlertModal: React.FC<Props> = ({ onNavigateToContracts }) => {
  const { currentUser, contracts, employees, getDaysUntilExpiry } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [hasDismissed, setHasDismissed] = useState(false);

  // Check if current user is eligible for expiry alert popups (DEPT_HEAD, HC, GM)
  const isEligibleRole = 
    currentUser.role === 'DEPT_HEAD' || 
    currentUser.role === 'HC' || 
    currentUser.role === 'GM';

  // Contracts relevant to current user
  const relevantContracts = contracts.filter(c => {
    if (c.status !== 'ACTIVE' && c.status !== 'EXPIRING_SOON') return false;
    if (!c.endDate) return false;

    if (currentUser.role === 'DEPT_HEAD') {
      const emp = employees.find(e => e.id === c.employeeId);
      return emp?.departmentId === currentUser.departmentId;
    }
    return true; // HC and GM see company-wide
  });

  // Contracts expiring in <= 30 days (1 month threshold)
  const expiring1Month = relevantContracts.filter(c => {
    const days = getDaysUntilExpiry(c.endDate);
    return days !== null && days >= 0 && days <= 30;
  });

  // Contracts expiring in 31 - 60 days (2 months threshold)
  const expiring2Months = relevantContracts.filter(c => {
    const days = getDaysUntilExpiry(c.endDate);
    return days !== null && days > 30 && days <= 60;
  });

  const totalAlertContracts = expiring1Month.length + expiring2Months.length;

  // Automatically trigger pop up when role switches to eligible role and has expiring contracts
  useEffect(() => {
    setHasDismissed(false);
    if (isEligibleRole && totalAlertContracts > 0) {
      setIsOpen(true);
    } else {
      setIsOpen(false);
    }
  }, [currentUser.id, currentUser.role, totalAlertContracts]);

  if (!isOpen || !isEligibleRole || totalAlertContracts === 0) {
    return null;
  }

  const handleReviewClick = () => {
    setIsOpen(false);
    onNavigateToContracts();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col border border-slate-200">
        {/* Header with High-Priority Badge */}
        <div className="bg-gradient-to-r from-slate-900 to-rose-950 text-white p-5 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-rose-600/30 border border-rose-500/50 flex items-center justify-center text-rose-400 shrink-0">
              <BellRing className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 uppercase tracking-wider mb-1">
                Official Contract Expiry Notice
              </div>
              <h3 className="font-bold text-white text-base sm:text-lg">
                Upcoming Contract Expirations ({totalAlertContracts})
              </h3>
              <p className="text-xs text-slate-300 mt-0.5">
                Notice for <strong>{currentUser.name}</strong> ({currentUser.role})
              </p>
            </div>
          </div>

          <button 
            onClick={() => setIsOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notice Explanation */}
        <div className="p-4 bg-amber-50 border-b border-amber-200 text-xs text-amber-950 flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <strong>Mandatory HR Policy Thresholds (1 & 2 Months):</strong> 
            Under GMCC Human Capital regulations, employment contracts expiring within 1 month (≤ 30 days) or 2 months (31-60 days) require department appraisal, renewal preparation, or transition planning to ensure operational continuity.
          </div>
        </div>

        {/* Scrollable list of expiring contracts */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-4 flex-1">
          {/* Section 1: 1 Month Alert (Urgent <= 30 Days) */}
          {expiring1Month.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-900 uppercase tracking-wide flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping"></span>
                  🚨 1 Month Alert (Expiring ≤ 30 Days) — Immediate Action
                </span>
                <span className="text-[11px] font-semibold text-rose-700 bg-rose-100 px-2 py-0.5 rounded">
                  {expiring1Month.length} Contract{expiring1Month.length !== 1 ? 's' : ''}
                </span>
              </div>

              <div className="divide-y divide-slate-100 border border-rose-200 rounded-xl overflow-hidden bg-rose-50/30">
                {expiring1Month.map(c => {
                  const daysLeft = getDaysUntilExpiry(c.endDate);
                  return (
                    <div key={c.id} className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 text-xs">{c.employeeName}</span>
                          <span className="text-[10px] font-mono bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded border border-rose-200">
                            {c.employmentType}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {c.position} · {c.departmentId.replace('DEP-', '')}
                        </p>
                        <span className="text-[10px] text-slate-400 font-mono block mt-1">
                          Ref: {c.contractNumber} (v{c.version})
                        </span>
                      </div>

                      <div className="text-left sm:text-right shrink-0">
                        <span className="text-xs font-bold text-rose-700 bg-rose-100 px-2.5 py-1 rounded-md border border-rose-300 inline-block">
                          {daysLeft} Days Remaining
                        </span>
                        <div className="text-[10px] text-slate-500 mt-1">
                          Ends on: {new Date(c.endDate).toLocaleDateString('en-GB')}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Section 2: 2 Months Alert (31 - 60 Days) */}
          {expiring2Months.length > 0 && (
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-900 uppercase tracking-wide flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-600" />
                  ⚠️ 2 Months Alert (Expiring 31 - 60 Days) — Department Review
                </span>
                <span className="text-[11px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
                  {expiring2Months.length} Contract{expiring2Months.length !== 1 ? 's' : ''}
                </span>
              </div>

              <div className="divide-y divide-slate-100 border border-amber-200 rounded-xl overflow-hidden bg-amber-50/30">
                {expiring2Months.map(c => {
                  const daysLeft = getDaysUntilExpiry(c.endDate);
                  return (
                    <div key={c.id} className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 text-xs">{c.employeeName}</span>
                          <span className="text-[10px] font-mono bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded border border-blue-200">
                            {c.employmentType}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {c.position} · {c.departmentId.replace('DEP-', '')}
                        </p>
                        <span className="text-[10px] text-slate-400 font-mono block mt-1">
                          Ref: {c.contractNumber} (v{c.version})
                        </span>
                      </div>

                      <div className="text-left sm:text-right shrink-0">
                        <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2.5 py-1 rounded-md border border-amber-300 inline-block">
                          {daysLeft} Days Remaining
                        </span>
                        <div className="text-[10px] text-slate-500 mt-1">
                          Ends on: {new Date(c.endDate).toLocaleDateString('en-GB')}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={() => setIsOpen(false)}
            className="w-full sm:w-auto px-4 py-2.5 text-xs font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-200 rounded-xl transition-colors order-2 sm:order-1"
          >
            Acknowledge & Close
          </button>

          <button
            onClick={handleReviewClick}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-xs transition-colors order-1 sm:order-2"
          >
            <FileCheck2 className="w-4 h-4" />
            Review Contracts in Detail
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
