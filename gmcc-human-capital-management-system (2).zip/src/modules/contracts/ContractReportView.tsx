import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { EmploymentContract, Employee } from '../../types';
import { 
  FileCheck2, 
  Search, 
  Filter, 
  Download, 
  Printer, 
  Plus, 
  RefreshCw, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  FileText, 
  Upload, 
  ChevronRight,
  UserCheck,
  Calendar,
  Layers,
  History,
  Building2,
  ExternalLink,
  Trash2,
  Coins
} from 'lucide-react';
import { ContractReportPrintModal } from './ContractReportPrintModal';

interface Props {
  onOpenAddContractModal: (employeeId?: string) => void;
  onOpenRenewalModal: (contract: EmploymentContract) => void;
  onOpenSignedUploadModal: (contract: EmploymentContract) => void;
  onViewTermination: (contract: EmploymentContract) => void;
}

export const ContractReportView: React.FC<Props> = ({
  onOpenAddContractModal,
  onOpenRenewalModal,
  onOpenSignedUploadModal,
  onViewTermination
}) => {
  const { contracts, employees, departments, currentUser, getDaysUntilExpiry, deleteContract } = useApp();

  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [periodFilter, setPeriodFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [contractToDelete, setContractToDelete] = useState<EmploymentContract | null>(null);
  const [deleteToast, setDeleteToast] = useState<string | null>(null);

  // Group all contracts by employee
  const groupedData: {
    employee: Employee;
    contracts: EmploymentContract[];
    activeContract?: EmploymentContract;
    latestContract?: EmploymentContract;
    totalPeriods: number;
    totalMonthsWorked: number;
  }[] = [];

  // Scoped contracts based on role
  const visibleContracts = contracts.filter(c => {
    if (currentUser.role === 'STAFF') {
      return c.employeeId === currentUser.employeeId;
    }
    if (currentUser.role === 'DEPT_HEAD') {
      const emp = employees.find(e => e.id === c.employeeId);
      return emp?.departmentId === currentUser.departmentId;
    }
    return true;
  });

  // Unique employees from visible contracts
  const employeeIdsWithContracts = Array.from(new Set(visibleContracts.map(c => c.employeeId)));

  employeeIdsWithContracts.forEach(empId => {
    const emp = employees.find(e => e.id === empId);
    if (!emp) return;

    const empContractsList = visibleContracts
      .filter(c => c.employeeId === empId)
      .sort((a, b) => (a.termNumber || a.version || 1) - (b.termNumber || b.version || 1));

    const activeContract = empContractsList.find(c => c.status === 'ACTIVE' || c.status === 'EXPIRING_SOON');
    const latestContract = empContractsList[empContractsList.length - 1];

    // Compute approximate months across all periods
    let totalDays = 0;
    empContractsList.forEach(c => {
      if (c.startDate && c.endDate) {
        const d1 = new Date(c.startDate).getTime();
        const d2 = new Date(c.endDate).getTime();
        if (d2 > d1) {
          totalDays += Math.ceil((d2 - d1) / (1000 * 60 * 60 * 24));
        }
      }
    });
    const totalMonthsWorked = Math.round(totalDays / 30.4375);

    groupedData.push({
      employee: emp,
      contracts: empContractsList,
      activeContract,
      latestContract,
      totalPeriods: empContractsList.length,
      totalMonthsWorked
    });
  });

  // Filter grouped data
  const filteredGroupedData = groupedData.filter(item => {
    const emp = item.employee;

    // Dept filter
    if (deptFilter !== 'ALL' && emp.departmentId !== deptFilter) return false;

    // Type filter
    if (typeFilter !== 'ALL') {
      const hasType = item.contracts.some(c => c.employmentType === typeFilter);
      if (!hasType) return false;
    }

    // Period filter
    if (periodFilter !== 'ALL') {
      const currentPeriod = item.activeContract?.termNumber || item.latestContract?.termNumber || 1;
      if (periodFilter === 'P1' && currentPeriod !== 1) return false;
      if (periodFilter === 'P2' && currentPeriod !== 2) return false;
      if (periodFilter === 'P3_PLUS' && currentPeriod < 3) return false;
    }

    // Status filter
    if (statusFilter !== 'ALL') {
      if (statusFilter === 'ACTIVE' && !item.activeContract) return false;
      if (statusFilter === 'EXPIRING_SOON' && item.activeContract?.status !== 'EXPIRING_SOON') return false;
      if (statusFilter === 'EXPIRED') {
        if (item.activeContract) return false;
        if (item.latestContract?.status !== 'EXPIRED' && item.latestContract?.status !== 'RENEWED') return false;
      }
      if (statusFilter === 'TERMINATED' && item.latestContract?.status !== 'TERMINATED') return false;
    }

    // Search query
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchName = emp.fullName.toLowerCase().includes(q);
      const matchNik = (emp.employeeNumber || emp.id).toLowerCase().includes(q);
      const matchContracts = item.contracts.some(c => c.contractNumber.toLowerCase().includes(q));
      const matchJob = (emp.jobTitle || '').toLowerCase().includes(q);
      if (!matchName && !matchNik && !matchContracts && !matchJob) return false;
    }

    return true;
  });

  // Metrics for overview cards
  const totalEmployeesWithContracts = groupedData.length;
  const countInPeriod1 = groupedData.filter(i => (i.activeContract?.termNumber || i.latestContract?.termNumber || 1) === 1).length;
  const countInPeriod2 = groupedData.filter(i => (i.activeContract?.termNumber || i.latestContract?.termNumber || 1) === 2).length;
  const countInPeriod3Plus = groupedData.filter(i => (i.activeContract?.termNumber || i.latestContract?.termNumber || 1) >= 3).length;
  const countExpiredWithoutRenewal = groupedData.filter(i => !i.activeContract && i.latestContract?.status !== 'TERMINATED').length;

  const handleExportCSV = () => {
    const headers = [
      'No',
      'NIK',
      'Nama Karyawan',
      'Departemen',
      'Jabatan',
      'Tipe Kontrak',
      'Total Periode',
      'Periode Berjalan',
      'Akumulasi Masa Kerja (Bulan)',
      'Status Kontrak Saat Ini',
      'Runtutan Riwayat Kontrak'
    ];

    const rows = filteredGroupedData.map((item, idx) => {
      const emp = item.employee;
      const dept = departments.find(d => d.id === emp.departmentId)?.name || emp.departmentId;
      const historyStr = item.contracts
        .map(c => `[Periode ${c.termNumber || c.version || 1}: ${c.contractNumber} (${c.startDate} s/d ${c.endDate || '-'}) - Status: ${c.status}]`)
        .join('; ');

      return [
        idx + 1,
        `"${emp.employeeNumber || emp.id}"`,
        `"${emp.fullName}"`,
        `"${dept}"`,
        `"${emp.jobTitle}"`,
        `"${emp.employmentType}"`,
        item.totalPeriods,
        item.activeContract ? `Periode ${item.activeContract.termNumber || 1}` : 'Kontrak Habis',
        item.totalMonthsWorked,
        item.activeContract ? item.activeContract.status : 'EXPIRED',
        `"${historyStr.replace(/"/g, '""')}"`
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Laporan_Rekap_Periode_Kontrak_GMCC_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Human Capital</span>
            <ChevronRight className="w-3 h-3" />
            <span>Rekapitulasi PKWT & Daily Worker</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Layers className="w-5 h-5 text-emerald-700" />
            Laporan Riwayat Periode Kontrak (Periode 1, 2, dst)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Monitoring berjenjang masa kerja kontrak karyawan: Periode 1 (Awal), Periode 2 (Perpanjangan ke-1), Periode 3, dan pengawasan kepatuhan batas perpanjangan.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-semibold shadow-2xs transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-emerald-700" />
            <span>Ekspor CSV</span>
          </button>
          <button
            onClick={() => setIsPrintModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-xs transition-colors"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-400" />
            <span>Cetak Rekap Resmi (A4)</span>
          </button>
          {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && (
            <button
              onClick={() => onOpenAddContractModal()}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-sm transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>+ Terbitkan Kontrak Baru</span>
            </button>
          )}
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
            Total Pegawai Kontrak
          </span>
          <div className="text-xl font-bold text-slate-900 mt-1">
            {totalEmployeesWithContracts} orang
          </div>
          <span className="text-[10px] text-slate-400 mt-0.5 block">PKWT & Daily Worker</span>
        </div>

        <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-3.5 shadow-2xs">
          <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">
            Periode 1 (Awal)
          </span>
          <div className="text-xl font-bold text-emerald-950 mt-1">
            {countInPeriod1} orang
          </div>
          <span className="text-[10px] text-emerald-700 mt-0.5 block">Kontrak masa kerja pertama</span>
        </div>

        <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-3.5 shadow-2xs">
          <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wider block">
            Periode 2 (Perpanjangan 1)
          </span>
          <div className="text-xl font-bold text-blue-950 mt-1">
            {countInPeriod2} orang
          </div>
          <span className="text-[10px] text-blue-700 mt-0.5 block">Perpanjangan kontrak pertama</span>
        </div>

        <div className="bg-purple-50/70 border border-purple-200 rounded-xl p-3.5 shadow-2xs">
          <span className="text-[10px] font-bold text-purple-800 uppercase tracking-wider block">
            Periode 3+ (Lanjutan)
          </span>
          <div className="text-xl font-bold text-purple-950 mt-1">
            {countInPeriod3Plus} orang
          </div>
          <span className="text-[10px] text-purple-700 mt-0.5 block">Evaluasi tetap (PKWTT)</span>
        </div>

        <div className="bg-rose-50/70 border border-rose-200 rounded-xl p-3.5 shadow-2xs col-span-2 sm:col-span-1">
          <span className="text-[10px] font-bold text-rose-800 uppercase tracking-wider block">
            Kontrak Habis (Perlu Baru)
          </span>
          <div className="text-xl font-bold text-rose-950 mt-1">
            {countExpiredWithoutRenewal} orang
          </div>
          <span className="text-[10px] text-rose-700 mt-0.5 block">Menunggu penerbitan periode</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-2xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Cari nama karyawan, NIK, atau nomor kontrak..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:border-emerald-700"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap w-full md:w-auto">
          {/* Departemen */}
          <select
            value={deptFilter}
            onChange={e => setDeptFilter(e.target.value)}
            className="text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-700 focus:outline-hidden"
          >
            <option value="ALL">Semua Departemen</option>
            {departments.map(d => (
              <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
            ))}
          </select>

          {/* Tipe */}
          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-700 focus:outline-hidden"
          >
            <option value="ALL">Semua Tipe Kontrak</option>
            <option value="PKWT">PKWT (Kontrak Staff)</option>
            <option value="DAILY_WORKER">Daily Worker (SPK Harian Lepas)</option>
          </select>

          {/* Periode */}
          <select
            value={periodFilter}
            onChange={e => setPeriodFilter(e.target.value)}
            className="text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-700 focus:outline-hidden font-semibold"
          >
            <option value="ALL">Semua Periode</option>
            <option value="P1">Periode 1 Saja (Awal)</option>
            <option value="P2">Periode 2 Saja (Perpanjangan ke-1)</option>
            <option value="P3_PLUS">Periode 3+ (Perpanjangan Lanjut)</option>
          </select>

          {/* Status */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-700 focus:outline-hidden"
          >
            <option value="ALL">Semua Status</option>
            <option value="ACTIVE">Aktif Berjalan</option>
            <option value="EXPIRING_SOON">Segera Habis (Alert ≤ 90 Hari)</option>
            <option value="EXPIRED">Kontrak Habis (Perlu Baru)</option>
            <option value="TERMINATED">Terminasi (Selesai/PHK)</option>
          </select>
        </div>
      </div>

      {/* Grouped Employee Cards with Sequential Contract Periods */}
      <div className="space-y-4">
        {filteredGroupedData.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="font-bold text-slate-800 text-sm">Tidak Ada Catatan Riwayat Kontrak</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Belum ada data kontrak yang sesuai dengan kriteria filter atau pencarian Anda. Gunakan tombol "+ Terbitkan Kontrak Baru" untuk mendaftarkan kontrak pegawai.
            </p>
            {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && (
              <button
                onClick={() => onOpenAddContractModal()}
                className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>+ Terbitkan Kontrak Baru Sekarang</span>
              </button>
            )}
          </div>
        ) : (
          filteredGroupedData.map((item, idx) => {
            const emp = item.employee;
            const dept = departments.find(d => d.id === emp.departmentId)?.name || emp.departmentId;
            const daysLeft = item.activeContract ? getDaysUntilExpiry(item.activeContract.endDate) : null;
            const nextTermNumber = (item.latestContract?.termNumber || item.latestContract?.version || 1) + 1;

            return (
              <div 
                key={emp.id} 
                className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden transition-all hover:border-slate-300"
              >
                {/* Employee Header Ribbon */}
                <div className="px-5 py-4 bg-slate-50 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-emerald-700 to-teal-500 text-white font-bold text-sm flex items-center justify-center shadow-xs shrink-0">
                      {emp.fullName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-slate-900 text-sm">{emp.fullName}</h3>
                        <span className="font-mono text-xs text-slate-500 font-semibold">
                          ({emp.employeeNumber || emp.id})
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                          emp.employmentType === 'DAILY_WORKER'
                            ? 'bg-amber-50 text-amber-800 border-amber-300'
                            : 'bg-blue-50 text-blue-800 border-blue-200'
                        }`}>
                          {emp.employmentType === 'DAILY_WORKER' ? 'Daily Worker' : 'PKWT Kontrak'}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-2 flex-wrap">
                        <span className="font-medium text-slate-700">{emp.jobTitle}</span>
                        <span>·</span>
                        <span>{dept}</span>
                        <span>·</span>
                        <span className="font-medium text-emerald-800">
                          Total Masa Kerja: ~{item.totalMonthsWorked} Bulan ({item.totalPeriods} Periode Kontrak)
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Status Badge */}
                    {item.activeContract ? (
                      <span className={`px-2.5 py-1 rounded-lg text-xs font-bold border flex items-center gap-1.5 ${
                        item.activeContract.status === 'EXPIRING_SOON'
                          ? 'bg-rose-50 text-rose-700 border-rose-300'
                          : 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      }`}>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Aktif di Periode {item.activeContract.termNumber || 1}</span>
                        {daysLeft !== null && (
                          <span className="font-mono text-[11px] font-normal opacity-80">
                            ({daysLeft} hari lagi)
                          </span>
                        )}
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-rose-50 text-rose-800 border border-rose-300 flex items-center gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                        <span>Kontrak Periode {item.latestContract?.termNumber || 1} Telah Habis</span>
                      </span>
                    )}

                    {/* Action Button: Add Next Contract Period */}
                    {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && (
                      <button
                        onClick={() => onOpenAddContractModal(emp.id)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-2xs transition-colors"
                        title="Terbitkan kontrak periode berikutnya untuk karyawan ini"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>+ Kontrak Periode {nextTermNumber}</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Table of Contract Periods for this Employee */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-white border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                      <tr>
                        <th className="py-2.5 px-4 w-28">Periode</th>
                        <th className="py-2.5 px-4">Nomor Kontrak</th>
                        <th className="py-2.5 px-4">Tipe</th>
                        <th className="py-2.5 px-4">Masa Berlaku</th>
                        <th className="py-2.5 px-4">Durasi</th>
                        <th className="py-2.5 px-4">Status Kontrak</th>
                        <th className="py-2.5 px-4">Gaji Kompensasi</th>
                        <th className="py-2.5 px-4">Salinan Berkas TTD</th>
                        <th className="py-2.5 px-4">Catatan & Dasar</th>
                        <th className="py-2.5 px-4 text-right">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {item.contracts.map(c => {
                        const cDays = getDaysUntilExpiry(c.endDate);
                        const term = c.termNumber || c.version || 1;

                        // Calculate months
                        let durationMonths = 12;
                        if (c.startDate && c.endDate) {
                          const d1 = new Date(c.startDate).getTime();
                          const d2 = new Date(c.endDate).getTime();
                          durationMonths = Math.max(1, Math.round((d2 - d1) / (1000 * 60 * 60 * 24 * 30.4375)));
                        }

                        return (
                          <tr key={c.id} className="hover:bg-slate-50/80 transition-colors">
                            {/* Periode Badge */}
                            <td className="py-3 px-4">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md font-bold text-xs border ${
                                term === 1
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                  : term === 2
                                    ? 'bg-blue-50 text-blue-800 border-blue-200'
                                    : 'bg-purple-50 text-purple-800 border-purple-200'
                              }`}>
                                Periode {term}
                              </span>
                            </td>

                            {/* Nomor Kontrak */}
                            <td className="py-3 px-4">
                              <div className="font-mono font-semibold text-slate-900">{c.contractNumber}</div>
                              <span className="text-[10px] text-slate-400">ID: {c.id}</span>
                            </td>

                            {/* Tipe */}
                            <td className="py-3 px-4">
                              <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                                c.employmentType === 'DAILY_WORKER'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}>
                                {c.employmentType === 'DAILY_WORKER' ? 'SPK DW' : 'PKWT'}
                              </span>
                            </td>

                            {/* Masa Berlaku */}
                            <td className="py-3 px-4 text-slate-700">
                              <div className="font-medium text-slate-800">
                                {c.startDate} s/d {c.endDate || '-'}
                              </div>
                            </td>

                            {/* Durasi */}
                            <td className="py-3 px-4 font-semibold text-slate-700">
                              {durationMonths} Bulan
                            </td>

                            {/* Status */}
                            <td className="py-3 px-4">
                              {c.status === 'TERMINATED' ? (
                                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                                  TERMINATED
                                </span>
                              ) : c.status === 'RENEWED' ? (
                                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-600 border border-slate-200" title="Kontrak selesai dan dilanjutkan ke periode berikutnya">
                                  RENEWED (Selesai)
                                </span>
                              ) : c.status === 'EXPIRING_SOON' ? (
                                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-300">
                                  EXPIRING ({cDays} hari)
                                </span>
                              ) : c.status === 'EXPIRED' ? (
                                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                                  HABIS (EXPIRED)
                                </span>
                              ) : (
                                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-300">
                                  AKTIF BERJALAN
                                </span>
                              )}
                            </td>

                            {/* Gaji Kompensasi */}
                            <td className="py-3 px-4">
                              {c.compensationStatus === 'DITERIMA' ? (
                                <div className="space-y-0.5">
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-300">
                                    <FileCheck2 className="w-3 h-3 text-emerald-600" />
                                    Diterima
                                  </span>
                                  {c.compensationAmount ? (
                                    <span className="block text-[9.5px] font-mono font-semibold text-emerald-950">
                                      Rp {c.compensationAmount.toLocaleString('id-ID')}
                                    </span>
                                  ) : null}
                                </div>
                              ) : c.employmentType === 'DAILY_WORKER' ? (
                                <span className="text-[10px] text-slate-400 italic">N/A (DW)</span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-amber-50 text-amber-800 border border-amber-300">
                                  <Clock className="w-3 h-3 text-amber-600" />
                                  Belum
                                </span>
                              )}
                            </td>

                            {/* Salinan TTD */}
                            <td className="py-3 px-4">
                              {c.signedContractFileName ? (
                                <div className="space-y-0.5">
                                  <div className="flex items-center gap-1 text-emerald-800 font-semibold text-[11px] truncate max-w-[140px]" title={c.signedContractFileName}>
                                    <FileCheck2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                    <span className="truncate">{c.signedContractFileName}</span>
                                  </div>
                                  {c.signedContractFileUrl && (
                                    <a
                                      href={c.signedContractFileUrl}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="text-[10px] text-emerald-700 hover:text-emerald-900 font-bold hover:underline flex items-center gap-0.5"
                                    >
                                      <span>Buka Berkas</span>
                                      <ExternalLink className="w-2.5 h-2.5" />
                                    </a>
                                  )}
                                </div>
                              ) : (
                                (currentUser.role === 'HC' || currentUser.role === 'ADMIN') ? (
                                  <button
                                    onClick={() => onOpenSignedUploadModal(c)}
                                    className="inline-flex items-center gap-1 text-[10px] font-semibold text-slate-500 hover:text-emerald-700 bg-slate-100 hover:bg-emerald-50 px-2 py-1 rounded border border-slate-200 transition-colors"
                                  >
                                    <Upload className="w-2.5 h-2.5 text-emerald-600" />
                                    <span>+ Lampirkan TTD</span>
                                  </button>
                                ) : (
                                  <span className="text-[10px] text-slate-400 italic">Belum Ada</span>
                                )
                              )}
                            </td>

                            {/* Catatan */}
                            <td className="py-3 px-4 text-slate-600 max-w-xs truncate text-[11px]">
                              {c.notes || '-'}
                            </td>

                            {/* Aksi Baris */}
                            <td className="py-3 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5 flex-wrap">
                                {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && 
                                 c.status !== 'RENEWED' && c.status !== 'TERMINATED' && (
                                  <button
                                    onClick={() => onOpenRenewalModal(c)}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-md border border-emerald-300 transition-colors"
                                    title="Perpanjang ke periode berikutnya"
                                  >
                                    <RefreshCw className="w-3 h-3 text-emerald-700" />
                                    <span>Perpanjang (Periode {term + 1})</span>
                                  </button>
                                )}

                                {c.status === 'TERMINATED' && (
                                  <button
                                    onClick={() => onViewTermination(c)}
                                    className="inline-flex items-center gap-1 px-2 py-1 text-[10px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md border border-slate-200 transition-colors"
                                  >
                                    Detail PHK
                                  </button>
                                )}

                                {/* Hapus Data Kontrak Ini */}
                                {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && (
                                  <button
                                    onClick={() => setContractToDelete(c)}
                                    className="inline-flex items-center gap-1 px-2 py-1 text-[10px] font-semibold text-rose-700 bg-rose-50/70 hover:bg-rose-100 rounded-md transition-colors border border-rose-200"
                                    title="Hapus data kontrak periode ini"
                                  >
                                    <Trash2 className="w-3 h-3 text-rose-600" />
                                    <span>Hapus</span>
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Printable Report Modal */}
      <ContractReportPrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        filteredContracts={visibleContracts}
        departments={departments}
        deptFilter={deptFilter}
        typeFilter={typeFilter}
      />

      {/* Modal Konfirmasi Hapus Data Kontrak */}
      {contractToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 text-xs animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 border-b border-slate-200 pb-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-900">Konfirmasi Hapus Data Kontrak</h4>
                <p className="text-[11px] text-slate-500">Tindakan ini akan menghapus data kontrak dari sistem</p>
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl space-y-2 border border-slate-200">
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Karyawan:</span>
                <span className="font-bold text-slate-900">{contractToDelete.employeeName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Nomor Kontrak:</span>
                <span className="font-mono font-semibold text-slate-800">{contractToDelete.contractNumber}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Periode:</span>
                <span className="font-semibold text-slate-800">
                  Periode {contractToDelete.termNumber || contractToDelete.version || 1} ({contractToDelete.employmentType})
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Masa Berlaku:</span>
                <span className="font-mono text-slate-700">{contractToDelete.startDate} s/d {contractToDelete.endDate || '-'}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Gaji Kompensasi:</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  contractToDelete.compensationStatus === 'DITERIMA' 
                    ? 'bg-emerald-100 text-emerald-800' 
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {contractToDelete.compensationStatus === 'DITERIMA' ? 'Diterima' : 'Belum'}
                </span>
              </div>
            </div>

            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-rose-900">
              <AlertTriangle className="w-4 h-4 text-rose-600 mt-0.5 shrink-0" />
              <p className="text-[11px] leading-relaxed">
                Apakah Anda yakin ingin <strong>menghapus data ini</strong>? Berkas dan riwayat terkait kontrak ini akan dihapus dari laporan dan database GMCC.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setContractToDelete(null)}
                className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteContract(contractToDelete.id);
                  setDeleteToast(`Data kontrak ${contractToDelete.contractNumber} (${contractToDelete.employeeName}) berhasil dihapus.`);
                  setTimeout(() => setDeleteToast(null), 3500);
                  setContractToDelete(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold transition-colors shadow-2xs flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Ya, Hapus Data Ini</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {deleteToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2 duration-200 text-xs font-medium">
          <Trash2 className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{deleteToast}</span>
          <button onClick={() => setDeleteToast(null)} className="text-slate-400 hover:text-white ml-2">✕</button>
        </div>
      )}
    </div>
  );
};
