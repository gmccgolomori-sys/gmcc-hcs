import React, { useState, useEffect } from 'react';
import { EmploymentContract } from '../../types';
import { useApp } from '../../context/AppContext';
import { X, RefreshCw, AlertCircle, CheckCircle2, Calendar, FileText, Sparkles, Coins } from 'lucide-react';

interface Props {
  contract: EmploymentContract | null;
  onClose: () => void;
}

export const ContractRenewalModal: React.FC<Props> = ({ contract, onClose }) => {
  const { renewContract, contracts } = useApp();

  const currentTerm = contract?.termNumber || contract?.version || 1;
  const nextTerm = currentTerm + 1;

  // Calculate default start date: day after contract end date if available, or today
  const computeInitialStartDate = () => {
    if (!contract?.endDate) {
      return new Date().toISOString().split('T')[0];
    }
    const end = new Date(contract.endDate);
    end.setDate(end.getDate() + 1);
    return end.toISOString().split('T')[0];
  };

  const computeEndDateFromDuration = (startDateStr: string, months: number) => {
    if (!startDateStr) return '';
    const date = new Date(startDateStr);
    date.setMonth(date.getMonth() + months);
    date.setDate(date.getDate() - 1);
    return date.toISOString().split('T')[0];
  };

  const [newStartDate, setNewStartDate] = useState('');
  const [newEndDate, setNewEndDate] = useState('');
  const [newContractNumber, setNewContractNumber] = useState('');
  const [selectedDurationMonths, setSelectedDurationMonths] = useState<number>(12);
  const [renewalNotes, setRenewalNotes] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  // Gaji / Uang Kompensasi PKWT untuk periode yang diperpanjang (PP 35/2021)
  const [compensationStatus, setCompensationStatus] = useState<'DITERIMA' | 'BELUM'>('BELUM');
  const [compensationAmount, setCompensationAmount] = useState<number | undefined>(undefined);
  const [compensationPaidDate, setCompensationPaidDate] = useState<string>('');
  const [compensationNotes, setCompensationNotes] = useState<string>('');

  useEffect(() => {
    if (contract) {
      const initialStart = computeInitialStartDate();
      setNewStartDate(initialStart);
      setNewEndDate(computeEndDateFromDuration(initialStart, 12));
      setSelectedDurationMonths(12);

      // Auto format new contract number: replace or append -P[nextTerm]
      const baseNum = contract.contractNumber.replace(/-P\d+$/i, '').replace(/-R\d+$/i, '');
      setNewContractNumber(`${baseNum}-P${nextTerm}`);
      setRenewalNotes(`Perpanjangan Kontrak PKWT Periode ${nextTerm} berdasarkan evaluasi kinerja memuaskan`);
    }
  }, [contract]);

  if (!contract) return null;

  const handleDurationSelect = (months: number) => {
    setSelectedDurationMonths(months);
    if (newStartDate) {
      setNewEndDate(computeEndDateFromDuration(newStartDate, months));
    }
  };

  const handleStartDateChange = (val: string) => {
    setNewStartDate(val);
    if (selectedDurationMonths && val) {
      setNewEndDate(computeEndDateFromDuration(val, selectedDurationMonths));
    }
  };

  // Find all historical contracts for this employee
  const employeeContracts = contracts
    .filter(c => c.employeeId === contract.employeeId)
    .sort((a, b) => (a.termNumber || a.version || 1) - (b.termNumber || b.version || 1));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStartDate || !newEndDate) return;

    renewContract(
      contract.id,
      newStartDate,
      newEndDate,
      renewalNotes || `Perpanjangan Kontrak Periode ${nextTerm} (${newStartDate} s/d ${newEndDate})`,
      newContractNumber,
      nextTerm,
      {
        compensationStatus,
        compensationAmount,
        compensationPaidDate: compensationPaidDate || undefined,
        compensationNotes: compensationNotes || undefined
      }
    );

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Perpanjang Kontrak Kerja</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Menerbitkan kontrak baru untuk <strong className="text-emerald-400">Periode {nextTerm}</strong>
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center flex flex-col items-center justify-center space-y-2">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-1">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-slate-900 text-base">Kontrak Periode {nextTerm} Berhasil Diterbitkan!</h4>
            <p className="text-xs text-slate-600 max-w-sm">
              Kontrak sebelumnya Periode {currentTerm} diarsipkan dengan status <strong>RENEWED</strong>. Kontrak baru kini aktif dan tercatat dalam laporan kontrak berjenjang.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            {/* Periode Banner */}
            <div className="p-3.5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">Status Periode Kontrak</span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-bold text-[11px]">
                    Periode {currentTerm} (Selesai/Habis)
                  </span>
                  <span className="text-emerald-700 font-bold">&rarr;</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-600 text-white font-bold text-[11px] shadow-2xs">
                    Periode Baru: Periode {nextTerm}
                  </span>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-900 bg-white/80 px-2 py-1 rounded border border-emerald-200">
                P{nextTerm}
              </span>
            </div>

            {/* Existing Contract Snapshot */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Karyawan:</span>
                <span className="font-bold text-slate-900">{contract.employeeName} ({contract.employeeId})</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Jabatan & Departemen:</span>
                <span className="text-slate-700 font-medium">{contract.position} · {contract.departmentId.replace('DEP-', '')}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Nomor Kontrak Berjalan:</span>
                <span className="font-mono text-slate-800 font-semibold">{contract.contractNumber}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Masa Berlaku Periode {currentTerm}:</span>
                <span className="text-slate-700 font-medium">
                  {contract.startDate} s/d <strong className="text-rose-700">{contract.endDate || '-'}</strong>
                </span>
              </div>
            </div>

            {/* Previous History Chain if multi-period */}
            {employeeContracts.length > 1 && (
              <div className="p-2.5 bg-slate-100/70 border border-slate-200 rounded-lg">
                <span className="text-[10px] font-bold text-slate-600 uppercase tracking-wide block mb-1">
                  Riwayat Kontrak Terdahulu:
                </span>
                <div className="space-y-1 max-h-24 overflow-y-auto pr-1">
                  {employeeContracts.map(c => (
                    <div key={c.id} className="flex items-center justify-between text-[11px] bg-white px-2 py-1 rounded border border-slate-200">
                      <span className="font-semibold text-slate-800">
                        Periode {c.termNumber || c.version || 1}
                      </span>
                      <span className="font-mono text-[10px] text-slate-500">{c.contractNumber}</span>
                      <span className="text-[10px] text-slate-600">{c.startDate} s/d {c.endDate}</span>
                      <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                        c.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {c.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* New Contract Number */}
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Nomor Kontrak Baru (Periode {nextTerm}) *
              </label>
              <div className="relative">
                <FileText className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={newContractNumber}
                  onChange={e => setNewContractNumber(e.target.value)}
                  placeholder="Misal: 012/GMCC-HC/PKWT/IV/2026-P2"
                  className="w-full text-xs rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-slate-900 font-mono font-semibold focus:outline-hidden focus:border-emerald-700"
                />
              </div>
            </div>

            {/* Duration Quick Buttons */}
            <div>
              <label className="block font-bold text-slate-800 mb-1.5">
                Pilih Durasi Kontrak Baru Periode {nextTerm}
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: '3 Bulan', months: 3 },
                  { label: '6 Bulan', months: 6 },
                  { label: '1 Tahun', months: 12 },
                  { label: '2 Tahun', months: 24 }
                ].map(item => (
                  <button
                    key={item.months}
                    type="button"
                    onClick={() => handleDurationSelect(item.months)}
                    className={`py-1.5 px-2 rounded-lg font-bold text-center border text-[11px] transition-all ${
                      selectedDurationMonths === item.months
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tanggal Mulai Baru *</label>
                <input
                  type="date"
                  required
                  value={newStartDate}
                  onChange={e => handleStartDateChange(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tanggal Berakhir Baru *</label>
                <input
                  type="date"
                  required
                  value={newEndDate}
                  onChange={e => {
                    setNewEndDate(e.target.value);
                    setSelectedDurationMonths(0);
                  }}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:border-emerald-700 font-bold text-emerald-900"
                />
              </div>
            </div>

            {/* Kolom Informasi Gaji Kompensasi PKWT (PP 35/2021) */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                  <Coins className="w-4 h-4 text-emerald-700" />
                  Informasi Gaji Kompensasi Periode {currentTerm} (PP 35/2021)
                </label>
                <span className="text-[10px] text-slate-500 font-medium">Kompensasi Akhir Masa PKWT</span>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <label className={`flex items-center gap-2.5 p-3 rounded-xl border cursor-pointer transition-all ${
                  compensationStatus === 'DITERIMA' 
                    ? 'border-emerald-500 bg-emerald-50/80 text-emerald-950 font-bold shadow-2xs' 
                    : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                }`}>
                  <input
                    type="radio"
                    name="renew_compensationStatus"
                    value="DITERIMA"
                    checked={compensationStatus === 'DITERIMA'}
                    onChange={() => setCompensationStatus('DITERIMA')}
                    className="w-4 h-4 text-emerald-600 focus:ring-emerald-500"
                  />
                  <div>
                    <span className="block text-xs font-bold text-slate-900">Diterima</span>
                    <span className="block text-[10px] text-emerald-700 font-normal">Sudah dibayarkan kepada staf</span>
                  </div>
                </label>

                <label className={`flex items-center gap-2.5 p-3 rounded-xl border cursor-pointer transition-all ${
                  compensationStatus === 'BELUM' 
                    ? 'border-amber-500 bg-amber-50/80 text-amber-950 font-bold shadow-2xs' 
                    : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                }`}>
                  <input
                    type="radio"
                    name="renew_compensationStatus"
                    value="BELUM"
                    checked={compensationStatus === 'BELUM'}
                    onChange={() => setCompensationStatus('BELUM')}
                    className="w-4 h-4 text-amber-600 focus:ring-amber-500"
                  />
                  <div>
                    <span className="block text-xs font-bold text-slate-900">Belum</span>
                    <span className="block text-[10px] text-amber-700 font-normal">Belum cair / proses pengajuan</span>
                  </div>
                </label>
              </div>

              {/* Rincian Tambahan jika Diterima */}
              {compensationStatus === 'DITERIMA' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200 animate-in fade-in duration-150">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Nominal Uang Kompensasi (Rp)
                    </label>
                    <input
                      type="number"
                      value={compensationAmount || ''}
                      onChange={e => setCompensationAmount(e.target.value ? Number(e.target.value) : undefined)}
                      placeholder="Contoh: 4500000"
                      className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Tanggal Pembayaran
                    </label>
                    <input
                      type="date"
                      value={compensationPaidDate}
                      onChange={e => setCompensationPaidDate(e.target.value)}
                      className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 font-mono"
                    />
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Dasar Perpanjangan & Catatan Ketentuan</label>
              <textarea
                rows={2}
                placeholder="Contoh: Berdasarkan hasil appraisal H2 2026 dan rekomendasi Head of Department..."
                value={renewalNotes}
                onChange={e => setRenewalNotes(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:border-emerald-700"
              />
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-amber-900">
              <AlertCircle className="w-4 h-4 text-amber-700 mt-0.5 shrink-0" />
              <div className="text-[11px] leading-relaxed">
                <strong>Kepatuhan Audit Ketenagakerjaan:</strong> Kontrak lama (Periode {currentTerm}) tetap tersimpan dalam riwayat dengan status <code>RENEWED</code>. Seluruh runtutan kontrak (Periode 1, Periode 2, dst) akan tercatat lengkap dalam <strong>Laporan Riwayat Kontrak</strong>.
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Terbitkan Kontrak Periode {nextTerm}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
