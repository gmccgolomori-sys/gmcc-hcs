import React, { useState, useRef } from 'react';
import { EmploymentContract } from '../../types';
import { useApp } from '../../context/AppContext';
import { 
  X, 
  Upload, 
  FileCheck, 
  FileText, 
  CheckCircle2, 
  AlertCircle,
  ShieldCheck,
  HardDrive
} from 'lucide-react';

interface Props {
  contract: EmploymentContract | null;
  onClose: () => void;
}

export const SignedContractUploadModal: React.FC<Props> = ({ contract, onClose }) => {
  const { attachSignedContract, currentUser } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!contract) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMsg('');
    setFileName(file.name);
    const sizeInKb = file.size / 1024;
    setFileSize(sizeInKb > 1024 ? `${(sizeInKb / 1024).toFixed(1)} MB` : `${Math.round(sizeInKb)} KB`);

    // Create browser object URL for preview
    const objectUrl = URL.createObjectURL(file);
    setFileUrl(objectUrl);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fileName) {
      setErrorMsg('Silakan pilih berkas / file copy kontrak yang sudah ditandatangani terlebih dahulu.');
      return;
    }

    attachSignedContract(contract.id, {
      fileName,
      fileUrl: fileUrl || 'https://images.unsplash.com/photo-1450133064473-71024230f91b?w=600&auto=format&fit=crop&q=80',
      notes: notes || `Lampiran salinan fisik kontrak resmi bertanda tangan (${contract.contractNumber}).`
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between rounded-t-2xl">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <FileCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm tracking-tight text-white">
                Upload Salinan Kontrak Bertanda Tangan (Signed Copy)
              </h3>
              <p className="text-[11px] text-slate-400">
                Penyimpanan Otomatis Google Drive · Folder 03 Personal Files
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center flex flex-col items-center justify-center space-y-2">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-2">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-slate-900 text-base">Salinan Kontrak Berhasil Dilampirkan!</h4>
            <p className="text-xs text-slate-500 max-w-sm">
              Berkas telah tersinkronisasi ke data kontrak kerja dan secara otomatis diarsipkan pada Google Drive Personal File (Folder 03 Employment & Contracts).
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            {/* Contract Target Info Box */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Nomor Kontrak:</span>
                <span className="font-mono font-bold text-slate-900">{contract.contractNumber}</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Nama Karyawan:</span>
                <span className="font-bold text-slate-900">{contract.employeeName}</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Jabatan & Departemen:</span>
                <span className="font-semibold text-slate-700">{contract.position} · {contract.departmentId}</span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Periode Kontrak:</span>
                <span className="font-mono text-slate-700">
                  {new Date(contract.startDate).toLocaleDateString('id-ID')} s/d {contract.endDate ? new Date(contract.endDate).toLocaleDateString('id-ID') : '-'}
                </span>
              </div>
            </div>

            {/* Error Message */}
            {errorMsg && (
              <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* File Chooser Area */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-800">
                Pilih Berkas Salinan Kontrak (Signed PDF / Scan) <span className="text-rose-500">*WAJIB PILIH FILE</span>
              </label>

              {fileName ? (
                <div className="flex items-center justify-between p-3.5 bg-emerald-50/70 border border-emerald-300 rounded-xl">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <FileCheck className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate text-xs">
                        {fileName}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {fileSize} · Siap Diunggah & Dilampirkan
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-[11px] text-emerald-800 hover:text-emerald-900 font-bold px-2.5 py-1 bg-white rounded-lg border border-emerald-300 shadow-2xs shrink-0"
                  >
                    Ganti File
                  </button>
                </div>
              ) : (
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-300 hover:border-emerald-600 rounded-xl p-6 text-center cursor-pointer transition-all bg-slate-50 hover:bg-emerald-50/30 flex flex-col items-center justify-center space-y-2 group"
                >
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center group-hover:scale-105 transition-transform">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-800 block text-xs">
                      Klik di sini untuk Choose File dari Komputer Anda
                    </span>
                    <span className="text-[11px] text-slate-500 mt-0.5 block">
                      Mendukung format PDF (Disarankan), JPG, PNG (Scan TTD Basah / e-Meterai)
                    </span>
                  </div>
                </div>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>

            {/* Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Catatan Penandatanganan Kontrak (Opsional)
              </label>
              <textarea
                rows={2}
                placeholder="misal: Telah ditandatangani oleh General Manager dan Karyawan, bermeterai Rp 10.000..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:border-emerald-700"
              />
            </div>

            {/* Automatic Drive Archival Notice */}
            <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-blue-950 flex items-start gap-2">
              <HardDrive className="w-4 h-4 text-blue-700 mt-0.5 shrink-0" />
              <div className="text-[11px] leading-relaxed">
                <span className="font-bold block">Integrasi Google Drive Otomatis:</span>
                File yang diunggah akan otomatis terhubung ke kontrak nomor <strong>{contract.contractNumber}</strong> dan tersimpan di <em>Folder 03 Employment & Contracts</em> staf bersangkutan.
              </div>
            </div>

            {/* Buttons */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm transition-colors"
              >
                <FileCheck className="w-4 h-4" />
                Simpan & Lampirkan Kontrak TTD
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
