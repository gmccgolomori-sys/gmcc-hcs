import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Users, 
  FolderLock, 
  Calendar, 
  GraduationCap, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  ArrowRight, 
  HardDrive, 
  FileCode,
  ShieldCheck,
  Building2,
  Bell,
  FileSpreadsheet
} from 'lucide-react';

interface Props {
  onNavigate: (module: string, empId?: string) => void;
}

export const OverviewDashboard: React.FC<Props> = ({ onNavigate }) => {
  const { 
    currentUser, 
    employees, 
    contracts, 
    leaveApplications, 
    trainingPlans, 
    auditLogs, 
    departments,
    getDaysUntilExpiry,
    getLeaveBalanceSummary
  } = useApp();

  const userLeave = getLeaveBalanceSummary(currentUser.employeeId || '', 'ANNUAL_LEAVE');

  const isDeptHead = currentUser.role === 'DEPT_HEAD';
  const myDeptId = currentUser.departmentId;
  const currentDept = departments.find(d => d.id === myDeptId);

  // Scoped active employees: Dept Head only sees staff in their department
  const scopedEmployees = isDeptHead
    ? employees.filter(e => e.departmentId === myDeptId)
    : employees;

  // Scoped contracts: Dept Head only sees contracts in their department
  const scopedContracts = isDeptHead
    ? contracts.filter(c => {
        const emp = employees.find(e => e.id === c.employeeId);
        return emp?.departmentId === myDeptId || c.departmentId === myDeptId;
      })
    : contracts;

  // Contracts expiring <= 30 days scoped
  const urgentContracts = scopedContracts.filter(c => {
    if (c.status !== 'ACTIVE' && c.status !== 'EXPIRING_SOON') return false;
    const days = getDaysUntilExpiry(c.endDate);
    return days !== null && days >= 0 && days <= 30;
  });

  // Pending leaves scoped
  const pendingLeaves = leaveApplications.filter(a => {
    const isPending = ['PENDING_DEPT_HEAD', 'PENDING_HC', 'PENDING_GM'].includes(a.status);
    if (!isPending) return false;
    if (isDeptHead) {
      return a.departmentId === myDeptId || employees.find(e => e.id === a.employeeId)?.departmentId === myDeptId;
    }
    return true;
  });

  // Scoped training plans
  const scopedTrainingPlans = isDeptHead
    ? trainingPlans.filter(p => p.departmentId === myDeptId || p.trainingScope === 'GENERIC_ALL_STAFF')
    : trainingPlans;

  return (
    <div className="space-y-6">
      {/* Executive Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-6 shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 mb-3">
            <Building2 className="w-3.5 h-3.5" />
            Golo Mori Convention Center · Labuan Bajo, NTT
          </div>
          <h1 className="text-2xl font-bold tracking-tight">
            Welcome, {currentUser.name}
          </h1>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            {isDeptHead 
              ? `Dashboard Pemantauan Khusus Departemen ${currentDept?.name || myDeptId}: Menampilkan data dan staf tim Anda.`
              : 'GMCC Human Capital Management System: Personal Files, Employment Contracts, 4-Stage Leave Workflow, and Training Programs.'}
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-4 text-xs">
            <span className="text-slate-400">Current Role:</span>
            <span className="font-semibold text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-700/60">
              {currentUser.role} {isDeptHead ? `(${currentDept?.name || myDeptId})` : ''}
            </span>
            <span className="text-slate-400">·</span>
            <span className="text-slate-300">Timezone: Asia/Makassar (WITA)</span>
          </div>
        </div>
      </div>

      {/* Dept Head Scoped Notice Banner */}
      {isDeptHead && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-300 text-xs text-emerald-950 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              <strong>Dashboard Terproteksi Departemen ({currentDept?.name || myDeptId}):</strong> Metrik staf aktif, kontrak kerja, antrean cuti, dan pelatihan hanya menampilkan data staf di bawah naungan departemen Anda.
            </span>
          </div>
          <span className="font-mono font-bold bg-white px-2 py-0.5 rounded border border-emerald-300 text-emerald-800 shrink-0">
            {scopedEmployees.length} Staf Departemen
          </span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Employees */}
        <div 
          onClick={() => onNavigate('employees')}
          className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 hover:shadow-md transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-semibold uppercase tracking-wider text-slate-700">
              {isDeptHead ? 'Staff Departemen' : 'Active Staff'}
            </span>
            <Users className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{scopedEmployees.length}</div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <HardDrive className="w-3 h-3 text-emerald-700" />
            <span>{isDeptHead ? 'Staf tim departemen Anda' : 'Dedicated Google Drive folders initialized'}</span>
          </div>
        </div>

        {/* Contract Expiry Alerts */}
        <div 
          onClick={() => onNavigate('contracts')}
          className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 hover:shadow-md transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-semibold uppercase tracking-wider text-slate-700">Contract Expiry Alerts</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{urgentContracts.length}</div>
          <div className="text-[11px] text-rose-600 font-medium mt-1">
            {urgentContracts.length > 0 
              ? `${urgentContracts.length} kontrak staf jatuh tempo ≤ 30 hari` 
              : 'Semua kontrak staf departemen aman'}
          </div>
        </div>

        {/* Leave Queue */}
        <div 
          onClick={() => onNavigate('leave')}
          className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 hover:shadow-md transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-semibold uppercase tracking-wider text-slate-700">Pending Leave Requests</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{pendingLeaves.length}</div>
          <div className="text-[11px] text-amber-700 font-medium mt-1">
            {isDeptHead ? 'Permohonan cuti staf departemen Anda' : 'Awaiting 4-stage sequential approval'}
          </div>
        </div>

        {/* Training Plans */}
        <div 
          onClick={() => onNavigate('training')}
          className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 hover:shadow-md transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-semibold uppercase tracking-wider text-slate-700">
              {isDeptHead ? 'Training Departemen & Generic' : 'Annual Training Plans'}
            </span>
            <GraduationCap className="w-4 h-4 text-blue-700" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{scopedTrainingPlans.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">
            {scopedTrainingPlans.filter(p => p.status === 'APPROVED_BY_GM').length} program disahkan GM
          </div>
        </div>
      </div>

      {/* Quick Launchpad & Workflow Guidance */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Quick Actions & Personal Folders */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
            <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-4">
              Quick Operations & Structured Folders
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={() => onNavigate('personal-files')}
                className="p-4 rounded-xl border border-slate-200 hover:border-emerald-600 hover:bg-emerald-50/40 text-left transition-all group flex items-start gap-3"
              >
                <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 border border-emerald-100 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                  <HardDrive className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Personal Files Explorer</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Browse the 10 standard category folders per employee in Google Drive.
                  </p>
                </div>
              </button>

              <button
                onClick={() => onNavigate('leave')}
                className="p-4 rounded-xl border border-slate-200 hover:border-emerald-600 hover:bg-emerald-50/40 text-left transition-all group flex items-start gap-3"
              >
                <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0 border border-blue-100 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Leave Approval Engine</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Execute Staff → Dept Head → HC → GM 4-stage sequential workflow.
                  </p>
                </div>
              </button>

              <button
                onClick={() => onNavigate('leave-review')}
                className="p-4 rounded-xl border border-emerald-300 bg-emerald-50/30 hover:border-emerald-600 hover:bg-emerald-50/60 text-left transition-all group flex items-start gap-3"
              >
                <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 border border-emerald-200 group-hover:bg-emerald-700 group-hover:text-white transition-colors">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    Review & Laporan Cuti 2025
                    <span className="text-[9px] font-bold bg-emerald-700 text-white px-1.5 py-0.2 rounded-full">Report</span>
                  </h4>
                  <p className="text-[11px] text-slate-600 mt-0.5">
                    {currentUser.role === 'DEPT_HEAD' 
                      ? 'Dashboard review cuti 2025 khusus staf departemen Anda.' 
                      : 'Laporan hak cuti, cuti diambil & sisa seluruh karyawan GMCC.'}
                  </p>
                </div>
              </button>


              <button
                onClick={() => onNavigate('contracts')}
                className="p-4 rounded-xl border border-slate-200 hover:border-emerald-600 hover:bg-emerald-50/40 text-left transition-all group flex items-start gap-3"
              >
                <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0 border border-amber-100 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Contract Expiry Alerts</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Monitor 90/60/30/14/7-day renewal thresholds with audit trail.
                  </p>
                </div>
              </button>

              <button
                onClick={() => onNavigate('training')}
                className="p-4 rounded-xl border border-slate-200 hover:border-emerald-600 hover:bg-emerald-50/40 text-left transition-all group flex items-start gap-3"
              >
                <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center shrink-0 border border-purple-100 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Training Management</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Propose departmental programs, review budgets, and track certificates.
                  </p>
                </div>
              </button>
            </div>
          </div>

          {/* Urgent Items Action List */}
          {urgentContracts.length > 0 && (
            <div className="bg-rose-50/70 border border-rose-200 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-rose-900 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-700" />
                  Urgent Employment Contract Attention Needed
                </span>
                <button
                  onClick={() => onNavigate('contracts')}
                  className="text-xs font-semibold text-rose-800 hover:underline flex items-center gap-0.5"
                >
                  Manage Contracts <ArrowRight className="w-3 h-3" />
                </button>
              </div>
              <div className="space-y-2 mt-2">
                {urgentContracts.map(c => {
                  const days = getDaysUntilExpiry(c.endDate);
                  return (
                    <div key={c.id} className="bg-white p-3 rounded-lg border border-rose-200 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-semibold text-slate-900">{c.employeeName}</span>
                        <span className="text-slate-500 block text-[11px]">{c.position} · {c.contractNumber}</span>
                      </div>
                      <span className="font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                        Expires in {days} days ({new Date(c.endDate).toLocaleDateString('en-GB')})
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Right: Security & Live Audit Stream */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                Live System Audit Trail
              </h3>
              {(currentUser.role === 'ADMIN' || currentUser.role === 'GM') && (
                <button 
                  onClick={() => onNavigate('admin')}
                  className="text-[11px] text-emerald-700 font-semibold hover:underline"
                >
                  View Full Log
                </button>
              )}
            </div>

            <div className="space-y-3">
              {auditLogs.length === 0 && (
                <div className="py-6 text-center text-xs text-slate-400">
                  Belum ada catatan audit trail. Sistem siap beroperasi dari basis data nol.
                </div>
              )}
              {auditLogs.slice(0, 5).map((log, idx) => (
                <div key={`${log.id}-${idx}`} className="text-xs pb-3 border-b border-slate-100 last:border-b-0 last:pb-0">
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
                    <span className="font-mono text-emerald-800 font-semibold">{log.action}</span>
                    <span>{new Date(log.timestamp).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <p className="text-slate-700 line-clamp-2 text-[11px]">
                    {log.description}
                  </p>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    by {log.actorName} ({log.actorRole})
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-400 text-center">
            GMCC HCMS · Enterprise Grade · Asia/Makassar
          </div>
        </div>
      </div>
    </div>
  );
};
