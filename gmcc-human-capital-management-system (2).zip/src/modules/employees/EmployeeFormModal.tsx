import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { GMCC_DEPARTMENTS } from '../../data/categories';
import { EmploymentType, EmploymentStatus, UserRole } from '../../types';
import { 
  X, 
  UserPlus, 
  CheckCircle2, 
  Camera, 
  Upload, 
  KeyRound, 
  User, 
  Eye, 
  EyeOff, 
  RefreshCw,
  ShieldCheck
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const EmployeeFormModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { addEmployee, employees, addUserAccount } = useApp();

  const [fullName, setFullName] = useState('');
  const [preferredName, setPreferredName] = useState('');
  const [email, setEmail] = useState('');
  const [companyEmail, setCompanyEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [departmentId, setDepartmentId] = useState(GMCC_DEPARTMENTS[0].id);
  const [jobTitle, setJobTitle] = useState('');
  const [employmentType, setEmploymentType] = useState<EmploymentType>('PKWT');
  const [employmentStatus, setEmploymentStatus] = useState<EmploymentStatus>('ACTIVE');
  const [joinDate, setJoinDate] = useState('2026-10-15');
  const [location, setLocation] = useState('Golo Mori Convention Center, Labuan Bajo');
  const [workSchedule, setWorkSchedule] = useState('Standard 5/2 Roster (Mon-Fri 08:30-17:30)');
  const [idCardNumber, setIdCardNumber] = useState('');
  const [dailyRate, setDailyRate] = useState<number>(250000);
  const [assignedEvent, setAssignedEvent] = useState('');
  const [dwAgreementNumber, setDwAgreementNumber] = useState('');
  const [contractDurationMonths, setContractDurationMonths] = useState<number>(12);
  const [avatarUrl, setAvatarUrl] = useState('');

  // User ID and Password credentials for Staff
  const [createAccount, setCreateAccount] = useState<boolean>(true);
  const [accountUserId, setAccountUserId] = useState<string>('');
  const [accountPassword, setAccountPassword] = useState<string>('Staff@2026!');
  const [accountRole, setAccountRole] = useState<UserRole>('STAFF');
  const [showPassword, setShowPassword] = useState<boolean>(false);

  const [isSuccess, setIsSuccess] = useState(false);

  // Auto-generate suggested User ID from preferredName or fullName
  useEffect(() => {
    const raw = preferredName || fullName.split(' ')[0] || '';
    if (raw) {
      const clean = raw.toLowerCase().replace(/[^a-z0-9]/g, '');
      setAccountUserId(clean);
    }
  }, [preferredName, fullName]);

  // Auto-detect Role based on Job Title or Department (e.g. General Manager -> GM)
  useEffect(() => {
    const titleLower = jobTitle.toLowerCase();
    if (titleLower.includes('general manager') || titleLower === 'gm' || departmentId === 'DEP-EXEC') {
      setAccountRole('GM');
    } else if (titleLower.includes('human capital') || departmentId === 'DEP-HC') {
      setAccountRole('HC');
    } else if (titleLower.includes('dept head') || titleLower.includes('head') || titleLower.includes('director')) {
      setAccountRole('DEPT_HEAD');
    }
  }, [jobTitle, departmentId]);

  const generatePassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*';
    let res = '';
    for (let i = 0; i < 6; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setAccountPassword(`Gmcc@${res}!`);
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !jobTitle) return;

    const dept = GMCC_DEPARTMENTS.find(d => d.id === departmentId);
    const finalCompanyEmail = companyEmail || `${(preferredName || fullName.split(' ')[0]).toLowerCase()}@golomoricc.com`;

    // Calculate next sequential employee number based on existing employees
    let maxEmpNum = 0;
    employees.forEach(e => {
      const m = e.employeeNumber?.match(/(\d+)$/);
      if (m) {
        const val = parseInt(m[1], 10);
        if (!isNaN(val) && val > maxEmpNum) maxEmpNum = val;
      }
    });
    const nextEmployeeNum = (maxEmpNum + 1).toString().padStart(3, '0');
    const autoEmployeeNumber = `GMCC-2026-${nextEmployeeNum}`;

    const newEmp = addEmployee({
      employeeNumber: autoEmployeeNumber,
      fullName: fullName.trim(),
      preferredName: (preferredName || fullName.split(' ')[0]).trim(),
      email: (email || `${fullName.toLowerCase().replace(/\s+/g, '.')}@gmail.com`).trim(),
      companyEmail: finalCompanyEmail.trim(),
      phone: (phone || '+62 812 0000 0000').trim(),
      departmentId,
      jobTitle: jobTitle.trim(),
      employmentType,
      employmentStatus,
      joinDate,
      directSupervisorName: dept?.headName || 'Head of Department',
      location: location.trim(),
      workSchedule: employmentType === 'DAILY_WORKER' ? 'Casual On-Call Event Roster' : workSchedule,
      avatarUrl: avatarUrl ? avatarUrl.trim() : undefined,
      idCardType: 'KTP',
      idCardNumber: idCardNumber.trim() || '5315000000000000',
      address: 'Labuan Bajo, Manggarai Barat, NTT',
      dailyRate: employmentType === 'DAILY_WORKER' ? Number(dailyRate) : undefined,
      assignedEvent: employmentType === 'DAILY_WORKER' ? assignedEvent.trim() : undefined,
      dwAgreementNumber: employmentType === 'DAILY_WORKER' ? dwAgreementNumber || `SPK-DW/GMCC/${dept?.code || 'OPS'}/2026/0${nextEmployeeNum}` : undefined,
      contractDurationMonths: employmentType === 'PKWT' ? Number(contractDurationMonths) : undefined
    });

    // Create user login credentials if enabled
    if (createAccount && accountUserId && accountPassword) {
      addUserAccount({
        userId: accountUserId.trim(),
        username: accountUserId.trim(),
        password: accountPassword.trim(),
        name: newEmp.fullName,
        email: newEmp.companyEmail,
        role: accountRole,
        employeeId: newEmp.id,
        departmentId: newEmp.departmentId,
        status: 'ACTIVE'
      });
    }

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[92vh] overflow-y-auto border border-slate-200">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white rounded-t-2xl">
          <div>
            <h3 className="font-bold text-slate-100 text-base">Tambah Data Karyawan Baru</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Input data staf, upload foto profil, dan buatkan User ID & Password login
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center flex flex-col items-center justify-center">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-3">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-slate-900 text-base">Data Karyawan & Akun Berhasil Dibuat!</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm">
              Rekord karyawan dan kredensial login telah tersimpan. Folder Google Drive personal file telah diinisialisasi.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            {/* Foto Profil Karyawan */}
            <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-emerald-700" />
                  Foto Profil Karyawan (Profile Photo)
                </label>
                {avatarUrl && (
                  <button
                    type="button"
                    onClick={() => setAvatarUrl('')}
                    className="text-[10px] text-rose-600 hover:text-rose-700 font-semibold"
                  >
                    Hapus Foto
                  </button>
                )}
              </div>

              <div className="flex items-center gap-3.5">
                <div className="relative shrink-0">
                  {avatarUrl ? (
                    <img 
                      src={avatarUrl} 
                      alt="Preview" 
                      className="w-14 h-14 rounded-full object-cover border-2 border-emerald-600 shadow-xs" 
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-full bg-slate-200 text-slate-400 flex items-center justify-center border border-dashed border-slate-300">
                      <User className="w-6 h-6" />
                    </div>
                  )}
                </div>

                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <label className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-[11px] rounded-lg shadow-xs cursor-pointer transition-colors">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Unggah Foto</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={e => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onloadend = () => setAvatarUrl(reader.result as string);
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>

                    <input
                      type="text"
                      placeholder="atau paste URL foto..."
                      value={avatarUrl}
                      onChange={e => setAvatarUrl(e.target.value)}
                      className="flex-1 min-w-[140px] px-2.5 py-1 text-xs rounded-lg border border-slate-300 bg-white"
                    />
                  </div>

                  <div className="flex items-center gap-1 text-[10px] text-slate-500">
                    <span>Pilihan Cepat:</span>
                    <button
                      type="button"
                      onClick={() => setAvatarUrl('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80')}
                      className="px-1.5 py-0.5 bg-slate-200 hover:bg-emerald-100 rounded text-slate-700"
                    >
                      Pria
                    </button>
                    <button
                      type="button"
                      onClick={() => setAvatarUrl('https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80')}
                      className="px-1.5 py-0.5 bg-slate-200 hover:bg-emerald-100 rounded text-slate-700"
                    >
                      Wanita
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Nama & Posisi */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Nama Lengkap *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Yohanes Don Bosco"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Nama Panggilan</label>
                <input
                  type="text"
                  placeholder="e.g. Bosco"
                  value={preferredName}
                  onChange={e => setPreferredName(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Departemen *</label>
                <select
                  value={departmentId}
                  onChange={e => setDepartmentId(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden"
                >
                  {GMCC_DEPARTMENTS.map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Jabatan / Job Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. F&B Service Captain"
                  value={jobTitle}
                  onChange={e => setJobTitle(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Tipe Hubungan Kerja *</label>
                <select
                  value={employmentType}
                  onChange={e => setEmploymentType(e.target.value as EmploymentType)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 font-bold"
                >
                  <option value="PKWT">PKWT (Kontrak Waktu Tertentu)</option>
                  <option value="DAILY_WORKER">Daily Worker (Pekerja Harian Lepas)</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Status Karyawan *</label>
                <select
                  value={employmentStatus}
                  onChange={e => setEmploymentStatus(e.target.value as EmploymentStatus)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900"
                >
                  <option value="ACTIVE">ACTIVE (Aktif Bekerja)</option>
                  <option value="PROBATION">PROBATION (Masa Percobaan)</option>
                  <option value="INACTIVE">INACTIVE (Non-aktif)</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Email Perusahaan</label>
                <input
                  type="email"
                  placeholder="name@golomoricc.com"
                  value={companyEmail}
                  onChange={e => setCompanyEmail(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 font-mono"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Nomor HP / WhatsApp *</label>
                <input
                  type="text"
                  required
                  placeholder="+62 812 ..."
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Tanggal Bergabung (Join Date)</label>
                <input
                  type="date"
                  value={joinDate}
                  onChange={e => setJoinDate(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Nomor KTP (NIK 16-Digit)</label>
                <input
                  type="text"
                  placeholder="5315000000000000"
                  value={idCardNumber}
                  onChange={e => setIdCardNumber(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 font-mono"
                />
              </div>
            </div>

            {/* User ID & Password Account Creation Section */}
            <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-3">
              <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-900 text-xs">
                <input
                  type="checkbox"
                  checked={createAccount}
                  onChange={e => setCreateAccount(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <span className="flex items-center gap-1.5 text-emerald-800">
                  <KeyRound className="w-4 h-4 text-emerald-700" />
                  Buat Sekalian User ID & Password Login untuk Staf Ini
                </span>
              </label>

              {createAccount && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-200">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      User ID / Username *
                    </label>
                    <input
                      type="text"
                      required
                      value={accountUserId}
                      onChange={e => setAccountUserId(e.target.value)}
                      placeholder="Masukkan User ID"
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-mono text-slate-900 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1 flex items-center justify-between">
                      <span>Password *</span>
                      <button
                        type="button"
                        onClick={generatePassword}
                        className="text-[10px] text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-0.5"
                      >
                        <RefreshCw className="w-3 h-3" /> Acak
                      </button>
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={accountPassword}
                        onChange={e => setAccountPassword(e.target.value)}
                        className="w-full px-3 py-2 pr-9 rounded-lg border border-slate-300 bg-white font-mono text-slate-900 text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Hak Akses (Role) *
                    </label>
                    <select
                      value={accountRole}
                      onChange={e => setAccountRole(e.target.value as UserRole)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-900 text-xs font-semibold"
                    >
                      <option value="STAFF">STAFF (Karyawan Reguler)</option>
                      <option value="DEPT_HEAD">DEPT_HEAD (Kepala Departemen)</option>
                      <option value="HC">HC (Human Capital)</option>
                      <option value="GM">GM (General Manager)</option>
                    </select>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="pt-2 border-t border-slate-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Batal
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs cursor-pointer"
              >
                <UserPlus className="w-4 h-4" />
                Simpan Karyawan & Akun Login
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
