import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { GMCC_DEPARTMENTS } from '../../data/categories';
import { Employee, EmploymentType, EmploymentStatus, UserRole } from '../../types';
import { 
  X, 
  UserCheck, 
  Building2, 
  Briefcase, 
  Calendar, 
  MapPin, 
  Phone, 
  Mail, 
  CreditCard, 
  ShieldCheck, 
  AlertCircle,
  Save,
  CheckCircle2,
  Clock,
  Sparkles,
  KeyRound,
  Plus,
  RefreshCw,
  FileCheck2,
  CalendarRange,
  ChevronDown,
  ChevronUp,
  History
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  employee: Employee | null;
  onClose: () => void;
}

export const EmployeeEditModal: React.FC<Props> = ({
  isOpen,
  employee,
  onClose
}) => {
  const { 
    updateEmployee, 
    currentUser, 
    getUserAccountByEmployeeId, 
    updateUserAccount,
    contracts,
    addContract,
    renewContract
  } = useApp();

  const [fullName, setFullName] = useState('');
  const [preferredName, setPreferredName] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [accountRole, setAccountRole] = useState<UserRole>('STAFF');
  const [employmentType, setEmploymentType] = useState<EmploymentType>('PKWT');
  const [employmentStatus, setEmploymentStatus] = useState<EmploymentStatus>('ACTIVE');
  const [joinDate, setJoinDate] = useState('');
  const [companyEmail, setCompanyEmail] = useState('');
  const [personalEmail, setPersonalEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [workSchedule, setWorkSchedule] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  
  // Specific DW fields
  const [dailyRate, setDailyRate] = useState<number>(250000);
  const [assignedEvent, setAssignedEvent] = useState('');
  const [dwAgreementNumber, setDwAgreementNumber] = useState('');
  const [contractDurationMonths, setContractDurationMonths] = useState<number>(12);
  
  // Restricted Identity / Contact fields
  const [idCardNumber, setIdCardNumber] = useState('');
  const [address, setAddress] = useState('');
  const [emergencyContactName, setEmergencyContactName] = useState('');
  const [emergencyContactPhone, setEmergencyContactPhone] = useState('');
  const [emergencyContactRelation, setEmergencyContactRelation] = useState('');
  
  const [isSaved, setIsSaved] = useState(false);

  // Contract Multi-Period Management states
  const [showAddContractForm, setShowAddContractForm] = useState(false);
  const [newContractNumber, setNewContractNumber] = useState('');
  const [newContractStartDate, setNewContractStartDate] = useState('');
  const [newContractDurationMonths, setNewContractDurationMonths] = useState<number>(12);
  const [newContractEndDate, setNewContractEndDate] = useState('');
  const [newContractNotes, setNewContractNotes] = useState('');
  const [contractSuccessMsg, setContractSuccessMsg] = useState<string | null>(null);

  // Contracts for this employee sorted by start date
  const employeeContracts = (employee && contracts)
    ? contracts
        .filter(c => c.employeeId === employee.id)
        .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
    : [];

  const latestContract = employeeContracts[employeeContracts.length - 1];
  const nextTermNumber = employeeContracts.length + 1;

  function addMonthsToDate(dateStr: string, months: number): string {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '';
    d.setMonth(d.getMonth() + Number(months));
    d.setDate(d.getDate() - 1);
    return d.toISOString().slice(0, 10);
  }

  function getNextDay(dateStr: string): string {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return '';
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  }

  const handleOpenAddContract = () => {
    if (showAddContractForm) {
      setShowAddContractForm(false);
      return;
    }
    const year = new Date().getFullYear();
    const cleanNum = employee?.employeeNumber ? employee.employeeNumber.slice(-3) : '001';
    
    if (latestContract) {
      const start = getNextDay(latestContract.endDate) || latestContract.endDate;
      const end = addMonthsToDate(start, 12);
      const baseNum = latestContract.contractNumber.replace(/-R\d+$/, '');
      setNewContractNumber(`${baseNum}-R${nextTermNumber}`);
      setNewContractStartDate(start);
      setNewContractDurationMonths(12);
      setNewContractEndDate(end);
      setNewContractNotes(`Perpanjangan Kontrak PKWT Periode ${nextTermNumber} evaluasi kinerja baik.`);
    } else {
      const start = joinDate || new Date().toISOString().slice(0, 10);
      const end = addMonthsToDate(start, contractDurationMonths || 12);
      setNewContractNumber(`GMCC-HC/PKWT/${year}/${cleanNum}`);
      setNewContractStartDate(start);
      setNewContractDurationMonths(contractDurationMonths || 12);
      setNewContractEndDate(end);
      setNewContractNotes('Kontrak PKWT Awal (Periode 1)');
    }
    setShowAddContractForm(true);
  };

  const handleDurationChange = (months: number) => {
    setNewContractDurationMonths(months);
    if (newContractStartDate) {
      setNewContractEndDate(addMonthsToDate(newContractStartDate, months));
    }
  };

  const handleStartDateChange = (startDate: string) => {
    setNewContractStartDate(startDate);
    if (startDate && newContractDurationMonths) {
      setNewContractEndDate(addMonthsToDate(startDate, newContractDurationMonths));
    }
  };

  const handleSaveContractPeriod = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!employee || !newContractStartDate || !newContractEndDate) return;

    if (latestContract) {
      renewContract(
        latestContract.id,
        newContractStartDate,
        newContractEndDate,
        newContractNotes || `Perpanjangan Kontrak PKWT Periode ${nextTermNumber}`,
        newContractNumber || `${latestContract.contractNumber}-P${nextTermNumber}`,
        nextTermNumber
      );
      setContractSuccessMsg(`Kontrak Periode ${nextTermNumber} berhasil diterbitkan dan kontrak Periode ${employeeContracts.length} diarsipkan sebagai Selesai.`);
    } else {
      addContract({
        contractNumber: newContractNumber || `GMCC-HC/PKWT/${new Date().getFullYear()}/001`,
        employeeId: employee.id,
        employeeName: fullName || employee.fullName,
        departmentId: departmentId || employee.departmentId,
        position: jobTitle || employee.jobTitle,
        employmentType: 'PKWT',
        startDate: newContractStartDate,
        endDate: newContractEndDate,
        status: 'ACTIVE',
        termNumber: 1,
        notes: newContractNotes || 'Kontrak Awal (Periode 1)'
      });
      setContractSuccessMsg('Kontrak awal Periode 1 berhasil diterbitkan dan tercatat dalam sistem.');
    }

    setContractDurationMonths(newContractDurationMonths);
    setEmploymentStatus('ACTIVE');
    setShowAddContractForm(false);
    setTimeout(() => setContractSuccessMsg(null), 5000);
  };

  useEffect(() => {
    if (employee) {
      setFullName(employee.fullName || '');
      setPreferredName(employee.preferredName || '');
      setJobTitle(employee.jobTitle || '');
      setDepartmentId(employee.departmentId || GMCC_DEPARTMENTS[0].id);
      // Ensure only PKWT or DAILY_WORKER (no PKWTT)
      setEmploymentType(employee.employmentType === 'DAILY_WORKER' ? 'DAILY_WORKER' : 'PKWT');
      setEmploymentStatus(employee.employmentStatus || 'ACTIVE');
      setJoinDate(employee.joinDate || '');
      setCompanyEmail(employee.companyEmail || '');
      setPersonalEmail(employee.email || '');
      setPhone(employee.phone || '');
      setLocation(employee.location || 'Golo Mori Convention Center, Labuan Bajo');
      setWorkSchedule(employee.workSchedule || '');
      setAvatarUrl(employee.avatarUrl || '');
      setDailyRate(employee.dailyRate || 250000);
      setAssignedEvent(employee.assignedEvent || '');
      setDwAgreementNumber(employee.dwAgreementNumber || '');
      setContractDurationMonths(employee.contractDurationMonths || 12);
      setIdCardNumber(employee.idCardNumber || '');
      setAddress(employee.address || '');
      setEmergencyContactName(employee.emergencyContactName || '');
      setEmergencyContactPhone(employee.emergencyContactPhone || '');
      setEmergencyContactRelation(employee.emergencyContactRelation || '');

      // Check linked user account role
      const linked = getUserAccountByEmployeeId(employee.id);
      if (linked) {
        const titleLower = (employee.jobTitle || '').toLowerCase();
        if (linked.role === 'STAFF' && (titleLower.includes('general manager') || titleLower === 'gm' || employee.departmentId === 'DEP-EXEC')) {
          setAccountRole('GM');
        } else {
          setAccountRole(linked.role);
        }
      } else {
        const titleLower = (employee.jobTitle || '').toLowerCase();
        if (titleLower.includes('general manager') || titleLower === 'gm' || employee.departmentId === 'DEP-EXEC') {
          setAccountRole('GM');
        } else if (titleLower.includes('human capital') || employee.departmentId === 'DEP-HC') {
          setAccountRole('HC');
        } else if (titleLower.includes('dept head') || titleLower.includes('head') || titleLower.includes('director')) {
          setAccountRole('DEPT_HEAD');
        } else {
          setAccountRole('STAFF');
        }
      }

      setIsSaved(false);
    }
  }, [employee, getUserAccountByEmployeeId]);

  // Auto-promote to GM when job title is edited to General Manager or Executive
  useEffect(() => {
    const titleLower = jobTitle.toLowerCase();
    if (titleLower.includes('general manager') || titleLower === 'gm' || departmentId === 'DEP-EXEC') {
      setAccountRole('GM');
    }
  }, [jobTitle, departmentId]);

  if (!isOpen || !employee) return null;

  const canEdit = currentUser.role === 'HC' || currentUser.role === 'GM' || currentUser.role === 'ADMIN';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canEdit) return;

    const dept = GMCC_DEPARTMENTS.find(d => d.id === departmentId);

    const updated: Employee = {
      ...employee,
      fullName,
      preferredName: preferredName || fullName.split(' ')[0],
      jobTitle,
      departmentId,
      employmentType,
      employmentStatus,
      joinDate,
      companyEmail,
      email: personalEmail,
      phone,
      location,
      workSchedule,
      avatarUrl: avatarUrl || undefined,
      directSupervisorName: dept?.headName || employee.directSupervisorName,
      idCardNumber,
      address,
      emergencyContactName,
      emergencyContactPhone,
      emergencyContactRelation,
      dailyRate: employmentType === 'DAILY_WORKER' ? Number(dailyRate) : undefined,
      assignedEvent: employmentType === 'DAILY_WORKER' ? assignedEvent : undefined,
      dwAgreementNumber: employmentType === 'DAILY_WORKER' ? dwAgreementNumber : undefined,
      contractDurationMonths: employmentType === 'PKWT' ? Number(contractDurationMonths) : undefined,
      updatedAt: new Date().toISOString()
    };

    updateEmployee(updated);

    // Also sync linked UserAccount role & status
    const linked = getUserAccountByEmployeeId(employee.id);
    if (linked) {
      updateUserAccount({
        ...linked,
        name: fullName,
        email: companyEmail || linked.email,
        role: accountRole,
        departmentId: departmentId,
        status: employmentStatus === 'EX_EMPLOYEE' || employmentStatus === 'INACTIVE' ? 'SUSPENDED' : 'ACTIVE',
        updatedAt: new Date().toISOString()
      });
    }

    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto border border-slate-200">
        {/* Modal Header */}
        <div className="sticky top-0 z-10 bg-slate-900 text-white px-5 sm:px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm sm:text-base tracking-tight text-white">Edit Profil Karyawan</h3>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                  {employee.id}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Perbarui data pegawai, status penugasan, dan informasi kontrak GMCC
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Authorization Banner */}
        <div className="bg-emerald-50 border-b border-emerald-200 px-5 sm:px-6 py-2.5 flex items-center justify-between text-xs text-emerald-900">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              <strong>Otorisasi Pengeditan:</strong> Anda masuk sebagai <strong>{currentUser.name} ({currentUser.role})</strong>. GM & HC memiliki wewenang penuh untuk memperbarui profil karyawan ini.
            </span>
          </div>
          <span className="font-bold text-[10px] bg-white px-2 py-0.5 rounded border border-emerald-300 text-emerald-800 shrink-0 hidden sm:inline">
            GM & HC Authorized
          </span>
        </div>

        {isSaved ? (
          <div className="p-10 text-center flex flex-col items-center justify-center">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-3 animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-slate-900 text-base">Profil Karyawan Berhasil Diperbarui!</h4>
            <p className="text-xs text-slate-500 mt-1">Perubahan telah disimpan ke master data pegawai GMCC.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-6 text-xs">
            {/* 1. Basic Info */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 pb-2">
                <Briefcase className="w-4 h-4 text-emerald-700" />
                1. Data Utama & Jabatan
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nama Lengkap & Gelar *</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nama Panggilan / Preferred Name</label>
                  <input
                    type="text"
                    value={preferredName}
                    onChange={e => setPreferredName(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Departemen *</label>
                  <select
                    value={departmentId}
                    onChange={e => setDepartmentId(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
                  >
                    {GMCC_DEPARTMENTS.map(d => (
                      <option key={d.id} value={d.id}>
                        {d.code} — {d.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Jabatan / Job Title *</label>
                  <input
                    type="text"
                    required
                    value={jobTitle}
                    onChange={e => setJobTitle(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-emerald-700" />
                    Hak Akses Akun (Role) *
                  </label>
                  <select
                    value={accountRole}
                    onChange={e => setAccountRole(e.target.value as UserRole)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-emerald-50 text-emerald-950 font-bold focus:outline-hidden focus:border-emerald-700"
                  >
                    <option value="STAFF">STAFF (Karyawan Reguler)</option>
                    <option value="DEPT_HEAD">DEPT_HEAD (Kepala Departemen)</option>
                    <option value="HC">HC (Human Capital Manager)</option>
                    <option value="GM">GM (General Manager)</option>
                    <option value="ADMIN">ADMIN (System Administrator)</option>
                    <option value="AUDITOR">AUDITOR (Internal Auditor)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* 2. Employment Type (Strictly Kontrak PKWT or Daily Worker) */}
            <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-emerald-700" />
                  2. Status Hubungan Kerja (Kontrak PKWT & Daily Worker)
                </h4>
                <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                  Hanya PKWT & DW
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tipe Pegawai *</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setEmploymentType('PKWT')}
                      className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all text-center ${
                        employmentType === 'PKWT'
                          ? 'bg-amber-100 border-amber-600 text-amber-900 shadow-xs'
                          : 'bg-white border-slate-300 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      Kontrak (PKWT)
                    </button>
                    <button
                      type="button"
                      onClick={() => setEmploymentType('DAILY_WORKER')}
                      className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all text-center ${
                        employmentType === 'DAILY_WORKER'
                          ? 'bg-purple-100 border-purple-600 text-purple-900 shadow-xs'
                          : 'bg-white border-slate-300 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      Daily Worker (DW)
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-500 mt-1">
                    *Status karyawan tetap (PKWTT) ditiadakan. Seluruh staf di bawah Kontrak PKWT atau Pekerja Harian Lepas (DW).
                  </p>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Status Kepegawaian *</label>
                  <select
                    value={employmentStatus}
                    onChange={e => setEmploymentStatus(e.target.value as EmploymentStatus)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-semibold"
                  >
                    <option value="ACTIVE">ACTIVE (Aktif Bekerja)</option>
                    <option value="PROBATION">PROBATION (Masa Percobaan)</option>
                    <option value="INACTIVE">INACTIVE (Cuti Panjang / Non-Aktif)</option>
                    <option value="EX_EMPLOYEE">EX_EMPLOYEE (Habis Kontrak / Mantan Karyawan)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Tanggal Mulai Bergabung (Join Date) *</label>
                  <input
                    type="date"
                    required
                    value={joinDate}
                    onChange={e => setJoinDate(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                  />
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    Basis perhitungan prorate hak cuti tahunan staf.
                  </p>
                </div>

                {employmentType === 'PKWT' ? (
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Durasi Kontrak Berjalan (Bulan)</label>
                    <input
                      type="number"
                      min="1"
                      max="60"
                      value={contractDurationMonths}
                      onChange={e => setContractDurationMonths(Number(e.target.value))}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-semibold"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Upah Harian (Daily Rate IDR)</label>
                    <input
                      type="number"
                      step="5000"
                      value={dailyRate}
                      onChange={e => setDailyRate(Number(e.target.value))}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-semibold"
                    />
                  </div>
                )}

                {employmentType === 'DAILY_WORKER' && (
                  <>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Penugasan Event KTT / MICE</label>
                      <input
                        type="text"
                        placeholder="Contoh: ASEAN Summit & Gala Dinner"
                        value={assignedEvent}
                        onChange={e => setAssignedEvent(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Nomor SPK Daily Worker</label>
                      <input
                        type="text"
                        placeholder="Contoh: SPK-DW/GMCC/FB/2026/088"
                        value={dwAgreementNumber}
                        onChange={e => setDwAgreementNumber(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-mono"
                      />
                    </div>
                  </>
                )}

                {/* Multi-Period Contract History & Renewal (Periode 1, 2, dst) */}
                {employmentType === 'PKWT' && (
                  <div className="col-span-1 sm:col-span-2 pt-3 border-t border-slate-200 space-y-3">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <History className="w-4 h-4 text-emerald-700" />
                        <span className="font-bold text-slate-800 text-xs">
                          Riwayat Periode Kontrak ({employeeContracts.length} Periode Tercatat)
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={handleOpenAddContract}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs transition-all active:scale-95"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>
                          {employeeContracts.length === 0
                            ? 'Buat Kontrak Awal (Periode 1)'
                            : `+ Tambah Kontrak Baru / Perpanjang Periode (Periode ${nextTermNumber})`}
                        </span>
                      </button>
                    </div>

                    {/* Success Alert Banner */}
                    {contractSuccessMsg && (
                      <div className="p-3 bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-xl text-xs flex items-center gap-2 animate-in fade-in duration-200">
                        <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                        <span className="font-medium">{contractSuccessMsg}</span>
                      </div>
                    )}

                    {/* Timeline of existing contract periods */}
                    {employeeContracts.length > 0 ? (
                      <div className="space-y-2">
                        {employeeContracts.map((c, idx) => {
                          const termLabel = `Periode ${c.termNumber || (idx + 1)}`;
                          const isRunning = c.status === 'ACTIVE' || c.status === 'EXPIRING_SOON';
                          return (
                            <div
                              key={c.id}
                              className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 transition-all ${
                                isRunning
                                  ? 'bg-emerald-50/70 border-emerald-300 shadow-2xs'
                                  : 'bg-white border-slate-200 text-slate-600'
                              }`}
                            >
                              <div className="flex items-center gap-2.5 min-w-0">
                                <span
                                  className={`px-2 py-1 rounded-md text-[11px] font-bold font-mono shrink-0 ${
                                    isRunning
                                      ? 'bg-emerald-700 text-white shadow-2xs'
                                      : 'bg-slate-200 text-slate-700'
                                  }`}
                                >
                                  {termLabel}
                                </span>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="font-semibold text-slate-900 text-xs">
                                      {new Date(c.startDate).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' })} s/d {c.endDate ? new Date(c.endDate).toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'}
                                    </span>
                                    <span className="text-[10px] font-mono text-slate-500">
                                      ({c.contractNumber})
                                    </span>
                                  </div>
                                  {c.notes && (
                                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                                      {c.notes}
                                    </p>
                                  )}
                                </div>
                              </div>

                              <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                                <span
                                  className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                                    c.status === 'ACTIVE'
                                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                      : c.status === 'EXPIRING_SOON'
                                      ? 'bg-rose-100 text-rose-800 border-rose-300'
                                      : c.status === 'RENEWED'
                                      ? 'bg-blue-50 text-blue-800 border-blue-200'
                                      : 'bg-slate-100 text-slate-600 border-slate-200'
                                  }`}
                                >
                                  {c.status === 'ACTIVE'
                                    ? 'Aktif Berjalan'
                                    : c.status === 'EXPIRING_SOON'
                                    ? 'Jatuh Tempo'
                                    : c.status === 'RENEWED'
                                    ? 'Selesai / Diperpanjang'
                                    : c.status}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="p-3 bg-white rounded-xl border border-dashed border-slate-300 text-center text-xs text-slate-500">
                        Belum ada dokumen kontrak terbit untuk staf ini. Klik tombol di atas untuk menerbitkan <strong>Kontrak Periode 1</strong>.
                      </div>
                    )}

                    {/* Interactive Form: Add / Renew Contract Period */}
                    {showAddContractForm && (
                      <div className="p-4 bg-emerald-50/60 rounded-xl border-2 border-emerald-500/60 shadow-md space-y-3 animate-in fade-in zoom-in-98 duration-200">
                        <div className="flex items-center justify-between border-b border-emerald-200 pb-2">
                          <div className="flex items-center gap-2">
                            <CalendarRange className="w-4 h-4 text-emerald-800" />
                            <h5 className="font-bold text-emerald-950 text-xs">
                              {latestContract
                                ? `Formulir Perpanjangan Kontrak: Periode ${nextTermNumber}`
                                : 'Formulir Penerbitan Kontrak Awal: Periode 1'}
                            </h5>
                          </div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-200/80 text-emerald-900 border border-emerald-300">
                            Periode {nextTermNumber}
                          </span>
                        </div>

                        {latestContract && (
                          <div className="p-2.5 rounded-lg bg-white/80 border border-emerald-200 text-[11px] text-slate-700 flex items-center justify-between">
                            <span>Kontrak sebelumnya ({latestContract.contractNumber}) berakhir pada: <strong>{new Date(latestContract.endDate).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })}</strong></span>
                            <span className="text-emerald-700 font-semibold text-[10px]">Otomatis diarsipkan sebagai Selesai</span>
                          </div>
                        )}

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                          <div>
                            <label className="block font-semibold text-slate-800 mb-1">
                              Nomor Kontrak Baru (PKWT) *
                            </label>
                            <input
                              type="text"
                              required
                              value={newContractNumber}
                              onChange={e => setNewContractNumber(e.target.value)}
                              placeholder="Contoh: GMCC-HC/PKWT/2026/012-R2"
                              className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-mono font-medium text-slate-900 focus:outline-hidden focus:border-emerald-700"
                            />
                          </div>

                          <div>
                            <label className="block font-semibold text-slate-800 mb-1">
                              Pilihan Cepat Durasi
                            </label>
                            <div className="grid grid-cols-4 gap-1.5">
                              {[3, 6, 12, 24].map(m => (
                                <button
                                  key={m}
                                  type="button"
                                  onClick={() => handleDurationChange(m)}
                                  className={`py-1.5 px-2 rounded-lg text-[11px] font-bold border transition-colors ${
                                    newContractDurationMonths === m
                                      ? 'bg-emerald-700 text-white border-emerald-800 shadow-2xs'
                                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                                  }`}
                                >
                                  {m === 12 ? '1 Tahun' : m === 24 ? '2 Tahun' : `${m} Bln`}
                                </button>
                              ))}
                            </div>
                          </div>

                          <div>
                            <label className="block font-semibold text-slate-800 mb-1">
                              Tanggal Mulai Kontrak Baru *
                            </label>
                            <input
                              type="date"
                              required
                              value={newContractStartDate}
                              onChange={e => handleStartDateChange(e.target.value)}
                              className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-medium text-slate-900 focus:outline-hidden focus:border-emerald-700"
                            />
                          </div>

                          <div>
                            <label className="block font-semibold text-slate-800 mb-1">
                              Tanggal Berakhir Kontrak Baru *
                            </label>
                            <input
                              type="date"
                              required
                              value={newContractEndDate}
                              onChange={e => setNewContractEndDate(e.target.value)}
                              className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-medium text-slate-900 focus:outline-hidden focus:border-emerald-700 font-bold text-emerald-900"
                            />
                          </div>

                          <div className="sm:col-span-2">
                            <label className="block font-semibold text-slate-800 mb-1">
                              Catatan Perpanjangan / Alasan Penambahan Periode
                            </label>
                            <input
                              type="text"
                              value={newContractNotes}
                              onChange={e => setNewContractNotes(e.target.value)}
                              placeholder="Misal: Perpanjangan PKWT Periode 2 evaluasi kinerja memenuhi standar"
                              className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 text-xs"
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-end gap-2 pt-2 border-t border-emerald-200">
                          <button
                            type="button"
                            onClick={() => setShowAddContractForm(false)}
                            className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-white font-medium text-xs transition-colors"
                          >
                            Batal
                          </button>
                          <button
                            type="button"
                            onClick={handleSaveContractPeriod}
                            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs transition-colors"
                          >
                            <Save className="w-3.5 h-3.5" />
                            <span>Terbitkan & Simpan Kontrak Periode {nextTermNumber}</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* 3. Operational & Contacts */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-200 pb-2">
                <Phone className="w-4 h-4 text-emerald-700" />
                3. Kontak & Jadwal Operasional
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email Perusahaan (GMCC)</label>
                  <input
                    type="email"
                    value={companyEmail}
                    onChange={e => setCompanyEmail(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email Pribadi</label>
                  <input
                    type="email"
                    value={personalEmail}
                    onChange={e => setPersonalEmail(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nomor Telepon / WhatsApp</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Lokasi Kerja</label>
                  <input
                    type="text"
                    value={location}
                    onChange={e => setLocation(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Jadwal Kerja / Roster</label>
                  <input
                    type="text"
                    value={workSchedule}
                    onChange={e => setWorkSchedule(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                  />
                </div>
              </div>
            </div>

            {/* 4. Identity & Emergency Contacts */}
            <div className="space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-emerald-700" />
                4. Data Kependudukan & Kontak Darurat (Kerahasiaan HC & GM)
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nomor KTP / Passport</label>
                  <input
                    type="text"
                    value={idCardNumber}
                    onChange={e => setIdCardNumber(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">URL Foto Profil</label>
                  <input
                    type="url"
                    value={avatarUrl}
                    placeholder="https://..."
                    onChange={e => setAvatarUrl(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 text-[11px]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Alamat Domisili</label>
                  <input
                    type="text"
                    value={address}
                    onChange={e => setAddress(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nama Kontak Darurat</label>
                  <input
                    type="text"
                    value={emergencyContactName}
                    onChange={e => setEmergencyContactName(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Nomor HP / Hubungan Darurat</label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="Nomor HP"
                      value={emergencyContactPhone}
                      onChange={e => setEmergencyContactPhone(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                    />
                    <input
                      type="text"
                      placeholder="Hubungan (Suami/Istri/Ibu/dll)"
                      value={emergencyContactRelation}
                      onChange={e => setEmergencyContactRelation(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
              <span className="text-[11px] text-slate-500">
                Perubahan langsung disinkronkan ke seluruh modul (personal files, review cuti, & kontrak).
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-sm transition-colors"
                >
                  <Save className="w-4 h-4" />
                  Simpan Perubahan Profil
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
