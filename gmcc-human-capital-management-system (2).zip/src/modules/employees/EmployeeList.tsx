import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { GMCC_DEPARTMENTS } from '../../data/categories';
import { Employee, EmploymentType } from '../../types';
import { 
  Users, 
  Search, 
  Plus, 
  HardDrive, 
  Eye, 
  ChevronRight, 
  ShieldCheck,
  Calendar,
  Briefcase,
  Lock,
  Building2,
  Banknote,
  Sparkles,
  Clock,
  FileCheck,
  Pencil,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { EmployeeDetailModal } from './EmployeeDetailModal';
import { EmployeeFormModal } from './EmployeeFormModal';
import { EmployeeEditModal } from './EmployeeEditModal';

interface Props {
  onNavigateToDrive: (empId?: string) => void;
}

export const EmployeeList: React.FC<Props> = ({ onNavigateToDrive }) => {
  const { employees, currentUser, documents, contracts, getUserAccountByEmployeeId, deleteEmployee } = useApp();

  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('ALL');
  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [employeeToDelete, setEmployeeToDelete] = useState<Employee | null>(null);
  const [deleteToast, setDeleteToast] = useState<string | null>(null);

  // STRICT ACCESS CONTROL:
  // - STAFF can ONLY see their own employee record
  // - DEPT_HEAD can ONLY see staff in their department
  // - HC, GM, ADMIN, AUDITOR can see company-wide
  const roleScopedEmployees = employees.filter(emp => {
    if (currentUser.role === 'STAFF') {
      return emp.id === currentUser.employeeId;
    }
    if (currentUser.role === 'DEPT_HEAD') {
      return emp.departmentId === currentUser.departmentId;
    }
    return true; // HC, GM, ADMIN, AUDITOR
  });

  const filteredEmployees = roleScopedEmployees.filter(emp => {
    if (selectedDept !== 'ALL' && emp.departmentId !== selectedDept) return false;
    if (selectedType !== 'ALL' && emp.employmentType !== selectedType) return false;
    if (selectedStatus !== 'ALL' && emp.employmentStatus !== selectedStatus) return false;

    if (search.trim()) {
      const q = search.toLowerCase();
      const match = 
        emp.fullName.toLowerCase().includes(q) ||
        emp.jobTitle.toLowerCase().includes(q) ||
        emp.id.toLowerCase().includes(q) ||
        emp.employeeNumber.toLowerCase().includes(q) ||
        (emp.assignedEvent && emp.assignedEvent.toLowerCase().includes(q));
      if (!match) return false;
    }

    return true;
  });

  // Sort: Active employees on top, Inactive / Ex-Employees at the bottom
  const sortedEmployees = [...filteredEmployees].sort((a, b) => {
    const aActive = a.employmentStatus === 'ACTIVE';
    const bActive = b.employmentStatus === 'ACTIVE';
    if (aActive && !bActive) return -1;
    if (!aActive && bActive) return 1;
    return a.fullName.localeCompare(b.fullName);
  });

  // Department name for Dept Head notice
  const currentDept = GMCC_DEPARTMENTS.find(d => d.id === currentUser.departmentId);

  // Counts by Employment Type (Only PKWT & Daily Worker)
  const countPKWT = roleScopedEmployees.filter(e => e.employmentType === 'PKWT').length;
  const countDailyWorker = roleScopedEmployees.filter(e => e.employmentType === 'DAILY_WORKER').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Human Capital</span>
            <ChevronRight className="w-3 h-3" />
            <span>Staff Directory</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Employee Directory</h1>
          <p className="text-xs text-slate-500 mt-1">
            Golo Mori Convention Center staff profiles: Contract Staff (PKWT) and Casual Daily Workers (DW).
          </p>
        </div>

        {(currentUser.role === 'HC' || currentUser.role === 'GM' || currentUser.role === 'ADMIN') && (
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition-colors self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            Add New Employee / DW
          </button>
        )}
      </div>

      {/* Role Access Scope Notice */}
      {currentUser.role === 'STAFF' && (
        <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-xl flex items-center gap-3 text-xs text-blue-900">
          <Lock className="w-4 h-4 text-blue-700 shrink-0" />
          <div>
            <strong>Staff Self-View Scope:</strong> Under GMCC security policy, you can only access and view your own employee profile, contract, and personal files. Other employees' records are strictly restricted.
          </div>
        </div>
      )}

      {currentUser.role === 'DEPT_HEAD' && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-3 text-xs text-emerald-950">
          <Building2 className="w-4 h-4 text-emerald-700 shrink-0" />
          <div>
            <strong>Department Head Scoped View ({currentDept?.name || currentUser.departmentId}):</strong> You can only view staff members (Contract and Daily Workers) directly assigned under your department. Access to other departments is restricted.
          </div>
        </div>
      )}

      {/* Employment Category Tabs (PKWT Contract Staff & Casual Daily Worker only) */}
      <div className="bg-white rounded-xl border border-slate-200 p-2 shadow-xs flex flex-wrap items-center gap-1.5">
        <button
          onClick={() => setSelectedType('ALL')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            selectedType === 'ALL'
              ? 'bg-slate-900 text-white font-bold'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          All Staff ({roleScopedEmployees.length})
        </button>

        <button
          onClick={() => setSelectedType('PKWT')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            selectedType === 'PKWT'
              ? 'bg-amber-600 text-white font-bold'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Contract Staff / PKWT ({countPKWT})
        </button>

        <button
          onClick={() => setSelectedType('DAILY_WORKER')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            selectedType === 'DAILY_WORKER'
              ? 'bg-purple-700 text-white font-bold'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Daily Worker / Harian Lepas ({countDailyWorker})
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by name, EMP ID, job title, event..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-600"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Department selector (hidden for Dept Head and Staff since they are strictly scoped) */}
          {(currentUser.role === 'HC' || currentUser.role === 'GM' || currentUser.role === 'ADMIN' || currentUser.role === 'AUDITOR') && (
            <select
              value={selectedDept}
              onChange={e => setSelectedDept(e.target.value)}
              className="text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-700 focus:outline-hidden"
            >
              <option value="ALL">All Departments</option>
              {GMCC_DEPARTMENTS.map(d => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          )}

          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-700 focus:outline-hidden"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="PROBATION">Probation</option>
            <option value="EX_EMPLOYEE">Ex-Employee</option>
          </select>
        </div>
      </div>

      {/* Employee Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sortedEmployees.length === 0 && (
          <div className="col-span-full bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500 space-y-3 shadow-xs">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center mx-auto text-slate-400">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-800">Database Karyawan Masih Kosong (Nol Data)</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
              Seluruh data dummy telah dihapus. Sistem siap digunakan untuk menginput data karyawan resmi GMCC.
            </p>
            {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && (
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Tambah Karyawan Pertama
              </button>
            )}
          </div>
        )}
        {sortedEmployees.map(emp => {
          const docCount = documents.filter(d => d.employeeId === emp.id).length;
          const empContracts = contracts
            .filter(c => c.employeeId === emp.id)
            .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
          const activeContract = contracts.find(c => c.employeeId === emp.id && (c.status === 'ACTIVE' || c.status === 'EXPIRING_SOON'));
          const isDailyWorker = emp.employmentType === 'DAILY_WORKER';
          const isPKWT = emp.employmentType === 'PKWT';

          return (
            <div 
              key={emp.id}
              className={`bg-white rounded-xl border shadow-xs hover:shadow-md transition-all overflow-hidden flex flex-col justify-between ${
                isDailyWorker ? 'border-amber-200 hover:border-amber-300' : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="p-5">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={emp.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80'}
                      alt={emp.fullName}
                      className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-200 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h3 className="font-semibold text-slate-900 text-sm">{emp.fullName}</h3>
                        {((emp.jobTitle && (emp.jobTitle.toLowerCase().includes('general manager') || emp.jobTitle.toLowerCase() === 'gm')) || emp.departmentId === 'DEP-EXEC' || getUserAccountByEmployeeId(emp.id)?.role === 'GM') && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-900 text-emerald-200 border border-emerald-700">
                            General Manager (GM)
                          </span>
                        )}
                        {emp.employmentStatus !== 'ACTIVE' && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-100 text-rose-700 border border-rose-300">
                            Non-Aktif
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">{emp.jobTitle}</p>
                      <span className="text-[10px] font-mono text-slate-400">{emp.id} · {emp.employeeNumber}</span>
                    </div>
                  </div>

                  {/* Employment Type Badge */}
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border shrink-0 ${
                    isDailyWorker
                      ? 'bg-amber-50 text-amber-800 border-amber-300'
                      : 'bg-blue-50 text-blue-800 border-blue-200'
                  }`}>
                    {isDailyWorker ? 'Daily Worker' : 'PKWT Kontrak'}
                  </span>
                </div>

                {/* Specific Daily Worker Info Box */}
                {isDailyWorker && (
                  <div className="bg-amber-50/70 border border-amber-200 rounded-lg p-2.5 mb-3 text-xs text-amber-950 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-amber-700 flex items-center gap-1">
                        <Banknote className="w-3.5 h-3.5" />
                        Daily Rate:
                      </span>
                      <span className="font-bold font-mono">
                        Rp {emp.dailyRate?.toLocaleString('id-ID')} / day
                      </span>
                    </div>
                    {emp.assignedEvent && (
                      <div className="text-[11px] text-amber-800 truncate" title={emp.assignedEvent}>
                        <span className="font-semibold">Event:</span> {emp.assignedEvent}
                      </div>
                    )}
                    {emp.dwAgreementNumber && (
                      <div className="text-[10px] font-mono text-amber-700 truncate">
                        SPK: {emp.dwAgreementNumber}
                      </div>
                    )}
                  </div>
                )}

                {/* Contract Staff Info Box with Multi-Term History (Awal Periode s/d Berjalan) */}
                {isPKWT && empContracts.length > 0 && (
                  <div className="bg-blue-50/60 border border-blue-200 rounded-lg p-2.5 mb-3 text-xs text-blue-950 space-y-1.5">
                    <div className="flex justify-between items-center">
                      <span className="text-blue-900 font-bold flex items-center gap-1 text-[11px]">
                        <Clock className="w-3.5 h-3.5 text-blue-700" />
                        Kontrak Kerja ({empContracts.length} Periode):
                      </span>
                      <span className="text-[10px] font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-blue-200 text-blue-800">
                        {empContracts.length > 1 ? `${empContracts.length} Periode Berjalan` : 'Periode 1'}
                      </span>
                    </div>

                    {/* Timeline of all terms from awal periode to running */}
                    <div className="space-y-1 mt-1">
                      {empContracts.map((ctr, cIdx) => {
                        const isCurrentRunning = ctr.status === 'ACTIVE' || ctr.status === 'EXPIRING_SOON';
                        return (
                          <div 
                            key={ctr.id}
                            className={`flex items-center justify-between p-1.5 rounded text-[10px] border transition-all ${
                              isCurrentRunning
                                ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950 font-semibold shadow-2xs'
                                : 'bg-white/80 border-slate-200 text-slate-600'
                            }`}
                          >
                            <div className="flex items-center gap-1.5 min-w-0">
                              <span className={`px-1.5 py-0.2 rounded font-mono font-bold text-[9px] shrink-0 ${
                                isCurrentRunning ? 'bg-emerald-700 text-white' : 'bg-slate-200 text-slate-700'
                              }`}>
                                Periode {ctr.termNumber || (cIdx + 1)}
                              </span>
                              <span className="truncate text-[10px]">
                                {new Date(ctr.startDate).toLocaleDateString('id-ID', { month: 'short', year: 'numeric' })} – {ctr.endDate ? new Date(ctr.endDate).toLocaleDateString('id-ID', { month: 'short', year: 'numeric' }) : '-'}
                              </span>
                            </div>

                            <div className="flex items-center gap-1 shrink-0 ml-1">
                              {ctr.signedContractFileName && (
                                <span title="Salinan kontrak sudah ditandatangani" className="text-emerald-700">
                                  <FileCheck className="w-3 h-3" />
                                </span>
                              )}
                              <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                                ctr.status === 'EXPIRING_SOON'
                                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                                  : isCurrentRunning
                                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                    : 'bg-slate-100 text-slate-600 border border-slate-200'
                              }`}>
                                {ctr.status === 'RENEWED' ? 'Selesai' : ctr.status === 'EXPIRING_SOON' ? 'Jatuh Tempo' : ctr.status}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="space-y-1.5 text-xs text-slate-600 border-t border-slate-100 pt-3">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Department</span>
                    <span className="font-medium text-slate-800">{emp.departmentId.replace('DEP-', '')}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Join Date</span>
                    <span>{new Date(emp.joinDate).toLocaleDateString('en-GB')}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Drive Folder</span>
                    <span className="text-emerald-700 font-medium">{docCount} documents in 10 folders</span>
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-1 text-xs">
                <button
                  onClick={() => setSelectedEmployee(emp)}
                  className="inline-flex items-center gap-1 text-slate-700 hover:text-slate-900 font-medium py-1 px-2 rounded-md hover:bg-slate-200 transition-colors"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Lihat Profil
                </button>

                {(currentUser.role === 'HC' || currentUser.role === 'GM' || currentUser.role === 'ADMIN') && (
                  <button
                    onClick={() => setEditingEmployee(emp)}
                    className="inline-flex items-center gap-1 text-indigo-700 hover:text-indigo-900 font-semibold py-1 px-2 rounded-md hover:bg-indigo-50 transition-colors"
                    title="Edit Profil Karyawan (GM & HC)"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    Edit
                  </button>
                )}

                {(currentUser.role === 'GM' || currentUser.role === 'ADMIN') && (
                  <button
                    onClick={() => setEmployeeToDelete(emp)}
                    className="inline-flex items-center gap-1 text-rose-600 hover:text-rose-800 font-semibold py-1 px-2 rounded-md hover:bg-rose-50 transition-colors"
                    title="Hapus Profil Karyawan Ini (Permanent Delete)"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                    Hapus
                  </button>
                )}

                <button
                  onClick={() => onNavigateToDrive(emp.id)}
                  className="inline-flex items-center gap-1 text-emerald-700 hover:text-emerald-800 font-medium py-1 px-2 rounded-md hover:bg-emerald-100/60 transition-colors"
                >
                  <HardDrive className="w-3.5 h-3.5" />
                  Drive
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredEmployees.length === 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Users className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-700">Belum Ada Data Karyawan (Data Bersih / Kosong)</p>
          <p className="text-xs text-slate-500 mt-1">
            Seluruh data karyawan contoh telah dibersihkan secara permanen. Klik tombol <strong>&quot;Add New Employee / DW&quot;</strong> di atas untuk mendaftarkan karyawan atau pekerja harian resmi GMCC.
          </p>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {employeeToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Konfirmasi Hapus Profil Karyawan</h3>
                <p className="text-xs text-slate-500">Tindakan ini permanen dan menghapus seluruh data terkait</p>
              </div>
            </div>

            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl space-y-2 text-xs text-rose-950">
              <div className="font-semibold text-slate-900 flex items-center justify-between">
                <span>{employeeToDelete.fullName}</span>
                <span className="font-mono text-[11px] text-slate-600 bg-white px-2 py-0.5 rounded border border-rose-200">
                  {employeeToDelete.employeeNumber}
                </span>
              </div>
              <p className="text-[11px] text-slate-600">
                Departemen: <strong>{employeeToDelete.departmentId.replace('DEP-', '')}</strong> · Jabatan: <strong>{employeeToDelete.jobTitle}</strong>
              </p>
              <div className="pt-2 border-t border-rose-200/80 flex items-start gap-2 text-rose-900 text-[11px]">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>
                  Menghapus profil ini akan otomatis menghapus riwayat seluruh <strong>kontrak kerja</strong>, <strong>arsip berkas drive</strong>, <strong>permohonan & saldo cuti</strong>, serta <strong>akun login GMCC</strong> karyawan ini.
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setEmployeeToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  const empName = employeeToDelete.fullName;
                  const empNum = employeeToDelete.employeeNumber;
                  deleteEmployee(employeeToDelete.id);
                  setEmployeeToDelete(null);
                  setDeleteToast(`Profil karyawan ${empName} (${empNum}) beserta seluruh kontrak dan berkas berhasil dihapus dari sistem.`);
                  setTimeout(() => setDeleteToast(null), 5000);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 transition-colors shadow-xs"
              >
                Ya, Hapus Profil Ini
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {deleteToast && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center justify-between gap-3 text-xs animate-in fade-in slide-in-from-bottom-2 duration-200">
          <span>{deleteToast}</span>
          <button
            onClick={() => setDeleteToast(null)}
            className="text-slate-400 hover:text-white font-bold ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {/* Modals */}
      <EmployeeDetailModal
        employee={selectedEmployee}
        onClose={() => setSelectedEmployee(null)}
        onOpenDriveFolder={(empId) => onNavigateToDrive(empId)}
        onEdit={(emp) => setEditingEmployee(emp)}
        onDelete={(emp) => setEmployeeToDelete(emp)}
      />

      <EmployeeEditModal
        isOpen={!!editingEmployee}
        employee={editingEmployee}
        onClose={() => setEditingEmployee(null)}
      />

      <EmployeeFormModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />
    </div>
  );
};
