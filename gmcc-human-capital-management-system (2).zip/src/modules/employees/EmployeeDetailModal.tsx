import React, { useState } from 'react';
import { Employee, EmploymentContract } from '../../types';
import { useApp } from '../../context/AppContext';
import { 
  X, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Briefcase, 
  Shield, 
  HardDrive, 
  AlertCircle,
  FileText,
  FileCheck,
  Clock,
  Trash2,
  Coins,
  UserX,
  CheckCircle2,
  DollarSign
} from 'lucide-react';
import { ContractTerminationModal } from '../contracts/ContractTerminationModal';

interface Props {
  employee: Employee | null;
  onClose: () => void;
  onOpenDriveFolder: (empId: string) => void;
  onEdit?: (emp: Employee) => void;
  onDelete?: (emp: Employee) => void;
}

export const EmployeeDetailModal: React.FC<Props> = ({
  employee,
  onClose,
  onOpenDriveFolder,
  onEdit,
  onDelete
}) => {
  const { currentUser, documents, contracts, updateContract } = useApp();

  const [selectedContractForTermination, setSelectedContractForTermination] = useState<EmploymentContract | null>(null);
  const [editingCompensationContract, setEditingCompensationContract] = useState<EmploymentContract | null>(null);
  const [compStatus, setCompStatus] = useState<'DITERIMA' | 'BELUM'>('BELUM');
  const [compAmount, setCompAmount] = useState<string>('');
  const [compPaidDate, setCompPaidDate] = useState<string>('');
  const [compNotes, setCompNotes] = useState<string>('');
  const [compToast, setCompToast] = useState<string | null>(null);

  if (!employee) return null;

  // Confidential fields visible only to HC, ADMIN, GM, or the employee themselves
  const canViewSensitive = 
    currentUser.role === 'HC' || 
    currentUser.role === 'ADMIN' || 
    currentUser.role === 'GM' ||
    (currentUser.role === 'STAFF' && currentUser.employeeId === employee.id);

  const empDocs = documents.filter(d => d.employeeId === employee.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200">
        {/* Header */}
        <div className="relative bg-slate-900 text-white p-6 rounded-t-xl overflow-hidden">
          <button 
            onClick={onClose} 
            className="absolute top-4 right-4 p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <img
              src={employee.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80'}
              alt={employee.fullName}
              className="w-16 h-16 rounded-xl object-cover ring-2 ring-emerald-500/50"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">{employee.fullName}</h3>
                <span className="text-xs font-mono bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded border border-emerald-800">
                  {employee.id}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">{employee.jobTitle}</p>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
                <span>{employee.departmentId}</span>
                <span>·</span>
                <span className="text-emerald-400 font-medium">{employee.employmentType} ({employee.employmentStatus})</span>
              </div>
            </div>
          </div>
        </div>

        {/* Content Tabs */}
        <div className="p-6 space-y-6 text-xs">
          {/* Work Information */}
          <div>
            <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Briefcase className="w-3.5 h-3.5 text-emerald-700" />
              Work & Employment Information
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-4 rounded-lg border border-slate-200">
              <div>
                <span className="text-slate-500 block">Company Email</span>
                <span className="font-semibold text-slate-900">{employee.companyEmail}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Work Location</span>
                <span className="font-semibold text-slate-900">{employee.location}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Join Date</span>
                <span className="font-semibold text-slate-900">{new Date(employee.joinDate).toLocaleDateString('en-GB')}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Work Schedule</span>
                <span className="font-semibold text-slate-900">{employee.workSchedule}</span>
              </div>
              {employee.directSupervisorName && (
                <div>
                  <span className="text-slate-500 block">Direct Supervisor / Dept Head</span>
                  <span className="font-semibold text-slate-900">{employee.directSupervisorName}</span>
                </div>
              )}
              <div>
                <span className="text-slate-500 block">Google Drive Master Folder</span>
                <span className="font-mono text-emerald-700">{employee.driveFolderId}</span>
              </div>
            </div>
          </div>

          {/* Daily Worker Specific Section */}
          {employee.employmentType === 'DAILY_WORKER' && (
            <div className="bg-amber-50 border border-amber-200 p-4 rounded-lg space-y-2">
              <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
                Daily Worker (Harian Lepas) Engagement Terms
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-amber-700 block">Agreed Daily Wage Rate</span>
                  <span className="font-bold text-slate-900 font-mono text-sm">
                    Rp {employee.dailyRate?.toLocaleString('id-ID')} / day
                  </span>
                </div>
                <div>
                  <span className="text-amber-700 block">Assigned Event / Project</span>
                  <span className="font-semibold text-slate-900">
                    {employee.assignedEvent || 'General Convention Operations'}
                  </span>
                </div>
                <div>
                  <span className="text-amber-700 block">SPK Agreement Number</span>
                  <span className="font-mono text-slate-800">
                    {employee.dwAgreementNumber || 'SPK-DW/GMCC/2026'}
                  </span>
                </div>
                <div>
                  <span className="text-amber-700 block">Payment Scheme</span>
                  <span className="text-slate-800">Bi-weekly timesheet bank transfer</span>
                </div>
              </div>
            </div>
          )}

          {/* Multi-Term Contract History (Awal Periode s/d Berjalan) */}
          {employee.employmentType === 'PKWT' && (
            <div className="bg-blue-50/70 border border-blue-200 p-4 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-blue-950 uppercase tracking-wider flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-blue-700" />
                  Riwayat & Periode Kontrak Kerja (Awal Periode s/d Berjalan)
                </h4>
                <span className="text-[11px] font-mono font-bold bg-white px-2 py-0.5 rounded border border-blue-300 text-blue-800">
                  {contracts.filter(c => c.employeeId === employee.id).length} Term Kontrak
                </span>
              </div>

              {contracts.filter(c => c.employeeId === employee.id).length === 0 ? (
                <div className="p-3 bg-white rounded-lg border border-slate-200 text-slate-500 text-xs">
                  Belum ada rekaman kontrak kerja tercatat.
                </div>
              ) : (
                <div className="space-y-2">
                  {contracts
                    .filter(c => c.employeeId === employee.id)
                    .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
                    .map((ctr, idx) => {
                      const isCurrent = ctr.status === 'ACTIVE' || ctr.status === 'EXPIRING_SOON';
                      return (
                        <div 
                          key={ctr.id}
                          className={`p-3 rounded-lg border transition-all ${
                            isCurrent
                              ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950 shadow-2xs'
                              : 'bg-white border-slate-200 text-slate-700'
                          }`}
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                            <div className="flex items-center gap-2">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                                isCurrent ? 'bg-emerald-700 text-white' : 'bg-slate-200 text-slate-700'
                              }`}>
                                Term {ctr.termNumber || (idx + 1)}
                              </span>
                              <span className="font-mono font-semibold text-xs text-slate-900">
                                {ctr.contractNumber}
                              </span>
                              <span className="text-[11px] text-slate-500">
                                · {ctr.position}
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                ctr.status === 'EXPIRING_SOON'
                                  ? 'bg-rose-100 text-rose-800 border-rose-300'
                                  : isCurrent
                                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                    : 'bg-slate-100 text-slate-600 border-slate-200'
                              }`}>
                                {ctr.status === 'RENEWED' ? 'Selesai / Diperpanjang' : ctr.status === 'EXPIRING_SOON' ? 'Jatuh Tempo (Segera Diperpanjang)' : ctr.status}
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] pt-1.5 border-t border-slate-100/80">
                            <div>
                              <span className="text-slate-500">Periode Masa Berlaku:</span>
                              <span className="font-semibold text-slate-800 ml-1">
                                {new Date(ctr.startDate).toLocaleDateString('id-ID', { dateStyle: 'medium' })} s/d {ctr.endDate ? new Date(ctr.endDate).toLocaleDateString('id-ID', { dateStyle: 'medium' }) : '-'}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-500">Salinan Kontrak TTD:</span>
                              {ctr.signedContractFileName ? (
                                <span className="font-semibold text-emerald-800 ml-1 inline-flex items-center gap-1">
                                  <FileCheck className="w-3 h-3 text-emerald-700" />
                                  {ctr.signedContractFileName}
                                </span>
                              ) : (
                                <span className="text-slate-400 italic ml-1">Belum dilampirkan</span>
                              )}
                            </div>
                          </div>

                          {/* Informasi Status Gaji Kompensasi PKWT (Sesuai PP 35/2021) */}
                          <div className="pt-2 mt-2 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-slate-500 font-medium text-[11px] flex items-center gap-1">
                                <Coins className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                Gaji Kompensasi:
                              </span>
                              {ctr.compensationStatus === 'DITERIMA' ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300 shadow-2xs">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                                  Sudah Diterima
                                  {ctr.compensationAmount ? ` · Rp ${ctr.compensationAmount.toLocaleString('id-ID')}` : ''}
                                  {ctr.compensationPaidDate ? ` (${new Date(ctr.compensationPaidDate).toLocaleDateString('id-ID')})` : ''}
                                </span>
                              ) : ctr.employmentType === 'DAILY_WORKER' ? (
                                <span className="text-[10px] text-slate-400 italic">N/A (Daily Worker)</span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 text-amber-900 border border-amber-300">
                                  <Clock className="w-3 h-3 text-amber-600 shrink-0" />
                                  Belum Diterima
                                </span>
                              )}
                            </div>

                            {(currentUser.role === 'HC' || currentUser.role === 'GM' || currentUser.role === 'ADMIN') && ctr.employmentType !== 'DAILY_WORKER' && (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingCompensationContract(ctr);
                                  setCompStatus(ctr.compensationStatus || 'BELUM');
                                  setCompAmount(ctr.compensationAmount ? String(ctr.compensationAmount) : '');
                                  setCompPaidDate(ctr.compensationPaidDate || new Date().toISOString().slice(0, 10));
                                  setCompNotes(ctr.compensationNotes || '');
                                }}
                                className="text-[10px] text-emerald-700 hover:text-emerald-900 font-bold hover:underline flex items-center gap-1 ml-auto"
                                title="Ubah informasi gaji kompensasi kontrak ini"
                              >
                                <Coins className="w-3 h-3 text-emerald-600" />
                                <span>Ubah Status Kompensasi</span>
                              </button>
                            )}
                          </div>

                          {/* Tombol Terminasi untuk Kontrak Aktif */}
                          {isCurrent && (currentUser.role === 'HC' || currentUser.role === 'GM' || currentUser.role === 'ADMIN') && (
                            <div className="pt-2 mt-2 border-t border-emerald-300 flex items-center justify-between gap-2 bg-emerald-100/40 -mx-3 -mb-3 p-2.5 rounded-b-lg">
                              <div className="flex items-center gap-1.5 text-[11px] text-emerald-900 font-semibold">
                                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
                                Kontrak Kerja Berjalan (Periode Aktif)
                              </div>
                              <button
                                type="button"
                                onClick={() => setSelectedContractForTermination(ctr)}
                                className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-rose-700 bg-white hover:bg-rose-50 border border-rose-300 rounded-lg transition-colors shadow-2xs"
                                title="Terminasi / Akhiri kontrak kerja aktif ini"
                              >
                                <UserX className="w-3.5 h-3.5 text-rose-600" />
                                <span>Terminasi Kontrak Ini</span>
                              </button>
                            </div>
                          )}

                          {/* Status Terminasi jika Kontrak telah diakhiri */}
                          {ctr.status === 'TERMINATED' && (
                            <div className="pt-2 mt-2 border-t border-rose-200 text-xs text-rose-950 bg-rose-50 p-2.5 rounded-lg border border-rose-200">
                              <div className="font-bold flex items-center gap-1.5 text-rose-800">
                                <UserX className="w-3.5 h-3.5 text-rose-600" />
                                Kontrak Telah Diterminasi
                              </div>
                              <p className="text-[11px] text-rose-700 mt-0.5">
                                Alasan: <strong>{ctr.terminationDetails?.reasonLabel || ctr.terminationDetails?.reason || 'Pengakhiran Hubungan Kerja'}</strong>
                                {ctr.terminationDetails?.effectiveDate ? ` · Tanggal Efektif: ${ctr.terminationDetails.effectiveDate}` : ''}
                              </p>
                              {ctr.terminationDetails?.notes && (
                                <p className="text-[10px] text-slate-600 italic mt-0.5">
                                  Catatan: {ctr.terminationDetails.notes}
                                </p>
                              )}
                            </div>
                          )}

                          {ctr.notes && (
                            <p className="text-[10px] text-slate-500 mt-1.5 italic">
                              Catatan: {ctr.notes}
                            </p>
                          )}
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          )}

          {/* Sensitive Personal Information */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-emerald-700" />
                Personal & Identity Details
              </h4>
              {!canViewSensitive && (
                <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  Restricted to HC & Executive
                </span>
              )}
            </div>

            {canViewSensitive ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-4 rounded-lg border border-slate-200">
                <div>
                  <span className="text-slate-500 block">National Identity ({employee.idCardType || 'KTP'})</span>
                  <span className="font-semibold text-slate-900 font-mono">{employee.idCardNumber || 'Confidential'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Date of Birth & Gender</span>
                  <span className="font-semibold text-slate-900">
                    {employee.dateOfBirth ? new Date(employee.dateOfBirth).toLocaleDateString('en-GB') : '-'} ({employee.gender || '-'})
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Personal Contact</span>
                  <span className="font-semibold text-slate-900">{employee.phone}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Emergency Contact</span>
                  <span className="font-semibold text-slate-900">
                    {employee.emergencyContactName} ({employee.emergencyContactRelation}) - {employee.emergencyContactPhone}
                  </span>
                </div>
                <div className="sm:col-span-2">
                  <span className="text-slate-500 block">Registered Residential Address</span>
                  <span className="font-semibold text-slate-900">{employee.address}</span>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-slate-500 italic">
                Personal identity, emergency contacts, and residential addresses are restricted to authorized Human Capital personnel.
              </div>
            )}
          </div>

          {/* Documents summary */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-emerald-700" />
                Personal File Documents ({empDocs.length})
              </h4>
              <button
                onClick={() => {
                  onClose();
                  onOpenDriveFolder(employee.id);
                }}
                className="text-xs font-medium text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
              >
                <HardDrive className="w-3.5 h-3.5" />
                Open Drive Folder
              </button>
            </div>
            <div className="bg-slate-50 rounded-lg p-3 border border-slate-200 divide-y divide-slate-200">
              {empDocs.slice(0, 4).map(doc => (
                <div key={doc.id} className="py-2 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-medium text-slate-900">{doc.title}</span>
                    <span className="text-[10px] text-slate-400 block font-mono">{doc.fileName}</span>
                  </div>
                  <span className="text-[10px] text-slate-500">{doc.category.replace('_', ' ')}</span>
                </div>
              ))}
              {empDocs.length === 0 && (
                <div className="text-center text-slate-400 py-3">No documents uploaded yet.</div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {(currentUser.role === 'HC' || currentUser.role === 'GM' || currentUser.role === 'ADMIN') && onEdit && (
              <button
                onClick={() => {
                  onClose();
                  onEdit(employee);
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition-colors"
              >
                <Briefcase className="w-3.5 h-3.5" />
                Edit Profil Karyawan
              </button>
            )}

            {(currentUser.role === 'GM' || currentUser.role === 'ADMIN') && onDelete && (
              <button
                onClick={() => {
                  onClose();
                  onDelete(employee);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors"
                title="Hapus Profil Karyawan Ini (Permanent Delete)"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                Hapus Profil
              </button>
            )}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>

      {/* Contract Termination Modal */}
      {selectedContractForTermination && (
        <ContractTerminationModal
          contract={selectedContractForTermination}
          onClose={() => setSelectedContractForTermination(null)}
        />
      )}

      {/* Modal Ubah Status Kompensasi PKWT */}
      {editingCompensationContract && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                  <Coins className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Ubah Status Gaji Kompensasi</h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    {editingCompensationContract.contractNumber} (Periode {editingCompensationContract.termNumber || 1})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingCompensationContract(null)}
                className="p-1 rounded-md text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-950">
              Sesuai PP No. 35/2021, kompensasi wajib diberikan kepada karyawan PKWT saat berakhirnya jangka waktu kontrak atau perpanjangan.
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                updateContract({
                  ...editingCompensationContract,
                  compensationStatus: compStatus,
                  compensationAmount: compAmount ? Number(compAmount) : undefined,
                  compensationPaidDate: compPaidDate || undefined,
                  compensationNotes: compNotes || undefined
                });
                setEditingCompensationContract(null);
                setCompToast(`Status kompensasi ${editingCompensationContract.contractNumber} berhasil diperbarui.`);
                setTimeout(() => setCompToast(null), 4000);
              }}
              className="space-y-3.5"
            >
              <div>
                <label className="block font-bold text-slate-800 mb-1.5">Status Pembayaran Kompensasi</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCompStatus('DITERIMA')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                      compStatus === 'DITERIMA'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Sudah Diterima
                  </button>
                  <button
                    type="button"
                    onClick={() => setCompStatus('BELUM')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                      compStatus === 'BELUM'
                        ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <Clock className="w-4 h-4" />
                    Belum Diterima
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nominal Uang Kompensasi (Rp) {compStatus === 'DITERIMA' && <span className="text-rose-500">*</span>}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 font-bold text-slate-400 text-xs">Rp</span>
                  <input
                    type="number"
                    min="0"
                    placeholder="Contoh: 3500000"
                    value={compAmount}
                    onChange={(e) => setCompAmount(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 font-mono text-xs focus:outline-hidden focus:border-amber-600"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tanggal Diterima / Dibayarkan</label>
                <input
                  type="date"
                  value={compPaidDate}
                  onChange={(e) => setCompPaidDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-hidden focus:border-amber-600"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Catatan Tambahan Kompensasi</label>
                <textarea
                  rows={2}
                  value={compNotes}
                  onChange={(e) => setCompNotes(e.target.value)}
                  placeholder="Catatan transfer, tanda terima kuitansi, atau dasar perhitungan..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-hidden focus:border-amber-600"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setEditingCompensationContract(null)}
                  className="px-3.5 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-medium"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition-colors shadow-xs"
                >
                  Simpan Status Kompensasi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {compToast && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center justify-between gap-3 text-xs animate-in fade-in slide-in-from-bottom-2 duration-200">
          <span>{compToast}</span>
          <button
            onClick={() => setCompToast(null)}
            className="text-slate-400 hover:text-white font-bold ml-2"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
};
