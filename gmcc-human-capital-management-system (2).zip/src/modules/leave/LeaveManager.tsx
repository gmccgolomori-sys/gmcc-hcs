import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LeaveApplication, LeaveType } from '../../types';
import { 
  CalendarDays, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  XCircle, 
  RotateCcw, 
  Plus, 
  FileSpreadsheet, 
  History, 
  ChevronRight,
  ShieldAlert,
  ArrowRight,
  FileText,
  Printer
} from 'lucide-react';
import { LeaveApplicationModal } from './LeaveApplicationModal';
import { LeaveApprovalModal } from './LeaveApprovalModal';
import { LeaveLedgerModal } from './LeaveLedgerModal';
import { PublicHolidayCalendar } from './PublicHolidayCalendar';
import { LeavePdfFormModal } from './LeavePdfFormModal';

interface Props {
  onNavigateToReview?: () => void;
}

export const LeaveManager: React.FC<Props> = ({ onNavigateToReview }) => {
  const { 
    currentUser, 
    leaveApplications, 
    getLeaveBalanceSummary, 
    cancelLeaveApplication 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'MY_LEAVE' | 'APPROVAL_QUEUE' | 'HOLIDAYS'>('MY_LEAVE');
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [selectedAppForDecision, setSelectedAppForDecision] = useState<LeaveApplication | null>(null);
  const [selectedEmployeeForLedger, setSelectedEmployeeForLedger] = useState<string | null>(null);
  const [selectedAppForPdf, setSelectedAppForPdf] = useState<LeaveApplication | null>(null);

  // Active user's balance summaries
  const targetEmpId = currentUser.employeeId || 'EMP-0010';
  const annualBalance = getLeaveBalanceSummary(targetEmpId, 'ANNUAL_LEAVE');
  const extraOffBalance = getLeaveBalanceSummary(targetEmpId, 'EXTRA_OFF');
  const holidayBalance = getLeaveBalanceSummary(targetEmpId, 'PUBLIC_HOLIDAY_COMPENSATORY');

  // Filter applications based on strict role scope
  const visibleApplications = leaveApplications.filter(a => {
    if (currentUser.role === 'STAFF') {
      return a.employeeId === currentUser.employeeId;
    }
    if (currentUser.role === 'DEPT_HEAD') {
      // Dept Head can only see applications from their own department
      return a.departmentId === currentUser.departmentId;
    }
    return true; // HC, GM, ADMIN, AUDITOR can see company-wide
  });

  // Approval queue: items waiting specifically for the current user's role
  const pendingForMe = leaveApplications.filter(a => {
    // Cannot approve own request
    if (currentUser.employeeId === a.employeeId) return false;

    if (currentUser.role === 'DEPT_HEAD') {
      // STRICT: Only approve requests for staff in their own department
      return a.status === 'PENDING_DEPT_HEAD' && a.departmentId === currentUser.departmentId;
    }
    if (currentUser.role === 'HC') {
      return a.status === 'PENDING_HC';
    }
    if (currentUser.role === 'GM') {
      return a.status === 'PENDING_GM';
    }
    if (currentUser.role === 'ADMIN') {
      return ['PENDING_DEPT_HEAD', 'PENDING_HC', 'PENDING_GM'].includes(a.status);
    }
    return false;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Human Capital</span>
            <ChevronRight className="w-3 h-3" />
            <span>Leave Management & Approvals</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Leave & Entitlements</h1>
          <p className="text-xs text-slate-500 mt-1">
            Transaction-based ledger balance engine and strict 4-stage sequential GM approval workflow.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onNavigateToReview && currentUser.role !== 'STAFF' && (
            <button
              onClick={onNavigateToReview}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-emerald-900 bg-emerald-50 border border-emerald-300 hover:bg-emerald-100 rounded-lg shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4 text-emerald-700" />
              Review & Cetak Laporan Cuti
            </button>
          )}

          <button
            onClick={() => setSelectedEmployeeForLedger(targetEmpId)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-xs transition-colors"
          >
            <History className="w-4 h-4 text-slate-500" />
            Ledger History
          </button>


          <button
            onClick={() => setIsApplyModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            Apply for Leave
          </button>
        </div>
      </div>

      {/* Leave Balance Cards (3 Separate Ledgers) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Annual Leave */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-semibold uppercase tracking-wider text-slate-700">Annual Leave</span>
            <span className="font-mono text-emerald-700">Cuti Tahunan</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-slate-900">{annualBalance.availableBalance}</span>
            <span className="text-xs text-slate-500">days available</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 space-y-1">
            <div className="flex justify-between">
              <span>Total Entitlement:</span>
              <span className="font-medium text-slate-800">{annualBalance.openingBalance + annualBalance.totalCredits} days</span>
            </div>
            <div className="flex justify-between">
              <span>Approved Used:</span>
              <span className="font-medium text-rose-600">-{annualBalance.approvedUsage} days</span>
            </div>
            <div className="flex justify-between">
              <span>Pending in Approval:</span>
              <span className="font-medium text-amber-600">{annualBalance.pendingReservation} days reserved</span>
            </div>
          </div>
        </div>

        {/* Extra Off */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-semibold uppercase tracking-wider text-slate-700">Extra Off</span>
            <span className="font-mono text-blue-700">Overtime / Rest Day</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-slate-900">{extraOffBalance.availableBalance}</span>
            <span className="text-xs text-slate-500">days available</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 space-y-1">
            <div className="flex justify-between">
              <span>Authorized Credits:</span>
              <span className="font-medium text-slate-800">{extraOffBalance.totalCredits} days</span>
            </div>
            <div className="flex justify-between">
              <span>Approved Used:</span>
              <span className="font-medium text-rose-600">-{extraOffBalance.approvedUsage} days</span>
            </div>
            <div className="flex justify-between">
              <span>Policy Expiry:</span>
              <span className="font-medium text-slate-600">3 Months Validity</span>
            </div>
          </div>
        </div>

        {/* Public Holiday Compensatory */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-semibold uppercase tracking-wider text-slate-700">Public Holiday Duty</span>
            <span className="font-mono text-purple-700">Compensatory</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-slate-900">{holidayBalance.availableBalance}</span>
            <span className="text-xs text-slate-500">days available</span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 space-y-1">
            <div className="flex justify-between">
              <span>Holiday Duty Credits:</span>
              <span className="font-medium text-slate-800">{holidayBalance.totalCredits} days</span>
            </div>
            <div className="flex justify-between">
              <span>Compensated Used:</span>
              <span className="font-medium text-rose-600">-{holidayBalance.approvedUsage} days</span>
            </div>
            <div className="flex justify-between">
              <span>Official Verification:</span>
              <span className="font-medium text-emerald-600">HC Rostered</span>
            </div>
          </div>
        </div>
      </div>

      {/* Sequential 4-Stage Approval Workflow Banner */}
      <div className="bg-slate-900 text-slate-100 rounded-xl p-4 shadow-xs">
        <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-2">
          Mandatory Annual Leave Approval Workflow
        </div>
        <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 bg-slate-800/90 px-3 py-2 rounded-lg w-full md:w-auto">
            <span className="w-5 h-5 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[10px] font-bold">1</span>
            <div>
              <div className="font-semibold text-white">Staff / User</div>
              <div className="text-[10px] text-slate-400">Submits Request</div>
            </div>
          </div>

          <ArrowRight className="w-4 h-4 text-slate-600 hidden md:block shrink-0" />

          <div className="flex items-center gap-2 bg-slate-800/90 px-3 py-2 rounded-lg w-full md:w-auto">
            <span className="w-5 h-5 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[10px] font-bold">2</span>
            <div>
              <div className="font-semibold text-white">Department Head</div>
              <div className="text-[10px] text-slate-400">Roster & Operational Check</div>
            </div>
          </div>

          <ArrowRight className="w-4 h-4 text-slate-600 hidden md:block shrink-0" />

          <div className="flex items-center gap-2 bg-slate-800/90 px-3 py-2 rounded-lg w-full md:w-auto">
            <span className="w-5 h-5 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[10px] font-bold">3</span>
            <div>
              <div className="font-semibold text-white">Human Capital (HC)</div>
              <div className="text-[10px] text-slate-400">Entitlement & Policy Audit</div>
            </div>
          </div>

          <ArrowRight className="w-4 h-4 text-slate-600 hidden md:block shrink-0" />

          <div className="flex items-center gap-2 bg-emerald-950/80 border border-emerald-600/50 px-3 py-2 rounded-lg w-full md:w-auto">
            <span className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center text-[10px] font-bold">4</span>
            <div>
              <div className="font-semibold text-emerald-300">General Manager</div>
              <div className="text-[10px] text-emerald-400 font-bold">Final Sanction & Deduction</div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-200 flex items-center gap-4">
        <button
          onClick={() => setActiveTab('MY_LEAVE')}
          className={`pb-3 text-xs font-semibold transition-colors border-b-2 flex items-center gap-1.5 ${
            activeTab === 'MY_LEAVE'
              ? 'border-emerald-700 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <CalendarDays className="w-4 h-4" />
          Leave Applications ({visibleApplications.length})
        </button>

        {currentUser.role !== 'STAFF' && (
          <button
            onClick={() => setActiveTab('APPROVAL_QUEUE')}
            className={`pb-3 text-xs font-semibold transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'APPROVAL_QUEUE'
                ? 'border-emerald-700 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Clock className="w-4 h-4" />
            Approval Queue Pending Action
            {pendingForMe.length > 0 && (
              <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] bg-rose-600 text-white font-bold">
                {pendingForMe.length}
              </span>
            )}
          </button>
        )}

        <button
          onClick={() => setActiveTab('HOLIDAYS')}
          className={`pb-3 text-xs font-semibold transition-colors border-b-2 flex items-center gap-1.5 ${
            activeTab === 'HOLIDAYS'
              ? 'border-emerald-700 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <CalendarDays className="w-4 h-4" />
          Public Holiday Calendar
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'HOLIDAYS' ? (
        <PublicHolidayCalendar />
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">Request ID</th>
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Dates</th>
                  <th className="py-3 px-4">Days</th>
                  <th className="py-3 px-4">Status & Current Stage</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(activeTab === 'APPROVAL_QUEUE' ? pendingForMe : visibleApplications).map(app => {
                  const isApproved = app.status === 'APPROVED';
                  const isRejected = app.status.startsWith('REJECTED');
                  const isReturned = app.status === 'RETURNED_TO_EMPLOYEE';

                  return (
                    <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-mono font-medium text-slate-900">{app.id}</div>
                        <span className="text-[10px] text-slate-400">
                          {new Date(app.submittedAt).toLocaleDateString('en-GB')}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">{app.employeeName}</div>
                        <span className="text-[10px] text-slate-500">{app.departmentName}</span>
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-700">
                        {app.leaveType.replace('_', ' ')}
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        {new Date(app.startDate).toLocaleDateString('en-GB')} to {new Date(app.endDate).toLocaleDateString('en-GB')}
                      </td>
                      <td className="py-3 px-4 font-bold text-slate-900">
                        {app.totalDays} day(s)
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium border ${
                          isApproved 
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : isRejected
                              ? 'bg-rose-50 text-rose-700 border-rose-200'
                              : isReturned
                                ? 'bg-amber-50 text-amber-700 border-amber-200'
                                : 'bg-blue-50 text-blue-700 border-blue-200'
                        }`}>
                          {app.status.replace(/_/g, ' ')}
                        </span>
                        {app.deductionTransactionId && (
                          <div className="text-[9px] font-mono text-emerald-700 mt-0.5">
                            Deduction: {app.deductionTransactionId}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setSelectedAppForDecision(app)}
                            className="px-2.5 py-1 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-md transition-colors border border-emerald-200"
                          >
                            {activeTab === 'APPROVAL_QUEUE' ? 'Review & Decide' : 'Details'}
                          </button>

                          {/* Official Extract PDF Form (Available when Approved by GM) */}
                          {isApproved && (
                            <button
                              onClick={() => setSelectedAppForPdf(app)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-emerald-900 bg-emerald-100 hover:bg-emerald-200 rounded-md transition-colors border border-emerald-300"
                              title="Extract Official GMCC PDF Form"
                            >
                              <FileText className="w-3.5 h-3.5" />
                              PDF Form
                            </button>
                          )}

                          {/* Cancellation option if permitted */}
                          {app.status !== 'CANCELLED' && (currentUser.employeeId === app.employeeId || currentUser.role === 'ADMIN') && (
                            <button
                              onClick={() => {
                                const reason = prompt('Please enter reason for cancellation:');
                                if (reason) cancelLeaveApplication(app.id, reason);
                              }}
                              className="px-2 py-1 text-[11px] text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                              title="Cancel leave request"
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modals */}
      <LeaveApplicationModal
        isOpen={isApplyModalOpen}
        onClose={() => setIsApplyModalOpen(false)}
      />

      <LeaveApprovalModal
        application={selectedAppForDecision}
        onClose={() => setSelectedAppForDecision(null)}
      />

      <LeaveLedgerModal
        isOpen={!!selectedEmployeeForLedger}
        onClose={() => setSelectedEmployeeForLedger(null)}
        employeeId={selectedEmployeeForLedger || targetEmpId}
      />

      {/* Official Leave PDF Clearance Form Modal */}
      <LeavePdfFormModal
        application={selectedAppForPdf}
        onClose={() => setSelectedAppForPdf(null)}
      />
    </div>
  );
};
