import React, { useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { EmployeeLeaveReviewReport, Department } from '../../types';
import { 
  Printer, 
  X, 
  Download, 
  Building2, 
  Calendar, 
  CheckCircle2, 
  Info,
  Layers,
  Sparkles
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  year: number;
  reports: EmployeeLeaveReviewReport[];
  departments: Department[];
  deptFilterId?: string;
  printedByName: string;
  printedByRole: string;
}

export const LeavePrintReportModal: React.FC<Props> = ({
  isOpen,
  onClose,
  year,
  reports,
  departments,
  deptFilterId,
  printedByName,
  printedByRole
}) => {
  const printAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      document.body.classList.add('print-modal-active');
    } else {
      document.body.classList.remove('print-modal-active');
    }
    return () => {
      document.body.classList.remove('print-modal-active');
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const currentDeptName = deptFilterId && deptFilterId !== 'ALL'
    ? departments.find(d => d.id === deptFilterId)?.name || deptFilterId
    : 'Seluruh Departemen (Company-Wide)';

  const currentDateStr = new Date().toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const currentTimeStr = new Date().toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    timeZoneName: 'short'
  });

  // Calculate totals
  const totalStaff = reports.length;
  const eligibleStaff = reports.filter(r => r.employee.employmentType !== 'DAILY_WORKER');
  const totalCarryForward = eligibleStaff.reduce((sum, r) => sum + r.previousYearCarryForward, 0);
  const totalEntitlements = eligibleStaff.reduce((sum, r) => sum + r.entitlementDays, 0);
  const totalTaken = eligibleStaff.reduce((sum, r) => sum + r.takenDays, 0);
  const totalBalanceALSum = eligibleStaff.reduce((sum, r) => sum + r.totalBalanceAL, 0);
  const totalNextYearProjected = eligibleStaff.reduce((sum, r) => sum + r.nextYearProjectedTotal, 0);

  const handlePrint = () => {
    window.print();
  };

  const handleExportCSV = () => {
    const headers = [
      'No',
      'NIK',
      'Nama Karyawan',
      'Departemen',
      'Jabatan',
      'Tipe',
      'Masa Kontrak Berjalan (Join)',
      `Sisa Th Lalu (Carry Forward)`,
      `Hak Cuti Prorate ${year}`,
      `Cuti Diambil ${year}`,
      `Sisa Cuti Th ${year}`,
      `Total Balance AL (Akumulasi s/d Saat Ini)`,
      `Tahun Berikutnya (${year + 1}) Total AL`,
      `Pending`
    ];

    const rows = reports.map((r, idx) => {
      const emp = r.employee;
      const dept = departments.find(d => d.id === emp.departmentId)?.name || emp.departmentId;
      const contractDates = r.contract 
        ? `${r.contract.startDate} s/d ${r.contract.endDate || '-'}` 
        : `${emp.joinDate} (Join)`;

      return [
        idx + 1,
        `"${emp.employeeNumber || emp.id}"`,
        `"${emp.fullName}"`,
        `"${dept}"`,
        `"${emp.jobTitle}"`,
        `"${emp.employmentType}"`,
        `"${contractDates}"`,
        r.previousYearCarryForward,
        r.entitlementDays,
        r.takenDays,
        r.remainingDays,
        r.totalBalanceAL,
        r.nextYearProjectedTotal,
        r.pendingDays > 0 ? r.pendingDays : ''
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `GMCC_Laporan_Cuti_Resmi_${year}_${deptFilterId || 'ALL'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return createPortal(
    <div className="gmcc-print-portal fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto print:static print:p-0 print:m-0 print:bg-white print:overflow-visible">
      <div className="gmcc-print-sheet bg-white rounded-2xl shadow-2xl max-w-6xl w-full max-h-[95vh] flex flex-col overflow-hidden border border-slate-300 print:max-h-none print:shadow-none print:border-none print:w-full print:overflow-visible print:rounded-none">
        
        {/* Top Control Bar (Screen Only - Hidden during print) */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0 print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center">
              <Printer className="w-4 h-4 text-emerald-200" />
            </div>
            <div>
              <h3 className="font-bold text-sm tracking-tight text-white flex items-center gap-2">
                <span>Cetak Laporan Rekapitulasi Cuti Karyawan</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  Total Balance AL & Prorate
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Format Resmi A4 Landscape · Golo Mori Convention Center (GMCC) Labuan Bajo
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors"
              title="Unduh data dalam format file Excel / CSV"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Unduh CSV</span>
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-sm transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak Sekarang (Print / PDF)</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div 
          ref={printAreaRef}
          id="gmcc-leave-report-print"
          className="gmcc-printable-area p-6 sm:p-8 overflow-y-auto space-y-5 text-slate-900 bg-white font-sans text-xs print:p-0 print:overflow-visible print:m-0 print:w-full"
        >
          {/* GMCC Formal Letterhead */}
          <div className="border-b-2 border-slate-900 pb-3 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-emerald-900 text-white flex items-center justify-center font-bold text-xs tracking-wider">
                  GMCC
                </div>
                <div>
                  <h1 className="text-sm font-extrabold tracking-tight text-slate-950 uppercase leading-none">
                    GOLO MORI CONVENTION CENTER
                  </h1>
                  <p className="text-[10px] font-semibold text-emerald-800 uppercase tracking-widest mt-0.5">
                    Human Capital & General Affairs Division
                  </p>
                </div>
              </div>
              <p className="text-[9px] text-slate-500 leading-tight">
                Kawasan Pariwisata The Golo Mori by ITDC, Golo Mori, Labuan Bajo, Kabupaten Manggarai Barat, Nusa Tenggara Tim. 86763
              </p>
            </div>

            <div className="text-right text-[9px] space-y-0.5 border-l border-slate-300 pl-3">
              <span className="font-mono font-bold text-slate-800 block text-[11px]">
                GMCC/HC-LV-RPT/{year}
              </span>
              <span className="text-slate-500 block">Klasifikasi: Dokumen Audit Resmi</span>
              <span className="text-slate-500 block">Cut-Off: Per {reports[0]?.asOfMonthName || 'Oktober'} {year}</span>
            </div>
          </div>

          {/* Document Title & Period Information */}
          <div className="text-center space-y-1">
            <h2 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-950 underline underline-offset-4">
              LAPORAN REKAPITULASI HAK & SALDO CUTI TAHUNAN (TOTAL BALANCE AL)
            </h2>
            <p className="text-[10px] text-slate-600 font-medium">
              Tahun Anggaran {year} · Cakupan: {currentDeptName} · Akumulasi Prorate s/d Bulan {reports[0]?.asOfMonthName || 'Oktober'} {year}
            </p>
          </div>

          {/* Document Metadata & Summary Metrics Table */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-[10px]">
            <div>
              <span className="text-slate-500 block text-[9px]">Tanggal Cetak:</span>
              <span className="font-semibold text-slate-900">{currentDateStr}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[9px]">Dicetak Oleh:</span>
              <span className="font-semibold text-slate-900">{printedByName} ({printedByRole})</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[9px]">Total Karyawan:</span>
              <span className="font-bold font-mono text-slate-900">{totalStaff} Orang</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[9px]">Total Saldo AL {year}:</span>
              <span className="font-bold font-mono text-emerald-800">{totalBalanceALSum} Hari</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[9px]">Proyeksi AL Th {year + 1}:</span>
              <span className="font-bold font-mono text-indigo-800">{totalNextYearProjected} Hari</span>
            </div>
          </div>

          {/* Main Table (Matching Official Structure) */}
          <div className="overflow-x-auto print:overflow-visible">
            <table className="w-full text-left text-[10px] border border-slate-300 border-collapse">
              <thead className="bg-slate-100 text-slate-800 font-bold uppercase tracking-wider text-[9px]">
                <tr className="border-b border-slate-300">
                  <th className="py-2 px-1 text-center border-r border-slate-300 w-6">No</th>
                  <th className="py-2 px-2 border-r border-slate-300">NIK / Nama Karyawan</th>
                  <th className="py-2 px-2 border-r border-slate-300">Departemen & Jabatan</th>
                  <th className="py-2 px-1 text-center border-r border-slate-300 w-12">Tipe</th>
                  <th className="py-2 px-2 text-center border-r border-slate-300">Masa Kontrak (Join)</th>
                  <th className="py-2 px-2 text-center border-r border-slate-300 bg-slate-200/50">
                    Sisa Th Lalu<br />(Carry Forward)
                  </th>
                  <th className="py-2 px-2 text-center border-r border-slate-300 bg-emerald-50 text-emerald-950 font-bold">
                    Hak Prorate {year}<br /><span className="text-[8px] font-normal">(s/d Des)</span>
                  </th>
                  <th className="py-2 px-2 text-center border-r border-slate-300 bg-indigo-50 text-indigo-950">
                    Cuti Diambil<br />Th {year}
                  </th>
                  <th className="py-2 px-2 text-center border-r border-slate-300 bg-amber-50 text-amber-950">
                    Sisa Cuti<br />Th {year}
                  </th>
                  <th className="py-2 px-2 text-center border-r border-slate-300 bg-emerald-100/80 text-emerald-950 font-black">
                    Total Balance AL<br /><span className="text-[8px] font-normal">(Akumulasi Saat Ini)</span>
                  </th>
                  <th className="py-2 px-2 text-center border-r border-slate-300 bg-blue-100/70 text-blue-950 font-bold">
                    Tahun {year + 1}<br /><span className="text-[8px] font-normal">(Hak 12 + Akumulasi)</span>
                  </th>
                  <th className="py-2 px-1 text-center border-r border-slate-300 w-12">
                    Pending
                  </th>
                  <th className="py-2 px-1 text-center w-12">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {reports.length === 0 ? (
                  <tr>
                    <td colSpan={13} className="py-8 text-center text-slate-400">
                      Tidak ada data cuti karyawan yang dapat ditampilkan.
                    </td>
                  </tr>
                ) : (
                  reports.map((r, idx) => {
                    const emp = r.employee;
                    const dept = departments.find(d => d.id === emp.departmentId)?.name || emp.departmentId;
                    const contractDates = r.contract 
                      ? `${r.contract.startDate} s/d ${r.contract.endDate || '-'}`
                      : `${emp.joinDate} (Join)`;
                    const isDW = emp.employmentType === 'DAILY_WORKER';

                    return (
                      <tr key={emp.id} className="hover:bg-slate-50">
                        <td className="py-1.5 px-1 text-center font-mono text-slate-500 border-r border-slate-300">
                          {idx + 1}
                        </td>
                        <td className="py-1.5 px-2 border-r border-slate-300">
                          <span className="font-bold text-slate-900 block leading-tight">{emp.fullName}</span>
                          <span className="font-mono text-[9px] text-slate-500 block">{emp.employeeNumber || emp.id}</span>
                        </td>
                        <td className="py-1.5 px-2 border-r border-slate-300">
                          <span className="text-slate-800 block font-medium">{dept}</span>
                          <span className="text-[9px] text-slate-500 block">{emp.jobTitle}</span>
                        </td>
                        <td className="py-1.5 px-1 text-center border-r border-slate-300">
                          <span className="px-1 py-0.2 rounded text-[8.5px] font-bold border border-slate-300 bg-white">
                            {emp.employmentType}
                          </span>
                        </td>
                        <td className="py-1.5 px-2 text-center font-mono text-[9px] border-r border-slate-300 text-slate-700">
                          {contractDates}
                        </td>
                        <td className="py-1.5 px-2 text-center font-mono font-semibold border-r border-slate-300 bg-slate-50">
                          {isDW ? '-' : `${r.previousYearCarryForward} hr`}
                        </td>
                        <td className="py-1.5 px-2 text-center font-mono font-bold border-r border-slate-300 bg-emerald-50/70 text-emerald-950">
                          {isDW ? 'N/A' : (
                            <div>
                              <span>{r.entitlementDays} hr</span>
                              {r.prorateMonths !== undefined && r.prorateMonths < 12 && (
                                <span className="block text-[8px] text-emerald-700 font-normal">
                                  ({r.prorateMonths}/12 bln)
                                </span>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-1.5 px-2 text-center font-mono font-semibold border-r border-slate-300 bg-indigo-50/70 text-indigo-900">
                          {isDW ? '-' : `${r.takenDays} hr`}
                        </td>
                        <td className="py-1.5 px-2 text-center font-mono font-bold border-r border-slate-300 bg-amber-50/70 text-amber-950">
                          {isDW ? '-' : `${r.remainingDays} hr`}
                        </td>
                        <td className="py-1.5 px-2 text-center font-mono font-black border-r border-slate-300 bg-emerald-100/70 text-emerald-950 text-[11px]">
                          {isDW ? '-' : `${r.totalBalanceAL} hr`}
                        </td>
                        <td className="py-1.5 px-2 text-center font-mono font-bold border-r border-slate-300 bg-blue-50/80 text-blue-950">
                          {isDW ? '-' : (
                            <div>
                              <span className="font-extrabold">{r.nextYearProjectedTotal} hr</span>
                              <span className="block text-[7.5px] text-blue-700 font-normal">
                                (CF: {r.nextYearCarryForward} + 12)
                              </span>
                            </div>
                          )}
                        </td>
                        <td className="py-1.5 px-1 text-center font-mono border-r border-slate-300">
                          {r.pendingDays > 0 ? (
                            <span className="text-amber-700 font-bold">+{r.pendingDays}</span>
                          ) : (
                            <span className="text-slate-300">-</span>
                          )}
                        </td>
                        <td className="py-1.5 px-1 text-center">
                          <span className={`px-1 py-0.2 rounded text-[8px] font-bold ${
                            isDW
                              ? 'bg-slate-100 text-slate-600'
                              : r.totalBalanceAL === 0
                              ? 'bg-rose-100 text-rose-800'
                              : r.totalBalanceAL <= 3
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {isDW ? 'DW' : r.totalBalanceAL === 0 ? 'Habis' : 'Aktif'}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Calculation Methodology Note for Audits */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-[9px] text-slate-600 space-y-1">
            <p className="font-bold text-slate-800 flex items-center gap-1">
              <Info className="w-3.5 h-3.5 text-emerald-700" />
              <span>Ketentuan & Rumus Perhitungan Cuti Tahunan (Total Balance AL):</span>
            </p>
            <ul className="list-disc pl-4 space-y-0.5 text-slate-600">
              <li>
                <strong>Prorate Tahun Pertama:</strong> Karyawan baru yang bergabung di pertengahan tahun dihitung prorate dari bulan mulai bergabung sampai dengan Desember (12 - Bulan Masuk + 1). Contoh: Kristin mulai di bulan April = 12 - 4 + 1 = 9 hari (bukan full 12).
              </li>
              <li>
                <strong>Total Balance AL:</strong> Saldo Cuti Akumulasi = (Sisa Carry Forward Tahun Sebelumnya + Hak Cuti Prorate Tahun Ini) - Cuti Diambil Tahun Ini.
              </li>
              <li>
                <strong>Tahun Berikutnya:</strong> Diganti dengan Total Balance AL dan akumulasi dari tahun sebelumnya, di mana seluruh sisa Total Balance AL tahun ini diakumulasikan ke tahun berikutnya ditambah hak cuti penuh 12 hari (Total Proyeksi = 12 + Total Balance AL).
              </li>
            </ul>
          </div>

          {/* Official Signatures Verification Grid */}
          <div className="pt-4 border-t border-slate-300">
            <div className="grid grid-cols-3 gap-6 text-center text-[10px]">
              <div className="space-y-12">
                <div>
                  <p className="text-slate-500">Disiapkan & Diverifikasi Oleh:</p>
                  <p className="font-bold text-slate-800">Human Capital Officer / Admin</p>
                </div>
                <div className="border-t border-slate-400 mx-4 pt-1">
                  <p className="font-bold text-slate-900">Sarah Handayani, S.Psi.</p>
                  <p className="text-[9px] text-slate-500">Human Capital Manager GMCC</p>
                </div>
              </div>

              <div className="space-y-12">
                <div>
                  <p className="text-slate-500">Mengetahui & Menyetujui:</p>
                  <p className="font-bold text-slate-800">Department Head Terkait</p>
                </div>
                <div className="border-t border-slate-400 mx-4 pt-1">
                  <p className="font-bold text-slate-900">
                    {deptFilterId && deptFilterId !== 'ALL'
                      ? departments.find(d => d.id === deptFilterId)?.headName || 'Department Head'
                      : 'Para Kepala Departemen'}
                  </p>
                  <p className="text-[9px] text-slate-500">Head of Department</p>
                </div>
              </div>

              <div className="space-y-12">
                <div>
                  <p className="text-slate-500">Disahkan & Ditetapkan Oleh:</p>
                  <p className="font-bold text-slate-800">General Manager</p>
                </div>
                <div className="border-t border-slate-400 mx-4 pt-1">
                  <p className="font-bold text-slate-900">Bambang Wijaya, CHA</p>
                  <p className="text-[9px] text-slate-500">General Manager GMCC</p>
                </div>
              </div>
            </div>

            <div className="pt-4 mt-4 text-center text-[8.5px] text-slate-400 border-t border-slate-200">
              Dokumen ini dihasilkan secara terverifikasi dari Human Capital Management System (HCMS) Golo Mori Convention Center (GMCC) Labuan Bajo.
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
};
