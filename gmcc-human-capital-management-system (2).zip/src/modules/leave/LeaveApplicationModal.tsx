import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LeaveType } from '../../types';
import { X, Send, AlertCircle, Calendar, CheckCircle2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const LeaveApplicationModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { currentUser, employees, getLeaveBalanceSummary, submitLeaveApplication } = useApp();

  // If user is Staff, default to themselves. If HC/Admin, they can assist a staff member.
  const [employeeId, setEmployeeId] = useState(currentUser.employeeId || employees[0]?.id || '');
  const [leaveType, setLeaveType] = useState<LeaveType>('ANNUAL_LEAVE');
  const [startDate, setStartDate] = useState('2026-10-26');
  const [endDate, setEndDate] = useState('2026-10-28');
  const [reason, setReason] = useState('');
  const [contactDuringLeave, setContactDuringLeave] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  // Calculate working days (simple calculation excluding weekends)
  const calculateDays = (start: string, end: string): number => {
    if (!start || !end) return 0;
    const d1 = new Date(start);
    const d2 = new Date(end);
    if (d2 < d1) return 0;
    let count = 0;
    const cur = new Date(d1);
    while (cur <= d2) {
      const day = cur.getDay();
      if (day !== 0 && day !== 6) count++;
      cur.setDate(cur.getDate() + 1);
    }
    return count || 1;
  };

  const calculatedDays = calculateDays(startDate, endDate);
  const currentBalance = getLeaveBalanceSummary(employeeId, leaveType);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (calculatedDays <= 0) {
      setErrorMsg('Please select valid start and end dates.');
      return;
    }

    if (currentBalance.projectedBalance < calculatedDays) {
      setErrorMsg(`Insufficient leave balance. You have ${currentBalance.availableBalance} days available (${currentBalance.pendingReservation} days already pending approval).`);
      return;
    }

    const res = submitLeaveApplication({
      employeeId,
      leaveType,
      startDate,
      endDate,
      totalDays: calculatedDays,
      reason,
      contactDuringLeave
    });

    if (!res.success) {
      setErrorMsg(res.message);
    } else {
      setSuccessMsg(res.message);
      setTimeout(() => {
        setSuccessMsg('');
        onClose();
      }, 1500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h3 className="font-semibold text-slate-900 text-lg">Submit Leave Application</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Enforces 4-stage sequential approval: Staff → Dept Head → HC → GM
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {successMsg ? (
          <div className="p-8 text-center flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-3">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="font-semibold text-slate-900 text-base">Application Submitted</h4>
            <p className="text-xs text-slate-500 mt-1">{successMsg}</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            {errorMsg && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Applicant Selector */}
            <div>
              <label className="block font-medium text-slate-700 mb-1">Applying Employee *</label>
              <select
                value={employeeId}
                onChange={e => setEmployeeId(e.target.value)}
                disabled={currentUser.role === 'STAFF'}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden"
              >
                {employees.map(e => (
                  <option key={e.id} value={e.id}>
                    {e.fullName} ({e.id} - {e.departmentId.replace('DEP-', '')})
                  </option>
                ))}
              </select>
            </div>

            {/* Daily Worker Guidance Notice */}
            {(() => {
              const selectedEmp = employees.find(e => e.id === employeeId);
              if (selectedEmp?.employmentType === 'DAILY_WORKER') {
                return (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-900 text-[11px] space-y-1">
                    <span className="font-bold flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                      Daily Worker (Harian Lepas) Notice:
                    </span>
                    <span>
                      As a casual Daily Worker assigned to event shifts ({selectedEmp.assignedEvent || 'Event Operations'}), you do not accrue Annual Leave credits. Absences or shift swaps are coordinated directly with your Department Head ({selectedEmp.directSupervisorName || 'Dept Head'}).
                    </span>
                  </div>
                );
              }
              return null;
            })()}

            {/* Leave Type */}
            <div>
              <label className="block font-medium text-slate-700 mb-1">Leave Category *</label>
              <select
                value={leaveType}
                onChange={e => setLeaveType(e.target.value as LeaveType)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden"
              >
                <option value="ANNUAL_LEAVE">Annual Leave (Cuti Tahunan)</option>
                <option value="EXTRA_OFF">Extra Off (Overtime / Rest Day Compensation)</option>
                <option value="PUBLIC_HOLIDAY_COMPENSATORY">Public Holiday Duty Compensatory</option>
                <option value="SPECIAL_LEAVE">Special / Marriage / Bereavement Leave</option>
              </select>
            </div>

            {/* Live Balance Card */}
            <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-emerald-900 font-semibold block">
                  Current Available {leaveType.replace('_', ' ')}:
                </span>
                <span className="text-[11px] text-emerald-700">
                  {currentBalance.availableBalance} days available ({currentBalance.pendingReservation} days reserved in pending workflow)
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs text-emerald-800 block">Projected After:</span>
                <span className="text-sm font-bold text-emerald-950">
                  {currentBalance.availableBalance - calculatedDays} days
                </span>
              </div>
            </div>

            {/* Date Range */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Start Date *</label>
                <input
                  type="date"
                  required
                  value={startDate}
                  onChange={e => setStartDate(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">End Date *</label>
                <input
                  type="date"
                  required
                  value={endDate}
                  onChange={e => setEndDate(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700">
              <span>Calculated Working Days:</span>
              <span className="font-bold text-slate-900">{calculatedDays} day(s)</span>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Reason for Leave *</label>
              <textarea
                rows={3}
                required
                placeholder="State clear purpose of leave..."
                value={reason}
                onChange={e => setReason(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Contact Address / Phone During Leave</label>
              <input
                type="text"
                placeholder="+62 8xx or family address"
                value={contactDuringLeave}
                onChange={e => setContactDuringLeave(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
              />
            </div>

            {/* Workflow Notice */}
            <div className="p-3 bg-slate-100 rounded-lg text-slate-600 text-[11px] space-y-1">
              <span className="font-semibold block text-slate-800">Sequential Workflow Path:</span>
              <div>1. Submitted by Staff → Status: <code>PENDING_DEPT_HEAD</code></div>
              <div>2. Reviewed by Department Head → Forward to HC</div>
              <div>3. Verified by Human Capital → Forward to GM</div>
              <div>4. Final sanction by General Manager → <strong>Approved & Balance Deducted</strong></div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                Submit Application
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
