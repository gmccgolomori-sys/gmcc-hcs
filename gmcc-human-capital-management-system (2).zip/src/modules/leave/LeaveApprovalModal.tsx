import React, { useState } from 'react';
import { LeaveApplication } from '../../types';
import { useApp } from '../../context/AppContext';
import { 
  X, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  AlertCircle, 
  Calendar, 
  User, 
  Clock,
  ShieldCheck,
  FileText
} from 'lucide-react';

import { LeavePdfFormModal } from './LeavePdfFormModal';

interface Props {
  application: LeaveApplication | null;
  onClose: () => void;
}

export const LeaveApprovalModal: React.FC<Props> = ({ application, onClose }) => {
  const { currentUser, processLeaveApproval, getLeaveBalanceSummary } = useApp();

  const [comment, setComment] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [showPdfModal, setShowPdfModal] = useState(false);

  if (!application) return null;

  const balance = getLeaveBalanceSummary(application.employeeId, application.leaveType);

  // Check whether current user is allowed to act at this stage
  const canAct = (() => {
    // Cannot approve own request
    if (currentUser.employeeId === application.employeeId) return false;

    if (application.status === 'PENDING_DEPT_HEAD') {
      return currentUser.role === 'DEPT_HEAD' || currentUser.role === 'ADMIN';
    }
    if (application.status === 'PENDING_HC') {
      return currentUser.role === 'HC' || currentUser.role === 'ADMIN';
    }
    if (application.status === 'PENDING_GM') {
      return currentUser.role === 'GM' || currentUser.role === 'ADMIN';
    }
    return false;
  })();

  const handleAction = (action: 'APPROVE' | 'REJECT' | 'RETURN') => {
    setErrorMsg('');

    if ((action === 'REJECT' || action === 'RETURN') && !comment.trim()) {
      setErrorMsg('Mandatory reason/comment is required when rejecting or returning an application.');
      return;
    }

    const res = processLeaveApproval(application.id, action, comment);
    if (!res.success) {
      setErrorMsg(res.message);
    } else {
      setSuccessMsg(res.message);
      setTimeout(() => {
        setSuccessMsg('');
        onClose();
      }, 1500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto border border-slate-200">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h3 className="font-semibold text-slate-900 text-lg">Leave Approval Decision</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Request ID: <span className="font-mono text-slate-700">{application.id}</span>
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {successMsg ? (
          <div className="p-8 text-center flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-3">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="font-semibold text-slate-900 text-base">Decision Recorded</h4>
            <p className="text-xs text-slate-500 mt-1">{successMsg}</p>
          </div>
        ) : (
          <div className="p-6 space-y-5 text-xs">
            {errorMsg && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Application Overview */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{application.employeeName}</h4>
                  <p className="text-slate-500 text-[11px]">{application.position} · {application.departmentName}</p>
                </div>
                <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                  {application.leaveType.replace('_', ' ')}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200">
                <div>
                  <span className="text-slate-400 block">Requested Period:</span>
                  <span className="font-semibold text-slate-800">
                    {new Date(application.startDate).toLocaleDateString('en-GB')} – {new Date(application.endDate).toLocaleDateString('en-GB')}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Total Working Days:</span>
                  <span className="font-bold text-slate-900 text-sm">{application.totalDays} day(s)</span>
                </div>
              </div>

              <div>
                <span className="text-slate-400 block">Purpose / Reason:</span>
                <p className="text-slate-700 italic bg-white p-2 rounded border border-slate-200 mt-0.5">
                  "{application.reason}"
                </p>
              </div>

              {application.contactDuringLeave && (
                <div>
                  <span className="text-slate-400 block">Contact during leave:</span>
                  <span className="text-slate-700">{application.contactDuringLeave}</span>
                </div>
              )}
            </div>

            {/* Balance Calculation Snapshot */}
            <div className="p-3 bg-slate-900 text-slate-100 rounded-lg text-xs space-y-1">
              <div className="text-emerald-400 font-semibold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" />
                Ledger Verification Engine
              </div>
              <div className="grid grid-cols-3 gap-2 pt-1 text-[11px]">
                <div>
                  <span className="text-slate-400 block">Available Balance:</span>
                  <span className="font-bold text-white text-sm">{balance.availableBalance} days</span>
                </div>
                <div>
                  <span className="text-slate-400 block">This Request:</span>
                  <span className="font-bold text-amber-300 text-sm">-{application.totalDays} days</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Projected Balance:</span>
                  <span className="font-bold text-emerald-300 text-sm">
                    {balance.availableBalance - application.totalDays} days
                  </span>
                </div>
              </div>
            </div>

            {/* Sequential Approval Stage Tracker */}
            <div>
              <h5 className="font-semibold text-slate-800 mb-2 uppercase text-[11px] tracking-wider">
                Sequential Workflow Audit Trail
              </h5>
              <div className="space-y-2 border border-slate-200 rounded-lg p-3 bg-slate-50/50">
                <div className="flex items-center justify-between text-[11px] pb-1 border-b border-slate-200">
                  <span className="font-medium text-slate-700">Stage 1: Staff Application</span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Submitted ({new Date(application.submittedAt).toLocaleDateString('en-GB')})
                  </span>
                </div>

                {/* Stage 2: Dept Head */}
                {(() => {
                  const deptAction = application.approvalHistory.find(h => h.stage === 'DEPT_HEAD');
                  return (
                    <div className="flex flex-col gap-0.5 text-[11px] py-1 border-b border-slate-200">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-slate-700">Stage 2: Department Head</span>
                        {deptAction ? (
                          <span className="text-emerald-700 font-semibold">Approved by {deptAction.actorName}</span>
                        ) : application.status === 'PENDING_DEPT_HEAD' ? (
                          <span className="text-amber-700 font-semibold">Awaiting Dept Head Decision</span>
                        ) : (
                          <span className="text-slate-400">Pending</span>
                        )}
                      </div>
                      {deptAction?.comment && (
                        <p className="text-[10px] text-slate-500 italic pl-2">Comment: "{deptAction.comment}"</p>
                      )}
                    </div>
                  );
                })()}

                {/* Stage 3: HC */}
                {(() => {
                  const hcAction = application.approvalHistory.find(h => h.stage === 'HC');
                  return (
                    <div className="flex flex-col gap-0.5 text-[11px] py-1 border-b border-slate-200">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-slate-700">Stage 3: Human Capital (HC)</span>
                        {hcAction ? (
                          <span className="text-emerald-700 font-semibold">Approved by {hcAction.actorName}</span>
                        ) : application.status === 'PENDING_HC' ? (
                          <span className="text-amber-700 font-semibold">Awaiting HC Verification</span>
                        ) : (
                          <span className="text-slate-400">Pending</span>
                        )}
                      </div>
                      {hcAction?.comment && (
                        <p className="text-[10px] text-slate-500 italic pl-2">Comment: "{hcAction.comment}"</p>
                      )}
                    </div>
                  );
                })()}

                {/* Stage 4: GM */}
                {(() => {
                  const gmAction = application.approvalHistory.find(h => h.stage === 'GM');
                  return (
                    <div className="flex flex-col gap-0.5 text-[11px] pt-1">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-slate-700">Stage 4: General Manager (Final Sanction & Deduction)</span>
                        {gmAction ? (
                          <span className="text-emerald-700 font-bold">Approved by {gmAction.actorName}</span>
                        ) : application.status === 'PENDING_GM' ? (
                          <span className="text-amber-700 font-bold">Awaiting General Manager Approval</span>
                        ) : (
                          <span className="text-slate-400">Pending</span>
                        )}
                      </div>
                      {gmAction?.comment && (
                        <p className="text-[10px] text-slate-500 italic pl-2">Comment: "{gmAction.comment}"</p>
                      )}
                    </div>
                  );
                })()}
              </div>
            </div>

            {/* Decision Comments */}
            {canAct ? (
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Your Decision Remarks / Justification
                  {(application.status !== 'APPROVED') && (
                    <span className="text-slate-400 font-normal"> (Required for Reject/Return)</span>
                  )}
                </label>
                <textarea
                  rows={2}
                  placeholder={`Enter approval remarks or reason as ${currentUser.name} (${currentUser.role})...`}
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-600"
                />
              </div>
            ) : (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-[11px]">
                {currentUser.employeeId === application.employeeId ? (
                  <span>Policy Restriction: You cannot approve your own leave request.</span>
                ) : (
                  <span>
                    This application currently requires action from: <strong>{application.status.replace('PENDING_', '')}</strong>. 
                    Switch to the authorized role above to execute approval.
                  </span>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Close
                </button>

                {application.status === 'APPROVED' && (
                  <button
                    type="button"
                    onClick={() => setShowPdfModal(true)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-emerald-950 bg-emerald-100 hover:bg-emerald-200 rounded-lg border border-emerald-300 transition-colors"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    Extract Official PDF Form
                  </button>
                )}
              </div>

              {canAct && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleAction('RETURN')}
                    className="inline-flex items-center gap-1 px-3 py-2 text-xs font-medium text-amber-800 bg-amber-50 hover:bg-amber-100 rounded-lg border border-amber-200"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Return for Revision
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAction('REJECT')}
                    className="inline-flex items-center gap-1 px-3 py-2 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg border border-rose-200"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    Reject
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAction('APPROVE')}
                    className="inline-flex items-center gap-1 px-4 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {application.status === 'PENDING_GM' ? 'Grant Final Sanction & Deduct' : 'Approve & Route Forward'}
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* PDF Form Viewer */}
      {showPdfModal && (
        <LeavePdfFormModal
          application={application}
          onClose={() => setShowPdfModal(false)}
        />
      )}
    </div>
  );
};
