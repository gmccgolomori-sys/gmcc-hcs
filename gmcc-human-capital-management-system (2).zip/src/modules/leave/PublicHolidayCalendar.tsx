import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Calendar, CheckCircle2, ShieldCheck, Info } from 'lucide-react';

export const PublicHolidayCalendar: React.FC = () => {
  const { holidays, currentUser } = useApp();
  const [filterType, setFilterType] = useState<string>('ALL');

  const filteredHolidays = holidays.filter(h => {
    if (filterType !== 'ALL' && h.type !== filterType) return false;
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Policy explanation notice */}
      <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3">
        <Info className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
        <div className="text-xs text-emerald-950">
          <span className="font-semibold block mb-0.5">GMCC Public Holiday & Compensatory Policy:</span>
          Under GMCC convention center operational guidelines, public holidays do not automatically generate extra leave. 
          When an employee is formally rostered and works on a declared Public Holiday during a summit/convention, 
          an authorized <strong>Public Holiday Compensatory Credit</strong> is posted into their ledger by Human Capital with duty proof.
        </div>
      </div>

      {/* Holiday list card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-slate-900 text-sm">Official Public Holidays (Year 2026)</h3>
            <p className="text-xs text-slate-500">Asia/Makassar Timezone (WITA)</p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
              className="text-xs rounded-lg border border-slate-300 px-3 py-1.5 bg-white text-slate-700 focus:outline-hidden"
            >
              <option value="ALL">All Holidays & Cuti Bersama</option>
              <option value="NATIONAL">National Public Holidays</option>
              <option value="COLLECTIVE_LEAVE">Collective Leave (Cuti Bersama)</option>
            </select>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {filteredHolidays.map(holiday => (
            <div key={holiday.id} className="p-3.5 flex items-center justify-between hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-slate-100 text-slate-700 flex flex-col items-center justify-center font-mono text-[11px] shrink-0">
                  <span className="text-[9px] text-slate-400 uppercase">
                    {new Date(holiday.date).toLocaleDateString('en-GB', { month: 'short' })}
                  </span>
                  <span className="font-bold leading-none">
                    {new Date(holiday.date).getDate()}
                  </span>
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-slate-900">{holiday.name}</h4>
                  <span className="text-[10px] text-slate-400">
                    {new Date(holiday.date).toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric' })}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-medium px-2 py-0.5 rounded border ${
                  holiday.type === 'NATIONAL' 
                    ? 'bg-blue-50 text-blue-700 border-blue-200' 
                    : 'bg-purple-50 text-purple-700 border-purple-200'
                }`}>
                  {holiday.type === 'NATIONAL' ? 'National Holiday' : 'Cuti Bersama'}
                </span>
                {holiday.isOfficial && (
                  <span className="text-[10px] text-emerald-700 font-medium flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Official Gazette
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
