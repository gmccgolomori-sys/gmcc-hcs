import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { EmployeeLeaveReviewReport, Employee } from '../../types';
import { 
  CalendarDays, 
  Search, 
  Filter, 
  Download, 
  Printer, 
  History, 
  ShieldCheck, 
  Building2, 
  UserCheck, 
  AlertTriangle, 
  Clock, 
  ArrowRight, 
  Sparkles,
  ChevronDown,
  Layers,
  FileSpreadsheet,
  CheckCircle2,
  SlidersHorizontal,
  PlusCircle,
  TableProperties
} from 'lucide-react';
import { LeaveLedgerModal } from './LeaveLedgerModal';
import { AdminLedgerModal } from '../admin/AdminLedgerModal';
import { LeavePrintReportModal } from './LeavePrintReportModal';

export const LeaveReviewDashboard: React.FC = () => {
  const { 
    currentUser, 
    departments, 
    getAnnualLeaveReviewData 
  } = useApp();

  const [activeViewTab, setActiveViewTab] = useState<'yearly-summary' | 'multi-year-matrix'>('yearly-summary');
  const [selectedYear, setSelectedYear] = useState<number>(2026); // Default 2026 as current year
  const [selectedDeptId, setSelectedDeptId] = useState<string>(
    currentUser.role === 'DEPT_HEAD' && currentUser.departmentId 
      ? currentUser.departmentId 
      : 'ALL'
  );
  const [contractTypeFilter, setContractTypeFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedEmployeeForLedger, setSelectedEmployeeForLedger] = useState<string | null>(null);
  const [selectedEmployeeForAdjustment, setSelectedEmployeeForAdjustment] = useState<Employee | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Scoping enforcement: Dept Head can only see their own department
  const effectiveDeptId = currentUser.role === 'DEPT_HEAD' && currentUser.departmentId 
    ? currentUser.departmentId 
    : selectedDeptId;

  // Retrieve calculated annual leave reports for current selected year
  const allReports = getAnnualLeaveReviewData(selectedYear, effectiveDeptId);

  // Multi-year data for matrix view (2024, 2025, 2026)
  const reports2024 = getAnnualLeaveReviewData(2024, effectiveDeptId);
  const reports2025 = getAnnualLeaveReviewData(2025, effectiveDeptId);
  const reports2026 = getAnnualLeaveReviewData(2026, effectiveDeptId);

  // Filter by contract type and search query
  const filteredReports = allReports.filter(rep => {
    if (contractTypeFilter !== 'ALL' && rep.employee.employmentType !== contractTypeFilter) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = rep.employee.fullName.toLowerCase().includes(q);
      const matchEmpNo = rep.employee.employeeNumber.toLowerCase().includes(q);
      const matchTitle = rep.employee.jobTitle.toLowerCase().includes(q);
      const matchContract = rep.contract?.contractNumber?.toLowerCase().includes(q);
      return matchName || matchEmpNo || matchTitle || matchContract;
    }
    return true;
  });

  // Calculate high-level summary KPIs
  const totalEmployeesInScope = filteredReports.length;
  const eligibleEmployees = filteredReports.filter(r => r.employee.employmentType !== 'DAILY_WORKER');
  const totalEntitlements = eligibleEmployees.reduce((sum, r) => sum + r.entitlementDays, 0);
  const totalTaken = eligibleEmployees.reduce((sum, r) => sum + r.takenDays, 0);
  const totalCarryForward = eligibleEmployees.reduce((sum, r) => sum + r.previousYearCarryForward, 0);
  const totalAccumulatedBalanceAL = eligibleEmployees.reduce((sum, r) => sum + r.totalBalanceAL, 0);
  const highRemainingCount = eligibleEmployees.filter(r => r.totalBalanceAL >= 6).length;

  const currentDeptMeta = departments.find(d => d.id === effectiveDeptId);

  const handleExportCSV = () => {
    const headers = [
      "No",
      "NIK",
      "Nama Karyawan",
      "Departemen",
      "Jabatan",
      "Tipe Karyawan",
      "Masa Kontrak Berjalan",
      `Carry Forward Th Lalu`,
      `Hak Cuti Prorate ${selectedYear}`,
      `Sudah Diambil ${selectedYear}`,
      `Sisa Cuti Th ${selectedYear}`,
      `Total Balance AL (Akumulasi s/d Saat Ini)`,
      `Tahun Berikutnya (${selectedYear + 1}) Total AL`,
      `Pending`
    ];

    const rows = filteredReports.map((rep, idx) => {
      const emp = rep.employee;
      const deptName = departments.find(d => d.id === emp.departmentId)?.name || emp.departmentId;
      const contractDates = rep.contract ? `${rep.contract.startDate} s/d ${rep.contract.endDate || '-'}` : `${emp.joinDate} (Join)`;
      return [
        idx + 1,
        `"${emp.employeeNumber || emp.id}"`,
        `"${emp.fullName}"`,
        `"${deptName}"`,
        `"${emp.jobTitle}"`,
        `"${emp.employmentType}"`,
        `"${contractDates}"`,
        rep.previousYearCarryForward,
        rep.entitlementDays,
        rep.takenDays,
        rep.remainingDays,
        rep.totalBalanceAL,
        rep.nextYearProjectedTotal,
        rep.pendingDays > 0 ? rep.pendingDays : ""
      ].join(",");
    });

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers.join(","), ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `GMCC_Annual_Leave_Report_${selectedYear}_${effectiveDeptId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportMultiYearCSV = () => {
    const headers = [
      "No",
      "NIK",
      "Nama Karyawan",
      "Departemen",
      "Jabatan",
      "Tipe",
      "Masa Kontrak Berjalan (Join)",
      "Total Kuota 2024",
      "Cuti Diambil 2024",
      "Sisa Cuti 2024",
      "Total Kuota 2025",
      "Cuti Diambil 2025",
      "Sisa Cuti 2025 (Carry Forward)",
      "Total Kuota 2026 (per Okt)",
      "Cuti Diambil 2026",
      "Hak Cuti Prorate s/d Saat Ini (Total Balance AL)",
      "Tahun Berikutnya (2027 Proyeksi Total AL)"
    ];

    const rows = filteredReports.map((r26, idx) => {
      const emp = r26.employee;
      const dept = departments.find(d => d.id === emp.departmentId)?.name || emp.departmentId;
      const r24 = reports2024.find(r => r.employee.id === emp.id);
      const r25 = reports2025.find(r => r.employee.id === emp.id);
      const contractDates = r26.contract ? `${r26.contract.startDate} s/d ${r26.contract.endDate || '-'}` : `${emp.joinDate} (Join)`;

      return [
        idx + 1,
        `"${emp.employeeNumber || emp.id}"`,
        `"${emp.fullName}"`,
        `"${dept}"`,
        `"${emp.jobTitle}"`,
        `"${emp.employmentType}"`,
        `"${contractDates}"`,
        r24?.entitlementDays || 0,
        r24?.takenDays || 0,
        r24?.remainingDays || 0,
        r25?.entitlementDays || 0,
        r25?.takenDays || 0,
        r25?.remainingDays || 0,
        r26.entitlementDays,
        r26.takenDays,
        r26.totalBalanceAL,
        r26.nextYearProjectedTotal
      ].join(",");
    });

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers.join(","), ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `GMCC_Matriks_Cuti_MultiTahun_2024_2026.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    setIsPrintModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header and Scope Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 uppercase tracking-wider mb-1">
            <Building2 className="w-3.5 h-3.5" />
            <span>
              {currentUser.role === 'DEPT_HEAD' 
                ? `Departmental Review (${currentDeptMeta?.name || currentUser.departmentId})`
                : 'Executive & Human Capital Oversight (Company-Wide)'}
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <span>Review Cuti Tahunan & Laporan Dashboard</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold">
              Data per Oktober {selectedYear}
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Penghitungan prorate hak cuti berjalan (1 hari/bulan masa kerja aktif s/d bulan saat ini) dan akumulasi carry forward sisa cuti tahun sebelumnya.
          </p>
        </div>

        {/* Action Buttons: Year Selector, Print, Export */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Year Switcher (Active on Yearly Summary tab) */}
          {activeViewTab === 'yearly-summary' && (
            <div className="inline-flex rounded-lg border border-slate-300 bg-white p-0.5 shadow-xs">
              {[2024, 2025, 2026].map(yr => (
                <button
                  key={yr}
                  onClick={() => setSelectedYear(yr)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${
                    selectedYear === yr
                      ? 'bg-emerald-800 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Tahun {yr}
                </button>
              ))}
            </div>
          )}

          <button
            onClick={activeViewTab === 'multi-year-matrix' ? handleExportMultiYearCSV : handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-xs transition-colors"
            title="Download CSV Spreadsheet"
          >
            <Download className="w-3.5 h-3.5 text-emerald-700" />
            Export CSV
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-xs transition-colors"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-400" />
            Cetak Laporan Resmi
          </button>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setActiveViewTab('yearly-summary')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all ${
            activeViewTab === 'yearly-summary'
              ? 'border-emerald-700 text-emerald-800 bg-emerald-50/50 rounded-t-lg'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <CalendarDays className="w-4 h-4" />
          <span>Review Tahunan & Total Balance AL ({selectedYear})</span>
        </button>

        <button
          onClick={() => setActiveViewTab('multi-year-matrix')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold border-b-2 transition-all ${
            activeViewTab === 'multi-year-matrix'
              ? 'border-emerald-700 text-emerald-800 bg-emerald-50/50 rounded-t-lg'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <TableProperties className="w-4 h-4 text-emerald-700" />
          <span>Matriks Multi-Tahun (Format Excel GMCC: 2024 s/d 2026)</span>
          <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-emerald-700 text-white font-bold">
            Excel View
          </span>
        </button>
      </div>

      {/* Scoping Notice for Dept Head */}
      {currentUser.role === 'DEPT_HEAD' && (
        <div className="p-3.5 rounded-xl bg-teal-50 border border-teal-200 text-xs text-teal-900 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-teal-700 shrink-0" />
            <span>
              <strong>Akses Terproteksi Departemen:</strong> Anda masuk sebagai <strong>{currentUser.name}</strong>. Anda hanya dapat mereview kuota dan sisa cuti staf di bawah departemen <strong>{currentDeptMeta?.name || currentUser.departmentId}</strong>.
            </span>
          </div>
          <span className="text-[11px] font-mono font-semibold bg-white px-2 py-0.5 rounded border border-teal-300 text-teal-800 shrink-0">
            {filteredReports.length} Staf Terdata
          </span>
        </div>
      )}

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
            Total Staf
          </span>
          <div className="text-2xl font-bold text-slate-900 mt-1 flex items-baseline gap-1">
            {totalEmployeesInScope}
            <span className="text-xs font-normal text-slate-500">orang</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {eligibleEmployees.length} berhak cuti tahunan
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider block">
            Carry Forward Th. Lalu
          </span>
          <div className="text-2xl font-bold text-slate-800 mt-1 flex items-baseline gap-1">
            {totalCarryForward}
            <span className="text-xs font-normal text-slate-500">hari</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Sisa cuti akumulasi dari {selectedYear - 1}
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider block">
            Hak Prorate ({selectedYear})
          </span>
          <div className="text-2xl font-bold text-emerald-700 mt-1 flex items-baseline gap-1">
            {totalEntitlements}
            <span className="text-xs font-normal text-slate-500">hari</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Prorate s/d Oktober ({eligibleEmployees[0]?.prorateMonths || 10}/12 bln)
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-semibold text-indigo-700 uppercase tracking-wider block">
            Cuti Sudah Diambil
          </span>
          <div className="text-2xl font-bold text-indigo-700 mt-1 flex items-baseline gap-1">
            {totalTaken}
            <span className="text-xs font-normal text-slate-500">hari ({totalEntitlements > 0 ? Math.round((totalTaken / totalEntitlements) * 100) : 0}%)</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Approved & dipotong dari ledger
          </span>
        </div>

        <div className="bg-gradient-to-tr from-emerald-50 to-teal-50 p-4 rounded-xl border border-emerald-300 shadow-xs col-span-2 sm:col-span-1">
          <span className="text-[11px] font-bold text-emerald-900 uppercase tracking-wider block">
            Total Balance AL
          </span>
          <div className="text-2xl font-black text-emerald-950 mt-1 flex items-baseline gap-1">
            {totalAccumulatedBalanceAL}
            <span className="text-xs font-bold text-emerald-800">hari total</span>
          </div>
          <span className="text-[11px] text-emerald-700 mt-1 block font-medium">
            Akumulasi CF + Hak Prorate Berjalan
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex-1 flex flex-col sm:flex-row items-center gap-3">
          {/* Search */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari nama, NIK, jabatan, kontrak..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden focus:border-emerald-700"
            />
          </div>

          {/* Department Filter (Only for HC, GM, Admin, Auditor) */}
          {currentUser.role !== 'DEPT_HEAD' && (
            <div className="w-full sm:w-56">
              <select
                value={selectedDeptId}
                onChange={e => setSelectedDeptId(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-slate-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden font-medium text-slate-700"
              >
                <option value="ALL">🏢 Semua Departemen (All GMCC)</option>
                {departments.map(dept => (
                  <option key={dept.id} value={dept.id}>
                    {dept.name} ({dept.code})
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Contract / Employment Type Filter */}
          <div className="w-full sm:w-44">
            <select
              value={contractTypeFilter}
              onChange={e => setContractTypeFilter(e.target.value)}
              className="w-full text-xs px-3 py-2 bg-slate-50 rounded-lg border border-slate-200 focus:bg-white focus:outline-hidden font-medium text-slate-700"
            >
              <option value="ALL">Semua Jenis Staf</option>
              <option value="PKWT">PKWT (Kontrak)</option>
              <option value="DAILY_WORKER">Daily Worker (DW)</option>
            </select>
          </div>
        </div>

        <div className="text-xs text-slate-500 font-mono text-right shrink-0">
          Menampilkan <strong>{filteredReports.length}</strong> karyawan
        </div>
      </div>

      {/* VIEW TAB 1: Ringkasan Review Tahunan & Total Balance AL */}
      {activeViewTab === 'yearly-summary' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          {/* Mobile Interactive Cards (md:hidden) */}
          <div className="md:hidden divide-y divide-slate-200 p-2 space-y-3">
            {filteredReports.length === 0 ? (
              <div className="py-10 text-center text-slate-400">
                <CalendarDays className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                Tidak ada data cuti karyawan yang cocok.
              </div>
            ) : (
              filteredReports.map(rep => {
                const emp = rep.employee;
                const dept = departments.find(d => d.id === emp.departmentId);
                const isDW = emp.employmentType === 'DAILY_WORKER';

                return (
                  <div key={emp.id} className="bg-slate-50/80 rounded-xl p-3.5 border border-slate-200 shadow-2xs space-y-2.5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={emp.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                          alt={emp.fullName}
                          className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                        />
                        <div>
                          <h4 className="font-bold text-xs text-slate-900 leading-tight">{emp.fullName}</h4>
                          <p className="text-[11px] text-slate-600 truncate">{emp.jobTitle}</p>
                          <div className="flex items-center gap-1.5 mt-0.5 text-[10px] text-slate-400 font-mono">
                            <span>{emp.employeeNumber || emp.id}</span>
                            <span>·</span>
                            <span className="font-semibold text-slate-700">{dept?.code || emp.departmentId}</span>
                          </div>
                        </div>
                      </div>

                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border shrink-0 ${
                        isDW ? 'bg-purple-50 text-purple-800 border-purple-200' : 'bg-amber-50 text-amber-800 border-amber-200'
                      }`}>
                        {isDW ? 'Daily Worker' : 'PKWT Kontrak'}
                      </span>
                    </div>

                    {isDW ? (
                      <div className="p-2 bg-slate-100 rounded-lg text-[11px] text-slate-500 italic text-center">
                        Daily Worker tidak mendapatkan hak cuti tahunan (Upah harian lepas)
                      </div>
                    ) : (
                      <div className="space-y-2 pt-1">
                        <div className="grid grid-cols-5 gap-1 text-center text-xs">
                          <div className="bg-slate-100 border border-slate-200 rounded-lg p-1">
                            <span className="text-[8px] text-slate-500 font-medium block">CF Th Lalu</span>
                            <span className="font-bold text-slate-800 text-xs">{rep.previousYearCarryForward} hr</span>
                          </div>
                          <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-1">
                            <span className="text-[8px] text-emerald-800 font-medium block">Hak Prorate</span>
                            <span className="font-bold text-emerald-950 text-xs">{rep.entitlementDays} hr</span>
                          </div>
                          <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-1">
                            <span className="text-[8px] text-indigo-800 font-medium block">Diambil</span>
                            <span className="font-bold text-indigo-950 text-xs">{rep.takenDays} hr</span>
                            {rep.pendingDays > 0 && (
                              <span className="text-[8px] text-amber-600 block font-bold">+{rep.pendingDays}</span>
                            )}
                          </div>
                          <div className="bg-emerald-100/80 border border-emerald-300 rounded-lg p-1">
                            <span className="text-[8px] text-emerald-900 font-bold block">Total AL</span>
                            <span className="font-black text-emerald-950 text-xs">{rep.totalBalanceAL} hr</span>
                          </div>
                          <div className="bg-blue-100/80 border border-blue-300 rounded-lg p-1">
                            <span className="text-[8px] text-blue-900 font-bold block">Th {selectedYear + 1}</span>
                            <span className="font-black text-blue-950 text-xs">{rep.nextYearProjectedTotal} hr</span>
                          </div>
                        </div>

                        <div className="text-[10px] text-slate-500 bg-white p-2 rounded border border-slate-200 space-y-0.5">
                          <div><strong>Keterangan:</strong> {rep.totalBalanceALExplanation || rep.prorateExplanation}</div>
                          <div className="text-blue-800 font-medium"><strong>Th Berikutnya ({selectedYear + 1}):</strong> {rep.nextYearProjectedTotal} hr (Hak Baru: {rep.nextYearEntitlement} hr + Akumulasi: {rep.nextYearCarryForward} hr)</div>
                        </div>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 text-xs">
                      <span className="text-[10px] text-slate-500 font-mono">
                        {rep.contract?.endDate ? `Exp: ${rep.contract.endDate}` : `${emp.joinDate} (Join)`}
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setSelectedEmployeeForLedger(emp.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg shadow-2xs hover:bg-slate-100"
                        >
                          <History className="w-3.5 h-3.5 text-slate-500" />
                          Ledger
                        </button>

                        {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'DEPT_HEAD') && !isDW && (
                          <button
                            onClick={() => setSelectedEmployeeForAdjustment(emp)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-emerald-800 bg-emerald-100/70 border border-emerald-300 rounded-lg shadow-2xs hover:bg-emerald-200"
                          >
                            <PlusCircle className="w-3.5 h-3.5 text-emerald-700" />
                            Adjust
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Desktop Table View */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">Nama Karyawan</th>
                  <th className="py-3 px-3">Dept</th>
                  <th className="py-3 px-3">Jabatan</th>
                  <th className="py-3 px-3">Tipe & Masa Kontrak</th>
                  <th className="py-3 px-3 text-center bg-slate-100 text-slate-800">
                    Sisa Th. Lalu<br /><span className="text-[9px] font-normal text-slate-500">(Carry Forward)</span>
                  </th>
                  <th className="py-3 px-3 text-center bg-emerald-50 text-emerald-900">
                    Hak Cuti Prorate<br /><span className="text-[9px] font-normal text-emerald-700">({selectedYear} s/d {filteredReports[0]?.asOfMonthName || 'Okt'})</span>
                  </th>
                  <th className="py-3 px-3 text-center bg-indigo-50 text-indigo-900">
                    Sudah Diambil
                  </th>
                  <th className="py-3 px-3 text-center bg-amber-50 text-amber-900">
                    Sisa {selectedYear}
                  </th>
                  <th className="py-3 px-3 text-center bg-emerald-100/70 text-emerald-950 font-black">
                    Total Balance AL<br /><span className="text-[9px] font-normal text-emerald-800">(Akumulasi s/d Saat Ini)</span>
                  </th>
                  <th className="py-3 px-3 text-center bg-blue-100/60 text-blue-950 font-bold">
                    Tahun Berikutnya ({selectedYear + 1})<br /><span className="text-[9px] font-normal text-blue-800">(Hak 12 + Akumulasi Th Lalu)</span>
                  </th>
                  <th className="py-3 px-4 text-right print:hidden">Aksi & Ledger</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredReports.length === 0 ? (
                  <tr>
                    <td colSpan={11} className="py-12 text-center text-slate-400">
                      <CalendarDays className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                      Tidak ada data cuti karyawan yang cocok dengan kriteria pencarian.
                    </td>
                  </tr>
                ) : (
                  filteredReports.map(rep => {
                    const emp = rep.employee;
                    const dept = departments.find(d => d.id === emp.departmentId);
                    const isDW = emp.employmentType === 'DAILY_WORKER';

                    return (
                      <tr key={emp.id} className="hover:bg-slate-50/70 transition-colors">
                        {/* 1. Nama Karyawan & NIK */}
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={emp.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                              alt={emp.fullName}
                              className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0"
                            />
                            <div className="min-w-0">
                              <span className="font-semibold text-slate-900 block truncate">
                                {emp.fullName}
                              </span>
                              <span className="text-[10px] font-mono text-slate-400 block">
                                {emp.employeeNumber || emp.id}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* 2. Dept */}
                        <td className="py-3 px-3">
                          <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
                            {dept?.code || emp.departmentId}
                          </span>
                        </td>

                        {/* 3. Jabatan */}
                        <td className="py-3 px-3 text-slate-700 max-w-[160px] truncate" title={emp.jobTitle}>
                          {emp.jobTitle}
                        </td>

                        {/* 4. Tipe & Masa Kontrak */}
                        <td className="py-3 px-3">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1.5">
                              <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                                emp.employmentType === 'PKWT'
                                  ? 'bg-amber-100 text-amber-800'
                                  : emp.employmentType === 'DAILY_WORKER'
                                  ? 'bg-purple-100 text-purple-800'
                                  : 'bg-slate-100 text-slate-700'
                              }`}>
                                {emp.employmentType}
                              </span>
                              {rep.contract && (
                                <span className="text-[10px] text-slate-400 font-mono truncate max-w-[90px]" title={rep.contract.contractNumber}>
                                  P{rep.contract.termNumber || 1}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-500 block">
                              {isDW
                                ? `Daily Rate: Rp ${(emp.dailyRate || 250000).toLocaleString('id-ID')}`
                                : rep.contract?.endDate
                                ? `s/d ${rep.contract.endDate}`
                                : `${emp.joinDate} (Join)`}
                            </span>
                          </div>
                        </td>

                        {/* 5. Carry Forward Th. Lalu */}
                        <td className="py-3 px-3 text-center bg-slate-50">
                          {isDW ? (
                            <span className="text-slate-400 text-[11px]">-</span>
                          ) : (
                            <span className="font-semibold text-slate-800 text-xs">
                              {rep.previousYearCarryForward} hari
                            </span>
                          )}
                        </td>

                        {/* 6. Hak Cuti Prorate */}
                        <td className="py-3 px-3 text-center bg-emerald-50/50">
                          {isDW ? (
                            <span className="text-slate-400 text-[11px] italic">N/A (DW)</span>
                          ) : (
                            <div className="space-y-0.5">
                              <span className="font-bold text-slate-900 text-sm">
                                {rep.entitlementDays}{' '}
                                <span className="text-[10px] font-normal text-slate-500">hari</span>
                              </span>
                              {rep.prorateMonths !== undefined && (
                                <span className="block text-[10px] text-emerald-800 font-semibold bg-emerald-100/70 rounded px-1 py-0.2 mx-auto max-w-fit cursor-help" title={rep.prorateExplanation}>
                                  Prorate: {rep.prorateMonths}/12 bln
                                </span>
                              )}
                            </div>
                          )}
                        </td>

                        {/* 7. Sudah Diambil */}
                        <td className="py-3 px-3 text-center bg-indigo-50/50">
                          {isDW ? (
                            <span className="text-slate-400 text-[11px]">-</span>
                          ) : (
                            <div className="space-y-0.5">
                              <span className={`font-bold text-sm ${rep.takenDays > 0 ? 'text-indigo-700' : 'text-slate-400'}`}>
                                {rep.takenDays}{' '}
                                <span className="text-[10px] font-normal text-slate-500">hari</span>
                              </span>
                              {/* Apabila pendingan nol, tidak ditampilkan sesuai catatan user */}
                              {rep.pendingDays > 0 && (
                                <span className="text-[10px] text-amber-600 block font-bold" title="Pengajuan cuti sedang menunggu persetujuan">
                                  (+{rep.pendingDays} pending)
                                </span>
                              )}
                            </div>
                          )}
                        </td>

                        {/* 8. Sisa Cuti Tahun Ini */}
                        <td className="py-3 px-3 text-center bg-amber-50/50">
                          {isDW ? (
                            <span className="text-slate-400 text-[11px]">-</span>
                          ) : (
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold ${
                              rep.remainingDays >= 6
                                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                : rep.remainingDays > 0
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                : 'bg-rose-100 text-rose-800 border border-rose-300'
                            }`}>
                              {rep.remainingDays} hari
                            </span>
                          )}
                        </td>

                        {/* 9. Total Balance AL (Akumulasi s/d Saat Ini) */}
                        <td className="py-3 px-3 text-center bg-emerald-100/50">
                          {isDW ? (
                            <span className="text-slate-400 text-[11px]">-</span>
                          ) : (
                            <div className="space-y-0.5">
                              <span className="font-black text-emerald-950 text-sm">
                                {rep.totalBalanceAL} hari total
                              </span>
                              <span className="text-[9.5px] text-emerald-800 block font-medium" title={rep.totalBalanceALExplanation}>
                                {rep.previousYearCarryForward > 0
                                  ? `(CF: ${rep.previousYearCarryForward} + Hak: ${rep.entitlementDays})`
                                  : `(Prorate: ${rep.entitlementDays} hr)`}
                              </span>
                            </div>
                          )}
                        </td>

                        {/* 10. Tahun Berikutnya (Proyeksi Total AL: Hak Baru 12 + Akumulasi Th Lalu) */}
                        <td className="py-3 px-3 text-center bg-blue-50/50">
                          {isDW ? (
                            <span className="text-slate-400 text-[11px]">-</span>
                          ) : (
                            <div className="space-y-0.5">
                              <span className="font-extrabold text-blue-950 text-sm">
                                {rep.nextYearProjectedTotal}{' '}
                                <span className="text-[10px] font-normal text-slate-500">hari total</span>
                              </span>
                              <span className="text-[9px] text-blue-700 block font-medium">
                                (Hak 12 + CF {rep.nextYearCarryForward} hr)
                              </span>
                            </div>
                          )}
                        </td>

                        {/* 11. Aksi & Riwayat Ledger */}
                        <td className="py-3 px-4 text-right print:hidden">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => setSelectedEmployeeForLedger(emp.id)}
                              className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded shadow-2xs"
                              title="Buka rincian transaksi ledger cuti"
                            >
                              <History className="w-3 h-3 text-slate-500" />
                              Ledger
                            </button>

                            {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'DEPT_HEAD') && !isDW && (
                              <button
                                onClick={() => setSelectedEmployeeForAdjustment(emp)}
                                className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 hover:bg-emerald-100 rounded shadow-2xs"
                                title="Penyesuaian kuota atau jatah cuti langsung tanpa coding"
                              >
                                <PlusCircle className="w-3 h-3 text-emerald-700" />
                                Adjust
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* VIEW TAB 2: Matriks Multi-Tahun (Format Excel GMCC: 2024 s/d 2026) */}
      {activeViewTab === 'multi-year-matrix' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden space-y-3 p-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
            <div>
              <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <TableProperties className="w-4 h-4 text-emerald-700" />
                <span>Matriks Cuti Multi-Tahun (Format Resmi Spreadsheet Excel GMCC)</span>
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                * Apabila masih ada pendingan kalau nol tidak perlu ditampilkan · Data per Oktober 2026
              </p>
            </div>
            <button
              onClick={handleExportMultiYearCSV}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-2xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh Spreadsheet Excel (.csv)</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200 border-collapse">
              <thead className="bg-amber-300 text-slate-950 font-bold uppercase tracking-wider text-[10px]">
                <tr className="border-b border-slate-400">
                  <th className="py-2.5 px-2 text-center border-r border-slate-400 w-8">No</th>
                  <th className="py-2.5 px-3 border-r border-slate-400">NIK / Nama Karyawan</th>
                  <th className="py-2.5 px-3 border-r border-slate-400">Departemen & Jabatan</th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-400">Tipe</th>
                  <th className="py-2.5 px-3 text-center border-r border-slate-400">Masa Kontrak Berjalan</th>
                  
                  {/* 2024 */}
                  <th className="py-2.5 px-2 text-center border-r border-slate-400 bg-amber-200">Total Kuota 2024</th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-400 bg-amber-200">Cuti Diambil 2024</th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-400 bg-amber-200">Sisa Cuti 2024</th>

                  {/* 2025 */}
                  <th className="py-2.5 px-2 text-center border-r border-slate-400 bg-amber-300">Total Kuota 2025</th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-400 bg-amber-300">Cuti Diambil 2025</th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-400 bg-amber-300 font-black">Sisa 2025 (Carry Forward)</th>

                  {/* 2026 s/d Oktober */}
                  <th className="py-2.5 px-2 text-center border-r border-slate-400 bg-amber-400">Total Kuota 2026<br /><span className="text-[9px] font-normal">(per Okt)</span></th>
                  <th className="py-2.5 px-2 text-center border-r border-slate-400 bg-amber-400">Cuti Diambil 2026</th>
                  <th className="py-2.5 px-3 text-center bg-emerald-600 text-white font-black border-r border-slate-400">
                    Hak Cuti Prorate<br />s/d Saat Ini (Total Balance AL)
                  </th>

                  {/* Tahun Berikutnya 2027 */}
                  <th className="py-2.5 px-3 text-center bg-blue-700 text-white font-black">
                    Tahun Berikutnya (2027)<br /><span className="text-[9px] font-normal text-blue-200">(Hak 12 + Akumulasi Th Lalu)</span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-[11px]">
                {filteredReports.map((r26, idx) => {
                  const emp = r26.employee;
                  const dept = departments.find(d => d.id === emp.departmentId)?.name || emp.departmentId;
                  const r24 = reports2024.find(r => r.employee.id === emp.id);
                  const r25 = reports2025.find(r => r.employee.id === emp.id);
                  const contractDates = r26.contract ? `${r26.contract.startDate} s/d ${r26.contract.endDate || '-'}` : `${emp.joinDate} (Join)`;

                  return (
                    <tr key={emp.id} className="hover:bg-slate-50">
                      <td className="py-2 px-2 text-center font-mono border-r border-slate-300 font-semibold">{idx + 1}</td>
                      <td className="py-2 px-3 border-r border-slate-300">
                        <span className="font-bold text-slate-900 block">{emp.fullName}</span>
                        <span className="font-mono text-[10px] text-slate-500">{emp.employeeNumber || emp.id}</span>
                      </td>
                      <td className="py-2 px-3 border-r border-slate-300">
                        <span className="font-medium text-slate-800 block">{dept}</span>
                        <span className="text-[10px] text-slate-500">{emp.jobTitle}</span>
                      </td>
                      <td className="py-2 px-2 text-center border-r border-slate-300 font-bold">{emp.employmentType}</td>
                      <td className="py-2 px-3 text-center font-mono text-[10px] border-r border-slate-300">{contractDates}</td>

                      {/* 2024 */}
                      <td className="py-2 px-2 text-center font-mono border-r border-slate-300 bg-amber-50/50">{r24?.entitlementDays || 0} hr</td>
                      <td className="py-2 px-2 text-center font-mono border-r border-slate-300 bg-amber-50/50">{r24?.takenDays || 0} hr</td>
                      <td className="py-2 px-2 text-center font-mono border-r border-slate-300 bg-amber-50/50 font-bold">{r24?.remainingDays || 0} hr</td>

                      {/* 2025 */}
                      <td className="py-2 px-2 text-center font-mono border-r border-slate-300 bg-amber-100/40">{r25?.entitlementDays || 0} hr</td>
                      <td className="py-2 px-2 text-center font-mono border-r border-slate-300 bg-amber-100/40">{r25?.takenDays || 0} hr</td>
                      <td className="py-2 px-2 text-center font-mono border-r border-slate-300 bg-amber-100/70 font-black text-amber-950">{r25?.remainingDays || 0} hr</td>

                      {/* 2026 s/d Oktober */}
                      <td className="py-2 px-2 text-center font-mono border-r border-slate-300 bg-emerald-50 font-bold text-emerald-950">{r26.entitlementDays} hr</td>
                      <td className="py-2 px-2 text-center font-mono border-r border-slate-300 bg-indigo-50 font-semibold">{r26.takenDays} hr</td>
                      <td className="py-2 px-3 text-center font-mono bg-emerald-100 font-black text-emerald-950 text-sm border-r border-slate-300">
                        {r26.totalBalanceAL} hr
                      </td>

                      {/* Tahun Berikutnya 2027 */}
                      <td className="py-2 px-3 text-center font-mono bg-blue-100/90 font-black text-blue-950 text-sm">
                        {r26.nextYearProjectedTotal} hr
                        <span className="block text-[8.5px] text-blue-800 font-medium">
                          (Hak 12 + CF {r26.nextYearCarryForward} hr)
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Ledger Modal */}
      {selectedEmployeeForLedger && (
        <LeaveLedgerModal
          isOpen={!!selectedEmployeeForLedger}
          employeeId={selectedEmployeeForLedger}
          onClose={() => setSelectedEmployeeForLedger(null)}
        />
      )}

      {/* Adjust Modal */}
      {selectedEmployeeForAdjustment && (
        <AdminLedgerModal
          isOpen={!!selectedEmployeeForAdjustment}
          initialEmployeeId={selectedEmployeeForAdjustment.id}
          initialYear={selectedYear}
          onClose={() => setSelectedEmployeeForAdjustment(null)}
        />
      )}

      {/* Print Report Modal */}
      <LeavePrintReportModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        year={selectedYear}
        reports={filteredReports}
        departments={departments}
        deptFilterId={effectiveDeptId}
        printedByName={currentUser.name}
        printedByRole={currentUser.role}
      />
    </div>
  );
};
