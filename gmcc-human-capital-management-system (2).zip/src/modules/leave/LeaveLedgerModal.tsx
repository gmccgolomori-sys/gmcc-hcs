import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, ShieldCheck, ArrowDownRight, ArrowUpRight, FileSpreadsheet } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  employeeId: string;
}

export const LeaveLedgerModal: React.FC<Props> = ({ isOpen, onClose, employeeId }) => {
  const { leaveLedger, employees } = useApp();

  if (!isOpen) return null;

  const emp = employees.find(e => e.id === employeeId);
  const empEntries = leaveLedger
    .filter(l => l.employeeId === employeeId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col border border-slate-200">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h3 className="font-semibold text-slate-900 text-lg">Leave Transaction Ledger</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Permanent double-entry record for {emp?.fullName} ({emp?.id})
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 bg-emerald-50 border-b border-emerald-100 flex items-center justify-between text-xs text-emerald-900">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>Audit Guarantee: Historical ledger rows cannot be deleted or overwritten. Corrective actions generate explicit reversal entries.</span>
          </div>
          <button
            onClick={() => {
              const headers = ['Txn ID', 'Employee ID', 'Employee Name', 'Type', 'Category', 'Days', 'Effective Date', 'Authorized By', 'Details'];
              const rows = empEntries.map(e => [
                `"${e.id}"`,
                `"${e.employeeId}"`,
                `"${emp?.fullName || ''}"`,
                `"${e.transactionType}"`,
                `"${e.leaveType}"`,
                e.days,
                `"${e.effectiveDate}"`,
                `"${e.authorizedByName}"`,
                `"${(e.reason || '').replace(/"/g, '""')}"`
              ].join(','));
              const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows].join('\n');
              const encodedUri = encodeURI(csvContent);
              const link = document.createElement('a');
              link.setAttribute('href', encodedUri);
              link.setAttribute('download', `GMCC_Ledger_Cuti_${emp?.id || employeeId}.csv`);
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            }}
            className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 hover:text-emerald-950 underline"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            Export Ledger
          </button>
        </div>

        <div className="overflow-y-auto flex-1 p-6">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-3">Txn ID</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Days</th>
                <th className="py-2.5 px-3">Effective Date</th>
                <th className="py-2.5 px-3">Authorized By</th>
                <th className="py-2.5 px-3">Details / Reason</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {empEntries.map(entry => {
                const isCredit = entry.days > 0;

                return (
                  <tr key={entry.id} className="hover:bg-slate-50">
                    <td className="py-3 px-3 font-semibold text-slate-900">{entry.id}</td>
                    <td className="py-3 px-3 font-sans text-slate-700">
                      {entry.transactionType.replace(/_/g, ' ')}
                    </td>
                    <td className="py-3 px-3 font-sans text-slate-600">
                      {entry.leaveType.replace('_', ' ')}
                    </td>
                    <td className="py-3 px-3 font-bold">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs ${
                        isCredit 
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                          : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}>
                        {isCredit ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                        {entry.days > 0 ? `+${entry.days}` : entry.days}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-slate-600">
                      {entry.effectiveDate}
                    </td>
                    <td className="py-3 px-3 font-sans text-slate-700">
                      {entry.authorizedByName}
                    </td>
                    <td className="py-3 px-3 font-sans text-slate-600 max-w-xs truncate" title={entry.reason}>
                      {entry.reason}
                    </td>
                  </tr>
                );
              })}
              {empEntries.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-slate-400 font-sans">
                    No ledger transactions recorded yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
