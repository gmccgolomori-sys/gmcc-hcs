import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { PERSONAL_FILE_CATEGORIES } from '../../data/categories';
import { PersonalFileCategory } from '../../types';
import { 
  X, 
  UploadCloud, 
  Lock, 
  FileText, 
  CheckCircle2, 
  Upload, 
  FileCheck, 
  AlertTriangle,
  FolderOpen
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  defaultEmployeeId?: string;
  defaultCategory?: PersonalFileCategory;
}

export const DocumentUploadModal: React.FC<Props> = ({
  isOpen,
  onClose,
  defaultEmployeeId,
  defaultCategory
}) => {
  const { employees, uploadDocument, currentUser, canAccessCategory, canModifyCategory } = useApp();

  const [employeeId, setEmployeeId] = useState(defaultEmployeeId || employees[0]?.id || '');
  const [category, setCategory] = useState<PersonalFileCategory>(defaultCategory || '01_IDENTITY');
  const [title, setTitle] = useState('');
  const [fileName, setFileName] = useState('');
  const [fileType, setFileType] = useState('pdf');
  const [fileSize, setFileSize] = useState('1.5 MB');
  const [fileDataUrl, setFileDataUrl] = useState<string>('');
  const [isConfidential, setIsConfidential] = useState(false);
  const [notes, setNotes] = useState('');
  const [uploadedSuccess, setUploadedSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (defaultCategory) setCategory(defaultCategory);
    if (defaultEmployeeId) setEmployeeId(defaultEmployeeId);
  }, [defaultCategory, defaultEmployeeId]);

  if (!isOpen) return null;

  const selectedCategoryMeta = PERSONAL_FILE_CATEGORIES.find(c => c.code === category);

  // Handle actual file choose / upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    
    // Auto-detect size
    if (file.size < 1024 * 1024) {
      setFileSize(`${(file.size / 1024).toFixed(1)} KB`);
    } else {
      setFileSize(`${(file.size / (1024 * 1024)).toFixed(1)} MB`);
    }

    // Auto-detect extension
    const ext = file.name.split('.').pop()?.toLowerCase() || 'pdf';
    if (['jpg', 'jpeg', 'png', 'webp'].includes(ext)) {
      setFileType('image');
    } else if (['doc', 'docx'].includes(ext)) {
      setFileType('docx');
    } else if (['xls', 'xlsx'].includes(ext)) {
      setFileType('xlsx');
    } else {
      setFileType('pdf');
    }

    // Auto-suggest title if blank
    if (!title) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');
      setTitle(cleanName);
    }

    // Read as Data URL
    const reader = new FileReader();
    reader.onloadend = () => {
      setFileDataUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !fileName) return;

    uploadDocument({
      employeeId,
      category,
      title,
      fileName,
      fileSize,
      fileType,
      fileUrl: fileDataUrl || undefined,
      uploadedBy: currentUser.employeeId || currentUser.id,
      uploadedByName: currentUser.name,
      isConfidential: isConfidential || (selectedCategoryMeta?.isRestricted ?? false),
      notes,
      driveFolderId: `DRV-${employeeId}-${selectedCategoryMeta?.folderNumber}`
    });

    setUploadedSuccess(true);
    setTimeout(() => {
      setUploadedSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white rounded-t-2xl">
          <div>
            <h3 className="font-bold text-sm tracking-tight">Upload Personal File Document</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">Google Drive Structured Folder Storage</p>
          </div>
          <button 
            onClick={onClose} 
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {uploadedSuccess ? (
          <div className="p-8 text-center flex flex-col items-center justify-center">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-3">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-slate-900 text-base">Dokumen Berhasil Diunggah!</h4>
            <p className="text-xs text-slate-500 mt-1">Tersimpan secara aman di Google Drive personal file karyawan.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Target Folder Karyawan *</label>
              <select
                value={employeeId}
                onChange={e => setEmployeeId(e.target.value)}
                disabled={!!defaultEmployeeId && currentUser.role === 'STAFF'}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700"
              >
                {employees.map(emp => (
                  <option key={emp.id} value={emp.id}>
                    {emp.id} — {emp.fullName} ({emp.jobTitle})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Kategori Subfolder Personal File *</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as PersonalFileCategory)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 bg-white text-slate-900 focus:outline-hidden focus:border-emerald-700 font-medium"
              >
                {PERSONAL_FILE_CATEGORIES.map(cat => {
                  const allowedToModify = canModifyCategory(cat.code, employeeId);
                  const isDeptHeadRestricted = currentUser.role === 'DEPT_HEAD' && ['07_DISCIPLINE', '08_COMPENSATION_BENEFITS', '09_HEALTH_WORK_REQUIREMENTS'].includes(cat.code);
                  return (
                    <option key={cat.code} value={cat.code} disabled={!allowedToModify}>
                      {cat.name} {isDeptHeadRestricted ? '(Hanya Lihat / View-Only bagi Dept Head)' : cat.isRestricted ? '(Akses: HC / GM / Admin)' : ''} {!allowedToModify && !isDeptHeadRestricted ? '(Terkunci)' : ''}
                    </option>
                  );
                })}
              </select>
              {selectedCategoryMeta && (
                <p className="text-[11px] text-slate-500 mt-1 italic">
                  {selectedCategoryMeta.description}
                </p>
              )}
            </div>

            {/* Folder 07 Discipline Notice */}
            {category === '07_DISCIPLINE' && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                <div>
                  <span className="font-bold block text-xs">Subfolder 07 Discipline & Relations:</span>
                  <span className="text-[11px] leading-relaxed">
                    Silakan pilih file Surat Peringatan (SP1, SP2, SP3), Berita Acara Pemeriksaan (BAP), atau surat investigasi melalui tombol pilih file di bawah.
                  </span>
                </div>
              </div>
            )}

            {/* Real File Chooser Input Section */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-700">
                Pilih Berkas / File Dokumen <span className="text-rose-500">*WAJIB CHOOSE FILE</span>
              </label>

              {fileName ? (
                <div className="flex items-center justify-between p-3 bg-emerald-50/70 border border-emerald-300 rounded-xl">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <FileCheck className="w-5 h-5 text-emerald-700 shrink-0" />
                    <div className="min-w-0">
                      <span className="font-bold text-slate-900 block truncate text-xs">
                        {fileName}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {fileSize} · Format {fileType.toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-[11px] text-emerald-700 hover:text-emerald-800 font-semibold px-2 py-1 bg-white rounded border border-emerald-200 shadow-2xs shrink-0"
                  >
                    Ganti File
                  </button>
                </div>
              ) : (
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-300 hover:border-emerald-600 rounded-xl p-5 text-center cursor-pointer transition-all bg-slate-50 hover:bg-emerald-50/30 flex flex-col items-center justify-center space-y-1.5"
                >
                  <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                    <Upload className="w-5 h-5" />
                  </div>
                  <span className="font-bold text-slate-800 text-xs">
                    Klik di sini untuk Choose File dari Komputer
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Mendukung format PDF, DOCX, XLSX, JPG, PNG
                  </span>
                </div>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.webp"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>

            {/* Title / Subject */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Judul / Perihal Dokumen *</label>
              <input
                type="text"
                required
                placeholder="misal: Surat Peringatan Pertama (SP1) - Keterlambatan Shift"
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden focus:border-emerald-700"
              />
            </div>

            {/* Catatan / Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Catatan Tambahan (Opsional)</label>
              <textarea
                rows={2}
                placeholder="misal: Ditandatangani oleh HC Manager & Karyawan bersangkutan..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-900 focus:outline-hidden"
              />
            </div>

            {/* Bottom Actions */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                disabled={!fileName}
                className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg shadow-xs transition-colors ${
                  fileName 
                    ? 'text-white bg-emerald-700 hover:bg-emerald-800 cursor-pointer' 
                    : 'text-slate-400 bg-slate-200 cursor-not-allowed'
                }`}
              >
                <UploadCloud className="w-4 h-4" />
                Upload Dokumen ke Drive
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
