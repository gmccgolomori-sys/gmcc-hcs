import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PERSONAL_FILE_CATEGORIES } from '../../data/categories';
import { PersonalFileCategory, EmployeeDocument, Employee } from '../../types';
import { 
  Folder, 
  FolderOpen, 
  FileText, 
  Lock, 
  Upload, 
  Download, 
  Eye, 
  Trash2, 
  ShieldCheck, 
  AlertCircle, 
  Search,
  ExternalLink,
  ChevronRight,
  HardDrive,
  Users,
  Building2
} from 'lucide-react';
import { DocumentUploadModal } from './DocumentUploadModal';

export const PersonalFileManager: React.FC = () => {
  const { employees, documents, currentUser, deleteDocument, canAccessCategory, canModifyCategory } = useApp();

  // Filter accessible employees based on role and sort active staff to top, inactive at bottom
  const accessibleEmployees = employees
    .filter(emp => {
      if (currentUser.role === 'STAFF') {
        return emp.id === currentUser.employeeId;
      }
      if (currentUser.role === 'DEPT_HEAD') {
        return emp.departmentId === currentUser.departmentId;
      }
      return true; // HC, GM, ADMIN, AUDITOR can see all employees
    })
    .sort((a, b) => {
      const aActive = a.employmentStatus === 'ACTIVE';
      const bActive = b.employmentStatus === 'ACTIVE';
      if (aActive && !bActive) return -1;
      if (!aActive && bActive) return 1;
      return a.fullName.localeCompare(b.fullName);
    });

  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>(
    accessibleEmployees[0]?.id || employees[0]?.id || ''
  );

  React.useEffect(() => {
    if (!accessibleEmployees.some(e => e.id === selectedEmployeeId)) {
      if (accessibleEmployees.length > 0) {
        setSelectedEmployeeId(accessibleEmployees[0].id);
      }
    }
  }, [currentUser, accessibleEmployees, selectedEmployeeId]);

  const [selectedCategory, setSelectedCategory] = useState<PersonalFileCategory>('01_IDENTITY');
  const [searchDocQuery, setSearchDocQuery] = useState('');
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [previewDoc, setPreviewDoc] = useState<EmployeeDocument | null>(null);
  const [downloadNotice, setDownloadNotice] = useState<string | null>(null);

  const handleDownloadFile = (fileName: string) => {
    setDownloadNotice(`Sedang mengunduh "${fileName}" dari server Google Drive GMCC...`);
    setTimeout(() => {
      setDownloadNotice(null);
    }, 3500);
  };

  const selectedEmployee = employees.find(e => e.id === selectedEmployeeId);
  const selectedCategoryMeta = PERSONAL_FILE_CATEGORIES.find(c => c.code === selectedCategory);

  // Filter documents in current category for selected employee
  const categoryDocs = documents.filter(doc => 
    doc.employeeId === selectedEmployeeId && 
    doc.category === selectedCategory &&
    (searchDocQuery === '' || 
      doc.title.toLowerCase().includes(searchDocQuery.toLowerCase()) || 
      doc.fileName.toLowerCase().includes(searchDocQuery.toLowerCase()))
  );

  const isCurrentCategoryAccessible = selectedEmployee ? canAccessCategory(selectedCategory, selectedEmployee.id) : false;
  const canModifyCurrentCategory = selectedEmployee ? canModifyCategory(selectedCategory, selectedEmployee.id) : false;
  const isViewOnlyForDeptHead = currentUser.role === 'DEPT_HEAD' && ['07_DISCIPLINE', '08_COMPENSATION_BENEFITS', '09_HEALTH_WORK_REQUIREMENTS'].includes(selectedCategory);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Human Capital</span>
            <ChevronRight className="w-3 h-3" />
            <span>Structured Employee Folders</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Staff Personal Files</h1>
          <p className="text-xs text-slate-500 mt-1">
            Google Drive integrated 10-folder structure per employee with role-based document access controls.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {currentUser.role !== 'AUDITOR' && (
            <button
              onClick={() => setIsUploadOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition-colors"
            >
              <Upload className="w-4 h-4" />
              Upload Document
            </button>
          )}
        </div>
      </div>

      {/* Role Scoping Banner */}
      {currentUser.role === 'GM' && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center justify-between text-xs text-emerald-950">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              <strong>Otorisasi General Manager (GM):</strong> Anda memiliki akses penuh ke seluruh 10 subfolder berkas karyawan GMCC termasuk <strong>Folder 07 (Discipline)</strong>, <strong>Folder 08 (Compensation)</strong>, dan <strong>Folder 09 (Health & Safety)</strong>.
            </span>
          </div>
          <span className="font-mono font-bold bg-white px-2.5 py-1 rounded-lg border border-emerald-300 text-emerald-800 shrink-0">
            Folder 01–10 Terbuka (Akses GM Penuh)
          </span>
        </div>
      )}

      {currentUser.role === 'HC' && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-300 rounded-xl flex items-center justify-between text-xs text-emerald-950">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              <strong>Otorisasi Penuh Human Capital (HC):</strong> Anda memiliki hak akses penuh untuk membuka dan mengelola seluruh 10 subfolder personal file karyawan, termasuk <strong>Folder 07 (Discipline & Relations)</strong>, <strong>Folder 08 (Compensation & Benefits)</strong>, dan <strong>Folder 09 (Health & Work Safety)</strong>.
            </span>
          </div>
          <span className="font-mono font-bold bg-white px-2.5 py-1 rounded-lg border border-emerald-300 text-emerald-800 shrink-0">
            Folder 01–10 Terbuka (Akses HC Penuh)
          </span>
        </div>
      )}

      {currentUser.role === 'STAFF' && (
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl flex items-center gap-2.5 text-xs text-blue-900">
          <Lock className="w-4 h-4 text-blue-700 shrink-0" />
          <span>
            <strong>Personal File Security:</strong> You are viewing your own employee personal folder. Confidential subfolders (Discipline investigations, Compensation, and Medical) are restricted per GMCC HR policy.
          </span>
        </div>
      )}

      {currentUser.role === 'DEPT_HEAD' && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between gap-2.5 text-xs text-emerald-950">
          <div className="flex items-center gap-2.5">
            <Building2 className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              <strong>Akses Departemen Head:</strong> Anda dapat mengakses personal file staf departemen Anda. Untuk <strong>Folder 07 s/d 09</strong>, Anda memiliki hak <strong>Lihat Saja (View Only)</strong> dan tidak diizinkan menambah atau mengubah dokumen.
            </span>
          </div>
          <span className="font-mono font-semibold bg-white px-2 py-0.5 rounded border border-emerald-300 text-emerald-800 shrink-0">
            Folder 07–09 (View Only)
          </span>
        </div>
      )}

      {/* Main Drive Layout: Two column (Employee list on left, 10 Subfolders & Files on right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Employee Selector */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-100 bg-slate-50/70">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-700" />
                Employee Folders
              </span>
              <span className="text-xs text-slate-500">{accessibleEmployees.length} staff</span>
            </div>
            <p className="text-[11px] text-slate-500">
              {currentUser.role === 'STAFF' && 'Your personal file directory.'}
              {currentUser.role === 'DEPT_HEAD' && 'Department staff files (confidential files restricted).'}
              {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && 'Company-wide staff files repository.'}
            </p>
          </div>

          <div className="divide-y divide-slate-100 overflow-y-auto max-h-[560px]">
            {accessibleEmployees.map(emp => {
              const empDocCount = documents.filter(d => d.employeeId === emp.id).length;
              const isSelected = emp.id === selectedEmployeeId;

              return (
                <button
                  key={emp.id}
                  onClick={() => setSelectedEmployeeId(emp.id)}
                  className={`w-full text-left p-3.5 flex items-start gap-3 transition-colors ${
                    isSelected ? 'bg-emerald-50/60 border-l-4 border-emerald-700' : 'hover:bg-slate-50'
                  }`}
                >
                  <img
                    src={emp.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80'}
                    alt={emp.fullName}
                    className="w-10 h-10 rounded-lg object-cover ring-1 ring-slate-200 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-900 truncate">{emp.fullName}</span>
                      <div className="flex items-center gap-1">
                        {emp.employmentStatus !== 'ACTIVE' && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-200 text-slate-600 font-bold">
                            Non-Aktif
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400 font-mono">{emp.id}</span>
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-600 truncate mt-0.5">{emp.jobTitle}</p>
                    <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-400">
                      <span>{emp.departmentId.replace('DEP-', '')}</span>
                      <span>·</span>
                      <span>{emp.employmentType}</span>
                      <span>·</span>
                      <span className="text-emerald-700 font-medium">{empDocCount} docs</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Google Drive Hierarchy & Subfolders */}
        <div className="lg:col-span-8 space-y-4">
          {/* Drive Breadcrumb & Path Bar */}
          <div className="bg-slate-900 text-white rounded-xl p-4 shadow-xs">
            <div className="flex items-center gap-2 text-xs text-slate-400 font-mono overflow-x-auto pb-1">
              <HardDrive className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>GMCC HUMAN CAPITAL</span>
              <span>/</span>
              <span>01 PERSONAL FILE</span>
              <span>/</span>
              <span>ACTIVE EMPLOYEE</span>
              <span>/</span>
              <span className="text-emerald-400 font-semibold">{selectedEmployee?.id} - {selectedEmployee?.fullName}</span>
            </div>
            <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-800 pt-2 text-xs">
              <span className="text-slate-300">
                Drive ID: <span className="font-mono text-slate-400">{selectedEmployee?.driveFolderId}</span>
              </span>
              <span className="text-slate-300">
                Employment: <span className="text-emerald-300 font-medium">{selectedEmployee?.employmentType} ({selectedEmployee?.employmentStatus})</span>
              </span>
            </div>
          </div>

          {/* 10 Subfolder Navigation Buttons */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-4">
            <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wider mb-3">
              Standard 10 Category Subfolders
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {PERSONAL_FILE_CATEGORIES.map(cat => {
                const isSelected = cat.code === selectedCategory;
                const count = documents.filter(d => d.employeeId === selectedEmployeeId && d.category === cat.code).length;
                const hasAccess = selectedEmployee ? canAccessCategory(cat.code, selectedEmployee.id) : false;

                return (
                  <button
                    key={cat.code}
                    onClick={() => setSelectedCategory(cat.code)}
                    disabled={!hasAccess}
                    className={`relative p-2.5 rounded-lg text-left transition-all border flex flex-col justify-between min-h-[72px] ${
                      !hasAccess 
                        ? 'opacity-40 bg-slate-50 border-slate-200 cursor-not-allowed'
                        : isSelected
                          ? 'bg-emerald-50 border-emerald-600 text-emerald-950 ring-1 ring-emerald-600'
                          : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/70 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-1">
                      {isSelected ? (
                        <FolderOpen className="w-4 h-4 text-emerald-700" />
                      ) : (
                        <Folder className="w-4 h-4 text-slate-400" />
                      )}
                      {cat.isRestricted && (
                        hasAccess ? (
                          <span title="Akses Resmi HC: Folder Terbuka & Dapat Dikelola" className="text-emerald-700 bg-emerald-100/80 px-1 py-0.2 rounded text-[9px] font-bold flex items-center gap-0.5">
                            <ShieldCheck className="w-3 h-3 text-emerald-700" />
                            <span className="hidden sm:inline">HC</span>
                          </span>
                        ) : (
                          <span title="Terkunci - Hanya HC & Admin">
                            <Lock className="w-3 h-3 text-amber-600" />
                          </span>
                        )
                      )}
                    </div>
                    <div>
                      <div className="text-[11px] font-semibold truncate leading-tight">
                        {cat.name}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {count} file{count !== 1 ? 's' : ''}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Folder Content Area */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-slate-900 text-sm">{selectedCategoryMeta?.name}</h3>
                  {selectedCategoryMeta?.isRestricted && (
                    isCurrentCategoryAccessible ? (
                      isViewOnlyForDeptHead ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded border border-amber-300">
                          <Eye className="w-3.5 h-3.5 text-amber-700" />
                          Akses Dept Head: Lihat Saja (View Only) — Tidak dapat edit & tambah
                        </span>
                      ) : currentUser.role === 'GM' ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-300">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                          Akses Penuh General Manager (GM)
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-300">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                          Akses Resmi HC / Admin (Terbuka Penuh & Rahasia)
                        </span>
                      )
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10px] font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                        <Lock className="w-3 h-3" />
                        Restricted Confidential (Terkunci)
                      </span>
                    )
                  )}
                </div>
                <p className="text-xs text-slate-500 mt-0.5">{selectedCategoryMeta?.description}</p>
              </div>

              {/* Search within folder */}
              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Filter files in folder..."
                  value={searchDocQuery}
                  onChange={e => setSearchDocQuery(e.target.value)}
                  className="w-full text-xs pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 focus:outline-hidden focus:ring-1 focus:ring-emerald-600"
                />
              </div>
            </div>

            {/* Folder Security Check */}
            {!isCurrentCategoryAccessible ? (
              <div className="p-12 text-center">
                <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center mx-auto mb-3">
                  <Lock className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-semibold text-slate-900">Access Restricted</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  You are logged in as <span className="font-semibold text-slate-700">{currentUser.name} ({currentUser.role})</span>.
                  Under GMCC data protection policy, this confidential subfolder is strictly limited to authorized Human Capital, General Manager, and System Administrator roles.
                </p>
              </div>
            ) : categoryDocs.length === 0 ? (
              <div className="p-12 text-center">
                <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
                  <FileText className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-semibold text-slate-900">Folder is Empty</h4>
                <p className="text-xs text-slate-500 mt-1">
                  No files have been uploaded into {selectedCategoryMeta?.name} for this employee yet.
                </p>
                {canModifyCurrentCategory && currentUser.role !== 'AUDITOR' && (
                  <button
                    onClick={() => setIsUploadOpen(true)}
                    className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors border border-emerald-200"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Upload File to this Folder
                  </button>
                )}
                {isViewOnlyForDeptHead && (
                  <p className="mt-3 text-xs text-amber-700 bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200 inline-block">
                    Dept Head hanya memiliki akses pantau (View Only). Penambahan dokumen hanya dapat dilakukan oleh HC / GM.
                  </p>
                )}
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {categoryDocs.map(doc => (
                  <div key={doc.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 transition-colors">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 border border-emerald-100">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-semibold text-slate-900 truncate">{doc.title}</h4>
                          <span className="text-[10px] font-mono text-slate-400">{doc.fileType.toUpperCase()}</span>
                          {doc.isConfidential && (
                            <span className="text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                              Confidential
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 font-mono mt-0.5 truncate">{doc.fileName} · {doc.fileSize}</p>
                        <p className="text-[10px] text-slate-400 mt-1">
                          Uploaded on {new Date(doc.uploadedAt).toLocaleDateString('en-GB')} by {doc.uploadedByName}
                        </p>
                        {doc.notes && (
                          <p className="text-[11px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded mt-1.5 inline-block">
                            Note: {doc.notes}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                      <button
                        onClick={() => setPreviewDoc(doc)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                        title="View Document Details & Preview"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        Preview
                      </button>
                      <button
                        onClick={() => handleDownloadFile(doc.fileName)}
                        className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors"
                        title="Download file"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      {(currentUser.role === 'HC' || currentUser.role === 'ADMIN' || currentUser.role === 'GM') && (
                        <button
                          onClick={() => {
                            if (confirm(`Delete document "${doc.title}"?`)) {
                              deleteDocument(doc.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                          title="Delete document"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Upload Modal */}
      <DocumentUploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        defaultEmployeeId={selectedEmployeeId}
        defaultCategory={selectedCategory}
      />

      {/* Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-xl w-full overflow-hidden border border-slate-200">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-700" />
                <div>
                  <h3 className="font-semibold text-slate-900 text-sm">{previewDoc.title}</h3>
                  <p className="text-[11px] font-mono text-slate-500">{previewDoc.fileName}</p>
                </div>
              </div>
              <button 
                onClick={() => setPreviewDoc(null)} 
                className="text-slate-400 hover:text-slate-600 text-sm font-medium"
              >
                Close
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="bg-slate-900 text-slate-100 rounded-lg p-3 text-xs font-mono space-y-1">
                <div className="text-emerald-400">// Google Drive Metadata</div>
                <div>Drive File ID: {previewDoc.driveFileId}</div>
                <div className="break-all">Storage Path: {previewDoc.drivePath}</div>
                <div>Format: {previewDoc.fileType.toUpperCase()} ({previewDoc.fileSize})</div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg">
                  <span className="text-slate-500 block">Uploaded By:</span>
                  <span className="font-semibold text-slate-800">{previewDoc.uploadedByName}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg">
                  <span className="text-slate-500 block">Uploaded Date:</span>
                  <span className="font-semibold text-slate-800">{new Date(previewDoc.uploadedAt).toLocaleString('en-GB')}</span>
                </div>
              </div>

              {previewDoc.notes && (
                <div className="p-3 bg-slate-50 rounded-lg text-xs">
                  <span className="text-slate-500 block">Verification Notes:</span>
                  <span className="text-slate-700">{previewDoc.notes}</span>
                </div>
              )}

              {/* Document Mock Viewer Box */}
              <div className="border border-slate-200 rounded-lg p-6 bg-slate-50/50 text-center flex flex-col items-center justify-center space-y-2">
                <ShieldCheck className="w-8 h-8 text-emerald-600" />
                <span className="text-xs font-semibold text-slate-800">Verified GMCC Employee Document</span>
                <p className="text-[11px] text-slate-500 max-w-sm">
                  Document verified and stored in compliance with Indonesian Employment Law & GMCC Internal Regulation.
                </p>
                <button
                  onClick={() => handleDownloadFile(previewDoc.fileName)}
                  className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-800 hover:bg-slate-900 rounded-md transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download Original from Drive
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Download / Operation Toast */}
      {downloadNotice && (
        <div className="fixed bottom-20 right-4 sm:bottom-8 sm:right-8 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl border border-slate-700 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <Download className="w-4 h-4 text-emerald-400 shrink-0 animate-bounce" />
          <span className="text-xs font-medium">{downloadNotice}</span>
          <button 
            onClick={() => setDownloadNotice(null)}
            className="text-slate-400 hover:text-white ml-2 text-xs"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
};
