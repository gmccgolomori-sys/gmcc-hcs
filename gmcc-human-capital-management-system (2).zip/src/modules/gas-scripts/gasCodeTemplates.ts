export interface GasFile {
  name: string;
  description: string;
  category: 'CORE' | 'SERVICES' | 'SETUP';
  code: string;
}

export const GAS_FILES: GasFile[] = [
  {
    name: 'Setup.gs',
    description: 'Initializes Google Spreadsheet sheets, headers, and Google Drive 10-folder structure.',
    category: 'SETUP',
    code: `/**
 * GMCC HUMAN CAPITAL MANAGEMENT SYSTEM
 * Setup.gs - Initialization of Spreadsheet Sheets & Drive Folders
 * Timezone: Asia/Makassar (WITA)
 */

const CONFIG = {
  TIMEZONE: 'Asia/Makassar',
  ROOT_FOLDER_NAME: 'GMCC HUMAN CAPITAL',
  SHEET_ID: SpreadsheetApp.getActiveSpreadsheet().getId(),
  SUB_FOLDERS: [
    '01 PERSONAL FILE',
    '02 EMPLOYMENT CONTRACTS',
    '03 TRAINING & DEVELOPMENT',
    '04 HR REPORTS',
    '05 POLICY & SOP',
    '06 DOCUMENT TEMPLATES'
  ],
  PERSONAL_FILE_CATEGORIES: [
    '01 Identity',
    '02 Recruitment',
    '03 Employment',
    '04 Training',
    '05 Performance',
    '06 Attendance & Leave',
    '07 Discipline',
    '08 Compensation & Benefits',
    '09 Health & Work Requirements',
    '10 Exit'
  ]
};

function initGMCCSystem() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // 1. Initialize Sheets
  createSheetIfNotExists(ss, 'Employees', [
    'EmployeeID', 'EmployeeNumber', 'FullName', 'PreferredName', 'Email', 
    'CompanyEmail', 'Phone', 'DepartmentID', 'JobTitle', 'EmploymentType', 
    'EmploymentStatus', 'JoinDate', 'ProbationEndDate', 'SupervisorID', 
    'Location', 'WorkSchedule', 'DriveFolderID', 'CreatedAt', 'UpdatedAt'
  ]);

  createSheetIfNotExists(ss, 'Departments', [
    'DepartmentID', 'DepartmentName', 'DepartmentCode', 'HeadEmployeeID', 'HeadName'
  ]);

  createSheetIfNotExists(ss, 'Users_Roles', [
    'UserEmail', 'FullName', 'Role', 'EmployeeID', 'DepartmentID', 'IsActive'
  ]);

  createSheetIfNotExists(ss, 'Employee_Documents', [
    'DocumentID', 'EmployeeID', 'Category', 'Title', 'FileName', 
    'FileSize', 'FileType', 'DriveFileID', 'DriveFolderID', 'DrivePath', 
    'UploadedBy', 'UploadedAt', 'IsConfidential', 'Notes'
  ]);

  createSheetIfNotExists(ss, 'Employment_Contracts', [
    'ContractID', 'ContractNumber', 'EmployeeID', 'EmployeeName', 'DepartmentID', 
    'Position', 'EmploymentType', 'StartDate', 'EndDate', 'Status', 
    'Version', 'DriveFileID', 'ResponsibleHC', 'Notes', 'CreatedAt', 'UpdatedAt'
  ]);

  createSheetIfNotExists(ss, 'Leave_Applications', [
    'ApplicationID', 'EmployeeID', 'EmployeeName', 'DepartmentID', 'LeaveType', 
    'StartDate', 'EndDate', 'TotalDays', 'Reason', 'Status', 
    'DeptHeadDecision', 'DeptHeadDate', 'DeptHeadNotes', 
    'HCDecision', 'HCDate', 'HCNotes', 
    'GMDecision', 'GMDate', 'GMNotes', 
    'DeductionTxnID', 'SubmittedAt', 'UpdatedAt'
  ]);

  createSheetIfNotExists(ss, 'Leave_Ledger', [
    'TransactionID', 'EmployeeID', 'LeaveType', 'TransactionType', 'Days', 
    'EffectiveDate', 'ExpiryDate', 'RelatedApplicationID', 'AuthorizedBy', 
    'AuthorizedByName', 'ReferenceDoc', 'Reason', 'CreatedAt'
  ]);

  createSheetIfNotExists(ss, 'Public_Holiday_Calendar', [
    'HolidayID', 'Date', 'HolidayName', 'Type', 'IsOfficial', 'Notes'
  ]);

  createSheetIfNotExists(ss, 'Training_Plans', [
    'PlanID', 'Title', 'DepartmentID', 'Category', 'Priority', 'Objectives', 
    'TargetAudience', 'EstimatedParticipants', 'EstimatedCost', 'StartDate', 
    'EndDate', 'ProviderType', 'TrainerName', 'Status', 'SubmittedBy', 'SubmittedAt'
  ]);

  createSheetIfNotExists(ss, 'Audit_Log', [
    'LogID', 'Timestamp', 'ActorEmail', 'ActorRole', 'Module', 'Action', 'TargetID', 'Description'
  ]);

  Logger.log('Sheets initialized successfully.');

  // 2. Initialize Drive Folder Structure
  initDriveFolders();
}

function initDriveFolders() {
  let rootFolder;
  const existingRoots = DriveApp.getFoldersByName(CONFIG.ROOT_FOLDER_NAME);
  if (existingRoots.hasNext()) {
    rootFolder = existingRoots.next();
  } else {
    rootFolder = DriveApp.createFolder(CONFIG.ROOT_FOLDER_NAME);
  }

  CONFIG.SUB_FOLDERS.forEach(folderName => {
    const existing = rootFolder.getFoldersByName(folderName);
    if (!existing.hasNext()) {
      rootFolder.createFolder(folderName);
    }
  });

  Logger.log('Drive folder structure ready under ' + CONFIG.ROOT_FOLDER_NAME);
  return rootFolder.getId();
}

function createSheetIfNotExists(ss, sheetName, headers) {
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
    sheet.appendRow(headers);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#064e3b').setFontColor('#ffffff');
  }
  return sheet;
}`
  },
  {
    name: 'Code.gs',
    description: 'Application entry point for Google Apps Script Web App, routing, and HTML service serving.',
    category: 'CORE',
    code: `/**
 * Code.gs - Entry point for Google Apps Script Web App & REST API Sync
 */

function doGet(e) {
  // Check if API ping request
  if (e && e.parameter && e.parameter.action === 'PING') {
    return ContentService.createTextOutput(JSON.stringify({
      status: 'success',
      message: 'GMCC Google Apps Script API Active & Connected',
      timestamp: new Date().toISOString()
    })).setMimeType(ContentService.MimeType.JSON);
  }

  const user = AuthService.getCurrentUser();
  const template = HtmlService.createTemplateFromFile('Index');
  template.currentUser = user;
  
  return template.evaluate()
    .setTitle('GMCC Human Capital Management System')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1.0');
}

function doPost(e) {
  try {
    const postData = e.postData ? JSON.parse(e.postData.contents) : {};
    const action = postData.action || 'PING';

    if (action === 'PING') {
      return ContentService.createTextOutput(JSON.stringify({
        status: 'success',
        message: 'Koneksi GMCC Google Apps Script Berhasil!',
        timestamp: new Date().toISOString()
      })).setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'SYNC_ALL') {
      const summary = syncDatabaseAndFolders(postData.data);
      return ContentService.createTextOutput(JSON.stringify({
        status: 'success',
        message: 'Database Google Sheets & Folder Drive GMCC berhasil disinkronkan!',
        summary: summary,
        timestamp: new Date().toISOString()
      })).setMimeType(ContentService.MimeType.JSON);
    }

    return ContentService.createTextOutput(JSON.stringify({
      status: 'error',
      message: 'Unknown action: ' + action
    })).setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      status: 'error',
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Sinkronisasi Master Spreadsheet & Pembuatan Folder Google Drive
 */
function syncDatabaseAndFolders(data) {
  if (!data) return { synced: 0 };
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // 1. Sinkronkan Lembar Kerja Employees
  if (data.employees && data.employees.length > 0) {
    let empSheet = ss.getSheetByName('Employees');
    if (!empSheet) initGMCCSystem();
    empSheet = ss.getSheetByName('Employees');

    // Buat map ID yang sudah ada
    const values = empSheet.getDataRange().getValues();
    const existingIds = {};
    for (let i = 1; i < values.length; i++) {
      existingIds[values[i][0]] = i + 1; // row number
    }

    data.employees.forEach(emp => {
      const rowData = [
        emp.id,
        emp.employeeNumber || '',
        emp.fullName || '',
        emp.preferredName || '',
        emp.email || '',
        emp.companyEmail || '',
        emp.phone || '',
        emp.departmentId || '',
        emp.jobTitle || '',
        emp.employmentType || '',
        emp.employmentStatus || '',
        emp.joinDate || '',
        emp.probationEndDate || '',
        emp.directSupervisorId || '',
        emp.location || '',
        emp.workSchedule || '',
        emp.driveFolderId || '',
        emp.createdAt || new Date().toISOString(),
        new Date().toISOString()
      ];

      if (existingIds[emp.id]) {
        empSheet.getRange(existingIds[emp.id], 1, 1, rowData.length).setValues([rowData]);
      } else {
        empSheet.appendRow(rowData);
      }

      // Buat folder Google Drive jika status aktif
      if (emp.employmentStatus === 'ACTIVE') {
        try {
          PersonalFileService.createEmployeeFolders(emp.id, emp.fullName);
        } catch (e) {
          Logger.log('Folder creation notice: ' + e);
        }
      }
    });
  }

  // 2. Sinkronkan Lembar Kerja Contracts
  if (data.contracts && data.contracts.length > 0) {
    const ctrSheet = ss.getSheetByName('Employment_Contracts');
    if (ctrSheet) {
      const cVals = ctrSheet.getDataRange().getValues();
      const existingCIds = {};
      for (let i = 1; i < cVals.length; i++) {
        existingCIds[cVals[i][0]] = i + 1;
      }

      data.contracts.forEach(c => {
        const cRow = [
          c.id, c.contractNumber, c.employeeId, c.employeeName, c.departmentId,
          c.position, c.employmentType, c.startDate, c.endDate || '', c.status,
          c.version, c.driveFileId || '', c.responsibleHC || '', c.notes || '',
          c.createdAt, new Date().toISOString()
        ];
        if (existingCIds[c.id]) {
          ctrSheet.getRange(existingCIds[c.id], 1, 1, cRow.length).setValues([cRow]);
        } else {
          ctrSheet.appendRow(cRow);
        }
      });
    }
  }

  return {
    employeesSynced: data.employees ? data.employees.length : 0,
    contractsSynced: data.contracts ? data.contracts.length : 0
  };
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}`
  },
  {
    name: 'AuthService.gs',
    description: 'Identity verification via Session.getActiveUser() and role mapping from Users_Roles sheet.',
    category: 'SERVICES',
    code: `/**
 * AuthService.gs - Server-Side Identity Verification & Access Control
 */

const AuthService = {
  getCurrentUser: function() {
    const email = Session.getActiveUser().getEmail() || Session.getEffectiveUser().getEmail();
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName('Users_Roles');
    const data = sheet.getDataRange().getValues();

    for (let i = 1; i < data.length; i++) {
      if (data[i][0].toLowerCase() === email.toLowerCase() && data[i][5] === true) {
        return {
          email: data[i][0],
          fullName: data[i][1],
          role: data[i][2], // 'STAFF' | 'DEPT_HEAD' | 'HC' | 'GM' | 'ADMIN' | 'AUDITOR'
          employeeId: data[i][3],
          departmentId: data[i][4]
        };
      }
    }

    // Default fallback if unmapped
    return {
      email: email,
      fullName: 'GMCC Staff',
      role: 'STAFF',
      employeeId: '',
      departmentId: ''
    };
  },

  assertRole: function(allowedRoles) {
    const user = this.getCurrentUser();
    if (!allowedRoles.includes(user.role)) {
      throw new Error('Access Denied. Role ' + user.role + ' is unauthorized.');
    }
    return user;
  }
};`
  },
  {
    name: 'PersonalFileService.gs',
    description: 'Folder provisioning and document management for 10 subcategories per employee.',
    category: 'SERVICES',
    code: `/**
 * PersonalFileService.gs - Employee Personal File Subfolders in Google Drive
 */

const PersonalFileService = {
  createEmployeeFolders: function(employeeId, employeeName) {
    const rootName = 'GMCC HUMAN CAPITAL';
    const roots = DriveApp.getFoldersByName(rootName);
    if (!roots.hasNext()) throw new Error('Root folder not initialized.');
    const root = roots.next();

    const pfFolders = root.getFoldersByName('01 PERSONAL FILE');
    const pfFolder = pfFolders.hasNext() ? pfFolders.next() : root.createFolder('01 PERSONAL FILE');
    
    const activeFolders = pfFolder.getFoldersByName('ACTIVE EMPLOYEE');
    const activeFolder = activeFolders.hasNext() ? activeFolders.next() : pfFolder.createFolder('ACTIVE EMPLOYEE');

    const empFolderName = employeeId + ' - ' + employeeName;
    const empFolder = activeFolder.createFolder(empFolderName);

    // Create 10 standardized subfolders
    const categories = [
      '01 Identity',
      '02 Recruitment',
      '03 Employment',
      '04 Training',
      '05 Performance',
      '06 Attendance & Leave',
      '07 Discipline',
      '08 Compensation & Benefits',
      '09 Health & Work Requirements',
      '10 Exit'
    ];

    const categoryMap = {};
    categories.forEach(cat => {
      const sub = empFolder.createFolder(cat);
      categoryMap[cat] = sub.getId();
    });

    return {
      employeeFolderId: empFolder.getId(),
      subfolders: categoryMap
    };
  }
};`
  },
  {
    name: 'LeaveApprovalService.gs',
    description: 'Sequential 4-stage leave workflow with atomic ledger deduction strictly upon GM approval.',
    category: 'SERVICES',
    code: `/**
 * LeaveApprovalService.gs
 * Sequential Leave Workflow: Staff -> Dept Head -> HC -> General Manager -> Final Deduction
 */

const LeaveApprovalService = {
  processApproval: function(applicationId, action, comment) {
    const user = AuthService.getCurrentUser();
    const lock = LockService.getScriptLock();
    lock.waitLock(15000); // Prevent concurrent duplicate deductions

    try {
      const ss = SpreadsheetApp.getActiveSpreadsheet();
      const appSheet = ss.getSheetByName('Leave_Applications');
      const data = appSheet.getDataRange().getValues();

      let targetRow = -1;
      let app = null;

      for (let i = 1; i < data.length; i++) {
        if (data[i][0] === applicationId) {
          targetRow = i + 1;
          app = {
            id: data[i][0],
            employeeId: data[i][1],
            leaveType: data[i][4],
            startDate: data[i][5],
            endDate: data[i][6],
            totalDays: Number(data[i][7]),
            status: data[i][9]
          };
          break;
        }
      }

      if (!app) throw new Error('Application ' + applicationId + ' not found.');

      // Check stage permissions
      if (app.status === 'PENDING_DEPT_HEAD') {
        if (user.role !== 'DEPT_HEAD' && user.role !== 'ADMIN') {
          throw new Error('Only Department Head can approve at Stage 1.');
        }
        const nextStatus = (action === 'APPROVE') ? 'PENDING_HC' : (action === 'REJECT' ? 'REJECTED_BY_DEPT_HEAD' : 'RETURNED_TO_EMPLOYEE');
        appSheet.getRange(targetRow, 10).setValue(nextStatus);
        appSheet.getRange(targetRow, 11).setValue(action);
        appSheet.getRange(targetRow, 12).setValue(new Date());
        appSheet.getRange(targetRow, 13).setValue(comment);
      }
      else if (app.status === 'PENDING_HC') {
        if (user.role !== 'HC' && user.role !== 'ADMIN') {
          throw new Error('Only Human Capital can verify at Stage 2.');
        }
        const nextStatus = (action === 'APPROVE') ? 'PENDING_GM' : (action === 'REJECT' ? 'REJECTED_BY_HC' : 'RETURNED_TO_EMPLOYEE');
        appSheet.getRange(targetRow, 10).setValue(nextStatus);
        appSheet.getRange(targetRow, 14).setValue(action);
        appSheet.getRange(targetRow, 15).setValue(new Date());
        appSheet.getRange(targetRow, 16).setValue(comment);
      }
      else if (app.status === 'PENDING_GM') {
        if (user.role !== 'GM' && user.role !== 'ADMIN') {
          throw new Error('Only General Manager can grant final sanction.');
        }

        if (action === 'APPROVE') {
          // CRITICAL: Execute official ledger deduction ONLY now!
          const txnId = 'TXN-' + new Date().getTime();
          const ledgerSheet = ss.getSheetByName('Leave_Ledger');
          ledgerSheet.appendRow([
            txnId,
            app.employeeId,
            app.leaveType,
            'APPROVED_LEAVE_DEDUCTION',
            -app.totalDays, // Negative debit
            app.startDate,
            '',
            app.id,
            user.employeeId || user.email,
            user.fullName,
            app.id,
            'Approved by General Manager: ' + comment,
            new Date()
          ]);

          appSheet.getRange(targetRow, 10).setValue('APPROVED');
          appSheet.getRange(targetRow, 17).setValue('APPROVE');
          appSheet.getRange(targetRow, 18).setValue(new Date());
          appSheet.getRange(targetRow, 19).setValue(comment);
          appSheet.getRange(targetRow, 20).setValue(txnId); // Link deduction
        } else {
          const nextStatus = (action === 'REJECT') ? 'REJECTED_BY_GM' : 'RETURNED_TO_EMPLOYEE';
          appSheet.getRange(targetRow, 10).setValue(nextStatus);
          appSheet.getRange(targetRow, 17).setValue(action);
          appSheet.getRange(targetRow, 18).setValue(new Date());
          appSheet.getRange(targetRow, 19).setValue(comment);
        }
      }

      AuditService.log('LEAVE', 'LEAVE_' + action, 'Leave ' + applicationId + ' processed by ' + user.fullName);
      return { success: true };
    } finally {
      lock.releaseLock();
    }
  }
};`
  },
  {
    name: 'Triggers.gs',
    description: 'Scheduled time-driven automation for Contract Expiry (90, 60, 30, 14, 7 days) and notifications.',
    category: 'CORE',
    code: `/**
 * Triggers.gs - Scheduled Daily Automation
 */

function installDailyTriggers() {
  ScriptApp.newTrigger('checkContractExpiriesDaily')
    .timeBased()
    .everyDays(1)
    .atHour(8)
    .inTimezone('Asia/Makassar')
    .create();
}

function checkContractExpiriesDaily() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Employment_Contracts');
  const data = sheet.getDataRange().getValues();
  const today = new Date();
  
  const thresholds = [90, 60, 30, 14, 7, 0];

  for (let i = 1; i < data.length; i++) {
    const contract = data[i];
    const endDateStr = contract[8];
    const status = contract[9];

    if (endDateStr && status === 'ACTIVE') {
      const endDate = new Date(endDateStr);
      const diffTime = endDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (thresholds.includes(diffDays)) {
        NotificationService.sendContractExpiryAlert(contract[1], contract[3], diffDays);
        if (diffDays <= 30) {
          sheet.getRange(i + 1, 10).setValue('EXPIRING_SOON');
        }
      }
    }
  }
}`
  }
];
