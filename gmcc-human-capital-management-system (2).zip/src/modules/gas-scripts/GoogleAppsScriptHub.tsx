import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { GAS_FILES, GasFile } from './gasCodeTemplates';
import { 
  FileCode, 
  Copy, 
  Check, 
  Download, 
  ExternalLink, 
  ChevronRight, 
  FileSpreadsheet, 
  HardDrive, 
  Server,
  Layers,
  Terminal,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Cloud,
  Link,
  Save
} from 'lucide-react';

export const GoogleAppsScriptHub: React.FC = () => {
  const { 
    gasWebAppUrl, 
    setGasWebAppUrl, 
    syncToGoogleAppsScript, 
    isSyncing, 
    lastSyncTime, 
    syncStatus, 
    employees, 
    contracts 
  } = useApp();

  const [selectedFile, setSelectedFile] = useState<GasFile>(GAS_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [inputUrl, setInputUrl] = useState(gasWebAppUrl);
  const [isUrlSaved, setIsUrlSaved] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveUrl = (e: React.FormEvent) => {
    e.preventDefault();
    setGasWebAppUrl(inputUrl.trim());
    setIsUrlSaved(true);
    setTimeout(() => setIsUrlSaved(false), 2500);
  };

  const handleTriggerSync = async () => {
    if (!inputUrl.trim()) {
      alert('Silakan masukkan Web App URL Google Apps Script Anda terlebih dahulu.');
      return;
    }
    setGasWebAppUrl(inputUrl.trim());
    await syncToGoogleAppsScript(inputUrl.trim());
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Architecture & Deployment</span>
            <ChevronRight className="w-3 h-3" />
            <span>Google Apps Script Backend Suite</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Google Apps Script & Database Sync</h1>
          <p className="text-xs text-slate-500 mt-1">
            Pusat sinkronisasi cloud real-time ke Google Sheets Master Database dan otomatisasi 10 Subfolder Google Drive GMCC.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <a
            href="/full-app-index.html"
            download="Index.html"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors"
            title="Unduh seluruh aplikasi React persis seperti di preview dalam 1 file Index.html"
          >
            <Download className="w-4 h-4" />
            Unduh Index.html (Full App)
          </a>
          <button
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition-colors"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied to Clipboard!' : `Copy ${selectedFile.name}`}
          </button>
        </div>
      </div>

      {/* Live Google Sheets & Drive Sync Manager Card */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 text-white rounded-2xl p-5 sm:p-6 border border-emerald-800/50 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                Sinkronisasi Master Google Sheets & Google Drive
              </h2>
              <p className="text-xs text-slate-300">
                Hubungkan aplikasi dengan Web App URL Google Apps Script Anda untuk menyimpan data & membuat folder otomatis.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className={`text-[11px] font-mono px-2.5 py-1 rounded-full border flex items-center gap-1.5 ${
              gasWebAppUrl 
                ? 'bg-emerald-950/80 text-emerald-400 border-emerald-700' 
                : 'bg-amber-950/80 text-amber-300 border-amber-800'
            }`}>
              <span className={`w-2 h-2 rounded-full ${gasWebAppUrl ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}></span>
              {gasWebAppUrl ? 'Cloud URL Terpasang' : 'Belum Terhubung'}
            </span>
          </div>
        </div>

        {/* Sync Form */}
        <form onSubmit={handleSaveUrl} className="space-y-3">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Link className="w-3.5 h-3.5 text-emerald-400" />
                Google Apps Script Web App URL (Hasil Deploy)
              </span>
              <span className="text-[11px] text-slate-400">
                Deploy → New deployment → Web app (Who has access: Anyone)
              </span>
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="url"
                required
                value={inputUrl}
                onChange={e => setInputUrl(e.target.value)}
                placeholder="https://script.google.com/macros/s/.../exec"
                className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 placeholder:text-slate-600 font-mono text-xs focus:outline-hidden focus:border-emerald-500"
              />
              <button
                type="submit"
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 shrink-0"
              >
                <Save className="w-3.5 h-3.5 text-emerald-400" />
                {isUrlSaved ? 'Tersimpan!' : 'Simpan URL'}
              </button>
              <button
                type="button"
                onClick={handleTriggerSync}
                disabled={isSyncing}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 transition-all flex items-center justify-center gap-2 active:scale-98 disabled:opacity-60 shrink-0 cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                {isSyncing ? 'Menyinkronkan...' : 'Sinkronkan Sekarang'}
              </button>
            </div>
          </div>
        </form>

        {/* Status Feedback Notice */}
        {syncStatus && (
          <div className={`p-3.5 rounded-xl border flex items-start gap-2.5 text-xs ${
            syncStatus.success 
              ? 'bg-emerald-950/80 border-emerald-700 text-emerald-200' 
              : 'bg-rose-950/80 border-rose-800 text-rose-200'
          }`}>
            {syncStatus.success ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            )}
            <div className="space-y-0.5">
              <span className="font-bold block">{syncStatus.message}</span>
              {syncStatus.details && <p className="text-[11px] opacity-90">{syncStatus.details}</p>}
            </div>
          </div>
        )}

        {/* Sync Summary Meta */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-[11px] text-slate-400 border-t border-slate-800/80">
          <div className="flex items-center gap-4">
            <span>Karyawan siap kirim: <strong className="text-white">{employees.length}</strong></span>
            <span>Kontrak kerja: <strong className="text-white">{contracts.length}</strong></span>
            <span>10 Subfolder Drive: <strong className="text-emerald-400">Aktif</strong></span>
          </div>
          {lastSyncTime && (
            <div className="text-slate-400 font-mono">
              Terakhir sinkron: {new Date(lastSyncTime).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' })} WITA
            </div>
          )}
        </div>
      </div>

      {/* Deployment & Setup Checklist Guide */}
      <div className="bg-slate-900 text-slate-100 rounded-xl p-5 shadow-xs">
        <h3 className="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Terminal className="w-4 h-4" />
          Google Apps Script Web App Deployment Steps
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs mt-3">
          <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700/60">
            <span className="font-bold text-emerald-400 block mb-1">1. Create Spreadsheet</span>
            <p className="text-slate-300 text-[11px]">
              Create a new Google Sheet named <code className="text-emerald-300">GMCC Human Capital Master Database</code>. Open Extensions → Apps Script.
            </p>
          </div>
          <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700/60">
            <span className="font-bold text-emerald-400 block mb-1">2. Paste Service Files</span>
            <p className="text-slate-300 text-[11px]">
              Copy and create each <code className="text-emerald-300">.gs</code> file below into your Apps Script editor. Timezone: <code className="text-emerald-300">Asia/Makassar</code>.
            </p>
          </div>
          <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700/60">
            <span className="font-bold text-emerald-400 block mb-1">3. Run Setup Function</span>
            <p className="text-slate-300 text-[11px]">
              Select <code className="text-emerald-300">initGMCCSystem()</code> in <code className="text-slate-300">Setup.gs</code> and click Run. Authorize Drive & Sheets permissions.
            </p>
          </div>
          <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700/60">
            <span className="font-bold text-emerald-400 block mb-1">4. Deploy as Web App</span>
            <p className="text-slate-300 text-[11px]">
              Click Deploy → New Deployment → Web App. Execute as: <code className="text-emerald-300">User accessing the web app</code> (for authenticated audit).
            </p>
          </div>
        </div>
      </div>

      {/* Code Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: File List */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-100 bg-slate-50/70">
            <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-emerald-700" />
              Apps Script Files ({GAS_FILES.length})
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {GAS_FILES.map(file => {
              const isSelected = file.name === selectedFile.name;

              return (
                <button
                  key={file.name}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-3.5 transition-colors ${
                    isSelected ? 'bg-emerald-50/70 border-l-4 border-emerald-700' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-slate-900 flex items-center gap-1.5">
                      <FileCode className="w-3.5 h-3.5 text-emerald-700" />
                      {file.name}
                    </span>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold">{file.category}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">
                    {file.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Code Viewer */}
        <div className="lg:col-span-8 bg-slate-950 rounded-xl border border-slate-800 shadow-xs overflow-hidden flex flex-col">
          <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-rose-500/80"></span>
              <span className="w-3 h-3 rounded-full bg-amber-500/80"></span>
              <span className="w-3 h-3 rounded-full bg-emerald-500/80"></span>
              <span className="text-xs font-mono text-slate-300 ml-2">{selectedFile.name}</span>
            </div>

            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-300 hover:text-white px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>

          <div className="p-4 overflow-x-auto max-h-[560px] font-mono text-xs text-emerald-300/90 leading-relaxed">
            <pre>{selectedFile.code}</pre>
          </div>
        </div>
      </div>
    </div>
  );
};
