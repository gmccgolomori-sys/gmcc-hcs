import { 
  db, 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  getDocs, 
  onSnapshot,
  handleFirestoreError,
  OperationType 
} from './firebase';

export interface FirebaseSyncStatus {
  connected: boolean;
  isSyncing: boolean;
  lastSyncedAt: string | null;
  mode: 'CLOUD_FIRESTORE' | 'LOCAL_OFFLINE';
  error: string | null;
}

/**
 * Deep sanitization function that removes `undefined` properties and replaces NaN,
 * which Firestore strictly rejects with an 'Unsupported field value: undefined' exception.
 */
export function sanitizeForFirestore<T>(data: T): any {
  if (data === undefined) {
    return null;
  }
  if (data === null) {
    return null;
  }
  if (typeof data === 'number') {
    return isNaN(data) ? 0 : data;
  }
  if (Array.isArray(data)) {
    return data
      .filter(item => item !== undefined)
      .map(item => sanitizeForFirestore(item));
  }
  if (typeof data === 'object') {
    if (data instanceof Date) {
      return data.toISOString();
    }
    const clean: Record<string, any> = {};
    for (const [key, value] of Object.entries(data as Record<string, any>)) {
      if (value !== undefined) {
        clean[key] = sanitizeForFirestore(value);
      }
    }
    return clean;
  }
  return data;
}

/**
 * Save / Update a single document to Firestore with auto-sanitization
 */
export async function saveToFirestore<T extends { id: string }>(
  collectionName: string, 
  item: T
): Promise<boolean> {
  if (!db || !item || !item.id) return false;
  try {
    const docRef = doc(db, collectionName, String(item.id));
    const sanitized = sanitizeForFirestore(item);
    await setDoc(docRef, sanitized, { merge: true });
    return true;
  } catch (err) {
    console.error(`[Firestore Write Error] Failed on ${collectionName}/${item.id}:`, err);
    handleFirestoreError(err, OperationType.WRITE, `${collectionName}/${item.id}`);
    return false;
  }
}

/**
 * Delete a single document from Firestore
 */
export async function deleteFromFirestore(
  collectionName: string, 
  id: string
): Promise<void> {
  if (!db) return;
  try {
    const docRef = doc(db, collectionName, id);
    await deleteDoc(docRef);
  } catch (err) {
    console.error(`[Firestore Delete Error] Failed on ${collectionName}/${id}:`, err);
    handleFirestoreError(err, OperationType.DELETE, `${collectionName}/${id}`);
  }
}

/**
 * Initial bulk seed to Firestore if collection is empty
 */
export async function seedCollectionIfEmpty<T extends { id: string }>(
  collectionName: string,
  initialItems: T[]
): Promise<boolean> {
  if (!db) return false;
  try {
    const colRef = collection(db, collectionName);
    const snap = await getDocs(colRef);
    if (snap.empty && initialItems.length > 0) {
      for (const item of initialItems) {
        const sanitized = sanitizeForFirestore(item);
        await setDoc(doc(db, collectionName, item.id), sanitized, { merge: true });
      }
      return true;
    }
  } catch (err) {
    console.warn(`Could not check/seed collection ${collectionName}:`, err);
  }
  return false;
}
