import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Lock, 
  ShieldCheck, 
  User, 
  KeyRound, 
  Eye, 
  EyeOff, 
  AlertCircle, 
  ArrowRight
} from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { loginWithCredentials, logoutReason, clearLogoutReason } = useApp();
  const [userIdInput, setUserIdInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    clearLogoutReason();

    if (!userIdInput.trim()) {
      setErrorMessage('Silakan masukkan User ID atau Email Anda.');
      return;
    }
    if (!passwordInput.trim()) {
      setErrorMessage('Silakan masukkan kata sandi (password).');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const result = loginWithCredentials(userIdInput.trim(), passwordInput.trim());
      setIsLoading(false);
      if (!result.success) {
        setErrorMessage(result.message || 'Kredensial tidak valid.');
      }
    }, 300);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-slate-100 flex flex-col justify-center items-center p-4 sm:p-6 relative overflow-hidden font-sans">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-emerald-700/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-teal-600/15 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md space-y-6 relative z-10 animate-in fade-in zoom-in-95 duration-300">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 text-white font-extrabold text-2xl shadow-xl shadow-emerald-900/40 border border-emerald-500/30 mb-1">
            G
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center justify-center gap-2">
            GMCC Human Capital
          </h1>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            Golo Mori Convention Center · Sistem Manajemen SDM, Kontrak PKWT/DW & Personal Files
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-slate-900/80 backdrop-blur-md rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-2xl space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-300 uppercase tracking-wider">
              <Lock className="w-4 h-4 text-emerald-400" />
              <span>Portal Masuk Resmi</span>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60">
              WITA (UTC+8)
            </span>
          </div>

          {/* Inactivity Logout Notice */}
          {logoutReason === 'INACTIVITY_30MIN' && !errorMessage && (
            <div className="p-3 bg-amber-950/80 border border-amber-700/80 rounded-xl flex items-start gap-2.5 text-amber-200 text-xs animate-in fade-in duration-200">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">
                Sesi Anda telah berakhir secara otomatis karena tidak ada aktivitas selama 30 menit demi keamanan sistem. Silakan login kembali.
              </div>
            </div>
          )}

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3 bg-rose-950/80 border border-rose-800/80 rounded-xl flex items-start gap-2.5 text-rose-200 text-xs animate-in fade-in duration-200">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{errorMessage}</div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {/* User ID Field */}
            <div className="space-y-1.5">
              <label className="block text-slate-300 font-medium">
                User ID atau Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  autoFocus
                  required
                  placeholder="Masukkan User ID atau Email"
                  value={userIdInput}
                  onChange={e => setUserIdInput(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-800/90 border border-slate-700 text-slate-100 placeholder:text-slate-500 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono text-xs"
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="space-y-1.5">
              <label className="block text-slate-300 font-medium">
                Kata Sandi (Password)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <KeyRound className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Masukkan kata sandi akun Anda"
                  value={passwordInput}
                  onChange={e => setPasswordInput(e.target.value)}
                  className="w-full pl-9 pr-10 py-2.5 rounded-xl bg-slate-800/90 border border-slate-700 text-slate-100 placeholder:text-slate-500 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all text-xs"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-200"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold shadow-lg shadow-emerald-950 transition-all flex items-center justify-center gap-2 active:scale-98 disabled:opacity-70 disabled:cursor-not-allowed text-xs cursor-pointer"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Memverifikasi Kredensial...</span>
                </>
              ) : (
                <>
                  <span>Masuk ke Sistem HRIS</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Realtime Database Connection Badge */}
          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Database Cloud: <strong className="text-emerald-400 font-medium">Online Realtime</strong></span>
            </span>
            <span className="text-slate-500 text-[10px]">Firestore Cloud</span>
          </div>
        </div>

        {/* Security & Compliance Footer + Refresh Cache button */}
        <div className="space-y-3 text-center">
          <div className="text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Sistem Resmi GMCC Labuan Bajo · Sesi terenkripsi & tercatat dalam Audit Trail</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1.5">
            <button
              type="button"
              onClick={() => {
                if (typeof (window as any).forceClearCacheAndReload === 'function') {
                  (window as any).forceClearCacheAndReload();
                } else {
                  window.location.reload();
                }
              }}
              className="text-[11px] text-slate-400 hover:text-emerald-400 underline decoration-slate-600 hover:decoration-emerald-400 transition-colors cursor-pointer"
            >
              ↻ Perbarui Tampilan / Bersihkan Cache HP
            </button>
            <span className="text-slate-600 hidden sm:inline">·</span>
            <a
              href="/gmcc-hcms-deploy.zip"
              download="gmcc-hcms-deploy.zip"
              className="text-[11px] text-emerald-400 hover:text-emerald-300 font-medium underline decoration-emerald-700 hover:decoration-emerald-400 transition-colors cursor-pointer flex items-center gap-1"
            >
              <span>⬇</span>
              <span>Unduh Paket Deploy (ZIP)</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
