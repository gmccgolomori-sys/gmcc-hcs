import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  LayoutDashboard, 
  Users, 
  HardDrive, 
  FileCheck2, 
  CalendarDays,
  FileSpreadsheet,
  GraduationCap,
  Settings,
  Grid,
  FileCode,
  X,
  ChevronRight,
  ShieldCheck,
  UserCheck
} from 'lucide-react';

interface Props {
  activeModule: string;
  onSelectModule: (module: string) => void;
}

export const MobileBottomNav: React.FC<Props> = ({ activeModule, onSelectModule }) => {
  const { contracts, leaveApplications, currentUser, getDaysUntilExpiry } = useApp();
  const [isAppsDrawerOpen, setIsAppsDrawerOpen] = useState(false);

  // Urgent contracts count
  const urgentContracts = contracts.filter(c => {
    if (c.status !== 'ACTIVE' && c.status !== 'EXPIRING_SOON') return false;
    const days = getDaysUntilExpiry(c.endDate);
    return days !== null && days >= 0 && days <= 30;
  });

  // Pending leaves count
  const pendingLeaves = leaveApplications.filter(a => {
    if (currentUser.employeeId === a.employeeId) return false;
    if (currentUser.role === 'DEPT_HEAD') return a.status === 'PENDING_DEPT_HEAD' && a.departmentId === currentUser.departmentId;
    if (currentUser.role === 'HC') return a.status === 'PENDING_HC';
    if (currentUser.role === 'GM') return a.status === 'PENDING_GM';
    return false;
  });

  const isReviewer = currentUser.role === 'DEPT_HEAD' || currentUser.role === 'HC' || currentUser.role === 'GM';
  const isAdminOrGM = currentUser.role === 'ADMIN' || currentUser.role === 'GM';

  const bottomItems = [
    { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
    { id: 'employees', label: 'Staff', icon: Users },
    { id: 'personal-files', label: 'Drive', icon: HardDrive },
    { 
      id: isReviewer ? 'leave-review' : 'leave', 
      label: isReviewer ? 'Cuti Review' : 'Cuti', 
      icon: isReviewer ? FileSpreadsheet : CalendarDays, 
      badge: pendingLeaves.length > 0 ? pendingLeaves.length : undefined 
    },
    { id: 'more', label: 'Menu', icon: Grid, isAction: true }
  ];

  const allModules = [
    {
      id: 'dashboard',
      title: 'Executive Dashboard',
      description: 'Ringkasan operasional SDM & analitik',
      icon: LayoutDashboard,
      color: 'bg-emerald-600 text-white'
    },
    {
      id: 'employees',
      title: 'Employee Directory',
      description: 'Direktori staf, kontrak PKWT & edit profil',
      icon: Users,
      color: 'bg-blue-600 text-white'
    },
    {
      id: 'personal-files',
      title: 'Personal Files (10 Folder Drive)',
      description: 'Berkas digital Google Drive terstruktur',
      icon: HardDrive,
      color: 'bg-teal-600 text-white'
    },
    {
      id: 'contracts',
      title: 'PKWT & SPK Contracts',
      description: 'Masa berlaku kontrak, alert jatuh tempo & perpanjangan',
      icon: FileCheck2,
      color: 'bg-amber-600 text-white',
      badge: urgentContracts.length > 0 ? `${urgentContracts.length} Urgent` : undefined
    },
    {
      id: 'leave',
      title: 'Approval & Pengajuan Cuti',
      description: 'Pengajuan cuti, ledger cuti & approval berjenjang',
      icon: CalendarDays,
      color: 'bg-indigo-600 text-white',
      badge: pendingLeaves.length > 0 ? `${pendingLeaves.length} Pending` : undefined
    },
    ...(isReviewer ? [{
      id: 'leave-review',
      title: 'Review Laporan Cuti (Prorate)',
      description: 'Audit saldo cuti prorate, carry-forward & cetak resmi',
      icon: FileSpreadsheet,
      color: 'bg-emerald-700 text-white'
    }] : []),
    {
      id: 'training',
      title: 'Pelatihan & Target KPI GM',
      description: 'Monitoring 20 jam pelatihan & validasi kehadiran',
      icon: GraduationCap,
      color: 'bg-purple-600 text-white'
    },
    ...(isAdminOrGM ? [
      {
        id: 'gas-scripts',
        title: 'Google Apps Script (GAS)',
        description: 'Kode server-side Google Drive 10 Folder & Sheets',
        icon: FileCode,
        color: 'bg-emerald-800 text-white'
      },
      {
        id: 'admin',
        title: 'System & Admin Console',
        description: 'Manajemen akun, departemen, hari libur & audit trail',
        icon: Settings,
        color: 'bg-slate-700 text-white'
      }
    ] : [])
  ];

  return (
    <>
      {/* Interactive Mobile Apps Bottom Drawer / Sheet */}
      {isAppsDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={() => setIsAppsDrawerOpen(false)}
          />

          {/* Drawer Sheet */}
          <div className="fixed inset-x-0 bottom-0 bg-slate-900 border-t border-slate-800 rounded-t-3xl max-h-[85vh] flex flex-col shadow-2xl z-10 animate-in slide-in-from-bottom duration-200">
            {/* Sheet Handle & Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-700/80 text-white flex items-center justify-center">
                  <Grid className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">GMCC HRIS Mobile Apps</h3>
                  <p className="text-[10px] text-slate-400">Pilih modul aplikasi untuk navigasi cepat</p>
                </div>
              </div>

              <button
                onClick={() => setIsAppsDrawerOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* User Session Quick Info */}
            <div className="px-4 py-2.5 bg-slate-950/70 border-b border-slate-800/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-slate-300 font-medium">{currentUser.name}</span>
              </div>
              <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                {currentUser.role}
              </span>
            </div>

            {/* Modules List */}
            <div className="overflow-y-auto p-4 space-y-2.5 flex-1">
              {allModules.map(m => {
                const Icon = m.icon;
                const isCurrent = activeModule === m.id;

                return (
                  <button
                    key={m.id}
                    onClick={() => {
                      onSelectModule(m.id);
                      setIsAppsDrawerOpen(false);
                    }}
                    className={`w-full text-left p-3 rounded-2xl flex items-center justify-between transition-all ${
                      isCurrent
                        ? 'bg-emerald-950/70 border border-emerald-600/60 shadow-xs'
                        : 'bg-slate-800/60 border border-slate-750 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${m.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-bold truncate ${isCurrent ? 'text-emerald-300' : 'text-white'}`}>
                            {m.title}
                          </span>
                          {m.badge && (
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-rose-600 text-white">
                              {m.badge}
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 truncate mt-0.5">{m.description}</p>
                      </div>
                    </div>

                    <ChevronRight className={`w-4 h-4 shrink-0 ${isCurrent ? 'text-emerald-400' : 'text-slate-500'}`} />
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Modern Interactive Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800 text-slate-400 flex items-center justify-around px-2 py-1.5 lg:hidden shadow-xl pb-safe">
        {bottomItems.map(item => {
          const Icon = item.icon;
          const isActive = !item.isAction && activeModule === item.id;

          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.isAction) {
                  setIsAppsDrawerOpen(true);
                } else {
                  onSelectModule(item.id);
                }
              }}
              className={`flex flex-col items-center justify-center flex-1 py-1 px-1 rounded-xl transition-all active:scale-90 ${
                isActive 
                  ? 'text-emerald-400 font-bold scale-105' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 min-w-[16px] h-4 rounded-full bg-rose-600 text-white text-[9px] font-bold flex items-center justify-center px-1 animate-pulse">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
};
