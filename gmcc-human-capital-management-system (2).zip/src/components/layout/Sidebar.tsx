import React from 'react';
import { useApp } from '../../context/AppContext';
import { 
  LayoutDashboard, 
  Users, 
  HardDrive, 
  FileCheck2, 
  CalendarDays, 
  GraduationCap, 
  ShieldCheck, 
  FileCode,
  Building2,
  Lock,
  FileSpreadsheet,
  LogOut
} from 'lucide-react';

interface Props {
  activeModule: string;
  onSelectModule: (module: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<Props> = ({
  activeModule,
  onSelectModule,
  isOpenMobile,
  onCloseMobile
}) => {
  const { currentUser, logout } = useApp();

  const navItems = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard },
    { id: 'employees', label: 'Employee Directory', icon: Users },
    { id: 'personal-files', label: 'Personal Files (Drive)', icon: HardDrive },
    { id: 'contracts', label: 'Contract Management', icon: FileCheck2 },
    { id: 'leave', label: 'Leave & Workflow', icon: CalendarDays },
    { 
      id: 'leave-review', 
      label: 'Review & Laporan Cuti', 
      icon: FileSpreadsheet, 
      reviewRolesOnly: true 
    },
    { id: 'training', label: 'Training Management', icon: GraduationCap },
    { id: 'gas-scripts', label: 'Google Apps Script (GAS)', icon: FileCode, adminOnly: true },
    { id: 'admin', label: 'System Admin & Master', icon: ShieldCheck, adminOnly: true }
  ];


  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div 
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
        />
      )}

      <aside className={`fixed lg:static top-0 bottom-0 left-0 z-50 w-64 bg-slate-950 text-slate-300 flex flex-col justify-between border-r border-slate-800 transition-transform duration-200 ease-in-out print:hidden ${
        isOpenMobile ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      }`}>
        <div>
          {/* GMCC Brand Header */}
          <div className="p-5 border-b border-slate-800 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-700 to-teal-500 text-white flex items-center justify-center font-bold text-lg shadow-md shrink-0">
              G
            </div>
            <div>
              <div className="font-bold text-white tracking-tight text-sm leading-tight">
                GMCC HCMS
              </div>
              <div className="text-[11px] text-slate-400">
                Golo Mori Convention Center
              </div>
            </div>
          </div>

          {/* Navigation Menu */}
          <nav className="p-3 space-y-1">
            <div className="px-3 py-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500">
              Core Modules
            </div>

            {navItems.map(item => {
              const Icon = item.icon;
              const isSelected = activeModule === item.id;
              
              if (item.adminOnly && currentUser.role !== 'ADMIN' && currentUser.role !== 'GM') {
                return null;
              }
              if (item.reviewRolesOnly && currentUser.role !== 'DEPT_HEAD' && currentUser.role !== 'HC' && currentUser.role !== 'GM' && currentUser.role !== 'ADMIN' && currentUser.role !== 'AUDITOR') {
                return null;
              }


              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onSelectModule(item.id);
                    onCloseMobile();
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors ${
                    isSelected
                      ? 'bg-emerald-800 text-white font-semibold shadow-xs'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-white' : 'text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Current Profile Badge */}
        <div className="p-3.5 border-t border-slate-800/80 bg-slate-900/60 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center justify-center text-xs font-bold uppercase shrink-0">
              {currentUser.role.slice(0, 2)}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-semibold text-white truncate">
                {currentUser.name}
              </div>
              <div className="text-[10px] text-emerald-400 font-mono truncate">
                {currentUser.role}
              </div>
            </div>
          </div>
          <button
            onClick={() => logout()}
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors shrink-0"
            title="Keluar / Logout dari Sistem"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>
    </>
  );
};
