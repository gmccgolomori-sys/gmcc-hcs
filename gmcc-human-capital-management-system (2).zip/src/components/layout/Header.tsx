import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Menu, 
  Bell, 
  Calendar, 
  LogOut,
  Cloud,
  RefreshCw,
  KeyRound
} from 'lucide-react';
import { PWAInstallButton } from '../pwa/PWAInstallButton';
import { ChangeAdminPasswordModal } from '../auth/ChangeAdminPasswordModal';

interface Props {
  onToggleMobile: () => void;
  onNavigate: (module: string) => void;
}

export const Header: React.FC<Props> = ({ onToggleMobile, onNavigate }) => {
  const { 
    currentUser, 
    systemDate, 
    notifications, 
    markNotificationAsRead,
    logout,
    firebaseSyncStatus,
    forceServerSync
  } = useApp();

  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [isManualSyncing, setIsManualSyncing] = useState(false);
  const [syncToast, setSyncToast] = useState<string | null>(null);

  const unreadNotifs = notifications.filter(n => !n.read);

  const handleForceServerSync = async () => {
    setIsManualSyncing(true);
    const res = await forceServerSync();
    setIsManualSyncing(false);
    setSyncToast(res.message);
    setTimeout(() => setSyncToast(null), 4000);
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30 print:hidden">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleMobile}
          className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 lg:hidden cursor-pointer"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Timezone & Operational badge */}
        <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
          <Calendar className="w-3.5 h-3.5 text-emerald-700" />
          <span className="font-semibold text-slate-800">
            {new Date(systemDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
          </span>
          <span className="text-slate-300">|</span>
          <span className="font-mono text-[11px] text-slate-600">Asia/Makassar (WITA)</span>
        </div>

        {/* Firebase Realtime Cloud Sync Badge with Cache Override */}
        <div className="relative">
          <button
            type="button"
            onClick={handleForceServerSync}
            disabled={isManualSyncing || firebaseSyncStatus.isSyncing}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-semibold hover:bg-emerald-100 transition-colors shadow-2xs cursor-pointer"
            title={`Database Online Aktif (${firebaseSyncStatus.projectId}). Klik untuk paksa refresh dari server Firestore (Menimpa/Override cache browser).`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <Cloud className="w-3.5 h-3.5 text-emerald-600" />
            <span className="hidden md:inline">Cloud DB: Online</span>
            <span className="md:hidden">Online</span>
            {(isManualSyncing || firebaseSyncStatus.isSyncing) ? (
              <RefreshCw className="w-3 h-3 text-emerald-700 animate-spin ml-0.5" />
            ) : (
              <RefreshCw className="w-3 h-3 text-emerald-600 ml-0.5 opacity-60 hover:opacity-100" />
            )}
          </button>

          {syncToast && (
            <div className="absolute top-10 left-0 bg-slate-900 text-white text-xs px-3 py-1.5 rounded-lg shadow-xl z-50 whitespace-nowrap border border-slate-700 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>{syncToast}</span>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2.5">
        {/* PWA Install Button */}
        <PWAInstallButton />

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setIsNotifOpen(!isNotifOpen)}
            className="p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors relative"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotifs.length > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-600 text-white text-[10px] font-bold flex items-center justify-center">
                {unreadNotifs.length}
              </span>
            )}
          </button>

          {isNotifOpen && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden z-50">
              <div className="p-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900">Notifications & Alerts</span>
                <span className="text-[10px] text-slate-500 font-mono">{unreadNotifs.length} unread</span>
              </div>
              <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
                {notifications.map(n => (
                  <div 
                    key={n.id} 
                    onClick={() => {
                      markNotificationAsRead(n.id);
                      if (n.linkModule) onNavigate(n.linkModule);
                      setIsNotifOpen(false);
                    }}
                    className={`p-3 text-xs hover:bg-slate-50 transition-colors cursor-pointer ${
                      !n.read ? 'bg-emerald-50/40' : ''
                    }`}
                  >
                    <div className="flex items-center justify-between font-semibold text-slate-900 mb-0.5">
                      <span>{n.title}</span>
                      <span className="text-[10px] text-slate-400 font-normal">
                        {new Date(n.createdAt).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-slate-600 text-[11px] leading-relaxed">{n.message}</p>
                  </div>
                ))}
                {notifications.length === 0 && (
                  <div className="p-6 text-center text-xs text-slate-400">
                    No new notifications.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Logged in User Profile & Logout */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2.5 pl-3 pr-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50 text-xs shadow-2xs">
            <div className="w-7 h-7 rounded-lg bg-emerald-800 text-white flex items-center justify-center font-bold text-xs uppercase shrink-0">
              {currentUser.name.slice(0, 1)}
            </div>
            <div className="text-left">
              <span className="font-semibold text-slate-900 leading-tight block truncate max-w-[140px]">
                {currentUser.name}
              </span>
              <span className="text-[10px] font-mono text-emerald-700 font-bold block">
                {currentUser.role}
              </span>
            </div>
          </div>

          {/* Ubah Password Admin Button */}
          {currentUser.role === 'ADMIN' && (
            <button
              onClick={() => setIsPasswordModalOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-slate-700 hover:text-emerald-700 bg-slate-50 hover:bg-emerald-50 border border-slate-200 transition-colors cursor-pointer text-xs font-medium"
              title="Ubah Password Akun Administrator"
            >
              <KeyRound className="w-3.5 h-3.5 text-emerald-700" />
              <span className="hidden sm:inline">Ubah Sandi</span>
            </button>
          )}

          <button
            onClick={() => logout()}
            className="p-2 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 transition-colors cursor-pointer"
            title="Keluar / Logout dari Sistem"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Admin Change Password Modal */}
      <ChangeAdminPasswordModal
        isOpen={isPasswordModalOpen}
        onClose={() => setIsPasswordModalOpen(false)}
      />
    </header>
  );
};

