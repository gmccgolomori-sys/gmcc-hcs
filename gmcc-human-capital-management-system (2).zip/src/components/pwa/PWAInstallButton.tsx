import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { 
  Download, 
  Smartphone, 
  X, 
  ExternalLink, 
  Share, 
  PlusSquare, 
  CheckCircle2,
  AlertCircle,
  Copy
} from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, isInIframe, install } = usePWAInstall();
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [copied, setCopied] = useState(false);

  // If already running standalone as an installed PWA, do not show install button
  if (isInstalled) {
    return null;
  }

  const directUrl = window.location.href;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(directUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleInstallClick = async () => {
    if (isInstallable) {
      const ok = await install();
      if (!ok) {
        setShowGuideModal(true);
      }
    } else {
      setShowGuideModal(true);
    }
  };

  return (
    <>
      <button
        onClick={handleInstallClick}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-all active:scale-95"
        title="Install GMCC HRIS ke HP atau Desktop"
      >
        <Download className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Install App</span>
        <span className="sm:hidden">Install</span>
      </button>

      {/* Comprehensive Install Guide Modal */}
      {showGuideModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="font-bold text-sm">Panduan Install GMCC HRIS</h3>
                  <p className="text-[11px] text-slate-400">Pemasangan ke Layar Utama HP / Komputer</p>
                </div>
              </div>
              <button
                onClick={() => setShowGuideModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs text-slate-700">
              {/* Notice why "This app cannot be installed" occurred */}
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-amber-900">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <span className="font-bold block">Penyebab Pesan "This app cannot be installed":</span>
                  <p className="text-[11px] leading-relaxed text-amber-800">
                    Browser memblokir instalasi jika link dibuka di dalam <em>jendela preview / iframe</em>, atau jika link belum dibuka langsung di tab utama browser.
                  </p>
                </div>
              </div>

              {/* Step 1: Open direct URL */}
              <div className="space-y-1.5">
                <span className="font-bold text-slate-900 block flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-[10px] font-bold">1</span>
                  Buka Link Langsung di Browser Utama
                </span>
                <p className="text-[11px] text-slate-500">
                  Pastikan Anda membuka URL aplikasi secara langsung (bukan di dalam preview tool):
                </p>
                <div className="flex items-center gap-1.5 p-2 bg-slate-50 rounded-lg border border-slate-200 font-mono text-[10px] text-slate-700 overflow-x-auto">
                  <span className="truncate flex-1">{directUrl}</span>
                  <button
                    onClick={handleCopyUrl}
                    className="p-1 text-slate-500 hover:text-emerald-700 shrink-0"
                    title="Salin Link"
                  >
                    {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Step 2: Instructions based on device */}
              <div className="space-y-2 border-t border-slate-100 pt-3">
                <span className="font-bold text-slate-900 block flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-[10px] font-bold">2</span>
                  Langkah di Browser Anda:
                </span>

                {isIOS ? (
                  /* iOS Safari */
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-[11px]">
                    <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                      <Share className="w-3.5 h-3.5 text-blue-600" />
                      Safari (iPhone / iPad):
                    </div>
                    <ol className="list-decimal list-inside space-y-1 text-slate-600 pl-1">
                      <li>Buka link di browser <strong>Safari</strong>.</li>
                      <li>Tekan tombol <strong>Share / Bagikan</strong> (ikon kotak panah atas).</li>
                      <li>Gulir ke bawah, pilih <strong>Tambahkan ke Layar Utama</strong> (*Add to Home Screen*).</li>
                      <li>Klik <strong>Tambah</strong> (*Add*).</li>
                    </ol>
                  </div>
                ) : (
                  /* Android Chrome / Desktop Chrome */
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-[11px]">
                    <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                      <Smartphone className="w-3.5 h-3.5 text-emerald-700" />
                      Google Chrome (Android / Desktop):
                    </div>
                    <ol className="list-decimal list-inside space-y-1 text-slate-600 pl-1">
                      <li>Buka link di browser <strong>Google Chrome</strong>.</li>
                      <li>Tekan ikon <strong>titik tiga (⋮)</strong> di pojok kanan atas browser.</li>
                      <li>Pilih menu <strong>"Tambahkan ke Layar Utama"</strong> atau <strong>"Instal Aplikasi"</strong>.</li>
                      <li>Tekan <strong>Instal</strong>.</li>
                    </ol>
                  </div>
                )}
              </div>

              <div className="pt-2">
                <button
                  onClick={() => setShowGuideModal(false)}
                  className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-semibold text-xs transition-colors"
                >
                  Saya Mengerti
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
